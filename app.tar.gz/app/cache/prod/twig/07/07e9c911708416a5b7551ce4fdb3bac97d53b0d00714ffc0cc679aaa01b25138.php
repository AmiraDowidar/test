<?php

/* eZPlatformUIBundle:Exception:error403.html.twig */
class __TwigTemplate_10320f4cf2618753ae18e3b0c71a8711a6dd4b7c4323c09b36327976850fc6b3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle:Exception:error.html.twig", "eZPlatformUIBundle:Exception:error403.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle:Exception:error.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Exception:error403.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle:Exception:error.html.twig" %}*/
/* */
