<?php

/* eZPlatformUIBundle:Language:view.html.twig */
class __TwigTemplate_92facfbb9fe068e28a08d82a391d4036cf5102c0f0f29a2256b40eaec40c04ec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Language:view.html.twig", 1);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 6
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_languagelist"), "label" => $this->env->getExtension('translator')->trans("language.list", array(), "language")), 2 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("language.view.title", array("%languageName%" => $this->getAttribute(        // line 9
(isset($context["language"]) ? $context["language"] : null), "name", array())), "language")));
        // line 11
        echo "
    ";
        // line 12
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 15
    public function block_header_title($context, array $blocks = array())
    {
        // line 16
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.view.title", array("%languageName%" => $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "name", array())), "language"), "html", null, true);
        echo "</h1>
";
    }

    // line 19
    public function block_content($context, array $blocks = array())
    {
        // line 20
        echo "    <section class=\"ez-tabs ez-serverside-content\">
        <ul class=\"ez-tabs-list\">
            <li class=\"ez-tabs-label is-tab-selected\"><a href=\"#ez-tabs-language-name\">";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "name", array()), "html", null, true);
        echo "</a></li>
        </ul>
        <div class=\"ez-tabs-panel is-tab-selected\" id=\"ez-tabs-language-name\">
            <ul>
                <li>
                    <strong>";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.name.label", array(), "language"), "html", null, true);
        echo "</strong>
                    ";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "name", array()), "html", null, true);
        echo "
                </li>
                <li>
                    <strong>";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.code.label", array(), "language"), "html", null, true);
        echo "</strong>
                    ";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "languageCode", array()), "html", null, true);
        echo "
                </li>
                <li>
                    <strong>";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.id.label", array(), "language"), "html", null, true);
        echo "</strong>
                    ";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "id", array()), "html", null, true);
        echo "
                </li>
                <li>
                    <strong>";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.enabled.label", array(), "language"), "html", null, true);
        echo "</strong>
                    <input type=\"checkbox\" disabled ";
        // line 40
        if ($this->getAttribute((isset($context["language"]) ? $context["language"] : null), "enabled", array())) {
            echo "checked title=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.enabled", array(), "language"), "html", null, true);
            echo "\"";
        } else {
            echo "title=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.disabled", array(), "language"), "html", null, true);
            echo "\"";
        }
        echo ">
                </li>
            </ul>

            <div>
                ";
        // line 45
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_languagedelete", array("languageId" => $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "id", array()), "redirectErrorsTo" => "view"))));
        echo "
                ";
        // line 46
        if ((isset($context["canEdit"]) ? $context["canEdit"] : null)) {
            // line 47
            echo "                    <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_languageedit", array("languageId" => $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "id", array()))), "html", null, true);
            echo "\"
                       class=\"pure-button ez-button\" data-icon=\"&#xe606;\">
                        ";
            // line 49
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.edit", array(), "language"), "html", null, true);
            echo "
                    </a>
                ";
        } else {
            // line 52
            echo "                    <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">
                        ";
            // line 53
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.edit", array(), "language"), "html", null, true);
            echo "
                    </span>
                ";
        }
        // line 56
        echo "
                    ";
        // line 57
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : null), "languageId", array()), 'widget');
        echo "
                    ";
        // line 58
        echo         // line 59
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(        // line 60
(isset($context["deleteForm"]) ? $context["deleteForm"] : null), "delete", array()), 'widget', array("disabled" =>  !        // line 62
(isset($context["canEdit"]) ? $context["canEdit"] : null), "attr" => array("class" => "pure-button ez-button ez-remove-language-button ez-font-icon ez-button-delete")));
        // line 66
        echo "
                ";
        // line 67
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_end');
        echo "
            </div>
        </div>
    </section>
";
    }

    // line 73
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.view.title", array("%languageName%" => $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "name", array())), "language"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Language:view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  173 => 73,  164 => 67,  161 => 66,  159 => 62,  158 => 60,  157 => 59,  156 => 58,  152 => 57,  149 => 56,  143 => 53,  140 => 52,  134 => 49,  128 => 47,  126 => 46,  122 => 45,  106 => 40,  102 => 39,  96 => 36,  92 => 35,  86 => 32,  82 => 31,  76 => 28,  72 => 27,  64 => 22,  60 => 20,  57 => 19,  50 => 16,  47 => 15,  41 => 12,  38 => 11,  36 => 9,  34 => 6,  31 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "language" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_languagelist'), label: 'language.list'|trans({}, 'language')},*/
/*         {link: '', label: 'language.view.title'|trans({'%languageName%': language.name}, 'language')}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'language.view.title'|trans({'%languageName%': language.name}) }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-tabs ez-serverside-content">*/
/*         <ul class="ez-tabs-list">*/
/*             <li class="ez-tabs-label is-tab-selected"><a href="#ez-tabs-language-name">{{ language.name }}</a></li>*/
/*         </ul>*/
/*         <div class="ez-tabs-panel is-tab-selected" id="ez-tabs-language-name">*/
/*             <ul>*/
/*                 <li>*/
/*                     <strong>{{ 'language.name.label'|trans }}</strong>*/
/*                     {{ language.name }}*/
/*                 </li>*/
/*                 <li>*/
/*                     <strong>{{ 'language.code.label'|trans }}</strong>*/
/*                     {{ language.languageCode }}*/
/*                 </li>*/
/*                 <li>*/
/*                     <strong>{{ 'language.id.label'|trans }}</strong>*/
/*                     {{ language.id }}*/
/*                 </li>*/
/*                 <li>*/
/*                     <strong>{{ 'language.enabled.label'|trans }}</strong>*/
/*                     <input type="checkbox" disabled {% if language.enabled %}checked title="{{ 'language.enabled'|trans }}"{% else %}title="{{ 'language.disabled'|trans }}"{% endif %}>*/
/*                 </li>*/
/*             </ul>*/
/* */
/*             <div>*/
/*                 {{ form_start(deleteForm, {"action": path("admin_languagedelete", {"languageId": language.id, "redirectErrorsTo": "view"})}) }}*/
/*                 {% if canEdit %}*/
/*                     <a href="{{ path('admin_languageedit', {'languageId': language.id}) }}"*/
/*                        class="pure-button ez-button" data-icon="&#xe606;">*/
/*                         {{ 'language.edit'|trans }}*/
/*                     </a>*/
/*                 {% else %}*/
/*                     <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">*/
/*                         {{ 'language.edit'|trans }}*/
/*                     </span>*/
/*                 {% endif %}*/
/* */
/*                     {{ form_widget(deleteForm.languageId) }}*/
/*                     {{*/
/*                         form_widget(*/
/*                             deleteForm.delete,*/
/*                             {*/
/*                                 "disabled": not canEdit,*/
/*                                 "attr": {"class": "pure-button ez-button ez-remove-language-button ez-font-icon ez-button-delete"}*/
/*                             }*/
/*                         )*/
/*                     }}*/
/*                 {{ form_end(deleteForm) }}*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'language.view.title'|trans({'%languageName%': language.name}) }}{% endblock %}*/
/* */
