<?php

/* EzPublishCoreBundle:default/content:embed_image.html.twig */
class __TwigTemplate_8f2518bab5b5d97efb0393369557996b14f86e0e9a895bc578c24401c2e9b14a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["image_field_identifier"] = $this->env->getExtension('ezpublish.content')->getFirstFilledImageFieldIdentifier((isset($context["content"]) ? $context["content"] : null));
        // line 2
        echo "
";
        // line 3
        if ( !(null === (isset($context["image_field_identifier"]) ? $context["image_field_identifier"] : null))) {
            // line 4
            echo "    ";
            echo call_user_func_array($this->env->getFunction('ez_render_field')->getCallable(), array($this->env,             // line 5
(isset($context["content"]) ? $context["content"] : null),             // line 6
(isset($context["image_field_identifier"]) ? $context["image_field_identifier"] : null), array("parameters" => array("alias" => $this->getAttribute(            // line 7
(isset($context["objectParameters"]) ? $context["objectParameters"] : null), "size", array())))));
            // line 8
            echo "
";
        }
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/content:embed_image.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  32 => 8,  30 => 7,  29 => 6,  28 => 5,  26 => 4,  24 => 3,  21 => 2,  19 => 1,);
    }
}
/* {% set image_field_identifier = ez_first_filled_image_field_identifier(content) %}*/
/* */
/* {% if image_field_identifier is not null %}*/
/*     {{ ez_render_field(*/
/*        content,*/
/*        image_field_identifier,*/
/*        { parameters: { alias: objectParameters.size } }*/
/*     ) }}*/
/* {% endif %}*/
/* */
