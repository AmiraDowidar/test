<?php

/* eZPlatformUIBundle:Role:assign_role_by_section.html.twig */
class __TwigTemplate_2ca84e44f2e146c32815984e41fea32d8d43f255088b15a4fb90cb926cf0134c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Role:assign_role_by_section.html.twig", 3);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_role"), "label" => $this->env->getExtension('translator')->trans("role.dashboard_title", array(), "role")), 2 => array("link" => $this->env->getExtension('routing')->getPath("admin_roleView", array("roleId" => $this->getAttribute(        // line 11
(isset($context["role"]) ? $context["role"] : null), "id", array()))), "label" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array())), 3 => array("link" => null, "label" => $this->env->getExtension('translator')->trans("role.assign_role_limit_section", array(), "role")));
        // line 14
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 17
    public function block_header_title($context, array $blocks = array())
    {
        // line 18
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe62d;\">";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign_limit_section.user_or_group.pagetitle", array("%roleIdentifier%" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array())), "role"), "html", null, true);
        // line 20
        echo "</h1>
";
    }

    // line 23
    public function block_content($context, array $blocks = array())
    {
        // line 24
        echo "    <section class=\"ez-serverside-content\">
        <label for=\"data-role-assignment-section\">";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.choose_section", array(), "role"), "html", null, true);
        echo "</label>
        <select id=\"data-role-assignment-section\" class=\"ez-role-assignment-section-id\">
            ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sections"]) ? $context["sections"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 28
            echo "            ";
            // line 29
            echo "                <option data-section-rest-id=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadSection", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
            echo "\"
                        value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "name", array()), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['section'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "        </select>
        <p>
            <button
                data-universaldiscovery-limit-section-title=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign.universaldiscovery.title", array("%roleIdentifier%" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array())), "role"), "html_attr");
        echo "\"
                data-role-rest-id=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadRole", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "id", array()))), "html", null, true);
        echo "\"
                data-role-name=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array()), "html", null, true);
        echo "\"
                data-role-assignment-limitation-type=\"";
        // line 38
        echo "Section";
        echo "\"
                class=\"ez-role-assign-limit-section-button ez-button-tree pure-button ez-font-icon ez-button\">
                ";
        // line 40
        if ( !(isset($context["can_assign"]) ? $context["can_assign"] : null)) {
            echo "disabled";
        }
        // line 41
        echo "                ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign_limit_section.user_or_group", array(), "role"), "html", null, true);
        echo "
            </button>
            <a href=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_roleView", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "id", array()))), "html", null, true);
        echo "\" class=\"ez-role-assign-limit-section-cancel-button pure-button ez-button\">";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign_limit_section.cancel", array(), "role"), "html", null, true);
        // line 45
        echo "</a>
        </p>
    </section>
";
    }

    // line 50
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role", array(), "role"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Role:assign_role_by_section.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  133 => 50,  126 => 45,  124 => 44,  121 => 43,  115 => 41,  111 => 40,  106 => 38,  102 => 37,  98 => 36,  94 => 35,  89 => 32,  79 => 30,  74 => 29,  72 => 28,  68 => 27,  63 => 25,  60 => 24,  57 => 23,  52 => 20,  50 => 19,  48 => 18,  45 => 17,  38 => 14,  36 => 11,  34 => 8,  31 => 7,  11 => 3,);
    }
}
/* {# @var role \eZ\Publish\API\Repository\Values\User\Role #}*/
/* {# @var sections \eZ\Publish\API\Repository\Values\Content\Section[] #}*/
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "role" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_role'), label: 'role.dashboard_title'|trans},*/
/*         {link: path("admin_roleView", {"roleId": role.id}), label: role.identifier},*/
/*         {link: null, label: 'role.assign_role_limit_section'|trans}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe62d;">*/
/*         {{- 'role.assign_limit_section.user_or_group.pagetitle'|trans({'%roleIdentifier%': role.identifier}) -}}*/
/*     </h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <label for="data-role-assignment-section">{{ 'role.choose_section'|trans }}</label>*/
/*         <select id="data-role-assignment-section" class="ez-role-assignment-section-id">*/
/*             {% for section in sections %}*/
/*             {# @var section \eZ\Publish\API\Repository\Values\Content\Section #}*/
/*                 <option data-section-rest-id="{{ path('ezpublish_rest_loadSection', {'sectionId': section.id}) }}"*/
/*                         value="{{ section.id }}">{{ section.name }}</option>*/
/*             {% endfor %}*/
/*         </select>*/
/*         <p>*/
/*             <button*/
/*                 data-universaldiscovery-limit-section-title="{{ 'role.assign.universaldiscovery.title'|trans({'%roleIdentifier%': role.identifier })|e('html_attr') }}"*/
/*                 data-role-rest-id="{{ path( 'ezpublish_rest_loadRole', {'roleId': role.id}) }}"*/
/*                 data-role-name="{{ role.identifier }}"*/
/*                 data-role-assignment-limitation-type="{{ 'Section' }}"*/
/*                 class="ez-role-assign-limit-section-button ez-button-tree pure-button ez-font-icon ez-button">*/
/*                 {% if not can_assign %}disabled{% endif %}*/
/*                 {{ 'role.assign_limit_section.user_or_group'|trans }}*/
/*             </button>*/
/*             <a href="{{ path("admin_roleView", {"roleId": role.id}) }}" class="ez-role-assign-limit-section-cancel-button pure-button ez-button">*/
/*                 {{- 'role.assign_limit_section.cancel'|trans -}}*/
/*             </a>*/
/*         </p>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'role'|trans }}{% endblock %}*/
/* */
