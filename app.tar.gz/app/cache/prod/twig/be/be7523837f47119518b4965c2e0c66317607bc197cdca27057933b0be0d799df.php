<?php

/* eZPlatformUIBundle:ContentType:view_content_type.html.twig */
class __TwigTemplate_f6d743007788b0f52131190ea79a934a2dee24f0769c42dbee686ae63f83187a extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:ContentType:view_content_type.html.twig", 3);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 7
        $context["content_type_group"] = twig_first($this->env, $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "contentTypeGroups", array()));
        // line 8
        $context["content_type_name"] = (($this->getAttribute($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "names", array(), "any", false, true), (isset($context["language_code"]) ? $context["language_code"] : null), array(), "array", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "names", array(), "any", false, true), (isset($context["language_code"]) ? $context["language_code"] : null), array(), "array"), "")) : (""));
        // line 9
        $context["content_type_description"] = (($this->getAttribute($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "descriptions", array(), "any", false, true), (isset($context["language_code"]) ? $context["language_code"] : null), array(), "array", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "descriptions", array(), "any", false, true), (isset($context["language_code"]) ? $context["language_code"] : null), array(), "array"), "")) : (""));
        // line 3
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 11
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 12
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_contenttype"), "label" => $this->env->getExtension('translator')->trans("content_type.dashboard_title", array(), "content_type")), 2 => array("link" => $this->env->getExtension('routing')->getPath("admin_contenttypeGroupView", array("contentTypeGroupId" => $this->getAttribute(        // line 15
(isset($context["content_type_group"]) ? $context["content_type_group"] : null), "id", array()))), "label" => $this->getAttribute((isset($context["content_type_group"]) ? $context["content_type_group"] : null), "identifier", array())), 3 => array("link" => null, "label" =>         // line 16
(isset($context["content_type_name"]) ? $context["content_type_name"] : null)));
        // line 18
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 21
    public function block_header_title($context, array $blocks = array())
    {
        // line 22
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, (isset($context["content_type_name"]) ? $context["content_type_name"] : null), "html", null, true);
        echo " [";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->transchoice("content_type.content_count", (isset($context["content_count"]) ? $context["content_count"] : null), array(), "content_type"), "html", null, true);
        echo "]</h1>
";
    }

    // line 25
    public function block_content($context, array $blocks = array())
    {
        // line 26
        echo "    <section class=\"ez-serverside-content\">

        <p class=\"ez-technical-infos\">
            ";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.last_modified", array("%date%" => twig_localized_date_filter($this->env, $this->getAttribute(        // line 31
(isset($context["content_type"]) ? $context["content_type"] : null), "modificationDate", array()), "medium", "medium", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "locale", array())), "%modifier%" => $this->getAttribute(        // line 32
(isset($context["modifier"]) ? $context["modifier"] : null), "login", array())), "content_type"), "html", null, true);
        // line 34
        echo "
        </p>

        <div class=\"pure-g\">
            <div class=\"pure-u-1-2\">
                <div>
                    <h6>";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.name", array(), "content_type"), "html", null, true);
        echo "</h6>
                    ";
        // line 41
        echo twig_escape_filter($this->env, (isset($context["content_type_name"]) ? $context["content_type_name"] : null), "html", null, true);
        echo "
                </div>

                <div>
                    <h6>";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.identifier", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 46
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "identifier", array()), "html", null, true);
        echo "
                </div>

                <div>
                    <h6>";
        // line 50
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.description", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 51
        echo twig_escape_filter($this->env, (isset($context["content_type_description"]) ? $context["content_type_description"] : null), "html", null, true);
        echo "
                </div>

                <div>
                    <h6>";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.name_schema", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 56
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "nameSchema", array()), "html", null, true);
        echo "
                </div>

                <div>
                    <h6>";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.url_alias_schema", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "urlAliasSchema", array()), "html", null, true);
        echo "
                </div>
            </div>

            <div class=\"pure-u-1-2\">
                <div>
                    <h6>";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.container", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    <input type=\"checkbox\" disabled";
        // line 68
        if ($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "isContainer", array())) {
            echo " checked";
        }
        echo ">
                </div>

                <div>
                    <h6>";
        // line 72
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.default_availability", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 73
        echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "defaultAlwaysAvailable", array())) ? ($this->env->getExtension('translator')->trans("content_type.always_available", array(), "content_type")) : ($this->env->getExtension('translator')->trans("content_type.no_always_available", array(), "content_type"))), "html", null, true);
        echo "
                </div>

                <div>
                    <h6>";
        // line 77
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.default_children_sorting", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans(("content_type.sort_field." . $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "defaultSortField", array())), array(), "ezrepoforms_content_type"), "html", null, true);
        echo " / ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans(("content_type.sort_order." . $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "defaultSortOrder", array())), array(), "ezrepoforms_content_type"), "html", null, true);
        echo "
                </div>
            </div>

            <div class=\"pure-u-1\">
            ";
        // line 83
        if ((isset($context["can_edit"]) ? $context["can_edit"] : null)) {
            // line 84
            echo "                <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_contenttypeUpdate", array("contentTypeId" => $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "id", array()))), "html", null, true);
            echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.edit", array(), "content_type"), "html", null, true);
            echo "</a>
            ";
        } else {
            // line 86
            echo "                <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.edit", array(), "content_type"), "html", null, true);
            echo "</span>
            ";
        }
        // line 88
        echo "                ";
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_contenttypeDelete", array("contentTypeId" => $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "id", array())))));
        echo "
                    ";
        // line 89
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["delete_form"]) ? $context["delete_form"] : null), "contentTypeId", array()), 'widget');
        echo "
                    ";
        // line 90
        echo         // line 91
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(        // line 92
(isset($context["delete_form"]) ? $context["delete_form"] : null), "delete", array()), 'widget', array("disabled" =>  !        // line 94
(isset($context["can_delete"]) ? $context["can_delete"] : null), "attr" => array("class" => "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete", "title" => (( !        // line 96
(isset($context["can_delete"]) ? $context["can_delete"] : null)) ? ($this->env->getExtension('translator')->trans("content_type.is_in_use", array(), "content_type")) : ("")))));
        // line 99
        echo "
                ";
        // line 100
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : null), 'form_end');
        echo "
            </div>
        </div>
    </section>
";
    }

    // line 106
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, (isset($context["content_type_name"]) ? $context["content_type_name"] : null), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ContentType:view_content_type.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  223 => 106,  214 => 100,  211 => 99,  209 => 96,  208 => 94,  207 => 92,  206 => 91,  205 => 90,  201 => 89,  196 => 88,  190 => 86,  182 => 84,  180 => 83,  170 => 78,  166 => 77,  159 => 73,  155 => 72,  146 => 68,  142 => 67,  133 => 61,  129 => 60,  122 => 56,  118 => 55,  111 => 51,  107 => 50,  100 => 46,  96 => 45,  89 => 41,  85 => 40,  77 => 34,  75 => 32,  74 => 31,  73 => 29,  68 => 26,  65 => 25,  56 => 22,  53 => 21,  46 => 18,  44 => 16,  43 => 15,  41 => 12,  38 => 11,  34 => 3,  32 => 9,  30 => 8,  28 => 7,  11 => 3,);
    }
}
/* {# @var content_type \eZ\Publish\API\Repository\Values\ContentType\ContentType #}*/
/* */
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "content_type" %}*/
/* */
/* {% set content_type_group = content_type.contentTypeGroups|first %}*/
/* {% set content_type_name = content_type.names[language_code]|default('') %}*/
/* {% set content_type_description = content_type.descriptions[language_code]|default('') %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_contenttype'), label: 'content_type.dashboard_title'|trans},*/
/*         {link: path('admin_contenttypeGroupView', {'contentTypeGroupId': content_type_group.id}), label: content_type_group.identifier},*/
/*         {link: null, label: content_type_name}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ content_type_name }} [{{ 'content_type.content_count'|transchoice(content_count) }}]</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/* */
/*         <p class="ez-technical-infos">*/
/*             {{*/
/*                 "content_type.last_modified"|trans({*/
/*                     "%date%": content_type.modificationDate|localizeddate(locale=app.request.locale),*/
/*                     "%modifier%": modifier.login*/
/*                 })*/
/*             }}*/
/*         </p>*/
/* */
/*         <div class="pure-g">*/
/*             <div class="pure-u-1-2">*/
/*                 <div>*/
/*                     <h6>{{ "content_type.name"|trans }}</h6>*/
/*                     {{ content_type_name }}*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.identifier"|trans }}:</h6>*/
/*                     {{ content_type.identifier }}*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.description"|trans }}:</h6>*/
/*                     {{ content_type_description }}*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.name_schema"|trans }}:</h6>*/
/*                     {{ content_type.nameSchema }}*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.url_alias_schema"|trans }}:</h6>*/
/*                     {{ content_type.urlAliasSchema }}*/
/*                 </div>*/
/*             </div>*/
/* */
/*             <div class="pure-u-1-2">*/
/*                 <div>*/
/*                     <h6>{{ "content_type.container"|trans }}:</h6>*/
/*                     <input type="checkbox" disabled{% if content_type.isContainer %} checked{% endif %}>*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.default_availability"|trans }}:</h6>*/
/*                     {{ content_type.defaultAlwaysAvailable ? "content_type.always_available"|trans : "content_type.no_always_available"|trans }}*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.default_children_sorting"|trans }}:</h6>*/
/*                     {{ ("content_type.sort_field." ~ content_type.defaultSortField)|trans(domain="ezrepoforms_content_type") }} / {{ ("content_type.sort_order." ~ content_type.defaultSortOrder)|trans(domain="ezrepoforms_content_type") }}*/
/*                 </div>*/
/*             </div>*/
/* */
/*             <div class="pure-u-1">*/
/*             {% if can_edit %}*/
/*                 <a href="{{ path('admin_contenttypeUpdate', {'contentTypeId': content_type.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'content_type.edit'|trans }}</a>*/
/*             {% else %}*/
/*                 <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'content_type.edit'|trans }}</span>*/
/*             {% endif %}*/
/*                 {{ form_start(delete_form, {"action": path("admin_contenttypeDelete", {"contentTypeId": content_type.id})}) }}*/
/*                     {{ form_widget(delete_form.contentTypeId) }}*/
/*                     {{*/
/*                         form_widget(*/
/*                             delete_form.delete,*/
/*                             {*/
/*                                 "disabled": not can_delete,*/
/*                                 "attr": {"class": "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete",*/
/*                                          "title": not can_delete ? 'content_type.is_in_use'|trans}*/
/*                             }*/
/*                         )*/
/*                     }}*/
/*                 {{ form_end(delete_form) }}*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ content_type_name }}{% endblock %}*/
/* */
/* */
/* */
