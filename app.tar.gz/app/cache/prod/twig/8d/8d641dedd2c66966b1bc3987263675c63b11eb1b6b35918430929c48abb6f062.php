<?php

/* EzPublishCoreBundle:FieldType/RichText/embed:content.html.twig */
class __TwigTemplate_5bb584d14d7437a9675620b481c00b569222cf093087f907783f316b051135ec extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["params"] = array("objectParameters" => array());
        // line 2
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "config", array(), "any", true, true)) {
            // line 3
            echo "    ";
            $context["params"] = twig_array_merge((isset($context["params"]) ? $context["params"] : null), array("objectParameters" => $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "config", array())));
        }
        // line 5
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "link", array(), "any", true, true)) {
            // line 6
            echo "    ";
            $context["params"] = twig_array_merge((isset($context["params"]) ? $context["params"] : null), array("linkParameters" => $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "link", array())));
        }
        // line 8
        echo "<div class=\"";
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "align", array(), "any", true, true)) {
            echo "align-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "align", array()), "html", null, true);
        }
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "class", array(), "any", true, true)) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "class", array()), "html", null, true);
        }
        echo "\">
    ";
        // line 9
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("ez_content:embedContent", array("contentId" => $this->getAttribute(        // line 14
(isset($context["embedParams"]) ? $context["embedParams"] : null), "id", array()), "viewType" => $this->getAttribute(        // line 15
(isset($context["embedParams"]) ? $context["embedParams"] : null), "viewType", array()), "params" =>         // line 16
(isset($context["params"]) ? $context["params"] : null))));
        // line 20
        echo "
</div>
";
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/embed:content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  50 => 20,  48 => 16,  47 => 15,  46 => 14,  45 => 9,  33 => 8,  29 => 6,  27 => 5,  23 => 3,  21 => 2,  19 => 1,);
    }
}
/* {% set params = { "objectParameters": {} } %}*/
/* {% if embedParams.config is defined  %}*/
/*     {% set params = params|merge( { "objectParameters": embedParams.config } ) %}*/
/* {% endif %}*/
/* {% if embedParams.link is defined  %}*/
/*     {% set params = params|merge( { "linkParameters": embedParams.link } ) %}*/
/* {% endif %}*/
/* <div class="{% if embedParams.align is defined %}align-{{ embedParams.align }}{% endif %}{% if embedParams.class is defined %} {{ embedParams.class }}{% endif %}">*/
/*     {{*/
/*         render(*/
/*             controller(*/
/*                 "ez_content:embedContent",*/
/*                 {*/
/*                     "contentId": embedParams.id,*/
/*                     "viewType": embedParams.viewType,*/
/*                     "params": params*/
/*                 }*/
/*             )*/
/*         )*/
/*     }}*/
/* </div>*/
/* */
