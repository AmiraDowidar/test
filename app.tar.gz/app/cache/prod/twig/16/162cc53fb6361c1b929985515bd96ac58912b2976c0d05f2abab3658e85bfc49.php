<?php

/* @TedivmStash/Profiler/icon.svg */
class __TwigTemplate_ffb47d6c6ac6ee15bfe5d18fefad0696e75e7a07def029d95efaca4e265bfbb0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"M2,8 L6,3 L17,3 L21,8 L21,9 L21,21 L2,21 M3,8 L20,8 L16.5,3.6 L6.5,3.6 L3,8\"/>
    <text x=\"11.5\" y=\"18\" font-family=\"sans-serif\" font-size=\"10\" text-anchor=\"middle\">S</text>
</svg>
";
    }

    public function getTemplateName()
    {
        return "@TedivmStash/Profiler/icon.svg";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" height="24" viewBox="0 0 24 24" enable-background="new 0 0 24 24" xml:space="preserve">*/
/*     <path fill="#AAAAAA" d="M2,8 L6,3 L17,3 L21,8 L21,9 L21,21 L2,21 M3,8 L20,8 L16.5,3.6 L6.5,3.6 L3,8"/>*/
/*     <text x="11.5" y="18" font-family="sans-serif" font-size="10" text-anchor="middle">S</text>*/
/* </svg>*/
/* */
