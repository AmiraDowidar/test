<?php

/* eZPlatformUIBundle:Dashboard:dashboard.html.twig */
class __TwigTemplate_67a5b01820e04a8857ca898c0ac05b05c2cdecf967c7a0a827bddb0c013df064 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Dashboard:dashboard.html.twig", 1);
        $this->blocks = array(
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_header_title($context, array $blocks = array())
    {
        // line 6
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe618;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard"), "html", null, true);
        echo "</h1>
";
    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        // line 10
        echo "    <section class=\"ez-serverside-content\">
        <ul>
            <li><a href=\"";
        // line 12
        echo $this->env->getExtension('routing')->getPath("admin_systeminfo");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("system.information", array(), "systeminfo"), "html", null, true);
        echo "</a></li>
            <li><a href=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("admin_languagelist");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.list", array(), "language"), "html", null, true);
        echo "</a></li>
            <li><a href=\"";
        // line 14
        echo $this->env->getExtension('routing')->getPath("admin_sectionlist");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.list", array(), "section"), "html", null, true);
        echo "</a></li>
            <li><a href=\"";
        // line 15
        echo $this->env->getExtension('routing')->getPath("admin_contenttype");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.dashboard_title", array(), "content_type"), "html", null, true);
        echo "</a></li>
            <li><a href=\"";
        // line 16
        echo $this->env->getExtension('routing')->getPath("admin_role");
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.dashboard_title", array(), "role"), "html", null, true);
        echo "</a></li>
        </ul>
    </section>
";
    }

    // line 21
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Dashboard:dashboard.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  81 => 21,  71 => 16,  65 => 15,  59 => 14,  53 => 13,  47 => 12,  43 => 10,  40 => 9,  33 => 6,  30 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "dashboard" %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe618;">{{ 'dashboard.title'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <ul>*/
/*             <li><a href="{{ path('admin_systeminfo') }}">{{ 'system.information'|trans({}, 'systeminfo') }}</a></li>*/
/*             <li><a href="{{ path('admin_languagelist') }}">{{ 'language.list'|trans({}, 'language') }}</a></li>*/
/*             <li><a href="{{ path('admin_sectionlist') }}">{{ 'section.list'|trans({}, 'section') }}</a></li>*/
/*             <li><a href="{{ path('admin_contenttype') }}">{{ 'content_type.dashboard_title'|trans({}, 'content_type') }}</a></li>*/
/*             <li><a href="{{ path('admin_role') }}">{{ 'role.dashboard_title'|trans({}, 'role') }}</a></li>*/
/*         </ul>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'dashboard.title'|trans }}{% endblock %}*/
/* */
