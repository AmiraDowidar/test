<?php

/* :line:point_of_interest.html.twig */
class __TwigTemplate_f5dbbeb4efa9a4832339c707c31c74814caf97d3effe116d8dd989290d2d138d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "point_of_interest.html.twig";
    }

    public function getTemplateName()
    {
        return ":line:point_of_interest.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* point_of_interest.html.twig*/
