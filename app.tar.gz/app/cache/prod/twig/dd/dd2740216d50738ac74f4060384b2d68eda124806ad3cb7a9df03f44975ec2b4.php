<?php

/* eZPlatformUIBundle:SystemInfo:info.html.twig */
class __TwigTemplate_839146aa03a1e89f7d8d6306b349c67bbd5b7ec4803fb4d32234f7f978f98da2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:SystemInfo:info.html.twig", 1);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 6
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("system.information", array(), "systeminfo")));
        // line 10
        echo "
    ";
        // line 11
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 14
    public function block_header_title($context, array $blocks = array())
    {
        // line 15
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe617\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("system.information", array(), "systeminfo"), "html", null, true);
        echo "</h1>
";
    }

    // line 18
    public function block_content($context, array $blocks = array())
    {
        // line 19
        echo "    <section class=\"ez-tabs ez-serverside-content\">

        <ul class=\"ez-tabs-list\">
            ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["collector_identifiers"]) ? $context["collector_identifiers"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["collector_identifier"]) {
            // line 23
            echo "                <li class=\"ez-tabs-label";
            if ($this->getAttribute($context["loop"], "first", array())) {
                echo " is-tab-selected";
            }
            echo "\"><a href=\"#ez-tabs-";
            echo twig_escape_filter($this->env, $context["collector_identifier"], "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($context["collector_identifier"], array(), "systeminfo"), "html", null, true);
            echo "</a></li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['collector_identifier'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "        </ul>

        <div class=\"ez-tabs-panels\">
            ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["collector_identifiers"]) ? $context["collector_identifiers"] : null));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["collector_identifier"]) {
            // line 29
            echo "                <div class=\"ez-tabs-panel";
            if ($this->getAttribute($context["loop"], "first", array())) {
                echo " is-tab-selected";
            }
            echo "\" id=\"ez-tabs-";
            echo twig_escape_filter($this->env, $context["collector_identifier"], "html", null, true);
            echo "\">
                    ";
            // line 30
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("support_tools.view.controller:viewInfoAction", array("systemInfoIdentifier" =>             // line 32
$context["collector_identifier"], "viewType" => "pjax_tab")));
            // line 34
            echo "
                </div>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['collector_identifier'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "        </div>

    </section>
";
    }

    // line 42
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("system.information", array(), "systeminfo"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:SystemInfo:info.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  161 => 42,  154 => 37,  138 => 34,  136 => 32,  135 => 30,  126 => 29,  109 => 28,  104 => 25,  81 => 23,  64 => 22,  59 => 19,  56 => 18,  49 => 15,  46 => 14,  40 => 11,  37 => 10,  34 => 6,  31 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "systeminfo" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: '', label: 'system.information'|trans({}, 'systeminfo') },*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe617">{{ 'system.information'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-tabs ez-serverside-content">*/
/* */
/*         <ul class="ez-tabs-list">*/
/*             {% for collector_identifier in collector_identifiers %}*/
/*                 <li class="ez-tabs-label{% if loop.first %} is-tab-selected{% endif %}"><a href="#ez-tabs-{{ collector_identifier }}">{{ collector_identifier|trans }}</a></li>*/
/*             {% endfor %}*/
/*         </ul>*/
/* */
/*         <div class="ez-tabs-panels">*/
/*             {% for collector_identifier in collector_identifiers %}*/
/*                 <div class="ez-tabs-panel{% if loop.first %} is-tab-selected{% endif %}" id="ez-tabs-{{ collector_identifier }}">*/
/*                     {{ render( controller(*/
/*                     'support_tools.view.controller:viewInfoAction', {*/
/*                         'systemInfoIdentifier': collector_identifier,*/
/*                         'viewType': 'pjax_tab'*/
/*                     } ) ) }}*/
/*                 </div>*/
/*             {% endfor %}*/
/*         </div>*/
/* */
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{'system.information'|trans }}{% endblock %}*/
/* */
