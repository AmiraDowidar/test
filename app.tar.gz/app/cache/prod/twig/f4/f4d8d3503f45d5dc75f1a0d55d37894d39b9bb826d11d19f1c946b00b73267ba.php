<?php

/* eZPlatformUIBundle:Section:edit.html.twig */
class __TwigTemplate_d528bd756ca991c1bb1276fe9024841b531584b04f9b657b7fb1c7b89aac555c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Section:edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 5
        $context["editTitle"] = (($this->getAttribute((isset($context["section"]) ? $context["section"] : null), "new", array())) ? ($this->env->getExtension('translator')->trans("section.create.title", array(), "section")) : ($this->env->getExtension('translator')->trans("section.edit.title", array("%sectionName%" => $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "name", array())), "section")));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, (isset($context["editTitle"]) ? $context["editTitle"] : null), "html", null, true);
        echo "
";
    }

    // line 11
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 12
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_sectionlist"), "label" => $this->env->getExtension('translator')->trans("section.list", array(), "section")), 2 => array("link" => (($this->getAttribute(        // line 16
(isset($context["section"]) ? $context["section"] : null), "new", array())) ? ("") : ($this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "id", array()))))), "label" => $this->env->getExtension('translator')->trans("section.view.title", array("%sectionName%" => $this->getAttribute(        // line 17
(isset($context["section"]) ? $context["section"] : null), "name", array())), "section")), 3 => array("link" => "", "label" =>         // line 19
(isset($context["editTitle"]) ? $context["editTitle"] : null)));
        // line 21
        echo "
    ";
        // line 22
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 25
    public function block_header_title($context, array $blocks = array())
    {
        // line 26
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">
        ";
        // line 27
        echo twig_escape_filter($this->env, (isset($context["editTitle"]) ? $context["editTitle"] : null), "html", null, true);
        echo "
    </h1>
";
    }

    // line 31
    public function block_content($context, array $blocks = array())
    {
        // line 32
        echo "    <section class=\"ez-serverside-content\">
        ";
        // line 33
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("action" => (isset($context["actionUrl"]) ? $context["actionUrl"] : null), "attr" => array("class" => "pure-form pure-form-aligned")));
        echo "
            ";
        // line 34
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'errors');
        echo "

            <fieldset>
                <div class=\"pure-control-group\">
                    ";
        // line 38
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "name", array()), 'label');
        echo "
                    ";
        // line 39
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "name", array()), 'errors');
        echo "
                    ";
        // line 40
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "name", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 44
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "identifier", array()), 'label');
        echo "
                    ";
        // line 45
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "identifier", array()), 'errors');
        echo "
                    ";
        // line 46
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "identifier", array()), 'widget');
        echo "
                </div>
            </fieldset>

            <div class=\"pure-controls\">
                <a href=\"";
        // line 51
        echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["section"]) ? $context["section"] : null), "new", array())) ? ($this->env->getExtension('routing')->getPath("admin_sectionlist")) : ($this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "id", array()))))), "html", null, true);
        echo "\"
                   class=\"pure-button ez-button\">";
        // line 52
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.cancel", array(), "section"), "html", null, true);
        echo "</a>
                ";
        // line 53
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
            </div>

        ";
        // line 56
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
    </section>
";
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Section:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 56,  131 => 53,  127 => 52,  123 => 51,  115 => 46,  111 => 45,  107 => 44,  100 => 40,  96 => 39,  92 => 38,  85 => 34,  81 => 33,  78 => 32,  75 => 31,  68 => 27,  65 => 26,  62 => 25,  56 => 22,  53 => 21,  51 => 19,  50 => 17,  49 => 16,  47 => 12,  44 => 11,  37 => 8,  34 => 7,  30 => 1,  28 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "section" %}*/
/* */
/* {% set editTitle = section.new ? "section.create.title"|trans() : "section.edit.title"|trans({"%sectionName%": section.name}) %}*/
/* */
/* {% block title %}*/
/*     {{ editTitle }}*/
/* {% endblock %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_sectionlist'), label: 'section.list'|trans({})},*/
/*         {*/
/*             link: section.new ? "" : path('admin_sectionview', {'sectionId': section.id}),*/
/*             label: 'section.view.title'|trans({'%sectionName%': section.name})*/
/*         },*/
/*         {link: '', label: editTitle}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">*/
/*         {{ editTitle }}*/
/*     </h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         {{ form_start(form, {'action': actionUrl, "attr": {"class": "pure-form pure-form-aligned"}}) }}*/
/*             {{ form_errors(form) }}*/
/* */
/*             <fieldset>*/
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.name) }}*/
/*                     {{ form_errors(form.name) }}*/
/*                     {{ form_widget(form.name) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.identifier) }}*/
/*                     {{ form_errors(form.identifier) }}*/
/*                     {{ form_widget(form.identifier) }}*/
/*                 </div>*/
/*             </fieldset>*/
/* */
/*             <div class="pure-controls">*/
/*                 <a href="{{ section.new ? path("admin_sectionlist") : path("admin_sectionview", {"sectionId": section.id}) }}"*/
/*                    class="pure-button ez-button">{{ "section.cancel"|trans }}</a>*/
/*                 {{ form_widget(form.save, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*             </div>*/
/* */
/*         {{ form_end(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
