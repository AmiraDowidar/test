<?php

/* EzSystemsRepositoryFormsBundle:User:register_confirmation.html.twig */
class __TwigTemplate_07bc154fb2b6883a7ae25a2713f8aa5b1a5450ec1ad8f6e383440904b5bb816f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((((array_key_exists("noLayout", $context) && ((isset($context["noLayout"]) ? $context["noLayout"] : null) == true))) ? ((isset($context["viewbaseLayout"]) ? $context["viewbaseLayout"] : null)) : ((isset($context["pagelayout"]) ? $context["pagelayout"] : null))), "EzSystemsRepositoryFormsBundle:User:register_confirmation.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <h1>Your account has been created</h1>
    <p class=\"user-register-confirmation-message\">
        Thank you for registering an account. You can now <a href=\"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("login");
        echo "\">login</a>.
    </p>
";
    }

    public function getTemplateName()
    {
        return "EzSystemsRepositoryFormsBundle:User:register_confirmation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 6,  30 => 4,  27 => 3,  18 => 1,);
    }
}
/* {% extends noLayout is defined and noLayout == true ? viewbaseLayout : pagelayout %}*/
/* */
/* {% block content %}*/
/*     <h1>Your account has been created</h1>*/
/*     <p class="user-register-confirmation-message">*/
/*         Thank you for registering an account. You can now <a href="{{ path('login') }}">login</a>.*/
/*     </p>*/
/* {% endblock %}*/
/* */
