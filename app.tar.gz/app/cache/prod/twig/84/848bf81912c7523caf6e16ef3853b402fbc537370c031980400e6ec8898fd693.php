<?php

/* eZPlatformUIBundle:ez-support-tools/info:php.html.twig */
class __TwigTemplate_d49b69054a6378fb50d4bcbb5fa032be7145c967b1e955062165010f98834d76 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<h1>";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("php", array(), "systeminfo"), "html", null, true);
        echo "</h1>
<dl>
    <dt>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("php", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>
        ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "version", array()), "html", null, true);
        echo "
        (<a href=\"";
        // line 8
        echo $this->env->getExtension('routing')->getPath("admin_phpinfo");
        echo "\" target=\"_blank\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("php.info", array(), "systeminfo"), "html", null, true);
        echo "</a>)
    </dd>
    <dt>";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("php.accelerator", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>
        ";
        // line 12
        if ( !$this->getAttribute((isset($context["info"]) ? $context["info"] : null), "acceleratorEnabled", array())) {
            // line 13
            echo "            <strong>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("disabled", array(), "systeminfo"), "html", null, true);
            echo "</strong>
        ";
        }
        // line 15
        echo "        <a href=\"";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "acceleratorURL", array()), "html", null, true);
        echo "\" target=\"_blank\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "acceleratorName", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "acceleratorVersion", array()), "html", null, true);
        echo ")</a>
    </dd>
</dl>
";
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ez-support-tools/info:php.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 15,  50 => 13,  48 => 12,  43 => 10,  36 => 8,  32 => 7,  27 => 5,  22 => 3,  19 => 2,);
    }
}
/* {% trans_default_domain "systeminfo" %}*/
/* */
/* <h1>{{ 'php'|trans }}</h1>*/
/* <dl>*/
/*     <dt>{{ 'php'|trans }}</dt>*/
/*     <dd>*/
/*         {{ info.version }}*/
/*         (<a href="{{ path( 'admin_phpinfo' ) }}" target="_blank">{{ 'php.info'|trans }}</a>)*/
/*     </dd>*/
/*     <dt>{{ 'php.accelerator'|trans }}</dt>*/
/*     <dd>*/
/*         {% if not info.acceleratorEnabled %}*/
/*             <strong>{{ 'disabled'|trans }}</strong>*/
/*         {% endif %}*/
/*         <a href="{{ info.acceleratorURL }}" target="_blank">{{ info.acceleratorName }} ({{ info.acceleratorVersion }})</a>*/
/*     </dd>*/
/* </dl>*/
/* */
