<?php

/* EzPublishCoreBundle:FieldType/RichText/embed:content_inline_denied.html.twig */
class __TwigTemplate_5b5b27a05416149f8c9f4602c6ec6494bb05c91133180ae551b7438237a2c921 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "[[ Content #";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "id", array()), "html", null, true);
        echo ": You do not have permission to view this Content ]]
";
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/embed:content_inline_denied.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* [[ Content #{{ embedParams.id }}: You do not have permission to view this Content ]]*/
/* */
