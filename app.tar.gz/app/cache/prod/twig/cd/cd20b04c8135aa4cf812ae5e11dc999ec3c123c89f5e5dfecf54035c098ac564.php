<?php

/* eZPlatformUIBundle:Exception:error404.html.twig */
class __TwigTemplate_508e8912fffb54d5cee08d6789fa594afd83f38278f4873ad563d09d87a83b13 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle:Exception:error.html.twig", "eZPlatformUIBundle:Exception:error404.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle:Exception:error.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Exception:error404.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle:Exception:error.html.twig" %}*/
/* */
