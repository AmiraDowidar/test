<?php

/* EzPublishCoreBundle::fielddefinition_settings.html.twig */
class __TwigTemplate_da4439c634f4adbfb01a0492dbd14476d16526a3c5499eaef6c86ed32240e319 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'ezstring_settings' => array($this, 'block_ezstring_settings'),
            'eztext_settings' => array($this, 'block_eztext_settings'),
            'ezcountry_settings' => array($this, 'block_ezcountry_settings'),
            'ezboolean_settings' => array($this, 'block_ezboolean_settings'),
            'ezdatetime_settings' => array($this, 'block_ezdatetime_settings'),
            'ezdate_settings' => array($this, 'block_ezdate_settings'),
            'eztime_settings' => array($this, 'block_eztime_settings'),
            'ezinteger_settings' => array($this, 'block_ezinteger_settings'),
            'ezfloat_settings' => array($this, 'block_ezfloat_settings'),
            'ezselection_settings' => array($this, 'block_ezselection_settings'),
            'ezbinaryfile_settings' => array($this, 'block_ezbinaryfile_settings'),
            'ezmedia_settings' => array($this, 'block_ezmedia_settings'),
            'ezimage_settings' => array($this, 'block_ezimage_settings'),
            'ezobjectrelation_settings' => array($this, 'block_ezobjectrelation_settings'),
            'ezobjectrelationlist_settings' => array($this, 'block_ezobjectrelationlist_settings'),
            'ezpage_settings' => array($this, 'block_ezpage_settings'),
            'ezauthor_settings' => array($this, 'block_ezauthor_settings'),
            'ezurl_settings' => array($this, 'block_ezurl_settings'),
            'ezisbn_settings' => array($this, 'block_ezisbn_settings'),
            'ezkeyword_settings' => array($this, 'block_ezkeyword_settings'),
            'ezuser_settings' => array($this, 'block_ezuser_settings'),
            'ezemail_settings' => array($this, 'block_ezemail_settings'),
            'ezgmaplocation_settings' => array($this, 'block_ezgmaplocation_settings'),
            'ezsrrating_settings' => array($this, 'block_ezsrrating_settings'),
            'settings_maxfilesize' => array($this, 'block_settings_maxfilesize'),
            'settings_preferredrows' => array($this, 'block_settings_preferredrows'),
            'settings_selectionroot' => array($this, 'block_settings_selectionroot'),
            'settings_defaultvalue' => array($this, 'block_settings_defaultvalue'),
            'settings_minimumvalue' => array($this, 'block_settings_minimumvalue'),
            'settings_maximumvalue' => array($this, 'block_settings_maximumvalue'),
            'settings_allowmultiple' => array($this, 'block_settings_allowmultiple'),
            'settings_allowisbn13' => array($this, 'block_settings_allowisbn13'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 7
        echo "
";
        // line 8
        $this->displayBlock('ezstring_settings', $context, $blocks);
        // line 22
        echo "
";
        // line 23
        $this->displayBlock('eztext_settings', $context, $blocks);
        // line 29
        echo "
";
        // line 30
        $this->displayBlock('ezcountry_settings', $context, $blocks);
        // line 41
        echo "
";
        // line 42
        $this->displayBlock('ezboolean_settings', $context, $blocks);
        // line 54
        echo "
";
        // line 55
        $this->displayBlock('ezdatetime_settings', $context, $blocks);
        // line 78
        echo "
";
        // line 79
        $this->displayBlock('ezdate_settings', $context, $blocks);
        // line 89
        echo "
";
        // line 90
        $this->displayBlock('eztime_settings', $context, $blocks);
        // line 104
        echo "
";
        // line 105
        $this->displayBlock('ezinteger_settings', $context, $blocks);
        // line 115
        echo "
";
        // line 116
        $this->displayBlock('ezfloat_settings', $context, $blocks);
        // line 126
        echo "
";
        // line 127
        $this->displayBlock('ezselection_settings', $context, $blocks);
        // line 141
        echo "

";
        // line 143
        $this->displayBlock('ezbinaryfile_settings', $context, $blocks);
        // line 148
        echo "
";
        // line 149
        $this->displayBlock('ezmedia_settings', $context, $blocks);
        // line 175
        echo "
";
        // line 176
        $this->displayBlock('ezimage_settings', $context, $blocks);
        // line 181
        echo "
";
        // line 182
        $this->displayBlock('ezobjectrelation_settings', $context, $blocks);
        // line 198
        echo "
";
        // line 199
        $this->displayBlock('ezobjectrelationlist_settings', $context, $blocks);
        // line 236
        echo "
";
        // line 237
        $this->displayBlock('ezpage_settings', $context, $blocks);
        // line 245
        echo "

";
        // line 247
        $this->displayBlock('ezauthor_settings', $context, $blocks);
        // line 248
        echo "
";
        // line 249
        $this->displayBlock('ezurl_settings', $context, $blocks);
        // line 250
        echo "
";
        // line 251
        $this->displayBlock('ezisbn_settings', $context, $blocks);
        // line 259
        echo "
";
        // line 260
        $this->displayBlock('ezkeyword_settings', $context, $blocks);
        // line 261
        echo "
";
        // line 262
        $this->displayBlock('ezuser_settings', $context, $blocks);
        // line 263
        echo "
";
        // line 264
        $this->displayBlock('ezemail_settings', $context, $blocks);
        // line 265
        echo "
";
        // line 266
        $this->displayBlock('ezgmaplocation_settings', $context, $blocks);
        // line 267
        echo "
";
        // line 268
        $this->displayBlock('ezsrrating_settings', $context, $blocks);
        // line 269
        echo "
";
        // line 270
        $this->displayBlock('settings_maxfilesize', $context, $blocks);
        // line 281
        echo "
";
        // line 282
        $this->displayBlock('settings_preferredrows', $context, $blocks);
        // line 292
        echo "
";
        // line 293
        $this->displayBlock('settings_selectionroot', $context, $blocks);
        // line 304
        echo "
";
        // line 305
        $this->displayBlock('settings_defaultvalue', $context, $blocks);
        // line 315
        echo "
";
        // line 316
        $this->displayBlock('settings_minimumvalue', $context, $blocks);
        // line 326
        echo "
";
        // line 327
        $this->displayBlock('settings_maximumvalue', $context, $blocks);
        // line 337
        echo "
";
        // line 338
        $this->displayBlock('settings_allowmultiple', $context, $blocks);
        // line 344
        echo "
";
        // line 345
        $this->displayBlock('settings_allowisbn13', $context, $blocks);
    }

    // line 8
    public function block_ezstring_settings($context, array $blocks = array())
    {
        // line 9
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 10
        $context["defaultValue"] = $this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "defaultValue", array()), "text", array());
        // line 11
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    <li class=\"max-length\">
        <span>Max string length:</span>
        ";
        // line 14
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "validatorConfiguration", array()), "StringLengthValidator", array()), "maxStringLength", array())) {
            // line 15
            echo "            ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "validatorConfiguration", array()), "StringLengthValidator", array()), "maxStringLength", array()), "html", null, true);
            echo " characters
        ";
        } else {
            // line 17
            echo "            <em>No defined maximum string length</em>
        ";
        }
        // line 19
        echo "    </li>
</ul>
";
    }

    // line 23
    public function block_eztext_settings($context, array $blocks = array())
    {
        // line 24
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 25
        $context["rows"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "textRows", array());
        // line 26
        echo "    ";
        $this->displayBlock("settings_preferredrows", $context, $blocks);
        echo "
</ul>
";
    }

    // line 30
    public function block_ezcountry_settings($context, array $blocks = array())
    {
        // line 31
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 32
        $context["defaultValue"] = "";
        // line 33
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "defaultValue", array()), "countries", array()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
            // line 34
            echo "        ";
            $context["defaultValue"] = (((isset($context["defaultValue"]) ? $context["defaultValue"] : null) . $this->getAttribute($context["country"], "Name", array())) . (( !$this->getAttribute($context["loop"], "last", array())) ? (", ") : ("")));
            // line 35
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    ";
        // line 37
        $context["isMultiple"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "isMultiple", array());
        // line 38
        echo "    ";
        $this->displayBlock("settings_allowmultiple", $context, $blocks);
        echo "
</ul>
";
    }

    // line 42
    public function block_ezboolean_settings($context, array $blocks = array())
    {
        // line 43
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    <li class=\"default-value\">
        <span>Default value:</span>
        ";
        // line 46
        if ($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "defaultValue", array()), "bool", array())) {
            // line 47
            echo "            Checked
        ";
        } else {
            // line 49
            echo "            Unchecked
        ";
        }
        // line 51
        echo "    </li>
</ul>
";
    }

    // line 55
    public function block_ezdatetime_settings($context, array $blocks = array())
    {
        // line 56
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 57
        if (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "defaultType", array()) == twig_constant("eZ\\Publish\\Core\\FieldType\\DateAndTime\\Type::DEFAULT_EMPTY"))) {
            // line 58
            echo "        ";
            $context["defaultValue"] = "Empty";
            // line 59
            echo "    ";
        } elseif (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "defaultType", array()) == twig_constant("eZ\\Publish\\Core\\FieldType\\DateAndTime\\Type::DEFAULT_CURRENT_DATE"))) {
            // line 60
            echo "        ";
            $context["defaultValue"] = "Current datetime";
            // line 61
            echo "    ";
        } else {
            // line 62
            echo "        ";
            $context["interval"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "dateInterval", array());
            // line 63
            echo "        ";
            $context["defaultValue"] = "Current datetime adjusted by ";
            // line 64
            echo "        ";
            $context["defaultValue"] = (($this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "y", array())) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : null) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "y", array())) . " year(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : null)));
            // line 65
            echo "        ";
            $context["defaultValue"] = (($this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "m", array())) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : null) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "m", array())) . " month(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : null)));
            // line 66
            echo "        ";
            $context["defaultValue"] = (($this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "d", array())) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : null) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "d", array())) . " day(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : null)));
            // line 67
            echo "        ";
            $context["defaultValue"] = (($this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "h", array())) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : null) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "h", array())) . " hour(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : null)));
            // line 68
            echo "        ";
            $context["defaultValue"] = (($this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "i", array())) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : null) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "i", array())) . " minute(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : null)));
            // line 69
            echo "        ";
            $context["defaultValue"] = ((($this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "s", array()) && $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "useSeconds", array()))) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : null) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : null), "s", array())) . " second(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : null)));
            // line 70
            echo "    ";
        }
        // line 71
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    <li class=\"use-seconds\">
        <span>Use seconds:</span>
        ";
        // line 74
        echo (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "useSeconds", array())) ? ("Yes") : ("No"));
        echo "
    </li>
</ul>
";
    }

    // line 79
    public function block_ezdate_settings($context, array $blocks = array())
    {
        // line 80
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 81
        if (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "defaultType", array()) == twig_constant("eZ\\Publish\\Core\\FieldType\\Date\\Type::DEFAULT_EMPTY"))) {
            // line 82
            echo "        ";
            $context["defaultValue"] = "Empty";
            // line 83
            echo "    ";
        } else {
            // line 84
            echo "        ";
            $context["defaultValue"] = "Current date";
            // line 85
            echo "    ";
        }
        // line 86
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
</ul>
";
    }

    // line 90
    public function block_eztime_settings($context, array $blocks = array())
    {
        // line 91
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 92
        if (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "defaultType", array()) == twig_constant("eZ\\Publish\\Core\\FieldType\\Time\\Type::DEFAULT_EMPTY"))) {
            // line 93
            echo "        ";
            $context["defaultValue"] = "Empty";
            // line 94
            echo "    ";
        } else {
            // line 95
            echo "        ";
            $context["defaultValue"] = "Current time";
            // line 96
            echo "    ";
        }
        // line 97
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    <li class=\"use-seconds\">
        <span>Use seconds:</span>
        ";
        // line 100
        echo (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "useSeconds", array())) ? ("Yes") : ("No"));
        echo "
    </li>
</ul>
";
    }

    // line 105
    public function block_ezinteger_settings($context, array $blocks = array())
    {
        // line 106
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 107
        $context["defaultValue"] = $this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "defaultValue", array()), "value", array());
        // line 108
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    ";
        // line 109
        $context["minValue"] = $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "validatorConfiguration", array()), "IntegerValueValidator", array()), "minIntegerValue", array());
        // line 110
        echo "    ";
        $this->displayBlock("settings_minimumvalue", $context, $blocks);
        echo "
    ";
        // line 111
        $context["maxValue"] = $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "validatorConfiguration", array()), "IntegerValueValidator", array()), "maxIntegerValue", array());
        // line 112
        echo "    ";
        $this->displayBlock("settings_maximumvalue", $context, $blocks);
        echo "
</ul>
";
    }

    // line 116
    public function block_ezfloat_settings($context, array $blocks = array())
    {
        // line 117
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 118
        $context["defaultValue"] = $this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "defaultValue", array()), "value", array());
        // line 119
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    ";
        // line 120
        $context["minValue"] = $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "validatorConfiguration", array()), "FloatValueValidator", array()), "minFloatValue", array());
        // line 121
        echo "    ";
        $this->displayBlock("settings_minimumvalue", $context, $blocks);
        echo "
    ";
        // line 122
        $context["maxValue"] = $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "validatorConfiguration", array()), "FloatValueValidator", array()), "maxFloatValue", array());
        // line 123
        echo "    ";
        $this->displayBlock("settings_maximumvalue", $context, $blocks);
        echo "
</ul>
";
    }

    // line 127
    public function block_ezselection_settings($context, array $blocks = array())
    {
        // line 128
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    <li class=\"options\">
        <span>Defined options</span>
        <ul>
        ";
        // line 132
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "options", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["option"]) {
            // line 133
            echo "            <li>";
            echo twig_escape_filter($this->env, $context["option"], "html", null, true);
            echo "</li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 135
        echo "        </ul>
    </li>
    ";
        // line 137
        $context["isMultiple"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "isMultiple", array());
        // line 138
        echo "    ";
        $this->displayBlock("settings_allowmultiple", $context, $blocks);
        echo "
</ul>
";
    }

    // line 143
    public function block_ezbinaryfile_settings($context, array $blocks = array())
    {
        // line 144
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 145
        $this->displayBlock("settings_maxfilesize", $context, $blocks);
        echo "
</ul>
";
    }

    // line 149
    public function block_ezmedia_settings($context, array $blocks = array())
    {
        // line 150
        $context["type"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "mediaType", array());
        // line 151
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 152
        $this->displayBlock("settings_maxfilesize", $context, $blocks);
        echo "
    <li class=\"media-player-type\">
        <span>Media player type:</span>
        ";
        // line 155
        if (((isset($context["type"]) ? $context["type"] : null) == "flash")) {
            // line 156
            echo "            Flash
        ";
        } elseif ((        // line 157
(isset($context["type"]) ? $context["type"] : null) == "quick_time")) {
            // line 158
            echo "            Quicktime
        ";
        } elseif ((        // line 159
(isset($context["type"]) ? $context["type"] : null) == "real_player")) {
            // line 160
            echo "            Real Player
        ";
        } elseif ((        // line 161
(isset($context["type"]) ? $context["type"] : null) == "silverlight")) {
            // line 162
            echo "            Silverlight
        ";
        } elseif ((        // line 163
(isset($context["type"]) ? $context["type"] : null) == "windows_media_player")) {
            // line 164
            echo "            Window Media Player
        ";
        } elseif ((        // line 165
(isset($context["type"]) ? $context["type"] : null) == "html5_video")) {
            // line 166
            echo "            HTML5 Video
        ";
        } elseif ((        // line 167
(isset($context["type"]) ? $context["type"] : null) == "html5_audio")) {
            // line 168
            echo "            HTML5 Audio
        ";
        } else {
            // line 170
            echo "            <em>No defined value</em>
        ";
        }
        // line 172
        echo "    </li>
</ul>
";
    }

    // line 176
    public function block_ezimage_settings($context, array $blocks = array())
    {
        // line 177
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 178
        $this->displayBlock("settings_maxfilesize", $context, $blocks);
        echo "
</ul>
";
    }

    // line 182
    public function block_ezobjectrelation_settings($context, array $blocks = array())
    {
        // line 183
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    <li class=\"selection-method\">
        <span>Selection method:</span>
        ";
        // line 186
        if (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "selectionMethod", array()) == 0)) {
            // line 187
            echo "            Browse
        ";
        } elseif (($this->getAttribute(        // line 188
(isset($context["settings"]) ? $context["settings"] : null), "selectionMethod", array()) == 1)) {
            // line 189
            echo "            Drop-down list
        ";
        } else {
            // line 191
            echo "            Drop-down tree
        ";
        }
        // line 193
        echo "    </li>
    ";
        // line 194
        $context["rootLocationId"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "selectionRoot", array());
        // line 195
        echo "    ";
        $this->displayBlock("settings_selectionroot", $context, $blocks);
        echo "
</ul>
";
    }

    // line 199
    public function block_ezobjectrelationlist_settings($context, array $blocks = array())
    {
        // line 200
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    <li class=\"selection-method\">
        <span>Selection method:</span>
        ";
        // line 203
        if (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "selectionMethod", array()) == 0)) {
            // line 204
            echo "            Browse
        ";
        } elseif (($this->getAttribute(        // line 205
(isset($context["settings"]) ? $context["settings"] : null), "selectionMethod", array()) == 1)) {
            // line 206
            echo "            Drop-down list
        ";
        } elseif (($this->getAttribute(        // line 207
(isset($context["settings"]) ? $context["settings"] : null), "selectionMethod", array()) == 2)) {
            // line 208
            echo "            List with radio buttons
        ";
        } elseif (($this->getAttribute(        // line 209
(isset($context["settings"]) ? $context["settings"] : null), "selectionMethod", array()) == 3)) {
            // line 210
            echo "            List with checkboxes
        ";
        } elseif (($this->getAttribute(        // line 211
(isset($context["settings"]) ? $context["settings"] : null), "selectionMethod", array()) == 4)) {
            // line 212
            echo "            Multiple selection list
        ";
        } elseif (($this->getAttribute(        // line 213
(isset($context["settings"]) ? $context["settings"] : null), "selectionMethod", array()) == 5)) {
            // line 214
            echo "            Template based, multi
        ";
        } else {
            // line 216
            echo "            Template based, single
        ";
        }
        // line 218
        echo "    </li>
    <li class=\"allowed-content-types\">
        <span>Allowed content types:</span>
        ";
        // line 221
        if ($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "selectionContentTypes", array())) {
            // line 222
            echo "            ";
            // line 223
            echo "            <ul>
            ";
            // line 224
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "selectionContentTypes", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["typeIdentifier"]) {
                // line 225
                echo "                <li>";
                echo twig_escape_filter($this->env, $context["typeIdentifier"], "html", null, true);
                echo "</li>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['typeIdentifier'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 227
            echo "            </ul>
        ";
        } else {
            // line 229
            echo "            <em>Any</em>
        ";
        }
        // line 231
        echo "    </li>
    ";
        // line 232
        $context["rootLocationId"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "selectionDefaultLocation", array());
        // line 233
        echo "    ";
        $this->displayBlock("settings_selectionroot", $context, $blocks);
        echo "
</ul>
";
    }

    // line 237
    public function block_ezpage_settings($context, array $blocks = array())
    {
        // line 238
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    <li class=\"default-layout\">
        <span>Default layout:</span>
        ";
        // line 241
        echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "defaultLayout", array())) ? ($this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "defaultLayout", array())) : ("None")), "html", null, true);
        echo "
    </li>
</ul>
";
    }

    // line 247
    public function block_ezauthor_settings($context, array $blocks = array())
    {
    }

    // line 249
    public function block_ezurl_settings($context, array $blocks = array())
    {
    }

    // line 251
    public function block_ezisbn_settings($context, array $blocks = array())
    {
        // line 252
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 253
        $context["defaultValue"] = "";
        // line 254
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    ";
        // line 255
        $context["isISBN13"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : null), "isISBN13", array());
        // line 256
        echo "    ";
        $this->displayBlock("settings_allowisbn13", $context, $blocks);
        echo "
</ul>
";
    }

    // line 260
    public function block_ezkeyword_settings($context, array $blocks = array())
    {
    }

    // line 262
    public function block_ezuser_settings($context, array $blocks = array())
    {
    }

    // line 264
    public function block_ezemail_settings($context, array $blocks = array())
    {
    }

    // line 266
    public function block_ezgmaplocation_settings($context, array $blocks = array())
    {
    }

    // line 268
    public function block_ezsrrating_settings($context, array $blocks = array())
    {
    }

    // line 270
    public function block_settings_maxfilesize($context, array $blocks = array())
    {
        // line 271
        echo "    <li class=\"maximum-file-size\">
        <span>Maximum file size:</span>
        ";
        // line 273
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "validatorConfiguration", array()), "FileSizeValidator", array()), "maxFileSize", array())) {
            // line 274
            echo "            ";
            // line 275
            echo "            ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : null), "validatorConfiguration", array()), "FileSizeValidator", array()), "maxFileSize", array()), "html", null, true);
            echo " bytes
        ";
        } else {
            // line 277
            echo "            <em>No defined maximum size</em>
        ";
        }
        // line 279
        echo "    </li>
";
    }

    // line 282
    public function block_settings_preferredrows($context, array $blocks = array())
    {
        // line 283
        echo "    <li class=\"preferred-rows-number\">
        <span>Preferred number of rows:</span>
        ";
        // line 285
        if ((isset($context["rows"]) ? $context["rows"] : null)) {
            // line 286
            echo "            ";
            echo twig_escape_filter($this->env, (isset($context["rows"]) ? $context["rows"] : null), "html", null, true);
            echo " rows
        ";
        } else {
            // line 288
            echo "            <em>No preferred number of rows</em>
        ";
        }
        // line 290
        echo "    </li>
";
    }

    // line 293
    public function block_settings_selectionroot($context, array $blocks = array())
    {
        // line 294
        echo "    <li class=\"selection-root\">
        <span>Selection root:</span>
        ";
        // line 296
        if ((isset($context["rootLocationId"]) ? $context["rootLocationId"] : null)) {
            // line 297
            echo "            ";
            // line 298
            echo "            ";
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("ez_content:viewLocation", array("locationId" => (isset($context["rootLocationId"]) ? $context["rootLocationId"] : null), "viewType" => "line")), array("strategy" => "esi"));
            echo "
        ";
        } else {
            // line 300
            echo "            <em>No defined root</em>
        ";
        }
        // line 302
        echo "    </li>
";
    }

    // line 305
    public function block_settings_defaultvalue($context, array $blocks = array())
    {
        // line 306
        echo "    <li class=\"default-value\">
        <span>Default value:</span>
        ";
        // line 308
        if ((isset($context["defaultValue"]) ? $context["defaultValue"] : null)) {
            // line 309
            echo "            ";
            echo twig_escape_filter($this->env, (isset($context["defaultValue"]) ? $context["defaultValue"] : null), "html", null, true);
            echo "
        ";
        } else {
            // line 311
            echo "            <em>No default value</em>
        ";
        }
        // line 313
        echo "    </li>
";
    }

    // line 316
    public function block_settings_minimumvalue($context, array $blocks = array())
    {
        // line 317
        echo "    <li class=\"min-value\">
        <span>Minimum value:</span>
        ";
        // line 319
        if ((isset($context["minValue"]) ? $context["minValue"] : null)) {
            // line 320
            echo "            ";
            echo twig_escape_filter($this->env, (isset($context["minValue"]) ? $context["minValue"] : null), "html", null, true);
            echo "
        ";
        } else {
            // line 322
            echo "            <em>No defined minimum value</em>
        ";
        }
        // line 324
        echo "    </li>
";
    }

    // line 327
    public function block_settings_maximumvalue($context, array $blocks = array())
    {
        // line 328
        echo "    <li class=\"max-value\">
        <span>Maximum value:</span>
        ";
        // line 330
        if ((isset($context["maxValue"]) ? $context["maxValue"] : null)) {
            // line 331
            echo "            ";
            echo twig_escape_filter($this->env, (isset($context["maxValue"]) ? $context["maxValue"] : null), "html", null, true);
            echo "
        ";
        } else {
            // line 333
            echo "            <em>No defined maximum value</em>
        ";
        }
        // line 335
        echo "    </li>
";
    }

    // line 338
    public function block_settings_allowmultiple($context, array $blocks = array())
    {
        // line 339
        echo "    <li class=\"multiple\">
        <span>Allow multiple choices:</span>
        ";
        // line 341
        echo (((isset($context["isMultiple"]) ? $context["isMultiple"] : null)) ? ("Yes") : ("No"));
        echo "
    </li>
";
    }

    // line 345
    public function block_settings_allowisbn13($context, array $blocks = array())
    {
        // line 346
        echo "    <li class=\"isbn\">
        <span>Selected ISBN format:</span>
        ";
        // line 348
        echo (((isset($context["isISBN13"]) ? $context["isISBN13"] : null)) ? ("ISBN-13") : ("ISBN-10"));
        echo "
    </li>
";
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle::fielddefinition_settings.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  1055 => 348,  1051 => 346,  1048 => 345,  1041 => 341,  1037 => 339,  1034 => 338,  1029 => 335,  1025 => 333,  1019 => 331,  1017 => 330,  1013 => 328,  1010 => 327,  1005 => 324,  1001 => 322,  995 => 320,  993 => 319,  989 => 317,  986 => 316,  981 => 313,  977 => 311,  971 => 309,  969 => 308,  965 => 306,  962 => 305,  957 => 302,  953 => 300,  947 => 298,  945 => 297,  943 => 296,  939 => 294,  936 => 293,  931 => 290,  927 => 288,  921 => 286,  919 => 285,  915 => 283,  912 => 282,  907 => 279,  903 => 277,  897 => 275,  895 => 274,  893 => 273,  889 => 271,  886 => 270,  881 => 268,  876 => 266,  871 => 264,  866 => 262,  861 => 260,  853 => 256,  851 => 255,  846 => 254,  844 => 253,  839 => 252,  836 => 251,  831 => 249,  826 => 247,  818 => 241,  811 => 238,  808 => 237,  800 => 233,  798 => 232,  795 => 231,  791 => 229,  787 => 227,  778 => 225,  774 => 224,  771 => 223,  769 => 222,  767 => 221,  762 => 218,  758 => 216,  754 => 214,  752 => 213,  749 => 212,  747 => 211,  744 => 210,  742 => 209,  739 => 208,  737 => 207,  734 => 206,  732 => 205,  729 => 204,  727 => 203,  720 => 200,  717 => 199,  709 => 195,  707 => 194,  704 => 193,  700 => 191,  696 => 189,  694 => 188,  691 => 187,  689 => 186,  682 => 183,  679 => 182,  672 => 178,  667 => 177,  664 => 176,  658 => 172,  654 => 170,  650 => 168,  648 => 167,  645 => 166,  643 => 165,  640 => 164,  638 => 163,  635 => 162,  633 => 161,  630 => 160,  628 => 159,  625 => 158,  623 => 157,  620 => 156,  618 => 155,  612 => 152,  607 => 151,  605 => 150,  602 => 149,  595 => 145,  590 => 144,  587 => 143,  579 => 138,  577 => 137,  573 => 135,  564 => 133,  560 => 132,  552 => 128,  549 => 127,  541 => 123,  539 => 122,  534 => 121,  532 => 120,  527 => 119,  525 => 118,  520 => 117,  517 => 116,  509 => 112,  507 => 111,  502 => 110,  500 => 109,  495 => 108,  493 => 107,  488 => 106,  485 => 105,  477 => 100,  470 => 97,  467 => 96,  464 => 95,  461 => 94,  458 => 93,  456 => 92,  451 => 91,  448 => 90,  440 => 86,  437 => 85,  434 => 84,  431 => 83,  428 => 82,  426 => 81,  421 => 80,  418 => 79,  410 => 74,  403 => 71,  400 => 70,  397 => 69,  394 => 68,  391 => 67,  388 => 66,  385 => 65,  382 => 64,  379 => 63,  376 => 62,  373 => 61,  370 => 60,  367 => 59,  364 => 58,  362 => 57,  357 => 56,  354 => 55,  348 => 51,  344 => 49,  340 => 47,  338 => 46,  331 => 43,  328 => 42,  320 => 38,  318 => 37,  313 => 36,  299 => 35,  296 => 34,  278 => 33,  276 => 32,  271 => 31,  268 => 30,  260 => 26,  258 => 25,  253 => 24,  250 => 23,  244 => 19,  240 => 17,  234 => 15,  232 => 14,  225 => 11,  223 => 10,  218 => 9,  215 => 8,  211 => 345,  208 => 344,  206 => 338,  203 => 337,  201 => 327,  198 => 326,  196 => 316,  193 => 315,  191 => 305,  188 => 304,  186 => 293,  183 => 292,  181 => 282,  178 => 281,  176 => 270,  173 => 269,  171 => 268,  168 => 267,  166 => 266,  163 => 265,  161 => 264,  158 => 263,  156 => 262,  153 => 261,  151 => 260,  148 => 259,  146 => 251,  143 => 250,  141 => 249,  138 => 248,  136 => 247,  132 => 245,  130 => 237,  127 => 236,  125 => 199,  122 => 198,  120 => 182,  117 => 181,  115 => 176,  112 => 175,  110 => 149,  107 => 148,  105 => 143,  101 => 141,  99 => 127,  96 => 126,  94 => 116,  91 => 115,  89 => 105,  86 => 104,  84 => 90,  81 => 89,  79 => 79,  76 => 78,  74 => 55,  71 => 54,  69 => 42,  66 => 41,  64 => 30,  61 => 29,  59 => 23,  56 => 22,  54 => 8,  51 => 7,);
    }
}
/* {# Template blocks used to render the settings of each field definition #}*/
/* {# Block naming convention is <fieldTypeIdentifier>_settings> #}*/
/* {# The following variables are available in each block:*/
/*  #  - \eZ\Publish\API\Repository\Values\ContentType\FieldDefinition fielddefinition the field definition*/
/*  #  - array settings settings of the field definition*/
/*  #}*/
/* */
/* {% block ezstring_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set defaultValue = fielddefinition.defaultValue.text %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     <li class="max-length">*/
/*         <span>Max string length:</span>*/
/*         {% if fielddefinition.validatorConfiguration.StringLengthValidator.maxStringLength %}*/
/*             {{ fielddefinition.validatorConfiguration.StringLengthValidator.maxStringLength }} characters*/
/*         {% else %}*/
/*             <em>No defined maximum string length</em>*/
/*         {% endif %}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block eztext_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set rows = settings.textRows %}*/
/*     {{ block( 'settings_preferredrows' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezcountry_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set defaultValue = '' %}*/
/*     {% for country in fielddefinition.defaultValue.countries %}*/
/*         {% set defaultValue = defaultValue ~ country.Name ~ ( not loop.last ? ', ' : '' ) %}*/
/*     {% endfor %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     {% set isMultiple = settings.isMultiple %}*/
/*     {{ block( 'settings_allowmultiple' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezboolean_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     <li class="default-value">*/
/*         <span>Default value:</span>*/
/*         {% if fielddefinition.defaultValue.bool %}*/
/*             Checked*/
/*         {% else %}*/
/*             Unchecked*/
/*         {% endif %}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezdatetime_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% if settings.defaultType == constant( 'eZ\\Publish\\Core\\FieldType\\DateAndTime\\Type::DEFAULT_EMPTY' ) %}*/
/*         {% set defaultValue = 'Empty' %}*/
/*     {% elseif settings.defaultType == constant( 'eZ\\Publish\\Core\\FieldType\\DateAndTime\\Type::DEFAULT_CURRENT_DATE' ) %}*/
/*         {% set defaultValue = 'Current datetime' %}*/
/*     {% else %}*/
/*         {% set interval = settings.dateInterval %}*/
/*         {% set defaultValue = 'Current datetime adjusted by ' %}*/
/*         {% set defaultValue = interval.y ? defaultValue ~ interval.y ~ ' year(s)' : defaultValue %}*/
/*         {% set defaultValue = interval.m ? defaultValue ~ interval.m ~ ' month(s)' : defaultValue %}*/
/*         {% set defaultValue = interval.d ? defaultValue ~ interval.d ~ ' day(s)' : defaultValue %}*/
/*         {% set defaultValue = interval.h ? defaultValue ~ interval.h ~ ' hour(s)' : defaultValue %}*/
/*         {% set defaultValue = interval.i ? defaultValue ~ interval.i ~ ' minute(s)' : defaultValue %}*/
/*         {% set defaultValue = interval.s and settings.useSeconds ? defaultValue ~ interval.s ~ ' second(s)' : defaultValue %}*/
/*     {% endif %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     <li class="use-seconds">*/
/*         <span>Use seconds:</span>*/
/*         {{ settings.useSeconds ? 'Yes' : 'No' }}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezdate_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% if settings.defaultType == constant( 'eZ\\Publish\\Core\\FieldType\\Date\\Type::DEFAULT_EMPTY' ) %}*/
/*         {% set defaultValue = 'Empty' %}*/
/*     {% else %}*/
/*         {% set defaultValue = 'Current date' %}*/
/*     {% endif %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block eztime_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% if settings.defaultType == constant( 'eZ\\Publish\\Core\\FieldType\\Time\\Type::DEFAULT_EMPTY' ) %}*/
/*         {% set defaultValue = 'Empty' %}*/
/*     {% else %}*/
/*         {% set defaultValue = 'Current time' %}*/
/*     {% endif %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     <li class="use-seconds">*/
/*         <span>Use seconds:</span>*/
/*         {{ settings.useSeconds ? 'Yes' : 'No' }}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezinteger_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set defaultValue = fielddefinition.defaultValue.value %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     {% set minValue = fielddefinition.validatorConfiguration.IntegerValueValidator.minIntegerValue %}*/
/*     {{ block( 'settings_minimumvalue' ) }}*/
/*     {% set maxValue = fielddefinition.validatorConfiguration.IntegerValueValidator.maxIntegerValue %}*/
/*     {{ block( 'settings_maximumvalue' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezfloat_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set defaultValue = fielddefinition.defaultValue.value %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     {% set minValue = fielddefinition.validatorConfiguration.FloatValueValidator.minFloatValue %}*/
/*     {{ block( 'settings_minimumvalue' ) }}*/
/*     {% set maxValue = fielddefinition.validatorConfiguration.FloatValueValidator.maxFloatValue %}*/
/*     {{ block( 'settings_maximumvalue' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezselection_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     <li class="options">*/
/*         <span>Defined options</span>*/
/*         <ul>*/
/*         {% for option in settings.options %}*/
/*             <li>{{ option }}</li>*/
/*         {% endfor %}*/
/*         </ul>*/
/*     </li>*/
/*     {% set isMultiple = settings.isMultiple %}*/
/*     {{ block( 'settings_allowmultiple' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* */
/* {% block ezbinaryfile_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {{ block( 'settings_maxfilesize' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezmedia_settings %}*/
/* {% set type = settings.mediaType %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {{ block( 'settings_maxfilesize' ) }}*/
/*     <li class="media-player-type">*/
/*         <span>Media player type:</span>*/
/*         {% if type == 'flash' %}*/
/*             Flash*/
/*         {% elseif type == 'quick_time' %}*/
/*             Quicktime*/
/*         {% elseif type == 'real_player' %}*/
/*             Real Player*/
/*         {% elseif type == 'silverlight' %}*/
/*             Silverlight*/
/*         {% elseif type == 'windows_media_player' %}*/
/*             Window Media Player*/
/*         {% elseif type == 'html5_video' %}*/
/*             HTML5 Video*/
/*         {% elseif type == 'html5_audio' %}*/
/*             HTML5 Audio*/
/*         {% else %}*/
/*             <em>No defined value</em>*/
/*         {% endif %}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezimage_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {{ block( 'settings_maxfilesize' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezobjectrelation_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     <li class="selection-method">*/
/*         <span>Selection method:</span>*/
/*         {% if settings.selectionMethod == 0 %}*/
/*             Browse*/
/*         {% elseif settings.selectionMethod == 1 %}*/
/*             Drop-down list*/
/*         {% else %}*/
/*             Drop-down tree*/
/*         {% endif %}*/
/*     </li>*/
/*     {% set rootLocationId = settings.selectionRoot %}*/
/*     {{ block( 'settings_selectionroot' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezobjectrelationlist_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     <li class="selection-method">*/
/*         <span>Selection method:</span>*/
/*         {% if settings.selectionMethod == 0 %}*/
/*             Browse*/
/*         {% elseif settings.selectionMethod == 1 %}*/
/*             Drop-down list*/
/*         {% elseif settings.selectionMethod == 2 %}*/
/*             List with radio buttons*/
/*         {% elseif settings.selectionMethod == 3 %}*/
/*             List with checkboxes*/
/*         {% elseif settings.selectionMethod == 4 %}*/
/*             Multiple selection list*/
/*         {% elseif settings.selectionMethod == 5 %}*/
/*             Template based, multi*/
/*         {% else %}*/
/*             Template based, single*/
/*         {% endif %}*/
/*     </li>*/
/*     <li class="allowed-content-types">*/
/*         <span>Allowed content types:</span>*/
/*         {% if settings.selectionContentTypes %}*/
/*             {# TODO display content type name #}*/
/*             <ul>*/
/*             {% for typeIdentifier in settings.selectionContentTypes %}*/
/*                 <li>{{ typeIdentifier }}</li>*/
/*             {% endfor %}*/
/*             </ul>*/
/*         {% else %}*/
/*             <em>Any</em>*/
/*         {% endif %}*/
/*     </li>*/
/*     {% set rootLocationId = settings.selectionDefaultLocation %}*/
/*     {{ block( 'settings_selectionroot' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezpage_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     <li class="default-layout">*/
/*         <span>Default layout:</span>*/
/*         {{ settings.defaultLayout ? settings.defaultLayout : "None" }}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* */
/* {% block ezauthor_settings %}{% endblock %}*/
/* */
/* {% block ezurl_settings %}{% endblock %}*/
/* */
/* {% block ezisbn_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set defaultValue = '' %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     {% set isISBN13 = settings.isISBN13 %}*/
/*     {{ block( 'settings_allowisbn13' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezkeyword_settings %}{% endblock %}*/
/* */
/* {% block ezuser_settings %}{% endblock %}*/
/* */
/* {% block ezemail_settings %}{% endblock %}*/
/* */
/* {% block ezgmaplocation_settings %}{% endblock %}*/
/* */
/* {% block ezsrrating_settings %}{% endblock %}*/
/* */
/* {% block settings_maxfilesize %}*/
/*     <li class="maximum-file-size">*/
/*         <span>Maximum file size:</span>*/
/*         {% if fielddefinition.validatorConfiguration.FileSizeValidator.maxFileSize %}*/
/*             {# TODO l10n / unit #}*/
/*             {{ fielddefinition.validatorConfiguration.FileSizeValidator.maxFileSize }} bytes*/
/*         {% else %}*/
/*             <em>No defined maximum size</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_preferredrows %}*/
/*     <li class="preferred-rows-number">*/
/*         <span>Preferred number of rows:</span>*/
/*         {% if rows %}*/
/*             {{ rows }} rows*/
/*         {% else %}*/
/*             <em>No preferred number of rows</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_selectionroot %}*/
/*     <li class="selection-root">*/
/*         <span>Selection root:</span>*/
/*         {% if rootLocationId %}*/
/*             {# TODO: use a dedicated viewType #}*/
/*             {{ render( controller( "ez_content:viewLocation", {'locationId': rootLocationId, 'viewType': 'line'} ), {'strategy': 'esi'} ) }}*/
/*         {% else %}*/
/*             <em>No defined root</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_defaultvalue %}*/
/*     <li class="default-value">*/
/*         <span>Default value:</span>*/
/*         {% if defaultValue %}*/
/*             {{ defaultValue }}*/
/*         {% else %}*/
/*             <em>No default value</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_minimumvalue %}*/
/*     <li class="min-value">*/
/*         <span>Minimum value:</span>*/
/*         {% if minValue %}*/
/*             {{ minValue }}*/
/*         {% else %}*/
/*             <em>No defined minimum value</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_maximumvalue %}*/
/*     <li class="max-value">*/
/*         <span>Maximum value:</span>*/
/*         {% if maxValue %}*/
/*             {{ maxValue }}*/
/*         {% else %}*/
/*             <em>No defined maximum value</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_allowmultiple %}*/
/*     <li class="multiple">*/
/*         <span>Allow multiple choices:</span>*/
/*         {{ isMultiple ? 'Yes' : 'No' }}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_allowisbn13 %}*/
/*     <li class="isbn">*/
/*         <span>Selected ISBN format:</span>*/
/*         {{ isISBN13 ? 'ISBN-13' : 'ISBN-10' }}*/
/*     </li>*/
/* {% endblock %}*/
/* */
