<?php

/* EzSystemsRepositoryFormsBundle:content_name:content_name.html.twig */
class __TwigTemplate_a3af8d793792117a7cd0d9cefcf901510386514c52e70c6274c8362b2884ecda extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((isset($context["viewbaseLayout"]) ? $context["viewbaseLayout"] : null), "EzSystemsRepositoryFormsBundle:content_name:content_name.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : null)), "html", null, true);
        echo "
";
    }

    public function getTemplateName()
    {
        return "EzSystemsRepositoryFormsBundle:content_name:content_name.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  27 => 2,  18 => 1,);
    }
}
/* {% extends viewbaseLayout %}*/
/* {% block content %}*/
/* {{ ez_content_name( content ) }}*/
/* {% endblock %}*/
/* */
