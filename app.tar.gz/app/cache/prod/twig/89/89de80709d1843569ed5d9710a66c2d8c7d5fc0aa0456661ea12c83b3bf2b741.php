<?php

/* eZPlatformUIBundle:Section:create.html.twig */
class __TwigTemplate_577d18c658168e18150454f75bd45e6b11456bb0c8b847e081d92e4a42ba1200 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Section:create.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.create.title", array(), "section"), "html", null, true);
    }

    // line 7
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_sectionlist"), "label" => $this->env->getExtension('translator')->trans("section.list", array(), "section")), 2 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("section.create.title", array(), "section")));
        // line 13
        echo "
    ";
        // line 14
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 17
    public function block_header_title($context, array $blocks = array())
    {
        // line 18
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.create.title", array(), "section"), "html", null, true);
        echo "</h1>
";
    }

    // line 21
    public function block_content($context, array $blocks = array())
    {
        // line 22
        echo "    <section class=\"ez-serverside-content\">
        <ul class=\"ez-simpleform-error\">
            ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 25
            echo "                <li class=\"ez-simpleform-error-item\">";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "</li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "        </ul>

        ";
        // line 29
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form');
        echo "
    </section>
";
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Section:create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 29,  82 => 27,  73 => 25,  69 => 24,  65 => 22,  62 => 21,  55 => 18,  52 => 17,  46 => 14,  43 => 13,  40 => 8,  37 => 7,  31 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "section" %}*/
/* */
/* {% block title %}{{ 'section.create.title'|trans }}{% endblock %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_sectionlist'), label: 'section.list'|trans({}, 'section')},*/
/*         {link: '', label: 'section.create.title'|trans}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'section.create.title'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <ul class="ez-simpleform-error">*/
/*             {% for flashMessage in app.session.flashbag.get('error') %}*/
/*                 <li class="ez-simpleform-error-item">{{ flashMessage }}</li>*/
/*             {% endfor %}*/
/*         </ul>*/
/* */
/*         {{ form(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
