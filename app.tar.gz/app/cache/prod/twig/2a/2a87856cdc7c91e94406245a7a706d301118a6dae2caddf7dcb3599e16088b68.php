<?php

/* EzPublishCoreBundle:FieldType/RichText/embed:location_inline.html.twig */
class __TwigTemplate_096bce4dec61387d3d9a132ccb38bc5c1086c6d3cf134963d91fa910fe1a4bc9 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["params"] = array("objectParameters" => array());
        // line 2
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "config", array(), "any", true, true)) {
            // line 3
            echo "    ";
            $context["params"] = twig_array_merge((isset($context["params"]) ? $context["params"] : null), array("objectParameters" => $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "config", array())));
        }
        // line 5
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "link", array(), "any", true, true)) {
            // line 6
            echo "    ";
            $context["params"] = twig_array_merge((isset($context["params"]) ? $context["params"] : null), array("linkParameters" => $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "link", array())));
        }
        // line 8
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("ez_content:viewLocation", array("locationId" => $this->getAttribute(        // line 13
(isset($context["embedParams"]) ? $context["embedParams"] : null), "id", array()), "viewType" => $this->getAttribute(        // line 14
(isset($context["embedParams"]) ? $context["embedParams"] : null), "viewType", array()), "params" =>         // line 15
(isset($context["params"]) ? $context["params"] : null))));
        // line 19
        echo "
";
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/embed:location_inline.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  38 => 19,  36 => 15,  35 => 14,  34 => 13,  33 => 8,  29 => 6,  27 => 5,  23 => 3,  21 => 2,  19 => 1,);
    }
}
/* {% set params = { "objectParameters": {} } %}*/
/* {% if embedParams.config is defined  %}*/
/*     {% set params = params|merge( { "objectParameters": embedParams.config } ) %}*/
/* {% endif %}*/
/* {% if embedParams.link is defined  %}*/
/*     {% set params = params|merge( { "linkParameters": embedParams.link } ) %}*/
/* {% endif %}*/
/* {{*/
/*     render(*/
/*         controller(*/
/*             "ez_content:viewLocation",*/
/*             {*/
/*                 "locationId": embedParams.id,*/
/*                 "viewType": embedParams.viewType,*/
/*                 "params": params*/
/*             }*/
/*         )*/
/*     )*/
/* }}*/
/* */
