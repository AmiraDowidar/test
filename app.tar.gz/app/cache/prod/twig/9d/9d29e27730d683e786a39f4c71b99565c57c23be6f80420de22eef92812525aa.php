<?php

/* EzPublishCoreBundle:Security:login.html.twig */
class __TwigTemplate_db213e2fbc83d4a989a238da422fdfc48c921e9a0ece4d6eef11437f93594109 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'login_content' => array($this, 'block_login_content'),
            'login_fields' => array($this, 'block_login_fields'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((isset($context["layout"]) ? $context["layout"] : null), "EzPublishCoreBundle:Security:login.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $this->displayBlock('login_content', $context, $blocks);
    }

    public function block_login_content($context, array $blocks = array())
    {
        // line 5
        echo "        <div class=\"page-header\">
            <h1>";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Login"), "html", null, true);
        echo "</h1>
        </div>

        ";
        // line 9
        if ((isset($context["error"]) ? $context["error"] : null)) {
            // line 10
            echo "            <div class=\"alert alert-danger\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute((isset($context["error"]) ? $context["error"] : null), "message", array())), "html", null, true);
            echo "</div>
        ";
        }
        // line 12
        echo "
        <form action=\"";
        // line 13
        echo $this->env->getExtension('routing')->getPath("login_check");
        echo "\" method=\"post\" role=\"form\">
            ";
        // line 14
        $this->displayBlock('login_fields', $context, $blocks);
        // line 35
        echo "        </form>
    ";
    }

    // line 14
    public function block_login_fields($context, array $blocks = array())
    {
        // line 15
        echo "                <fieldset>
                    <div class=\"form-group\">
                        <label for=\"username\">";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Username:"), "html", null, true);
        echo "</label>
                        <input type=\"text\" id=\"username\" class=\"form-control\" name=\"_username\" value=\"";
        // line 18
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : null), "html", null, true);
        echo "\" required=\"required\" autofocus=\"autofocus\" autocomplete=\"on\" placeholder=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Enter login or email"), "html", null, true);
        echo "\" />
                    </div>
                    <div class=\"form-group";
        // line 20
        if ((isset($context["error"]) ? $context["error"] : null)) {
            echo " has-error";
        }
        echo "\">
                        <label for=\"password\">";
        // line 21
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Password:"), "html", null, true);
        echo "</label>
                        <input type=\"password\" id=\"password\" class=\"form-control\" name=\"_password\" required=\"required\" placeholder=\"";
        // line 22
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Enter password"), "html", null, true);
        echo "\" />
                    </div>

                    <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('form')->renderCsrfToken("authenticate"), "html", null, true);
        echo "\" />

                    ";
        // line 32
        echo "                    <button type=\"submit\" class=\"btn btn-primary\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("Login"), "html", null, true);
        echo "</button>
                </fieldset>
            ";
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  109 => 32,  104 => 25,  98 => 22,  94 => 21,  88 => 20,  81 => 18,  77 => 17,  73 => 15,  70 => 14,  65 => 35,  63 => 14,  59 => 13,  56 => 12,  50 => 10,  48 => 9,  42 => 6,  39 => 5,  32 => 4,  29 => 3,  20 => 1,);
    }
}
/* {% extends layout %}*/
/* */
/* {% block content %}*/
/*     {% block login_content %}*/
/*         <div class="page-header">*/
/*             <h1>{{ 'Login'|trans }}</h1>*/
/*         </div>*/
/* */
/*         {% if error %}*/
/*             <div class="alert alert-danger">{{ error.message|trans }}</div>*/
/*         {% endif %}*/
/* */
/*         <form action="{{ path( 'login_check' ) }}" method="post" role="form">*/
/*             {% block login_fields %}*/
/*                 <fieldset>*/
/*                     <div class="form-group">*/
/*                         <label for="username">{{ 'Username:'|trans }}</label>*/
/*                         <input type="text" id="username" class="form-control" name="_username" value="{{ last_username }}" required="required" autofocus="autofocus" autocomplete="on" placeholder="{{ 'Enter login or email'|trans }}" />*/
/*                     </div>*/
/*                     <div class="form-group{% if error %} has-error{% endif %}">*/
/*                         <label for="password">{{ 'Password:'|trans }}</label>*/
/*                         <input type="password" id="password" class="form-control" name="_password" required="required" placeholder="{{ 'Enter password'|trans }}" />*/
/*                     </div>*/
/* */
/*                     <input type="hidden" name="_csrf_token" value="{{ csrf_token("authenticate") }}" />*/
/* */
/*                     {#*/
/*                         If you want to control the URL the user*/
/*                         is redirected to on success (more details below)*/
/*                         <input type="hidden" name="_target_path" value="/account" />*/
/*                     #}*/
/*                     <button type="submit" class="btn btn-primary">{{ 'Login'|trans }}</button>*/
/*                 </fieldset>*/
/*             {% endblock %}*/
/*         </form>*/
/*     {% endblock %}*/
/* {% endblock %}*/
/* */
