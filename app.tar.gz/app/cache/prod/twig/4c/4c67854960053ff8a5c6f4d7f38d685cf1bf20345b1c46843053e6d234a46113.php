<?php

/* :line:ride.html.twig */
class __TwigTemplate_e12580b98f5dada8c8b1e0b0ecc0065c3f7872b2372e5bcb1776e33956ba0ab5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"col-xs-6 col-sm-3 col-md-3 col-lg-3\">
\t<!-- <i class=\"icon-earth\"></i> -->
\t<img src=\"";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/earth.svg"), "html", null, true);
        echo "\" alt=\"\" />
\t<br>
\t<span>
\t  ";
        // line 6
        echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : null)), "html", null, true);
        echo "
\t</span>
</div>";
    }

    public function getTemplateName()
    {
        return ":line:ride.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 6,  23 => 3,  19 => 1,);
    }
}
/* <div class="col-xs-6 col-sm-3 col-md-3 col-lg-3">*/
/* 	<!-- <i class="icon-earth"></i> -->*/
/* 	<img src="{{ asset('assets/images/earth.svg') }}" alt="" />*/
/* 	<br>*/
/* 	<span>*/
/* 	  {{ ez_content_name( content ) }}*/
/* 	</span>*/
/* </div>*/
