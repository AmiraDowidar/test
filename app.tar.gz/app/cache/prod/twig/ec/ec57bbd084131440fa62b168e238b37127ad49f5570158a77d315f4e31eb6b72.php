<?php

/* EzPublishCoreBundle:FieldType/RichText/tag:default_inline.html.twig */
class __TwigTemplate_3e07dfdca54d1c30e1c6e9accaab807f26550bd6457ae86cf45d6a9519885711 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "[[ RichText template tag <strong>";
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : null), "html", null, true);
        echo "</strong> is not configured ]]
";
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/tag:default_inline.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  19 => 1,);
    }
}
/* [[ RichText template tag <strong>{{ name }}</strong> is not configured ]]*/
/* */
