<?php

/* :full:ride.html.twig */
class __TwigTemplate_fb33a12a7a84b1b10a1ff107e66e355a2d12cf8ece43700571169aa5ae6aaee2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("pagelayout.html.twig", ":full:ride.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "pagelayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "
 <section class=\"top-banner\" style=\"background-image: url('";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/Libon-Out.jpg"), "html", null, true);
        echo "');\">
    <div class=\"mask\">

      <div class=\"container\">
        
        ";
        // line 10
        $this->loadTemplate("pagelayout_header.html.twig", ":full:ride.html.twig", 10)->display($context);
        // line 11
        echo "
        <!-- intro text -->
        <h2 class=\"text-center\">Cheap international calls</h2>
        <h3 class=\"text-center\">whenever you want</h3>

        <!-- search bar -->
        <div class=\"search-bar text-center\">
          <form action=\"\">
            <div class=\"row\">
              <i class=\"icon-search\"></i>
              <input type=\"search\" placeholder=\"Where do you want to call ?\" class=\"text-center\">
            </div>
          </form>
          <a href=\"#\">SEE ALL DESTINATIONS</a>
        </div>
        <!-- download app -->
        <div class=\"platforms text-center\">
          <a href=\"#\">
            <img src=\"";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/Apple-Store.png"), "html", null, true);
        echo "\" alt=\"\" />
          </a>
          <a href=\"#\">
            <img src=\"";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/Google-Play.png"), "html", null, true);
        echo "\" alt=\"\" />
          </a>
        </div>
      </div>
    </div>
</section>

<h2>Ride:</h2>

<h2>";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : null)), "html", null, true);
        echo "</h2>


";
    }

    public function getTemplateName()
    {
        return ":full:ride.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 41,  70 => 32,  64 => 29,  44 => 11,  42 => 10,  34 => 5,  31 => 4,  28 => 3,  11 => 1,);
    }
}
/* {% extends "pagelayout.html.twig" %}*/
/* */
/* {% block content %}*/
/* */
/*  <section class="top-banner" style="background-image: url('{{ asset('assets/images/Libon-Out.jpg') }}');">*/
/*     <div class="mask">*/
/* */
/*       <div class="container">*/
/*         */
/*         {% include 'pagelayout_header.html.twig' %}*/
/* */
/*         <!-- intro text -->*/
/*         <h2 class="text-center">Cheap international calls</h2>*/
/*         <h3 class="text-center">whenever you want</h3>*/
/* */
/*         <!-- search bar -->*/
/*         <div class="search-bar text-center">*/
/*           <form action="">*/
/*             <div class="row">*/
/*               <i class="icon-search"></i>*/
/*               <input type="search" placeholder="Where do you want to call ?" class="text-center">*/
/*             </div>*/
/*           </form>*/
/*           <a href="#">SEE ALL DESTINATIONS</a>*/
/*         </div>*/
/*         <!-- download app -->*/
/*         <div class="platforms text-center">*/
/*           <a href="#">*/
/*             <img src="{{ asset('assets/images/Apple-Store.png') }}" alt="" />*/
/*           </a>*/
/*           <a href="#">*/
/*             <img src="{{ asset('assets/images/Google-Play.png') }}" alt="" />*/
/*           </a>*/
/*         </div>*/
/*       </div>*/
/*     </div>*/
/* </section>*/
/* */
/* <h2>Ride:</h2>*/
/* */
/* <h2>{{ ez_content_name( content ) }}</h2>*/
/* */
/* */
/* {% endblock %} */
