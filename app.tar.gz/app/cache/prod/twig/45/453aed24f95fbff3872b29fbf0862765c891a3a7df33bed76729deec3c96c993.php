<?php

/* eZPlatformUIBundle:ContentType:list_content_type_groups.html.twig */
class __TwigTemplate_552ea58ac97712bf8acc99c0e5d3ca5eb5c05b63625a6a26d8e75b00f4993dfb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:ContentType:list_content_type_groups.html.twig", 1);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 6
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_contenttype"), "label" => $this->env->getExtension('translator')->trans("content_type.dashboard_title", array(), "content_type")), 2 => array("link" => null, "label" => $this->env->getExtension('translator')->trans("content_type.group.list", array(), "content_type")));
        // line 11
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 14
    public function block_header_title($context, array $blocks = array())
    {
        // line 15
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.list", array(), "content_type"), "html", null, true);
        echo "</h1>
";
    }

    // line 18
    public function block_content($context, array $blocks = array())
    {
        // line 19
        echo "    <section class=\"ez-serverside-content\">
        <div class=\"ez-table-data is-flexible\">
            <div class=\"ez-table-data-container\">
                <table class=\"pure-table pure-table-striped ez-selection-table\">
                    <thead>
                    <tr class=\"ez-selection-table-row\">
                        <th>";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.name", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th>";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.id", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th></th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["content_type_groups"]) ? $context["content_type_groups"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 33
            echo "                        ";
            // line 34
            echo "                        <tr>
                            <td><a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_contenttypeGroupView", array("contentTypeGroupId" => $this->getAttribute($context["group"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "identifier", array()), "html", null, true);
            echo "</a></td>
                            <td>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "id", array()), "html", null, true);
            echo "</td>
                            <td>
                            ";
            // line 38
            if ((isset($context["can_edit"]) ? $context["can_edit"] : null)) {
                // line 39
                echo "                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_contenttypeGroupEdit", array("contentTypeGroupId" => $this->getAttribute($context["group"], "id", array()))), "html", null, true);
                echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.edit", array(), "content_type"), "html", null, true);
                echo "</a>
                            ";
            } else {
                // line 41
                echo "                                <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.edit", array(), "content_type"), "html", null, true);
                echo "</span>
                            ";
            }
            // line 43
            echo "                            </td>
                            <td>
                                ";
            // line 45
            $context["deleteForm"] = $this->getAttribute((isset($context["delete_forms_by_id"]) ? $context["delete_forms_by_id"] : null), $this->getAttribute($context["group"], "id", array()), array(), "array");
            // line 46
            echo "                                ";
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_contenttypeGroupDelete", array("contentTypeGroupId" => $this->getAttribute($context["group"], "id", array())))));
            echo "
                                ";
            // line 47
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : null), "contentTypeGroupId", array()), 'widget');
            echo "
                                ";
            // line 48
            echo             // line 49
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(            // line 50
(isset($context["deleteForm"]) ? $context["deleteForm"] : null), "delete", array()), 'widget', array("disabled" =>  !            // line 52
(isset($context["can_delete"]) ? $context["can_delete"] : null), "attr" => array("class" => "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete")));
            // line 56
            echo "
                                ";
            // line 57
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_end');
            echo "
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "                    </tbody>
                </table>
                <p class=\"ez-table-data-buttons\">
                    ";
        // line 64
        if ((isset($context["can_edit"]) ? $context["can_edit"] : null)) {
            // line 65
            echo "                        <a href=\"";
            echo $this->env->getExtension('routing')->getPath("admin_contenttypeGroupEdit");
            echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.new", array(), "content_type"), "html", null, true);
            echo "</a>
                    ";
        } else {
            // line 67
            echo "                        <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.new", array(), "content_type"), "html", null, true);
            echo "</span>
                    ";
        }
        // line 69
        echo "                </p>
            </div>
        </div>
    </section>
";
    }

    // line 75
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.list", array(), "content_type"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ContentType:list_content_type_groups.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  176 => 75,  168 => 69,  162 => 67,  154 => 65,  152 => 64,  147 => 61,  137 => 57,  134 => 56,  132 => 52,  131 => 50,  130 => 49,  129 => 48,  125 => 47,  120 => 46,  118 => 45,  114 => 43,  108 => 41,  100 => 39,  98 => 38,  93 => 36,  87 => 35,  84 => 34,  82 => 33,  78 => 32,  69 => 26,  65 => 25,  57 => 19,  54 => 18,  47 => 15,  44 => 14,  37 => 11,  34 => 6,  31 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "content_type" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_contenttype'), label: 'content_type.dashboard_title'|trans},*/
/*         {link: null, label: 'content_type.group.list'|trans}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'content_type.group.list'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <div class="ez-table-data is-flexible">*/
/*             <div class="ez-table-data-container">*/
/*                 <table class="pure-table pure-table-striped ez-selection-table">*/
/*                     <thead>*/
/*                     <tr class="ez-selection-table-row">*/
/*                         <th>{{ 'content_type.group.name'|trans }}</th>*/
/*                         <th>{{ 'content_type.group.id'|trans }}</th>*/
/*                         <th></th>*/
/*                         <th></th>*/
/*                     </tr>*/
/*                     </thead>*/
/*                     <tbody>*/
/*                     {% for group in content_type_groups %}*/
/*                         {# @var group \eZ\Publish\Core\Repository\Values\ContentType\ContentTypeGroup #}*/
/*                         <tr>*/
/*                             <td><a href="{{ path("admin_contenttypeGroupView", {"contentTypeGroupId": group.id}) }}">{{ group.identifier }}</a></td>*/
/*                             <td>{{ group.id }}</td>*/
/*                             <td>*/
/*                             {% if can_edit %}*/
/*                                 <a href="{{ path("admin_contenttypeGroupEdit", {'contentTypeGroupId': group.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'content_type.group.edit'|trans }}</a>*/
/*                             {% else %}*/
/*                                 <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'content_type.group.edit'|trans }}</span>*/
/*                             {% endif %}*/
/*                             </td>*/
/*                             <td>*/
/*                                 {% set deleteForm = delete_forms_by_id[group.id] %}*/
/*                                 {{ form_start(deleteForm, {"action": path("admin_contenttypeGroupDelete", {"contentTypeGroupId": group.id})}) }}*/
/*                                 {{ form_widget(deleteForm.contentTypeGroupId) }}*/
/*                                 {{*/
/*                                     form_widget(*/
/*                                         deleteForm.delete,*/
/*                                         {*/
/*                                             "disabled": not can_delete,*/
/*                                             "attr": {"class": "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete"}*/
/*                                         }*/
/*                                     )*/
/*                                 }}*/
/*                                 {{ form_end(deleteForm) }}*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*                     </tbody>*/
/*                 </table>*/
/*                 <p class="ez-table-data-buttons">*/
/*                     {% if can_edit %}*/
/*                         <a href="{{ path('admin_contenttypeGroupEdit') }}" class="pure-button ez-button" data-icon="&#xe616;">{{ 'content_type.group.new'|trans }}</a>*/
/*                     {% else %}*/
/*                         <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe616;">{{ 'content_type.group.new'|trans }}</span>*/
/*                     {% endif %}*/
/*                 </p>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'content_type.group.list'|trans }}{% endblock %}*/
/* */
