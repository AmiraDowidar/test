<?php

/* eZPlatformUIBundle::pjax.html.twig */
class __TwigTemplate_855f6089017fe5e9f6aa5ed1ad05dd75b04a618e9d963e6a90bf19099ae84f99 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 8
        echo "<div data-name=\"title\">";
        $this->displayBlock('title', $context, $blocks);
        echo "</div>
<div data-name=\"html\">";
        // line 9
        $this->displayBlock('content', $context, $blocks);
        echo "</div>
";
    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle::pjax.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 9,  32 => 8,  26 => 9,  21 => 8,);
    }
}
/* {#*/
/*  # Generates an HTML like document to be used by the eZ.ServerSideViewService*/
/*  # JavaScript component*/
/*  # Template extending this one should implement two blocks:*/
/*  #   * title: to generate what will be used as the title of the web page*/
/*  #   * content: to generate the HTML code to put in the page*/
/*  #}*/
/* <div data-name="title">{% block title %}{% endblock %}</div>*/
/* <div data-name="html">{% block content %}{% endblock %}</div>*/
/* */
