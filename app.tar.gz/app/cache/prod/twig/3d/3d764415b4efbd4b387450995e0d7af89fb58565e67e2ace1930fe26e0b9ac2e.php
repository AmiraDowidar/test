<?php

/* EzPublishCoreBundle:default/content:text_linked.html.twig */
class __TwigTemplate_5acdef3f6a9b0480f7408953c441850761c9b16a795a7510bd10a1453ca4c313 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["content_name"] = $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : null));
        // line 2
        echo "
";
        // line 3
        if (array_key_exists("location", $context)) {
            // line 4
            echo "    <a href=\"";
            echo $this->env->getExtension('routing')->getPath((isset($context["location"]) ? $context["location"] : null));
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["content_name"]) ? $context["content_name"] : null), "html", null, true);
            echo "</a>
";
        } else {
            // line 6
            echo "    <p>";
            echo twig_escape_filter($this->env, (isset($context["content_name"]) ? $context["content_name"] : null), "html", null, true);
            echo "</p>
";
        }
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/content:text_linked.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 6,  26 => 4,  24 => 3,  21 => 2,  19 => 1,);
    }
}
/* {% set content_name=ez_content_name(content) %}*/
/* */
/* {% if location is defined %}*/
/*     <a href="{{ path(location) }}">{{ content_name }}</a>*/
/* {% else %}*/
/*     <p>{{ content_name }}</p>*/
/* {% endif %}*/
/* */
