<?php

/* EzSystemsRepositoryFormsBundle:Content:content_edit.html.twig */
class __TwigTemplate_8d653811ab0e087f26269a80694b7fc267f064dd631466562847516916f6aa50 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((((array_key_exists("noLayout", $context) && ((isset($context["noLayout"]) ? $context["noLayout"] : null) == true))) ? ((isset($context["viewbaseLayout"]) ? $context["viewbaseLayout"] : null)) : ((isset($context["pagelayout"]) ? $context["pagelayout"] : null))), "EzSystemsRepositoryFormsBundle:Content:content_edit.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    ";
        $context["contentForms"] = $this->loadTemplate("EzSystemsRepositoryFormsBundle:Content:content_form.html.twig", "EzSystemsRepositoryFormsBundle:Content:content_edit.html.twig", 4);
        // line 5
        echo "
    <section class=\"ez-content-edit\">
        ";
        // line 7
        echo $context["contentForms"]->getdisplay_form((isset($context["form"]) ? $context["form"] : null));
        echo "
    </section>
";
    }

    public function getTemplateName()
    {
        return "EzSystemsRepositoryFormsBundle:Content:content_edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 7,  33 => 5,  30 => 4,  27 => 3,  18 => 1,);
    }
}
/* {% extends noLayout is defined and noLayout == true ? viewbaseLayout : pagelayout %}*/
/* */
/* {% block content %}*/
/*     {% import "EzSystemsRepositoryFormsBundle:Content:content_form.html.twig" as contentForms %}*/
/* */
/*     <section class="ez-content-edit">*/
/*         {{ contentForms.display_form(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
