<?php

/* EzPublishCoreBundle:default/content:line.html.twig */
class __TwigTemplate_57a6530310c4a736172a179a2ffa7404ec24e2fda5d1f4a99bf85ae4f82f653f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["content_name"] = $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : null));
        // line 2
        echo "
";
        // line 3
        if (array_key_exists("location", $context)) {
            // line 4
            echo "    <p><a href=\"";
            echo $this->env->getExtension('routing')->getPath((isset($context["location"]) ? $context["location"] : null));
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["content_name"]) ? $context["content_name"] : null), "html", null, true);
            echo "</a></p>
";
        } else {
            // line 6
            echo "    <p>";
            echo twig_escape_filter($this->env, (isset($context["content_name"]) ? $context["content_name"] : null), "html", null, true);
            echo "</p>
";
        }
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/content:line.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 6,  26 => 4,  24 => 3,  21 => 2,  19 => 1,);
    }
}
/* {% set content_name=ez_content_name(content) %}*/
/* */
/* {% if location is defined %}*/
/*     <p><a href="{{ path(location) }}">{{ content_name }}</a></p>*/
/* {% else %}*/
/*     <p>{{ content_name }}</p>*/
/* {% endif %}*/
/* */
