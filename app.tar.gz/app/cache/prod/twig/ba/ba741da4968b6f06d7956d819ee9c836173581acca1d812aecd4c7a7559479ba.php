<?php

/* eZPlatformUIBundle:Section:list.html.twig */
class __TwigTemplate_adea3377624ea6e32488e535213af35fd7a8f5241afdcd1b338ab32589cbad0e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Section:list.html.twig", 1);
        $this->blocks = array(
            'choice_widget' => array($this, 'block_choice_widget'),
            'choice_row' => array($this, 'block_choice_row'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_choice_widget($context, array $blocks = array())
    {
        // line 6
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["form"]) ? $context["form"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 7
            echo "        ";
            $context["section"] = $this->getAttribute($this->getAttribute($context["child"], "vars", array()), "label", array());
            // line 8
            echo "
        <tr class=\"ez-selection-table-row\">
            <td>
                ";
            // line 11
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["child"], 'widget', array("disabled" =>  !$this->getAttribute((isset($context["section"]) ? $context["section"] : null), "canDelete", array()), "attr" => array("class" => "ez-selection-table-checkbox")));
            echo "
            </td>
            <td><a href=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "name", array()), "html", null, true);
            echo "</a></td>
            <td><a href=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "identifier", array()), "html", null, true);
            echo "</a></td>
            <td class=\"ez-table-data-id\"><a href=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "id", array()), "html", null, true);
            echo "</a></td>
            <td class=\"ez-table-data-count\">";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "contentCount", array()), "html", null, true);
            echo "</td>
            <td>
                <button
                    data-universaldiscovery-title=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assign.universaldiscovery.title", array("%sectionName%" => $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "name", array())), "section"), "html_attr");
            echo "\"
                    data-section-rest-id=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadSection", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "id", array()))), "html", null, true);
            echo "\"
                    data-section-name=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "name", array()), "html", null, true);
            echo "\"
                    class=\"ez-section-assign-button ez-button-tree pure-button ez-font-icon ez-button\"
                    ";
            // line 23
            if ( !$this->getAttribute((isset($context["section"]) ? $context["section"] : null), "canAssign", array())) {
                echo "disabled=\"disabled\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assign.contents", array(), "section"), "html", null, true);
            echo "</button>
            </td>
            <td>
                <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionedit", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : null), "id", array()))), "html", null, true);
            echo "\" class=\"pure-button ez-button";
            if ( !$this->getAttribute((isset($context["section"]) ? $context["section"] : null), "canEdit", array())) {
                echo " pure-button-disabled";
            }
            echo "\" data-icon=\"&#xe606;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.edit", array(), "section"), "html", null, true);
            echo "</a>
            </td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    // line 32
    public function block_choice_row($context, array $blocks = array())
    {
        // line 33
        echo "    ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'widget');
        echo "
";
    }

    // line 36
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 37
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("section.list", array(), "section")));
        // line 41
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 44
    public function block_header_title($context, array $blocks = array())
    {
        // line 45
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.list", array(), "section"), "html", null, true);
        echo "</h1>
";
    }

    // line 48
    public function block_content($context, array $blocks = array())
    {
        // line 49
        echo "    <section class=\"ez-serverside-content\">
        <div class=\"ez-table-data is-flexible\">
            <div class=\"ez-table-data-container\">
                <table class=\"pure-table pure-table-striped ez-selection-table\" data-selection-buttons=\".ez-remove-section-button\">
                    <thead>
                        <tr>
                            <th>";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.name", array(), "section"), "html", null, true);
        echo "</th>
                            <th>";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.identifier", array(), "section"), "html", null, true);
        echo "</th>
                            <th>";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.id", array(), "section"), "html", null, true);
        echo "</th>
                            <th>";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assigned.content", array(), "section"), "html", null, true);
        echo "</th>
                            <th colspan=\"3\"></th>
                        </tr>
                    </thead>
                    <tbody>
                    ";
        // line 63
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sectionList"]) ? $context["sectionList"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 64
            echo "                        <tr class=\"ez-selection-table-row\">
                            <td><a href=\"";
            // line 65
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "name", array()), "html", null, true);
            echo "</a></td>
                            <td><a href=\"";
            // line 66
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "identifier", array()), "html", null, true);
            echo "</a></td>
                            <td class=\"ez-table-data-id\"><a href=\"";
            // line 67
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "id", array()), "html", null, true);
            echo "</a></td>
                            <td class=\"ez-table-data-count\">";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contentCountBySectionId"]) ? $context["contentCountBySectionId"] : null), $this->getAttribute($context["section"], "id", array()), array(), "array"), "html", null, true);
            echo "</td>
                            <td>
                                <button
                                    data-universaldiscovery-title=\"";
            // line 71
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assign.universaldiscovery.title", array("%sectionName%" => $this->getAttribute($context["section"], "name", array())), "section"), "html_attr");
            echo "\"
                                    data-section-rest-id=\"";
            // line 72
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadSection", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
            echo "\"
                                    data-section-name=\"";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "name", array()), "html", null, true);
            echo "\"
                                    class=\"ez-section-assign-button ez-button-tree pure-button ez-font-icon ez-button\"
                                    ";
            // line 75
            if ( !(isset($context["canAssign"]) ? $context["canAssign"] : null)) {
                echo "disabled=\"disabled\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assign.contents", array(), "section"), "html", null, true);
            echo "</button>
                            </td>
                            <td>
                            ";
            // line 78
            if ((isset($context["canEdit"]) ? $context["canEdit"] : null)) {
                // line 79
                echo "                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionedit", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
                echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.edit", array(), "section"), "html", null, true);
                echo "</a>
                            ";
            } else {
                // line 81
                echo "                                <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.edit", array(), "section"), "html", null, true);
                echo "</span>
                            ";
            }
            // line 83
            echo "                            </td>
                            <td>
                                ";
            // line 85
            $context["deleteForm"] = $this->getAttribute((isset($context["deleteFormsBySectionId"]) ? $context["deleteFormsBySectionId"] : null), $this->getAttribute($context["section"], "id", array()), array(), "array");
            // line 86
            echo "                                ";
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_sectiondelete", array("sectionId" => $this->getAttribute($context["section"], "id", array()), "redirectErrorsTo" => "list"))));
            echo "
                                    ";
            // line 87
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : null), "sectionId", array()), 'widget');
            echo "
                                    ";
            // line 88
            echo             // line 89
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(            // line 90
(isset($context["deleteForm"]) ? $context["deleteForm"] : null), "delete", array()), 'widget', array("disabled" =>  !$this->getAttribute(            // line 92
(isset($context["deletableSections"]) ? $context["deletableSections"] : null), $this->getAttribute($context["section"], "id", array()), array(), "array", true, true), "attr" => array("class" => "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete")));
            // line 96
            echo "
                                ";
            // line 97
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_end');
            echo "
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['section'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 101
        echo "                    </tbody>
                </table>
                <p class=\"ez-table-data-buttons\">
                ";
        // line 104
        if ((isset($context["canEdit"]) ? $context["canEdit"] : null)) {
            // line 105
            echo "                    <a href=\"";
            echo $this->env->getExtension('routing')->getPath("admin_sectionedit");
            echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.new", array(), "section"), "html", null, true);
            echo "</a>
                ";
        } else {
            // line 107
            echo "                    <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.new", array(), "section"), "html", null, true);
            echo "</span>
                ";
        }
        // line 109
        echo "                </p>
            </div>
        </div>
    </section>
";
    }

    // line 115
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.list", array(), "section"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Section:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  315 => 115,  307 => 109,  301 => 107,  293 => 105,  291 => 104,  286 => 101,  276 => 97,  273 => 96,  271 => 92,  270 => 90,  269 => 89,  268 => 88,  264 => 87,  259 => 86,  257 => 85,  253 => 83,  247 => 81,  239 => 79,  237 => 78,  227 => 75,  222 => 73,  218 => 72,  214 => 71,  208 => 68,  202 => 67,  196 => 66,  190 => 65,  187 => 64,  183 => 63,  175 => 58,  171 => 57,  167 => 56,  163 => 55,  155 => 49,  152 => 48,  145 => 45,  142 => 44,  135 => 41,  132 => 37,  129 => 36,  122 => 33,  119 => 32,  101 => 26,  91 => 23,  86 => 21,  82 => 20,  78 => 19,  72 => 16,  66 => 15,  60 => 14,  54 => 13,  49 => 11,  44 => 8,  41 => 7,  36 => 6,  33 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "section" %}*/
/* */
/* {% block choice_widget %}*/
/*     {% for child in form %}*/
/*         {% set section = child.vars.label %}*/
/* */
/*         <tr class="ez-selection-table-row">*/
/*             <td>*/
/*                 {{ form_widget(child, {'disabled': not section.canDelete, 'attr': {'class': 'ez-selection-table-checkbox'} }) }}*/
/*             </td>*/
/*             <td><a href="{{ path( 'admin_sectionview', {'sectionId': section.id} ) }}">{{ section.name }}</a></td>*/
/*             <td><a href="{{ path( 'admin_sectionview', {'sectionId': section.id} ) }}">{{ section.identifier }}</a></td>*/
/*             <td class="ez-table-data-id"><a href="{{ path( "admin_sectionview", {"sectionId": section.id} ) }}">{{ section.id }}</a></td>*/
/*             <td class="ez-table-data-count">{{ section.contentCount }}</td>*/
/*             <td>*/
/*                 <button*/
/*                     data-universaldiscovery-title="{{ 'section.assign.universaldiscovery.title'|trans({'%sectionName%': section.name })|e('html_attr') }}"*/
/*                     data-section-rest-id="{{path( 'ezpublish_rest_loadSection', {'sectionId': section.id}) }}"*/
/*                     data-section-name="{{ section.name }}"*/
/*                     class="ez-section-assign-button ez-button-tree pure-button ez-font-icon ez-button"*/
/*                     {% if not section.canAssign %}disabled="disabled"{% endif %}>{{ 'section.assign.contents'|trans }}</button>*/
/*             </td>*/
/*             <td>*/
/*                 <a href="{{ path('admin_sectionedit', {'sectionId': section.id}) }}" class="pure-button ez-button{% if not section.canEdit %} pure-button-disabled{% endif %}" data-icon="&#xe606;">{{ 'section.edit'|trans }}</a>*/
/*             </td>*/
/*         </tr>*/
/*     {% endfor %}*/
/* {% endblock choice_widget  %}*/
/* */
/* {% block choice_row %}*/
/*     {{ form_widget(form) }}*/
/* {% endblock choice_row %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: '', label: 'section.list'|trans({}, 'section')}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'section.list'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <div class="ez-table-data is-flexible">*/
/*             <div class="ez-table-data-container">*/
/*                 <table class="pure-table pure-table-striped ez-selection-table" data-selection-buttons=".ez-remove-section-button">*/
/*                     <thead>*/
/*                         <tr>*/
/*                             <th>{{ 'section.name'|trans }}</th>*/
/*                             <th>{{ 'section.identifier'|trans }}</th>*/
/*                             <th>{{ 'section.id'|trans }}</th>*/
/*                             <th>{{ 'section.assigned.content'|trans }}</th>*/
/*                             <th colspan="3"></th>*/
/*                         </tr>*/
/*                     </thead>*/
/*                     <tbody>*/
/*                     {% for section in sectionList %}*/
/*                         <tr class="ez-selection-table-row">*/
/*                             <td><a href="{{ path( 'admin_sectionview', {'sectionId': section.id} ) }}">{{ section.name }}</a></td>*/
/*                             <td><a href="{{ path( 'admin_sectionview', {'sectionId': section.id} ) }}">{{ section.identifier }}</a></td>*/
/*                             <td class="ez-table-data-id"><a href="{{ path( "admin_sectionview", {"sectionId": section.id} ) }}">{{ section.id }}</a></td>*/
/*                             <td class="ez-table-data-count">{{ contentCountBySectionId[section.id] }}</td>*/
/*                             <td>*/
/*                                 <button*/
/*                                     data-universaldiscovery-title="{{ 'section.assign.universaldiscovery.title'|trans({'%sectionName%': section.name })|e('html_attr') }}"*/
/*                                     data-section-rest-id="{{ path( 'ezpublish_rest_loadSection', {'sectionId': section.id}) }}"*/
/*                                     data-section-name="{{ section.name }}"*/
/*                                     class="ez-section-assign-button ez-button-tree pure-button ez-font-icon ez-button"*/
/*                                     {% if not canAssign %}disabled="disabled"{% endif %}>{{ 'section.assign.contents'|trans }}</button>*/
/*                             </td>*/
/*                             <td>*/
/*                             {% if canEdit %}*/
/*                                 <a href="{{ path('admin_sectionedit', {'sectionId': section.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'section.edit'|trans }}</a>*/
/*                             {% else %}*/
/*                                 <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'section.edit'|trans }}</span>*/
/*                             {% endif %}*/
/*                             </td>*/
/*                             <td>*/
/*                                 {% set deleteForm = deleteFormsBySectionId[section.id] %}*/
/*                                 {{ form_start(deleteForm, {"action": path("admin_sectiondelete", {"sectionId": section.id, "redirectErrorsTo": "list"})}) }}*/
/*                                     {{ form_widget(deleteForm.sectionId) }}*/
/*                                     {{*/
/*                                         form_widget(*/
/*                                             deleteForm.delete,*/
/*                                             {*/
/*                                                 "disabled": deletableSections[section.id] is not defined,*/
/*                                                 "attr": {"class": "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete"}*/
/*                                             }*/
/*                                         )*/
/*                                     }}*/
/*                                 {{ form_end(deleteForm) }}*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*                     </tbody>*/
/*                 </table>*/
/*                 <p class="ez-table-data-buttons">*/
/*                 {% if canEdit %}*/
/*                     <a href="{{ path('admin_sectionedit') }}" class="pure-button ez-button" data-icon="&#xe616;">{{ 'section.new'|trans }}</a>*/
/*                 {% else %}*/
/*                     <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe616;">{{ 'section.new'|trans }}</span>*/
/*                 {% endif %}*/
/*                 </p>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'section.list'|trans }}{% endblock %}*/
/* */
