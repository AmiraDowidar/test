<?php

/* eZPlatformUIBundle:Role:view_role.html.twig */
class __TwigTemplate_61e840a5bb212adf1f18127b8fdc8c56ba4196c49a6e9eeebc67b143c9822e79 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Role:view_role.html.twig", 3);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_role"), "label" => $this->env->getExtension('translator')->trans("role.dashboard_title", array(), "role")), 2 => array("link" => null, "label" => $this->getAttribute(        // line 11
(isset($context["role"]) ? $context["role"] : null), "identifier", array())));
        // line 13
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 16
    public function block_header_title($context, array $blocks = array())
    {
        // line 17
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe62d;\">";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array()), "html", null, true);
        echo "</h1>
";
    }

    // line 20
    public function block_content($context, array $blocks = array())
    {
        // line 21
        echo "    <section class=\"ez-tabs ez-serverside-content\">
        <ul class=\"ez-tabs-list\">
            <li class=\"ez-tabs-label is-tab-selected\"><a href=\"#ez-tabs-role-name\">";
        // line 23
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array()), "html", null, true);
        echo "</a></li>
            <li class=\"ez-tabs-label\"><a href=\"#ez-tabs-content\">";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("assignment.user_or_group_using", array("%role%" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array()), "%count%" => twig_length_filter($this->env, (isset($context["role_assignments"]) ? $context["role_assignments"] : null))), "role"), "html", null, true);
        echo "</a></li>
        </ul>
        <div class=\"ez-tabs-panel is-tab-selected\" id=\"ez-tabs-role-name\">
            <div class=\"ez-table-data is-flexible\">
                <div class=\"ez-table-data-container\">
                    <table class=\"pure-table pure-table-striped ez-selection-table\">
                        <thead>
                        <tr class=\"ez-selection-table-row\">
                            <th>";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("policy.module", array(), "role"), "html", null, true);
        echo "</th>
                            <th>";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("policy.function", array(), "role"), "html", null, true);
        echo "</th>
                            <th>";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("policy.limitation", array(), "role"), "html", null, true);
        echo "</th>
                            <th></th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 40
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["role"]) ? $context["role"] : null), "policies", array()));
        $context['_iterated'] = false;
        foreach ($context['_seq'] as $context["_key"] => $context["policy"]) {
            // line 41
            echo "                            ";
            // line 42
            echo "                            <tr>
                                <td>";
            // line 44
            if (($this->getAttribute($context["policy"], "module", array()) == "*")) {
                // line 45
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("policy.module_all", array(), "role"), "html", null, true);
            } else {
                // line 47
                echo twig_escape_filter($this->env, $this->getAttribute($context["policy"], "module", array()), "html", null, true);
            }
            // line 49
            echo "</td>
                                <td>";
            // line 51
            if (($this->getAttribute($context["policy"], "function", array()) == "*")) {
                // line 52
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("policy.function_all", array(), "role"), "html", null, true);
            } else {
                // line 54
                echo twig_escape_filter($this->env, $this->getAttribute($context["policy"], "function", array()), "html", null, true);
            }
            // line 56
            echo "</td>
                                <td>";
            // line 58
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["policy"], "limitations", array()));
            $context['_iterated'] = false;
            $context['loop'] = array(
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            );
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["limitation"]) {
                // line 60
                echo twig_escape_filter($this->env, $this->getAttribute($context["limitation"], "identifier", array()), "html", null, true);
                // line 61
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($context["limitation"], "limitationValues", array()));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["limitationValue"]) {
                    // line 62
                    if ($this->getAttribute($context["loop"], "first", array())) {
                        echo "( ";
                    }
                    // line 64
                    echo twig_escape_filter($this->env, $context["limitationValue"], "html", null, true);
                    // line 65
                    if ( !$this->getAttribute($context["loop"], "last", array())) {
                        echo ", ";
                    }
                    // line 66
                    if ($this->getAttribute($context["loop"], "last", array())) {
                        echo " )";
                    }
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['limitationValue'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 68
                if ( !$this->getAttribute($context["loop"], "last", array())) {
                    echo ", ";
                }
                $context['_iterated'] = true;
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['length'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            if (!$context['_iterated']) {
                // line 70
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("policy.limitation_none", array(), "role"), "html", null, true);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['limitation'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 72
            echo "</td>
                                <td>
                                ";
            // line 74
            if (((isset($context["can_edit"]) ? $context["can_edit"] : null) && $this->getAttribute((isset($context["editablePolicies"]) ? $context["editablePolicies"] : null), $this->getAttribute($context["policy"], "id", array()), array(), "array", true, true))) {
                // line 75
                echo "                                    <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_policyEdit", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "id", array()), "policyId" => $this->getAttribute($context["policy"], "id", array()))), "html", null, true);
                echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.policy.edit_limitations", array(), "role"), "html", null, true);
                echo "</a>
                                ";
            } else {
                // line 77
                echo "                                    <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.policy.edit_limitations", array(), "role"), "html", null, true);
                echo "</span>
                                ";
            }
            // line 79
            echo "                                </td>
                                <td>
                                    ";
            // line 81
            $context["policyDeleteForm"] = $this->getAttribute((isset($context["deleteFormsByPolicyId"]) ? $context["deleteFormsByPolicyId"] : null), $this->getAttribute($context["policy"], "id", array()), array(), "array");
            // line 82
            echo "                                    ";
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["policyDeleteForm"]) ? $context["policyDeleteForm"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_policyDelete", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "id", array()), "policyId" => $this->getAttribute($context["policy"], "id", array())))));
            echo "
                                    ";
            // line 83
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["policyDeleteForm"]) ? $context["policyDeleteForm"] : null), "policyId", array()), 'widget');
            echo "
                                    ";
            // line 84
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["policyDeleteForm"]) ? $context["policyDeleteForm"] : null), "roleId", array()), 'widget');
            echo "
                                    ";
            // line 85
            echo             // line 86
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(            // line 87
(isset($context["policyDeleteForm"]) ? $context["policyDeleteForm"] : null), "delete", array()), 'widget', array("disabled" =>  !            // line 89
(isset($context["can_edit"]) ? $context["can_edit"] : null), "attr" => array("class" => "pure-button ez-button ez-font-icon ez-button-delete")));
            // line 93
            echo "
                                    ";
            // line 94
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["policyDeleteForm"]) ? $context["policyDeleteForm"] : null), 'form_end');
            echo "
                                </td>
                            </tr>
                        ";
            $context['_iterated'] = true;
        }
        if (!$context['_iterated']) {
            // line 98
            echo "                            <tr>
                                <td colspan=\"5\">";
            // line 99
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.policy_none", array(), "role"), "html", null, true);
            echo "</td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['policy'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 102
        echo "                        </tbody>
                    </table>

                    ";
        // line 105
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_roleDelete", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "id", array())))));
        echo "
                        <p class=\"ez-table-data-buttons\">
                        ";
        // line 107
        if ((isset($context["can_edit"]) ? $context["can_edit"] : null)) {
            // line 108
            echo "                            <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_policyEdit", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "id", array()))), "html", null, true);
            echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.policy.add", array(), "role"), "html", null, true);
            echo "</a>
                            <a href=\"";
            // line 109
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_roleUpdate", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "id", array()))), "html", null, true);
            echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.edit", array(), "role"), "html", null, true);
            echo "</a>
                        ";
        } else {
            // line 111
            echo "                            <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.edit", array(), "role"), "html", null, true);
            echo "</span>
                        ";
        }
        // line 113
        echo "
                            ";
        // line 114
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : null), "roleId", array()), 'widget');
        echo "
                            ";
        // line 115
        echo         // line 116
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(        // line 117
(isset($context["deleteForm"]) ? $context["deleteForm"] : null), "delete", array()), 'widget', array("disabled" =>  !        // line 119
(isset($context["can_delete"]) ? $context["can_delete"] : null), "attr" => array("class" => "pure-button ez-button ez-remove-role-button ez-font-icon ez-button-delete")));
        // line 123
        echo "
                        </p>
                    ";
        // line 125
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_end');
        echo "
                </div>
            </div>
        </div>

        <div class=\"ez-tabs-panel\" id=\"ez-tabs-content\">
            <div class=\"ez-table-data is-flexible\">
                <div class=\"ez-table-data-container\">
                    <table class=\"pure-table pure-table-striped ez-selection-table\">
                        <thead>
                        <tr class=\"ez-selection-table-row\">
                            <th>";
        // line 136
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("assignment.user_or_group", array(), "role"), "html", null, true);
        echo "</th>
                            <th>";
        // line 137
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("assignment.role_limitation", array(), "role"), "html", null, true);
        echo "</th>
                            <th></th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 142
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["role_assignments"]) ? $context["role_assignments"] : null));
        $context['_iterated'] = false;
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["role_assignment"]) {
            // line 143
            echo "                            ";
            // line 144
            echo "                            <tr>
                                <td>
                                    ";
            // line 147
            if ($this->getAttribute($context["role_assignment"], "getUserGroup", array(), "any", true, true)) {
                // line 148
                echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.content')->getTranslatedContentName($this->getAttribute($context["role_assignment"], "usergroup", array())), "html", null, true);
            } else {
                // line 150
                echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.content')->getTranslatedContentName($this->getAttribute($context["role_assignment"], "user", array())), "html", null, true);
            }
            // line 152
            echo "</td>
                                <td>";
            // line 154
            if ($this->getAttribute($context["role_assignment"], "rolelimitation", array())) {
                // line 155
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($context["role_assignment"], "rolelimitation", array()), "identifier", array()), "html", null, true);
                // line 156
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($context["role_assignment"], "rolelimitation", array()), "limitationValues", array()));
                $context['loop'] = array(
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                );
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["limitationValue"]) {
                    // line 157
                    if ($this->getAttribute($context["loop"], "first", array())) {
                        echo "( ";
                    }
                    // line 159
                    echo twig_escape_filter($this->env, $context["limitationValue"], "html", null, true);
                    // line 160
                    if ( !$this->getAttribute($context["loop"], "last", array())) {
                        echo ", ";
                    }
                    // line 161
                    if ($this->getAttribute($context["loop"], "last", array())) {
                        echo " )";
                    }
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['length'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['limitationValue'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 163
                if ( !$this->getAttribute($context["loop"], "last", array())) {
                    echo ", ";
                }
            } else {
                // line 165
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("assignment.role_limitation_none", array(), "role"), "html", null, true);
            }
            // line 167
            echo "</td>
                                <td>
                                    ";
            // line 169
            $context["deleteForm"] = $this->getAttribute((isset($context["deleteFormsByAssignment"]) ? $context["deleteFormsByAssignment"] : null), $this->getAttribute($context["role_assignment"], "id", array()), array(), "array");
            // line 170
            echo "                                    ";
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_roleAssignmentDelete", array("roleAssignmentId" => $this->getAttribute($context["role_assignment"], "id", array()), "redirectErrorsTo" => "view"))));
            echo "
                                    ";
            // line 171
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : null), "assignmentId", array()), 'widget');
            echo "
                                    ";
            // line 172
            echo             // line 173
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(            // line 174
(isset($context["deleteForm"]) ? $context["deleteForm"] : null), "delete", array()), 'widget', array("disabled" =>  !            // line 176
(isset($context["can_assign"]) ? $context["can_assign"] : null), "attr" => array("class" => "pure-button ez-button ez-remove-roleassignment-button ez-font-icon ez-button-delete")));
            // line 180
            echo "
                                    ";
            // line 181
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_end');
            echo "
                                </td>
                            </tr>
                        ";
            $context['_iterated'] = true;
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        if (!$context['_iterated']) {
            // line 185
            echo "                            <tr>
                                <td colspan=\"3\">";
            // line 186
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("assignment.none", array(), "role"), "html", null, true);
            echo "</td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role_assignment'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 189
        echo "                        </tbody>
                    </table>
                    <p>
                        <button
                                data-universaldiscovery-title=\"";
        // line 193
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign.universaldiscovery.title", array("%roleIdentifier%" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array())), "role"), "html_attr");
        echo "\"
                                data-role-rest-id=\"";
        // line 194
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadRole", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "id", array()))), "html", null, true);
        echo "\"
                                data-role-name=\"";
        // line 195
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array()), "html", null, true);
        echo "\"
                                data-role-assignment-limitation-type=\"";
        // line 196
        echo "none";
        echo "\"
                                class=\"ez-role-assign-button ez-button-tree pure-button ez-font-icon ez-button\">
                            ";
        // line 198
        if ( !(isset($context["can_assign"]) ? $context["can_assign"] : null)) {
            echo "disabled";
        }
        // line 199
        echo "                            ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign.user_or_group", array(), "role"), "html", null, true);
        echo "
                        </button>
                        <button
                                data-universaldiscovery-title=\"";
        // line 202
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign.universaldiscovery.title", array("%roleIdentifier%" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array())), "role"), "html_attr");
        echo "\"
                                data-universaldiscovery-limit-subtree-title=\"";
        // line 203
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign_limit_subtree.universaldiscovery.title", array("%roleIdentifier%" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array())), "role"), "html_attr");
        echo "\"
                                data-role-rest-id=\"";
        // line 204
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadRole", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "id", array()))), "html", null, true);
        echo "\"
                                data-role-name=\"";
        // line 205
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "identifier", array()), "html", null, true);
        echo "\"
                                data-role-assignment-limitation-type=\"";
        // line 206
        echo "Subtree";
        echo "\"
                                class=\"ez-role-assign-limit-subtree-button ez-button-tree pure-button ez-font-icon ez-button\">
                            ";
        // line 208
        if ( !(isset($context["can_assign"]) ? $context["can_assign"] : null)) {
            echo "disabled";
        }
        // line 209
        echo "                            ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign_limit_subtree.user_or_group", array(), "role"), "html", null, true);
        echo "
                        </button>
                        ";
        // line 211
        if ((isset($context["can_assign"]) ? $context["can_assign"] : null)) {
            // line 212
            echo "                            <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_roleAssignSection", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : null), "id", array()))), "html", null, true);
            echo "\" class=\"ez-button-tree pure-button ez-font-icon ez-button\">";
            // line 213
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign_limit_section.user_or_group", array(), "role"), "html", null, true);
            // line 214
            echo "</a>
                        ";
        } else {
            // line 216
            echo "                            <span class=\"ez-button-tree ez-font-icon pure-button ez-button pure-button-disabled\">";
            // line 217
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign_limit_section.user_or_group", array(), "role"), "html", null, true);
            // line 218
            echo "</span>
                        ";
        }
        // line 220
        echo "                    </p>
                </div>
            </div>
        </div>
    </section>
";
    }

    // line 227
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role", array(), "role"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Role:view_role.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  588 => 227,  579 => 220,  575 => 218,  573 => 217,  571 => 216,  567 => 214,  565 => 213,  561 => 212,  559 => 211,  553 => 209,  549 => 208,  544 => 206,  540 => 205,  536 => 204,  532 => 203,  528 => 202,  521 => 199,  517 => 198,  512 => 196,  508 => 195,  504 => 194,  500 => 193,  494 => 189,  485 => 186,  482 => 185,  465 => 181,  462 => 180,  460 => 176,  459 => 174,  458 => 173,  457 => 172,  453 => 171,  448 => 170,  446 => 169,  442 => 167,  439 => 165,  434 => 163,  418 => 161,  414 => 160,  412 => 159,  408 => 157,  391 => 156,  389 => 155,  387 => 154,  384 => 152,  381 => 150,  378 => 148,  376 => 147,  372 => 144,  370 => 143,  352 => 142,  344 => 137,  340 => 136,  326 => 125,  322 => 123,  320 => 119,  319 => 117,  318 => 116,  317 => 115,  313 => 114,  310 => 113,  304 => 111,  297 => 109,  290 => 108,  288 => 107,  283 => 105,  278 => 102,  269 => 99,  266 => 98,  257 => 94,  254 => 93,  252 => 89,  251 => 87,  250 => 86,  249 => 85,  245 => 84,  241 => 83,  236 => 82,  234 => 81,  230 => 79,  224 => 77,  216 => 75,  214 => 74,  210 => 72,  204 => 70,  189 => 68,  173 => 66,  169 => 65,  167 => 64,  163 => 62,  146 => 61,  144 => 60,  126 => 58,  123 => 56,  120 => 54,  117 => 52,  115 => 51,  112 => 49,  109 => 47,  106 => 45,  104 => 44,  101 => 42,  99 => 41,  94 => 40,  85 => 34,  81 => 33,  77 => 32,  66 => 24,  62 => 23,  58 => 21,  55 => 20,  48 => 17,  45 => 16,  38 => 13,  36 => 11,  34 => 8,  31 => 7,  11 => 3,);
    }
}
/* {# @var role \eZ\Publish\API\Repository\Values\User\Role #}*/
/* {# @var role_assignments \eZ\Publish\API\Repository\Values\User\RoleAssignment[] #}*/
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "role" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_role'), label: 'role.dashboard_title'|trans},*/
/*         {link: null, label: role.identifier}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe62d;">{{ role.identifier }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-tabs ez-serverside-content">*/
/*         <ul class="ez-tabs-list">*/
/*             <li class="ez-tabs-label is-tab-selected"><a href="#ez-tabs-role-name">{{ role.identifier }}</a></li>*/
/*             <li class="ez-tabs-label"><a href="#ez-tabs-content">{{ 'assignment.user_or_group_using'|trans({'%role%': role.identifier, '%count%': role_assignments|length }) }}</a></li>*/
/*         </ul>*/
/*         <div class="ez-tabs-panel is-tab-selected" id="ez-tabs-role-name">*/
/*             <div class="ez-table-data is-flexible">*/
/*                 <div class="ez-table-data-container">*/
/*                     <table class="pure-table pure-table-striped ez-selection-table">*/
/*                         <thead>*/
/*                         <tr class="ez-selection-table-row">*/
/*                             <th>{{ 'policy.module'|trans }}</th>*/
/*                             <th>{{ 'policy.function'|trans }}</th>*/
/*                             <th>{{ 'policy.limitation'|trans }}</th>*/
/*                             <th></th>*/
/*                             <th></th>*/
/*                         </tr>*/
/*                         </thead>*/
/*                         <tbody>*/
/*                         {% for policy in role.policies %}*/
/*                             {# @var policy \eZ\Publish\API\Repository\Values\User\Policy #}*/
/*                             <tr>*/
/*                                 <td>*/
/*                                     {%- if policy.module == '*' -%}*/
/*                                         {{- 'policy.module_all'|trans -}}*/
/*                                     {%- else -%}*/
/*                                         {{- policy.module -}}*/
/*                                     {%- endif -%}*/
/*                                 </td>*/
/*                                 <td>*/
/*                                     {%- if policy.function == '*' -%}*/
/*                                         {{- 'policy.function_all'|trans -}}*/
/*                                     {%- else -%}*/
/*                                         {{- policy.function -}}*/
/*                                     {%- endif -%}*/
/*                                 </td>*/
/*                                 <td>*/
/*                                     {%- for limitation in policy.limitations -%}*/
/*                                         {# @var limitation \eZ\Publish\API\Repository\Values\User\Limitation #}*/
/*                                         {{- limitation.identifier -}}*/
/*                                         {%- for limitationValue in limitation.limitationValues -%}*/
/*                                             {%- if loop.first -%}( {% endif -%}*/
/*                                             {# TODO: https://jira.ez.no/browse/EZP-24699 Enrich Role limitations view with links and human readable names #}*/
/*                                             {{- limitationValue -}}*/
/*                                             {%- if not loop.last -%}, {% endif -%}*/
/*                                             {%- if loop.last %} ){%- endif -%}*/
/*                                         {%- endfor -%}*/
/*                                         {%- if not loop.last -%}, {% endif -%}*/
/*                                     {%- else -%}*/
/*                                         {{- 'policy.limitation_none'|trans -}}*/
/*                                     {%- endfor -%}*/
/*                                 </td>*/
/*                                 <td>*/
/*                                 {% if can_edit and editablePolicies[policy.id] is defined %}*/
/*                                     <a href="{{ path('admin_policyEdit', {'roleId': role.id, 'policyId': policy.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'role.policy.edit_limitations'|trans }}</a>*/
/*                                 {% else %}*/
/*                                     <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'role.policy.edit_limitations'|trans }}</span>*/
/*                                 {% endif %}*/
/*                                 </td>*/
/*                                 <td>*/
/*                                     {% set policyDeleteForm = deleteFormsByPolicyId[policy.id] %}*/
/*                                     {{ form_start(policyDeleteForm, {"action": path("admin_policyDelete", {"roleId": role.id, "policyId": policy.id})}) }}*/
/*                                     {{ form_widget(policyDeleteForm.policyId) }}*/
/*                                     {{ form_widget(policyDeleteForm.roleId) }}*/
/*                                     {{*/
/*                                         form_widget(*/
/*                                             policyDeleteForm.delete,*/
/*                                             {*/
/*                                                 "disabled": not can_edit,*/
/*                                                 "attr": {"class": "pure-button ez-button ez-font-icon ez-button-delete"}*/
/*                                             }*/
/*                                         )*/
/*                                     }}*/
/*                                     {{ form_end(policyDeleteForm) }}*/
/*                                 </td>*/
/*                             </tr>*/
/*                         {% else %}*/
/*                             <tr>*/
/*                                 <td colspan="5">{{ 'role.policy_none'|trans }}</td>*/
/*                             </tr>*/
/*                         {% endfor %}*/
/*                         </tbody>*/
/*                     </table>*/
/* */
/*                     {{ form_start(deleteForm, {"action": path("admin_roleDelete", {"roleId": role.id})}) }}*/
/*                         <p class="ez-table-data-buttons">*/
/*                         {% if can_edit %}*/
/*                             <a href="{{ path('admin_policyEdit', {"roleId": role.id}) }}" class="pure-button ez-button" data-icon="&#xe616;">{{ 'role.policy.add'|trans }}</a>*/
/*                             <a href="{{ path('admin_roleUpdate', {"roleId": role.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'role.edit'|trans }}</a>*/
/*                         {% else %}*/
/*                             <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'role.edit'|trans }}</span>*/
/*                         {% endif %}*/
/* */
/*                             {{ form_widget(deleteForm.roleId) }}*/
/*                             {{*/
/*                                 form_widget(*/
/*                                     deleteForm.delete,*/
/*                                     {*/
/*                                         "disabled": not can_delete,*/
/*                                         "attr": {"class": "pure-button ez-button ez-remove-role-button ez-font-icon ez-button-delete"}*/
/*                                     }*/
/*                                 )*/
/*                             }}*/
/*                         </p>*/
/*                     {{ form_end(deleteForm) }}*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/* */
/*         <div class="ez-tabs-panel" id="ez-tabs-content">*/
/*             <div class="ez-table-data is-flexible">*/
/*                 <div class="ez-table-data-container">*/
/*                     <table class="pure-table pure-table-striped ez-selection-table">*/
/*                         <thead>*/
/*                         <tr class="ez-selection-table-row">*/
/*                             <th>{{ 'assignment.user_or_group'|trans }}</th>*/
/*                             <th>{{ 'assignment.role_limitation'|trans }}</th>*/
/*                             <th></th>*/
/*                         </tr>*/
/*                         </thead>*/
/*                         <tbody>*/
/*                         {% for role_assignment in role_assignments %}*/
/*                             {# @var role_assignment \eZ\Publish\API\Repository\Values\User\RoleAssignment #}*/
/*                             <tr>*/
/*                                 <td>*/
/*                                     {# These should be linked to the user/group views. See follow-up EZP-25030 #}*/
/*                                     {%- if role_assignment.getUserGroup is defined -%}*/
/*                                         {{ ez_content_name( role_assignment.usergroup ) }}*/
/*                                     {%- else -%}*/
/*                                         {{ ez_content_name( role_assignment.user ) }}*/
/*                                     {%- endif -%}*/
/*                                 </td>*/
/*                                 <td>*/
/*                                     {%- if role_assignment.rolelimitation -%}*/
/*                                         {{- role_assignment.rolelimitation.identifier -}}*/
/*                                         {%- for limitationValue in role_assignment.rolelimitation.limitationValues -%}*/
/*                                             {%- if loop.first -%}( {% endif -%}*/
/*                                             {# TODO: https://jira.ez.no/browse/EZP-24699 Enrich Role limitations view with links and human readable names #}*/
/*                                             {{- limitationValue -}}*/
/*                                             {%- if not loop.last -%}, {% endif -%}*/
/*                                             {%- if loop.last %} ){%- endif -%}*/
/*                                         {%- endfor -%}*/
/*                                         {%- if not loop.last -%}, {% endif -%}*/
/*                                     {%- else -%}*/
/*                                         {{- 'assignment.role_limitation_none'|trans -}}*/
/*                                     {%- endif -%}*/
/*                                 </td>*/
/*                                 <td>*/
/*                                     {% set deleteForm = deleteFormsByAssignment[role_assignment.id] %}*/
/*                                     {{ form_start(deleteForm, {"action": path("admin_roleAssignmentDelete", {"roleAssignmentId": role_assignment.id, "redirectErrorsTo": "view"})}) }}*/
/*                                     {{ form_widget(deleteForm.assignmentId) }}*/
/*                                     {{*/
/*                                         form_widget(*/
/*                                             deleteForm.delete,*/
/*                                             {*/
/*                                                 "disabled": not can_assign,*/
/*                                                 "attr": {"class": "pure-button ez-button ez-remove-roleassignment-button ez-font-icon ez-button-delete"}*/
/*                                             }*/
/*                                         )*/
/*                                     }}*/
/*                                     {{ form_end(deleteForm) }}*/
/*                                 </td>*/
/*                             </tr>*/
/*                         {% else %}*/
/*                             <tr>*/
/*                                 <td colspan="3">{{ 'assignment.none'|trans }}</td>*/
/*                             </tr>*/
/*                         {% endfor %}*/
/*                         </tbody>*/
/*                     </table>*/
/*                     <p>*/
/*                         <button*/
/*                                 data-universaldiscovery-title="{{ 'role.assign.universaldiscovery.title'|trans({'%roleIdentifier%': role.identifier })|e('html_attr') }}"*/
/*                                 data-role-rest-id="{{ path( 'ezpublish_rest_loadRole', {'roleId': role.id}) }}"*/
/*                                 data-role-name="{{ role.identifier }}"*/
/*                                 data-role-assignment-limitation-type="{{ 'none' }}"*/
/*                                 class="ez-role-assign-button ez-button-tree pure-button ez-font-icon ez-button">*/
/*                             {% if not can_assign %}disabled{% endif %}*/
/*                             {{ 'role.assign.user_or_group'|trans }}*/
/*                         </button>*/
/*                         <button*/
/*                                 data-universaldiscovery-title="{{ 'role.assign.universaldiscovery.title'|trans({'%roleIdentifier%': role.identifier })|e('html_attr') }}"*/
/*                                 data-universaldiscovery-limit-subtree-title="{{ 'role.assign_limit_subtree.universaldiscovery.title'|trans({'%roleIdentifier%': role.identifier })|e('html_attr') }}"*/
/*                                 data-role-rest-id="{{ path( 'ezpublish_rest_loadRole', {'roleId': role.id}) }}"*/
/*                                 data-role-name="{{ role.identifier }}"*/
/*                                 data-role-assignment-limitation-type="{{ 'Subtree' }}"*/
/*                                 class="ez-role-assign-limit-subtree-button ez-button-tree pure-button ez-font-icon ez-button">*/
/*                             {% if not can_assign %}disabled{% endif %}*/
/*                             {{ 'role.assign_limit_subtree.user_or_group'|trans }}*/
/*                         </button>*/
/*                         {% if can_assign %}*/
/*                             <a href="{{ path('admin_roleAssignSection', {"roleId": role.id}) }}" class="ez-button-tree pure-button ez-font-icon ez-button">*/
/*                                 {{- 'role.assign_limit_section.user_or_group'|trans -}}*/
/*                             </a>*/
/*                         {% else %}*/
/*                             <span class="ez-button-tree ez-font-icon pure-button ez-button pure-button-disabled">*/
/*                                 {{- 'role.assign_limit_section.user_or_group'|trans -}}*/
/*                             </span>*/
/*                         {% endif %}*/
/*                     </p>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'role'|trans }}{% endblock %}*/
/* */
