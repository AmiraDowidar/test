<?php

/* eZPlatformUIBundle:ez-support-tools/info:hardware.html.twig */
class __TwigTemplate_769ccce11c8ab1d84731b74dcba4782233e04a830fe953daa6870b05a01271c3 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<h1>";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("hardware", array(), "systeminfo"), "html", null, true);
        echo "</h1>
<dl>
    <dt>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("cpu", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>
        ";
        // line 7
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "cpuType", array()), "html", null, true);
        echo "
        ";
        // line 8
        if ($this->getAttribute((isset($context["info"]) ? $context["info"] : null), "cpuSpeed", array())) {
            // line 9
            echo "            (";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "cpuCount", array()), "html", null, true);
            echo "x";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "cpuSpeed", array()), "html", null, true);
            echo "&nbsp;";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("mhz", array(), "systeminfo"), "html", null, true);
            echo ")
        ";
        }
        // line 11
        echo "    </dd>
    <dt>";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("memory", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.fileSize')->sizeFilter($this->getAttribute((isset($context["info"]) ? $context["info"] : null), "memorySize", array()), 1), "html", null, true);
        echo "</dd>
</dl>
";
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ez-support-tools/info:hardware.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 13,  51 => 12,  48 => 11,  38 => 9,  36 => 8,  32 => 7,  27 => 5,  22 => 3,  19 => 2,);
    }
}
/* {% trans_default_domain "systeminfo" %}*/
/* */
/* <h1>{{ 'hardware'|trans }}</h1>*/
/* <dl>*/
/*     <dt>{{ 'cpu'|trans }}</dt>*/
/*     <dd>*/
/*         {{ info.cpuType }}*/
/*         {% if info.cpuSpeed %}*/
/*             ({{ info.cpuCount }}x{{ info.cpuSpeed }}&nbsp;{{ 'mhz'|trans }})*/
/*         {% endif %}*/
/*     </dd>*/
/*     <dt>{{ 'memory'|trans }}</dt>*/
/*     <dd>{{ info.memorySize|ez_file_size( 1 ) }}</dd>*/
/* </dl>*/
/* */
