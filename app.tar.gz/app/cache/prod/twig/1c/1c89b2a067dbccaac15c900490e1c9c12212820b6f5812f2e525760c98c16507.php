<?php

/* eZPlatformUIBundle:Language:edit.html.twig */
class __TwigTemplate_90e97dac20ef5fbe0a64c2b9695cbf45ff3c2ab67eddb98eba8629c7bc268faa extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Language:edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 5
        $context["editTitle"] = (($this->getAttribute((isset($context["language"]) ? $context["language"] : null), "new", array())) ? ($this->env->getExtension('translator')->trans("language.create.title", array(), "language")) : ($this->env->getExtension('translator')->trans("language.edit.title", array("%languageName%" => $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "name", array())), "language")));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, (isset($context["editTitle"]) ? $context["editTitle"] : null), "html", null, true);
        echo "
";
    }

    // line 11
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 12
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_languagelist"), "label" => $this->env->getExtension('translator')->trans("language.list", array(), "language")), 2 => array("link" => (($this->getAttribute(        // line 16
(isset($context["language"]) ? $context["language"] : null), "new", array())) ? ("") : ($this->env->getExtension('routing')->getPath("admin_languageview", array("languageId" => $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "id", array()))))), "label" => $this->env->getExtension('translator')->trans("language.view.title", array("%languageName%" => $this->getAttribute(        // line 17
(isset($context["language"]) ? $context["language"] : null), "name", array())), "language")), 3 => array("link" => "", "label" =>         // line 19
(isset($context["editTitle"]) ? $context["editTitle"] : null)));
        // line 21
        echo "
    ";
        // line 22
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 25
    public function block_header_title($context, array $blocks = array())
    {
        // line 26
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">
        ";
        // line 27
        echo twig_escape_filter($this->env, (isset($context["editTitle"]) ? $context["editTitle"] : null), "html", null, true);
        echo "
    </h1>
";
    }

    // line 31
    public function block_content($context, array $blocks = array())
    {
        // line 32
        echo "    <section class=\"ez-serverside-content\">
        ";
        // line 33
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("action" => (isset($context["actionUrl"]) ? $context["actionUrl"] : null), "attr" => array("class" => "pure-form pure-form-aligned")));
        echo "
            ";
        // line 34
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'errors');
        echo "

            <fieldset>
                <div class=\"pure-control-group\">
                    ";
        // line 38
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "name", array()), 'label');
        echo "
                    ";
        // line 39
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "name", array()), 'errors');
        echo "
                    ";
        // line 40
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "name", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 44
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "languageCode", array()), 'label');
        echo "
                    ";
        // line 45
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "languageCode", array()), 'errors');
        echo "
                    ";
        // line 46
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "languageCode", array()), 'widget', array("disabled" =>  !$this->getAttribute((isset($context["language"]) ? $context["language"] : null), "new", array())));
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 50
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "enabled", array()), 'label');
        echo "
                    ";
        // line 51
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "enabled", array()), 'errors');
        echo "
                    ";
        // line 52
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "enabled", array()), 'widget');
        echo "
                </div>
            </fieldset>

            <div class=\"pure-controls\">
                <a href=\"";
        // line 57
        echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["language"]) ? $context["language"] : null), "new", array())) ? ($this->env->getExtension('routing')->getPath("admin_languagelist")) : ($this->env->getExtension('routing')->getPath("admin_languageview", array("languageId" => $this->getAttribute((isset($context["language"]) ? $context["language"] : null), "id", array()))))), "html", null, true);
        echo "\"
                   class=\"pure-button ez-button\">";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.cancel", array(), "language"), "html", null, true);
        echo "</a>
                ";
        // line 59
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "save", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
            </div>

        ";
        // line 62
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
    </section>
";
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Language:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  152 => 62,  146 => 59,  142 => 58,  138 => 57,  130 => 52,  126 => 51,  122 => 50,  115 => 46,  111 => 45,  107 => 44,  100 => 40,  96 => 39,  92 => 38,  85 => 34,  81 => 33,  78 => 32,  75 => 31,  68 => 27,  65 => 26,  62 => 25,  56 => 22,  53 => 21,  51 => 19,  50 => 17,  49 => 16,  47 => 12,  44 => 11,  37 => 8,  34 => 7,  30 => 1,  28 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "language" %}*/
/* */
/* {% set editTitle = language.new ? "language.create.title"|trans() : "language.edit.title"|trans({"%languageName%": language.name}) %}*/
/* */
/* {% block title %}*/
/*     {{ editTitle }}*/
/* {% endblock %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_languagelist'), label: 'language.list'|trans({})},*/
/*         {*/
/*             link: language.new ? "" : path('admin_languageview', {'languageId': language.id}),*/
/*             label: 'language.view.title'|trans({'%languageName%': language.name})*/
/*         },*/
/*         {link: '', label: editTitle}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">*/
/*         {{ editTitle }}*/
/*     </h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         {{ form_start(form, {'action': actionUrl, "attr": {"class": "pure-form pure-form-aligned"}}) }}*/
/*             {{ form_errors(form) }}*/
/* */
/*             <fieldset>*/
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.name) }}*/
/*                     {{ form_errors(form.name) }}*/
/*                     {{ form_widget(form.name) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.languageCode) }}*/
/*                     {{ form_errors(form.languageCode) }}*/
/*                     {{ form_widget(form.languageCode, {"disabled": (not language.new)}) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.enabled) }}*/
/*                     {{ form_errors(form.enabled) }}*/
/*                     {{ form_widget(form.enabled) }}*/
/*                 </div>*/
/*             </fieldset>*/
/* */
/*             <div class="pure-controls">*/
/*                 <a href="{{ language.new ? path("admin_languagelist") : path("admin_languageview", {"languageId": language.id}) }}"*/
/*                    class="pure-button ez-button">{{ "language.cancel"|trans }}</a>*/
/*                 {{ form_widget(form.save, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*             </div>*/
/* */
/*         {{ form_end(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
