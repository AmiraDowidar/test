<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_6c39d1a9df894b85b5630b800aecbebde5e93fbd2717b0bfa3dd78d4cc6e1d8d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
