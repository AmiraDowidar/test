<?php

/* eZPlatformUIBundle:Exception:exception_full.html.twig */
class __TwigTemplate_5d7ac8178c34133b607a2e78730c7e5afaba0ffb7550bbce4154a32d7b9e3fd6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'notification' => array($this, 'block_notification'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"sf-reset\">
        ";
        // line 5
        echo twig_include($this->env, $context, "TwigBundle:Exception:exception.html.twig");
        echo "
    </div>

    <style type=\"text/css\">
        @import url('";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/structure.css")), "html", null, true);
        echo "');
        @import url('";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/body.css")), "html", null, true);
        echo "');
        @import url('";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "');
    </style>
";
    }

    // line 15
    public function block_notification($context, array $blocks = array())
    {
        // line 16
        echo "    <li data-state=\"error\">";
        echo $this->env->getExtension('code')->formatFileFromText(nl2br(twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : null), "message", array()), "html", null, true)));
        echo "</li>
";
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  60 => 16,  57 => 15,  50 => 11,  46 => 10,  42 => 9,  35 => 5,  32 => 4,  29 => 3,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% block content %}*/
/*     <div class="sf-reset">*/
/*         {{ include("TwigBundle:Exception:exception.html.twig") }}*/
/*     </div>*/
/* */
/*     <style type="text/css">*/
/*         @import url('{{ absolute_url(asset('bundles/framework/css/structure.css')) }}');*/
/*         @import url('{{ absolute_url(asset('bundles/framework/css/body.css')) }}');*/
/*         @import url('{{ absolute_url(asset('bundles/framework/css/exception.css')) }}');*/
/*     </style>*/
/* {% endblock %}*/
/* */
/* {% block notification %}*/
/*     <li data-state="error">{{ exception.message|nl2br|format_file_from_text }}</li>*/
/* {% endblock %}*/
/* */
