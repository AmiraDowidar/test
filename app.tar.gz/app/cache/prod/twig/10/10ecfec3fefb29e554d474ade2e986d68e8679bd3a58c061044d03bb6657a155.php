<?php

/* eZPlatformUIBundle:Role:update_role.html.twig */
class __TwigTemplate_d27d5b046a8dbf95dc40a34218138b07b9c43a337e4ef3bc39cceb8ac3c9eec6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Role:update_role.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'notification' => array($this, 'block_notification'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 7
        $context["edit_title"] = $this->env->getExtension('translator')->trans("role.edit_title", array("%roleName%" => $this->env->getExtension('translator')->trans((isset($context["role_name"]) ? $context["role_name"] : null), array(), "role")), "role");
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 9
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, (isset($context["edit_title"]) ? $context["edit_title"] : null), "html", null, true);
    }

    // line 11
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 12
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_role"), "label" => $this->env->getExtension('translator')->trans("role.dashboard_title", array(), "role")), 2 => array("link" => null, "label" =>         // line 15
(isset($context["edit_title"]) ? $context["edit_title"] : null)));
        // line 17
        echo "
    ";
        // line 18
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 21
    public function block_header_title($context, array $blocks = array())
    {
        // line 22
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe62d;\">";
        echo twig_escape_filter($this->env, (isset($context["edit_title"]) ? $context["edit_title"] : null), "html", null, true);
        echo "</h1>
";
    }

    // line 25
    public function block_content($context, array $blocks = array())
    {
        // line 26
        echo "    <section class=\"ez-serverside-content\">
        ";
        // line 27
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("action" => (isset($context["action_url"]) ? $context["action_url"] : null), "attr" => array("class" => "pure-form pure-form-aligned")));
        echo "
            ";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'errors');
        echo "

            <fieldset>
                <div class=\"pure-control-group\">
                    ";
        // line 32
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "identifier", array()), 'label');
        echo "
                    ";
        // line 33
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "identifier", array()), 'errors');
        echo "
                    ";
        // line 34
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "identifier", array()), 'widget');
        echo "
                </div>
            </fieldset>

            <div class=\"pure-controls\">
                ";
        // line 39
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "removeDraft", array()), 'widget', array("attr" => array("class" => "pure-button ez-button", "formnovalidate" => "formnovalidate")));
        echo "
                ";
        // line 40
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "saveRole", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
            </div>

        ";
        // line 43
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
    </section>
";
    }

    // line 47
    public function block_notification($context, array $blocks = array())
    {
        // line 48
        echo "    ";
        if (twig_length_filter($this->env, (isset($context["hasErrors"]) ? $context["hasErrors"] : null))) {
            // line 49
            echo "        <li data-state=\"error\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("form.validation_error", array(), "general"), "html", null, true);
            echo "</li>
    ";
        }
        // line 51
        echo "    ";
        $this->displayParentBlock("notification", $context, $blocks);
        echo "
";
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Role:update_role.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  129 => 51,  123 => 49,  120 => 48,  117 => 47,  110 => 43,  104 => 40,  100 => 39,  92 => 34,  88 => 33,  84 => 32,  77 => 28,  73 => 27,  70 => 26,  67 => 25,  60 => 22,  57 => 21,  51 => 18,  48 => 17,  46 => 15,  44 => 12,  41 => 11,  35 => 9,  31 => 1,  29 => 7,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* {# @var role_draft \eZ\Publish\API\Repository\Values\User\RoleDraft #}*/
/* {# @var role_name string #}*/
/* */
/* {% trans_default_domain "role" %}*/
/* */
/* {% set edit_title = "role.edit_title"|trans({"%roleName%": role_name|trans}) %}*/
/* */
/* {% block title %}{{ edit_title }}{% endblock %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path("admin_dashboard"), label: "dashboard.title"|trans({}, "dashboard")},*/
/*         {link: path("admin_role"), label: "role.dashboard_title"|trans({}, "role")},*/
/*         {link: null, label: edit_title}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe62d;">{{ edit_title }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         {{ form_start(form, {"action": action_url, "attr": {"class": "pure-form pure-form-aligned"}}) }}*/
/*             {{ form_errors(form) }}*/
/* */
/*             <fieldset>*/
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.identifier) }}*/
/*                     {{ form_errors(form.identifier) }}*/
/*                     {{ form_widget(form.identifier) }}*/
/*                 </div>*/
/*             </fieldset>*/
/* */
/*             <div class="pure-controls">*/
/*                 {{ form_widget(form.removeDraft, {"attr": {"class": "pure-button ez-button", "formnovalidate": "formnovalidate"}}) }}*/
/*                 {{ form_widget(form.saveRole, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*             </div>*/
/* */
/*         {{ form_end(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block notification %}*/
/*     {% if hasErrors|length %}*/
/*         <li data-state="error">{{ "form.validation_error"|trans(domain="general") }}</li>*/
/*     {% endif %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
