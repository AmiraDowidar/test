<?php

/* EzSystemsRepositoryFormsBundle:ContentType:field_types.html.twig */
class __TwigTemplate_e4bea8f5211c716b7c04e46548684cb8357d3f6acb17ac697c31884e7d5f35b2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'ezbinaryfile_field_definition_edit' => array($this, 'block_ezbinaryfile_field_definition_edit'),
            'ezcountry_field_definition_edit' => array($this, 'block_ezcountry_field_definition_edit'),
            'ezdate_field_definition_edit' => array($this, 'block_ezdate_field_definition_edit'),
            'ezdatetime_field_definition_edit' => array($this, 'block_ezdatetime_field_definition_edit'),
            'ezfloat_field_definition_edit' => array($this, 'block_ezfloat_field_definition_edit'),
            'ezimage_field_definition_edit' => array($this, 'block_ezimage_field_definition_edit'),
            'ezinteger_field_definition_edit' => array($this, 'block_ezinteger_field_definition_edit'),
            'ezisbn_field_definition_edit' => array($this, 'block_ezisbn_field_definition_edit'),
            'ezmedia_field_definition_edit' => array($this, 'block_ezmedia_field_definition_edit'),
            'ezobjectrelation_field_definition_edit' => array($this, 'block_ezobjectrelation_field_definition_edit'),
            'ezobjectrelationlist_field_definition_edit' => array($this, 'block_ezobjectrelationlist_field_definition_edit'),
            'ezpage_field_definition_edit' => array($this, 'block_ezpage_field_definition_edit'),
            'ezrichtext_field_definition_edit' => array($this, 'block_ezrichtext_field_definition_edit'),
            'ezselection_field_definition_edit' => array($this, 'block_ezselection_field_definition_edit'),
            'ezstring_field_definition_edit' => array($this, 'block_ezstring_field_definition_edit'),
            'eztext_field_definition_edit' => array($this, 'block_eztext_field_definition_edit'),
            'eztime_field_definition_edit' => array($this, 'block_eztime_field_definition_edit'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 8
        echo "
";
        // line 11
        $this->displayBlock('ezbinaryfile_field_definition_edit', $context, $blocks);
        // line 18
        echo "
";
        // line 19
        $this->displayBlock('ezcountry_field_definition_edit', $context, $blocks);
        // line 32
        echo "
";
        // line 33
        $this->displayBlock('ezdate_field_definition_edit', $context, $blocks);
        // line 40
        echo "
";
        // line 41
        $this->displayBlock('ezdatetime_field_definition_edit', $context, $blocks);
        // line 60
        echo "
";
        // line 61
        $this->displayBlock('ezfloat_field_definition_edit', $context, $blocks);
        // line 74
        echo "
";
        // line 75
        $this->displayBlock('ezimage_field_definition_edit', $context, $blocks);
        // line 82
        echo "
";
        // line 83
        $this->displayBlock('ezinteger_field_definition_edit', $context, $blocks);
        // line 96
        echo "
";
        // line 97
        $this->displayBlock('ezisbn_field_definition_edit', $context, $blocks);
        // line 104
        echo "
";
        // line 105
        $this->displayBlock('ezmedia_field_definition_edit', $context, $blocks);
        // line 118
        echo "
";
        // line 119
        $this->displayBlock('ezobjectrelation_field_definition_edit', $context, $blocks);
        // line 137
        echo "
";
        // line 138
        $this->displayBlock('ezobjectrelationlist_field_definition_edit', $context, $blocks);
        // line 162
        echo "
";
        // line 163
        $this->displayBlock('ezpage_field_definition_edit', $context, $blocks);
        // line 170
        echo "
";
        // line 171
        $this->displayBlock('ezrichtext_field_definition_edit', $context, $blocks);
        // line 178
        echo "
";
        // line 179
        $this->displayBlock('ezselection_field_definition_edit', $context, $blocks);
        // line 199
        echo "
";
        // line 200
        $this->displayBlock('ezstring_field_definition_edit', $context, $blocks);
        // line 219
        echo "
";
        // line 220
        $this->displayBlock('eztext_field_definition_edit', $context, $blocks);
        // line 227
        echo "
";
        // line 228
        $this->displayBlock('eztime_field_definition_edit', $context, $blocks);
    }

    // line 11
    public function block_ezbinaryfile_field_definition_edit($context, array $blocks = array())
    {
        // line 12
        echo "    <div class=\"ezbinaryfile-validator max-file-size";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 13
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxSize", array()), 'label');
        // line 14
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxSize", array()), 'errors');
        // line 15
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxSize", array()), 'widget');
        // line 16
        echo "</div>
";
    }

    // line 19
    public function block_ezcountry_field_definition_edit($context, array $blocks = array())
    {
        // line 20
        echo "    <div class=\"ezcountry-settings is-multiple";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 21
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isMultiple", array()), 'label');
        // line 22
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isMultiple", array()), 'errors');
        // line 23
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isMultiple", array()), 'widget');
        // line 24
        echo "</div>

    <div class=\"ezcountry-default-value";
        // line 26
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 27
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultValue", array()), 'label');
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultValue", array()), 'errors');
        // line 29
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultValue", array()), 'widget');
        // line 30
        echo "</div>
";
    }

    // line 33
    public function block_ezdate_field_definition_edit($context, array $blocks = array())
    {
        // line 34
        echo "    <div class=\"ezdate-settings default-type";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 35
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultType", array()), 'label');
        // line 36
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultType", array()), 'errors');
        // line 37
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultType", array()), 'widget');
        // line 38
        echo "</div>
";
    }

    // line 41
    public function block_ezdatetime_field_definition_edit($context, array $blocks = array())
    {
        // line 42
        echo "    <div class=\"ezdatetime-settings use-seconds";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 43
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "useSeconds", array()), 'label');
        // line 44
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "useSeconds", array()), 'errors');
        // line 45
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "useSeconds", array()), 'widget');
        // line 46
        echo "</div>

    <div class=\"ezdatetime-settings default-type";
        // line 48
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 49
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultType", array()), 'label');
        // line 50
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultType", array()), 'errors');
        // line 51
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultType", array()), 'widget');
        // line 52
        echo "</div>

    <div class=\"ezdatetime-settings date-interval";
        // line 54
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 55
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "dateInterval", array()), 'label');
        // line 56
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "dateInterval", array()), 'errors');
        // line 57
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "dateInterval", array()), 'widget');
        // line 58
        echo "</div>
";
    }

    // line 61
    public function block_ezfloat_field_definition_edit($context, array $blocks = array())
    {
        // line 62
        echo "    <div class=\"ezfloat-validator min-value";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 63
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "minValue", array()), 'label');
        // line 64
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "minValue", array()), 'errors');
        // line 65
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "minValue", array()), 'widget');
        // line 66
        echo "</div>

    <div class=\"ezfloat-validator max-value";
        // line 68
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 69
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxValue", array()), 'label');
        // line 70
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxValue", array()), 'errors');
        // line 71
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxValue", array()), 'widget');
        // line 72
        echo "</div>
";
    }

    // line 75
    public function block_ezimage_field_definition_edit($context, array $blocks = array())
    {
        // line 76
        echo "    <div class=\"ezimage-validator max-file-size";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 77
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxSize", array()), 'label');
        // line 78
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxSize", array()), 'errors');
        // line 79
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxSize", array()), 'widget');
        // line 80
        echo "</div>
";
    }

    // line 83
    public function block_ezinteger_field_definition_edit($context, array $blocks = array())
    {
        // line 84
        echo "    <div class=\"ezinteger-validator min-value";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 85
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "minValue", array()), 'label');
        // line 86
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "minValue", array()), 'errors');
        // line 87
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "minValue", array()), 'widget');
        // line 88
        echo "</div>

    <div class=\"ezinteger-validator max-value";
        // line 90
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 91
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxValue", array()), 'label');
        // line 92
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxValue", array()), 'errors');
        // line 93
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxValue", array()), 'widget');
        // line 94
        echo "</div>
";
    }

    // line 97
    public function block_ezisbn_field_definition_edit($context, array $blocks = array())
    {
        // line 98
        echo "    <div class=\"ezisbn-settings is-isbn13";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 99
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isISBN13", array()), 'label');
        // line 100
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isISBN13", array()), 'errors');
        // line 101
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isISBN13", array()), 'widget');
        // line 102
        echo "</div>
";
    }

    // line 105
    public function block_ezmedia_field_definition_edit($context, array $blocks = array())
    {
        // line 106
        echo "    <div class=\"ezmedia-validator max-file-size";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 107
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxSize", array()), 'label');
        // line 108
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxSize", array()), 'errors');
        // line 109
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxSize", array()), 'widget');
        // line 110
        echo "</div>

    <div class=\"ezmedia-settings media-type";
        // line 112
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 113
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "mediaType", array()), 'label');
        // line 114
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "mediaType", array()), 'errors');
        // line 115
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "mediaType", array()), 'widget');
        // line 116
        echo "</div>
";
    }

    // line 119
    public function block_ezobjectrelation_field_definition_edit($context, array $blocks = array())
    {
        // line 120
        echo "    <div class=\"ezobjectrelation-settings selection-root\">";
        // line 121
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionRoot", array()), 'label');
        // line 122
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionRoot", array()), 'errors');
        // line 123
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionRoot", array()), 'widget');
        // line 125
        echo "<button data-universaldiscovery-title=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("field_definition.ezobjectrelation.selection_root_udw_title", array(), "ezrepoforms_content_type"), "html", null, true);
        echo "\"
                class=\"ez-button-tree pure-button ez-font-icon ez-button ez-relation-pick-root-button\"
                data-relation-root-input-selector=\"#";
        // line 127
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionRoot", array()), "vars", array()), "id", array()), "html", null, true);
        echo "\"
                data-relation-selected-root-name-selector=\"#";
        // line 128
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionRoot", array()), "vars", array()), "id", array()), "html", null, true);
        echo "-selected-root-name\"
                >";
        // line 129
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("field_definition.ezobjectrelation.selection_root_udw_button", array(), "ezrepoforms_content_type"), "html", null, true);
        echo "</button>
        <div id=\"";
        // line 130
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionRoot", array()), "vars", array()), "id", array()), "html", null, true);
        echo "-selected-root-name\">
            ";
        // line 131
        if ( !twig_test_empty($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionRoot", array()), "vars", array()), "value", array()))) {
            // line 132
            echo "                ";
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("ez_content:viewLocation", array("locationId" => $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionRoot", array()), "vars", array()), "value", array()), "viewType" => "_platformui_content_name")));
            echo "
            ";
        }
        // line 134
        echo "        </div>
    </div>
";
    }

    // line 138
    public function block_ezobjectrelationlist_field_definition_edit($context, array $blocks = array())
    {
        // line 139
        echo "    <div class=\"ezobjectrelationlist-settings selection-default-location\">";
        // line 140
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionDefaultLocation", array()), 'label');
        // line 141
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionDefaultLocation", array()), 'errors');
        // line 142
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionDefaultLocation", array()), 'widget');
        // line 144
        echo "<button data-universaldiscovery-title=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("field_definition.ezobjectrelationlist.selection_root_udw_title", array(), "ezrepoforms_content_type"), "html", null, true);
        echo "\"
                class=\"ez-button-tree pure-button ez-font-icon ez-button ez-relation-pick-root-button\"
                data-relation-root-input-selector=\"#";
        // line 146
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionDefaultLocation", array()), "vars", array()), "id", array()), "html", null, true);
        echo "\"
                data-relation-selected-root-name-selector=\"#";
        // line 147
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionDefaultLocation", array()), "vars", array()), "id", array()), "html", null, true);
        echo "-selected-root-name\"
                >";
        // line 148
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("field_definition.ezobjectrelationlist.selection_root_udw_button", array(), "ezrepoforms_content_type"), "html", null, true);
        echo "</button>
        <div id=\"";
        // line 149
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionDefaultLocation", array()), "vars", array()), "id", array()), "html", null, true);
        echo "-selected-root-name\">
            ";
        // line 150
        if ( !twig_test_empty($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionDefaultLocation", array()), "vars", array()), "value", array()))) {
            // line 151
            echo "                ";
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("ez_content:viewLocation", array("locationId" => $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionDefaultLocation", array()), "vars", array()), "value", array()), "viewType" => "_platformui_content_name")));
            echo "
            ";
        }
        // line 153
        echo "        </div>
    </div>

    <div class=\"ezobjectrelationlist-settings selection-content-types\">";
        // line 157
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionContentTypes", array()), 'label');
        // line 158
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionContentTypes", array()), 'errors');
        // line 159
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "selectionContentTypes", array()), 'widget');
        // line 160
        echo "</div>
";
    }

    // line 163
    public function block_ezpage_field_definition_edit($context, array $blocks = array())
    {
        // line 164
        echo "    <div class=\"ezpage-settings default-layout";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 165
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultLayout", array()), 'label');
        // line 166
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultLayout", array()), 'errors');
        // line 167
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultLayout", array()), 'widget');
        // line 168
        echo "</div>
";
    }

    // line 171
    public function block_ezrichtext_field_definition_edit($context, array $blocks = array())
    {
        // line 172
        echo "    <div class=\"ezrichtext-settings num-rows";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 173
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "numRows", array()), 'label');
        // line 174
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "numRows", array()), 'errors');
        // line 175
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "numRows", array()), 'widget');
        // line 176
        echo "</div>
";
    }

    // line 179
    public function block_ezselection_field_definition_edit($context, array $blocks = array())
    {
        // line 180
        echo "    <div class=\"ezselection-settings is-multiple";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 181
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isMultiple", array()), 'label');
        // line 182
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isMultiple", array()), 'errors');
        // line 183
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "isMultiple", array()), 'widget');
        // line 184
        echo "</div>

    <div class=\"ezselection-settings options";
        // line 186
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">
        ";
        // line 187
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "options", array()), 'label');
        echo "
        ";
        // line 188
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "options", array()), 'errors');
        echo "
        ";
        // line 189
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "options", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["option"]) {
            // line 190
            echo "            <div>
                ";
            // line 191
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["option"], 'errors');
            echo "
                ";
            // line 192
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["option"], 'widget');
            echo "
            </div>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 195
        echo "        ";
        // line 196
        echo "        ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "options", array()), "vars", array()), "prototype", array()), 'widget');
        echo "
    </div>
";
    }

    // line 200
    public function block_ezstring_field_definition_edit($context, array $blocks = array())
    {
        // line 201
        echo "    <div class=\"ezstring-validator min-length";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 202
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "minLength", array()), 'label');
        // line 203
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "minLength", array()), 'errors');
        // line 204
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "minLength", array()), 'widget');
        // line 205
        echo "</div>

    <div class=\"ezstring-validator max-length";
        // line 207
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 208
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxLength", array()), 'label');
        // line 209
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxLength", array()), 'errors');
        // line 210
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "maxLength", array()), 'widget');
        // line 211
        echo "</div>

    <div class=\"ezstring-default-value";
        // line 213
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 214
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultValue", array()), 'label');
        // line 215
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultValue", array()), 'errors');
        // line 216
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultValue", array()), 'widget');
        // line 217
        echo "</div>
";
    }

    // line 220
    public function block_eztext_field_definition_edit($context, array $blocks = array())
    {
        // line 221
        echo "    <div class=\"eztext-settings text-rows";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 222
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "textRows", array()), 'label');
        // line 223
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "textRows", array()), 'errors');
        // line 224
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "textRows", array()), 'widget');
        // line 225
        echo "</div>
";
    }

    // line 228
    public function block_eztime_field_definition_edit($context, array $blocks = array())
    {
        // line 229
        echo "    <div class=\"eztime-settings use-seconds";
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 230
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "useSeconds", array()), 'label');
        // line 231
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "useSeconds", array()), 'errors');
        // line 232
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "useSeconds", array()), 'widget');
        // line 233
        echo "</div>

    <div class=\"eztime-settings default-type";
        // line 235
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : null))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : null), "html", null, true);
        }
        echo "\">";
        // line 236
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultType", array()), 'label');
        // line 237
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultType", array()), 'errors');
        // line 238
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "defaultType", array()), 'widget');
        // line 239
        echo "</div>
";
    }

    public function getTemplateName()
    {
        return "EzSystemsRepositoryFormsBundle:ContentType:field_types.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  725 => 239,  723 => 238,  721 => 237,  719 => 236,  713 => 235,  709 => 233,  707 => 232,  705 => 231,  703 => 230,  696 => 229,  693 => 228,  688 => 225,  686 => 224,  684 => 223,  682 => 222,  675 => 221,  672 => 220,  667 => 217,  665 => 216,  663 => 215,  661 => 214,  655 => 213,  651 => 211,  649 => 210,  647 => 209,  645 => 208,  639 => 207,  635 => 205,  633 => 204,  631 => 203,  629 => 202,  622 => 201,  619 => 200,  611 => 196,  609 => 195,  600 => 192,  596 => 191,  593 => 190,  589 => 189,  585 => 188,  581 => 187,  574 => 186,  570 => 184,  568 => 183,  566 => 182,  564 => 181,  557 => 180,  554 => 179,  549 => 176,  547 => 175,  545 => 174,  543 => 173,  536 => 172,  533 => 171,  528 => 168,  526 => 167,  524 => 166,  522 => 165,  515 => 164,  512 => 163,  507 => 160,  505 => 159,  503 => 158,  501 => 157,  496 => 153,  490 => 151,  488 => 150,  484 => 149,  480 => 148,  476 => 147,  472 => 146,  466 => 144,  464 => 142,  462 => 141,  460 => 140,  458 => 139,  455 => 138,  449 => 134,  443 => 132,  441 => 131,  437 => 130,  433 => 129,  429 => 128,  425 => 127,  419 => 125,  417 => 123,  415 => 122,  413 => 121,  411 => 120,  408 => 119,  403 => 116,  401 => 115,  399 => 114,  397 => 113,  391 => 112,  387 => 110,  385 => 109,  383 => 108,  381 => 107,  374 => 106,  371 => 105,  366 => 102,  364 => 101,  362 => 100,  360 => 99,  353 => 98,  350 => 97,  345 => 94,  343 => 93,  341 => 92,  339 => 91,  333 => 90,  329 => 88,  327 => 87,  325 => 86,  323 => 85,  316 => 84,  313 => 83,  308 => 80,  306 => 79,  304 => 78,  302 => 77,  295 => 76,  292 => 75,  287 => 72,  285 => 71,  283 => 70,  281 => 69,  275 => 68,  271 => 66,  269 => 65,  267 => 64,  265 => 63,  258 => 62,  255 => 61,  250 => 58,  248 => 57,  246 => 56,  244 => 55,  238 => 54,  234 => 52,  232 => 51,  230 => 50,  228 => 49,  222 => 48,  218 => 46,  216 => 45,  214 => 44,  212 => 43,  205 => 42,  202 => 41,  197 => 38,  195 => 37,  193 => 36,  191 => 35,  184 => 34,  181 => 33,  176 => 30,  174 => 29,  172 => 28,  170 => 27,  164 => 26,  160 => 24,  158 => 23,  156 => 22,  154 => 21,  147 => 20,  144 => 19,  139 => 16,  137 => 15,  135 => 14,  133 => 13,  126 => 12,  123 => 11,  119 => 228,  116 => 227,  114 => 220,  111 => 219,  109 => 200,  106 => 199,  104 => 179,  101 => 178,  99 => 171,  96 => 170,  94 => 163,  91 => 162,  89 => 138,  86 => 137,  84 => 119,  81 => 118,  79 => 105,  76 => 104,  74 => 97,  71 => 96,  69 => 83,  66 => 82,  64 => 75,  61 => 74,  59 => 61,  56 => 60,  54 => 41,  51 => 40,  49 => 33,  46 => 32,  44 => 19,  41 => 18,  39 => 11,  36 => 8,);
    }
}
/* {# Template blocks to be used for fieldDefinition edition #}*/
/* {# Block naming convention is <fieldTypeIdentifier>_field_definition_edit #}*/
/* {# Following variables are passed:*/
/*  # - \EzSystems\RepositoryForms\Data\FieldDefinitionData data Data object for current fieldDefinition.*/
/*  # - \Symfony\Component\Form\FormView form Field definition form.*/
/*  # - string languageCode*/
/*  #}*/
/* */
/* {# @var data \EzSystems\RepositoryForms\Data\FieldDefinitionData #}*/
/* {# @var form \Symfony\Component\Form\FormView #}*/
/* {% block ezbinaryfile_field_definition_edit %}*/
/*     <div class="ezbinaryfile-validator max-file-size{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.maxSize) -}}*/
/*         {{- form_errors(form.maxSize) -}}*/
/*         {{- form_widget(form.maxSize) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezcountry_field_definition_edit %}*/
/*     <div class="ezcountry-settings is-multiple{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.isMultiple) -}}*/
/*         {{- form_errors(form.isMultiple) -}}*/
/*         {{- form_widget(form.isMultiple) -}}*/
/*     </div>*/
/* */
/*     <div class="ezcountry-default-value{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.defaultValue) -}}*/
/*         {{- form_errors(form.defaultValue) -}}*/
/*         {{- form_widget(form.defaultValue) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezdate_field_definition_edit %}*/
/*     <div class="ezdate-settings default-type{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.defaultType) -}}*/
/*         {{- form_errors(form.defaultType) -}}*/
/*         {{- form_widget(form.defaultType) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezdatetime_field_definition_edit %}*/
/*     <div class="ezdatetime-settings use-seconds{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.useSeconds) -}}*/
/*         {{- form_errors(form.useSeconds) -}}*/
/*         {{- form_widget(form.useSeconds) -}}*/
/*     </div>*/
/* */
/*     <div class="ezdatetime-settings default-type{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.defaultType) -}}*/
/*         {{- form_errors(form.defaultType) -}}*/
/*         {{- form_widget(form.defaultType) -}}*/
/*     </div>*/
/* */
/*     <div class="ezdatetime-settings date-interval{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.dateInterval) -}}*/
/*         {{- form_errors(form.dateInterval) -}}*/
/*         {{- form_widget(form.dateInterval) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezfloat_field_definition_edit %}*/
/*     <div class="ezfloat-validator min-value{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.minValue) -}}*/
/*         {{- form_errors(form.minValue) -}}*/
/*         {{- form_widget(form.minValue) -}}*/
/*     </div>*/
/* */
/*     <div class="ezfloat-validator max-value{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.maxValue) -}}*/
/*         {{- form_errors(form.maxValue) -}}*/
/*         {{- form_widget(form.maxValue) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezimage_field_definition_edit %}*/
/*     <div class="ezimage-validator max-file-size{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.maxSize) -}}*/
/*         {{- form_errors(form.maxSize) -}}*/
/*         {{- form_widget(form.maxSize) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezinteger_field_definition_edit %}*/
/*     <div class="ezinteger-validator min-value{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.minValue) -}}*/
/*         {{- form_errors(form.minValue) -}}*/
/*         {{- form_widget(form.minValue) -}}*/
/*     </div>*/
/* */
/*     <div class="ezinteger-validator max-value{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.maxValue) -}}*/
/*         {{- form_errors(form.maxValue) -}}*/
/*         {{- form_widget(form.maxValue) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezisbn_field_definition_edit %}*/
/*     <div class="ezisbn-settings is-isbn13{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.isISBN13) -}}*/
/*         {{- form_errors(form.isISBN13) -}}*/
/*         {{- form_widget(form.isISBN13) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezmedia_field_definition_edit %}*/
/*     <div class="ezmedia-validator max-file-size{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.maxSize) -}}*/
/*         {{- form_errors(form.maxSize) -}}*/
/*         {{- form_widget(form.maxSize) -}}*/
/*     </div>*/
/* */
/*     <div class="ezmedia-settings media-type{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.mediaType) -}}*/
/*         {{- form_errors(form.mediaType) -}}*/
/*         {{- form_widget(form.mediaType) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezobjectrelation_field_definition_edit %}*/
/*     <div class="ezobjectrelation-settings selection-root">*/
/*         {{- form_label(form.selectionRoot) -}}*/
/*         {{- form_errors(form.selectionRoot) -}}*/
/*         {{- form_widget(form.selectionRoot) -}}*/
/* */
/*         <button data-universaldiscovery-title="{{"field_definition.ezobjectrelation.selection_root_udw_title"|trans({}, "ezrepoforms_content_type")}}"*/
/*                 class="ez-button-tree pure-button ez-font-icon ez-button ez-relation-pick-root-button"*/
/*                 data-relation-root-input-selector="#{{form.selectionRoot.vars.id}}"*/
/*                 data-relation-selected-root-name-selector="#{{form.selectionRoot.vars.id}}-selected-root-name"*/
/*                 >{{"field_definition.ezobjectrelation.selection_root_udw_button"|trans({}, "ezrepoforms_content_type")}}</button>*/
/*         <div id="{{form.selectionRoot.vars.id}}-selected-root-name">*/
/*             {% if form.selectionRoot.vars.value is not empty %}*/
/*                 {{ render( controller( "ez_content:viewLocation", {'locationId': form.selectionRoot.vars.value, 'viewType': '_platformui_content_name'} ) ) }}*/
/*             {% endif %}*/
/*         </div>*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezobjectrelationlist_field_definition_edit %}*/
/*     <div class="ezobjectrelationlist-settings selection-default-location">*/
/*         {{- form_label(form.selectionDefaultLocation) -}}*/
/*         {{- form_errors(form.selectionDefaultLocation) -}}*/
/*         {{- form_widget(form.selectionDefaultLocation) -}}*/
/* */
/*         <button data-universaldiscovery-title="{{"field_definition.ezobjectrelationlist.selection_root_udw_title"|trans({}, "ezrepoforms_content_type")}}"*/
/*                 class="ez-button-tree pure-button ez-font-icon ez-button ez-relation-pick-root-button"*/
/*                 data-relation-root-input-selector="#{{form.selectionDefaultLocation.vars.id}}"*/
/*                 data-relation-selected-root-name-selector="#{{form.selectionDefaultLocation.vars.id}}-selected-root-name"*/
/*                 >{{"field_definition.ezobjectrelationlist.selection_root_udw_button"|trans({}, "ezrepoforms_content_type")}}</button>*/
/*         <div id="{{form.selectionDefaultLocation.vars.id}}-selected-root-name">*/
/*             {% if form.selectionDefaultLocation.vars.value is not empty %}*/
/*                 {{ render( controller( "ez_content:viewLocation", {'locationId': form.selectionDefaultLocation.vars.value, 'viewType': '_platformui_content_name'} ) ) }}*/
/*             {% endif %}*/
/*         </div>*/
/*     </div>*/
/* */
/*     <div class="ezobjectrelationlist-settings selection-content-types">*/
/*         {{- form_label(form.selectionContentTypes) -}}*/
/*         {{- form_errors(form.selectionContentTypes) -}}*/
/*         {{- form_widget(form.selectionContentTypes) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezpage_field_definition_edit %}*/
/*     <div class="ezpage-settings default-layout{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.defaultLayout) -}}*/
/*         {{- form_errors(form.defaultLayout) -}}*/
/*         {{- form_widget(form.defaultLayout) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezrichtext_field_definition_edit %}*/
/*     <div class="ezrichtext-settings num-rows{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.numRows) -}}*/
/*         {{- form_errors(form.numRows) -}}*/
/*         {{- form_widget(form.numRows) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezselection_field_definition_edit %}*/
/*     <div class="ezselection-settings is-multiple{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.isMultiple) -}}*/
/*         {{- form_errors(form.isMultiple) -}}*/
/*         {{- form_widget(form.isMultiple) -}}*/
/*     </div>*/
/* */
/*     <div class="ezselection-settings options{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{ form_label(form.options) }}*/
/*         {{ form_errors(form.options) }}*/
/*         {% for option in form.options %}*/
/*             <div>*/
/*                 {{ form_errors(option) }}*/
/*                 {{ form_widget(option) }}*/
/*             </div>*/
/*         {% endfor %}*/
/*         {# This field is used for adding new select items #}*/
/*         {{ form_widget(form.options.vars.prototype) }}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block ezstring_field_definition_edit %}*/
/*     <div class="ezstring-validator min-length{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.minLength) -}}*/
/*         {{- form_errors(form.minLength) -}}*/
/*         {{- form_widget(form.minLength) -}}*/
/*     </div>*/
/* */
/*     <div class="ezstring-validator max-length{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.maxLength) -}}*/
/*         {{- form_errors(form.maxLength) -}}*/
/*         {{- form_widget(form.maxLength) -}}*/
/*     </div>*/
/* */
/*     <div class="ezstring-default-value{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.defaultValue) -}}*/
/*         {{- form_errors(form.defaultValue) -}}*/
/*         {{- form_widget(form.defaultValue) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block eztext_field_definition_edit %}*/
/*     <div class="eztext-settings text-rows{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.textRows) -}}*/
/*         {{- form_errors(form.textRows) -}}*/
/*         {{- form_widget(form.textRows) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block eztime_field_definition_edit %}*/
/*     <div class="eztime-settings use-seconds{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.useSeconds) -}}*/
/*         {{- form_errors(form.useSeconds) -}}*/
/*         {{- form_widget(form.useSeconds) -}}*/
/*     </div>*/
/* */
/*     <div class="eztime-settings default-type{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*         {{- form_label(form.defaultType) -}}*/
/*         {{- form_errors(form.defaultType) -}}*/
/*         {{- form_widget(form.defaultType) -}}*/
/*     </div>*/
/* {% endblock %}*/
/* */
