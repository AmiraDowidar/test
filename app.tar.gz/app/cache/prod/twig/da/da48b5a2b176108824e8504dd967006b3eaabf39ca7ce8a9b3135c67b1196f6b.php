<?php

/* EzPublishCoreBundle:default/content:full.html.twig */
class __TwigTemplate_910bfa78b7d825ffad1257fc6aad141c208f654d8bcb73ab45d1ced41488c1d8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate(((((isset($context["noLayout"]) ? $context["noLayout"] : null) == true)) ? ((isset($context["viewbaseLayout"]) ? $context["viewbaseLayout"] : null)) : ((isset($context["pagelayout"]) ? $context["pagelayout"] : null))), "EzPublishCoreBundle:default/content:full.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        // line 3
        echo "    <h2>";
        echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : null)), "html", null, true);
        echo "</h2>
    ";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["content"]) ? $context["content"] : null), "fieldsByLanguage", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            // line 5
            echo "        <h3>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["field"], "fieldDefIdentifier", array()), "html", null, true);
            echo "</h3>
        ";
            // line 6
            echo call_user_func_array($this->env->getFunction('ez_render_field')->getCallable(), array($this->env, (isset($context["content"]) ? $context["content"] : null), $this->getAttribute($context["field"], "fieldDefIdentifier", array())));
            echo "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/content:full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 6,  39 => 5,  35 => 4,  30 => 3,  27 => 2,  18 => 1,);
    }
}
/* {% extends noLayout == true ? viewbaseLayout : pagelayout %}*/
/* {% block content %}*/
/*     <h2>{{ ez_content_name(content) }}</h2>*/
/*     {% for field in content.fieldsByLanguage %}*/
/*         <h3>{{ field.fieldDefIdentifier }}</h3>*/
/*         {{ ez_render_field(content, field.fieldDefIdentifier) }}*/
/*     {% endfor %}*/
/* {% endblock %}*/
/* */
