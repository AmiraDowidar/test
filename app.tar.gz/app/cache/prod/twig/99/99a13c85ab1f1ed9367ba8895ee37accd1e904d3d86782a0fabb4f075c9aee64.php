<?php

/* eZPlatformUIBundle:components:breadcrumbs.html.twig */
class __TwigTemplate_93277f98093a202487542dc8e60088b7419b4117ca7bae3902768a1e2b039f47 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 6
        echo "<nav class=\"ez-breadcrumbs\">
    <ul class=\"ez-breadcrumbs-list\">
        ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["items"]) ? $context["items"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 9
            echo "            <li class=\"ez-breadcrumbs-item\">
                ";
            // line 10
            if ( !twig_test_empty($this->getAttribute($context["item"], "link", array()))) {
                // line 11
                echo "                    <a href=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "link", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "label", array()), "html", null, true);
                echo "</a>
                ";
            } else {
                // line 13
                echo "                    ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "label", array()), "html", null, true);
                echo "
                ";
            }
            // line 15
            echo "            </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "    </ul>
</nav>

";
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:components:breadcrumbs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 17,  46 => 15,  40 => 13,  32 => 11,  30 => 10,  27 => 9,  23 => 8,  19 => 6,);
    }
}
/* {#*/
/*  # Template dispalying the breadcrumbs.*/
/*  # Parameter :*/
/*  # - items: an array of hashes with a "link" and a "label" for each item.*/
/* #}*/
/* <nav class="ez-breadcrumbs">*/
/*     <ul class="ez-breadcrumbs-list">*/
/*         {% for item in items %}*/
/*             <li class="ez-breadcrumbs-item">*/
/*                 {% if item.link is not empty %}*/
/*                     <a href="{{ item.link }}">{{ item.label }}</a>*/
/*                 {% else %}*/
/*                     {{ item.label }}*/
/*                 {% endif %}*/
/*             </li>*/
/*         {% endfor %}*/
/*     </ul>*/
/* </nav>*/
/* */
/* */
