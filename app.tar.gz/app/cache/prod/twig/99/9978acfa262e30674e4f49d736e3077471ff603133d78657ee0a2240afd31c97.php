<?php

/* EzPublishCoreBundle:default/block:block.html.twig */
class __TwigTemplate_c2ffdfe26eb73cf9794a40aa08dc35daa4705fc9df395be285b5c60b9dfc97e5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div>
    <h3>Block ";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : null), "name", array()), "html", null, true);
        echo "</h3>
    <h3>Block view: ";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : null), "view", array()), "html", null, true);
        echo "</h3>
</div>
";
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/block:block.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 3,  22 => 2,  19 => 1,);
    }
}
/* <div>*/
/*     <h3>Block {{ block.name }}</h3>*/
/*     <h3>Block view: {{ block.view }}</h3>*/
/* </div>*/
/* */
