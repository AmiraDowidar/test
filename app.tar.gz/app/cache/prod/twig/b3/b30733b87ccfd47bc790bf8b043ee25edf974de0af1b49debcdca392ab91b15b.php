<?php

/* EzPublishCoreBundle:FieldType/RichText/embed:location_denied.html.twig */
class __TwigTemplate_a852dd8fc649f8667c554d687157daaeab8108251975fedce29a7f866a937436 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"";
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "align", array(), "any", true, true)) {
            echo "align-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "align", array()), "html", null, true);
        }
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "class", array(), "any", true, true)) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "class", array()), "html", null, true);
        }
        echo "\">
    Location #";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "id", array()), "html", null, true);
        echo ": You do not have permission to view this Location
</div>
";
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/embed:location_denied.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  31 => 2,  19 => 1,);
    }
}
/* <div class="{% if embedParams.align is defined %}align-{{ embedParams.align }}{% endif %}{% if embedParams.class is defined %} {{ embedParams.class }}{% endif %}">*/
/*     Location #{{ embedParams.id }}: You do not have permission to view this Location*/
/* </div>*/
/* */
