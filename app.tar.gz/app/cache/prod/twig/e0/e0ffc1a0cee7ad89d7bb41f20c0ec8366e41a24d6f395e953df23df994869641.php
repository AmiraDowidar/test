<?php

/* eZPlatformUIBundle:ContentType:view_content_type_group.html.twig */
class __TwigTemplate_3c809c77ac0100d894610d44d7476430a42a76260d3244e637c3e82731ee0c8c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:ContentType:view_content_type_group.html.twig", 3);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 8
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_contenttype"), "label" => $this->env->getExtension('translator')->trans("content_type.dashboard_title", array(), "content_type")), 2 => array("link" => null, "label" => $this->getAttribute(        // line 11
(isset($context["group"]) ? $context["group"] : null), "identifier", array())));
        // line 13
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 16
    public function block_header_title($context, array $blocks = array())
    {
        // line 17
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group", array("%name%" => $this->getAttribute((isset($context["group"]) ? $context["group"] : null), "identifier", array())), "content_type"), "html", null, true);
        echo "</h1>
";
    }

    // line 20
    public function block_content($context, array $blocks = array())
    {
        // line 21
        echo "    <section class=\"ez-serverside-content\">
        <div class=\"ez-table-data is-flexible\">
            <div class=\"ez-table-data-container\">
                <table class=\"pure-table pure-table-striped ez-selection-table\">
                    <thead>
                    <tr class=\"ez-selection-table-row\">
                        <th>";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.id", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th>";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.name", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th>";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.identifier", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th>";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.modified_date", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th></th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["content_types"]) ? $context["content_types"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["content_type"]) {
            // line 37
            echo "                        <tr>
                            <td>";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["content_type"], "id", array()), "html", null, true);
            echo "</td>
                            <td><a class=\"ez-contenttype-icon ez-contenttype-icon-";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["content_type"], "identifier", array()), "html", null, true);
            echo "\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_contenttypeView", array("contentTypeId" => $this->getAttribute($context["content_type"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.content')->getTranslatedProperty($context["content_type"], "name"), "html", null, true);
            echo "</a></td>
                            <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["content_type"], "identifier", array()), "html", null, true);
            echo "</td>
                            <td>";
            // line 41
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["content_type"], "modificationDate", array()), "medium", "medium", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "locale", array())), "html", null, true);
            echo "</td>
                            <td>
                            ";
            // line 43
            if ((isset($context["can_edit"]) ? $context["can_edit"] : null)) {
                // line 44
                echo "                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_contenttypeUpdate", array("contentTypeId" => $this->getAttribute($context["content_type"], "id", array()))), "html", null, true);
                echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.edit", array(), "content_type"), "html", null, true);
                echo "</a>
                            ";
            } else {
                // line 46
                echo "                                <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.edit", array(), "content_type"), "html", null, true);
                echo "</span>
                            ";
            }
            // line 48
            echo "                            </td>
                            <td>
                                ";
            // line 50
            $context["deleteForm"] = $this->getAttribute((isset($context["delete_forms_by_id"]) ? $context["delete_forms_by_id"] : null), $this->getAttribute($context["content_type"], "id", array()), array(), "array");
            // line 51
            echo "                                ";
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_contenttypeDelete", array("contentTypeId" => $this->getAttribute($context["content_type"], "id", array())))));
            echo "
                                    ";
            // line 52
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : null), "contentTypeId", array()), 'widget');
            echo "
                                    ";
            // line 53
            echo             // line 54
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(            // line 55
(isset($context["deleteForm"]) ? $context["deleteForm"] : null), "delete", array()), 'widget', array("disabled" =>  !$this->getAttribute(            // line 57
(isset($context["can_delete_by_id"]) ? $context["can_delete_by_id"] : null), $this->getAttribute($context["content_type"], "id", array()), array(), "array"), "attr" => array("class" => "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete", "title" => (( !$this->getAttribute(            // line 59
(isset($context["can_delete_by_id"]) ? $context["can_delete_by_id"] : null), $this->getAttribute($context["content_type"], "id", array()), array(), "array")) ? ($this->env->getExtension('translator')->trans("content_type.is_in_use", array(), "content_type")) : ("")))));
            // line 62
            echo "
                                ";
            // line 63
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_end');
            echo "
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['content_type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 67
        echo "                    </tbody>
                </table>
                ";
        // line 69
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["create_form"]) ? $context["create_form"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_contenttypeCreate", array("contentTypeGroupId" => $this->getAttribute((isset($context["group"]) ? $context["group"] : null), "id", array())))));
        echo "
                <p class=\"ez-table-data-buttons\">
                    ";
        // line 72
        echo "                    ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : null), "contentTypeGroupId", array()), 'widget');
        echo "
                    <button type=\"submit\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\"";
        // line 73
        if ( !(isset($context["can_create"]) ? $context["can_create"] : null)) {
            echo " disabled=\"disabled\"";
        }
        // line 74
        echo "                            name=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : null), "create", array()), "vars", array()), "full_name", array(), "array"), "html", null, true);
        echo "\"
                            id=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : null), "create", array()), "vars", array()), "id", array(), "array"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : null), "create", array()), "vars", array()), "label", array(), "array"), array(), "ezrepoforms_content_type"), "html", null, true);
        echo "</button>
                    ";
        // line 76
        $this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : null), "create", array()), "setRendered", array(), "method");
        // line 77
        echo "                </p>
                ";
        // line 78
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["create_form"]) ? $context["create_form"] : null), 'form_end');
        echo "
            </div>
        </div>
    </section>
";
    }

    // line 84
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.list", array(), "content_type"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ContentType:view_content_type_group.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  208 => 84,  199 => 78,  196 => 77,  194 => 76,  188 => 75,  183 => 74,  179 => 73,  174 => 72,  169 => 69,  165 => 67,  155 => 63,  152 => 62,  150 => 59,  149 => 57,  148 => 55,  147 => 54,  146 => 53,  142 => 52,  137 => 51,  135 => 50,  131 => 48,  125 => 46,  117 => 44,  115 => 43,  110 => 41,  106 => 40,  98 => 39,  94 => 38,  91 => 37,  87 => 36,  78 => 30,  74 => 29,  70 => 28,  66 => 27,  58 => 21,  55 => 20,  48 => 17,  45 => 16,  38 => 13,  36 => 11,  34 => 8,  31 => 7,  11 => 3,);
    }
}
/* {# @var group \eZ\Publish\API\Repository\Values\ContentType\ContentTypeGroup #}*/
/* {# @var content_types \eZ\Publish\API\Repository\Values\ContentType\ContentType[] #}*/
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "content_type" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_contenttype'), label: 'content_type.dashboard_title'|trans},*/
/*         {link: null, label: group.identifier}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'content_type.group'|trans({'%name%': group.identifier}) }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <div class="ez-table-data is-flexible">*/
/*             <div class="ez-table-data-container">*/
/*                 <table class="pure-table pure-table-striped ez-selection-table">*/
/*                     <thead>*/
/*                     <tr class="ez-selection-table-row">*/
/*                         <th>{{ 'content_type.id'|trans }}</th>*/
/*                         <th>{{ 'content_type.name'|trans }}</th>*/
/*                         <th>{{ 'content_type.identifier'|trans }}</th>*/
/*                         <th>{{ 'content_type.modified_date'|trans }}</th>*/
/*                         <th></th>*/
/*                         <th></th>*/
/*                     </tr>*/
/*                     </thead>*/
/*                     <tbody>*/
/*                     {% for content_type in content_types %}*/
/*                         <tr>*/
/*                             <td>{{ content_type.id }}</td>*/
/*                             <td><a class="ez-contenttype-icon ez-contenttype-icon-{{ content_type.identifier }}" href="{{ path('admin_contenttypeView', {'contentTypeId': content_type.id}) }}">{{ ez_trans_prop(content_type, "name") }}</a></td>*/
/*                             <td>{{ content_type.identifier }}</td>*/
/*                             <td>{{ content_type.modificationDate|localizeddate("medium", "medium", app.request.locale) }}</td>*/
/*                             <td>*/
/*                             {% if can_edit %}*/
/*                                 <a href="{{ path('admin_contenttypeUpdate', {'contentTypeId': content_type.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'content_type.edit'|trans }}</a>*/
/*                             {% else %}*/
/*                                 <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'content_type.edit'|trans }}</span>*/
/*                             {% endif %}*/
/*                             </td>*/
/*                             <td>*/
/*                                 {% set deleteForm = delete_forms_by_id[content_type.id] %}*/
/*                                 {{ form_start(deleteForm, {"action": path("admin_contenttypeDelete", {"contentTypeId": content_type.id})}) }}*/
/*                                     {{ form_widget(deleteForm.contentTypeId) }}*/
/*                                     {{*/
/*                                         form_widget(*/
/*                                             deleteForm.delete,*/
/*                                             {*/
/*                                                 "disabled": not can_delete_by_id[content_type.id],*/
/*                                                 "attr": {"class": "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete",*/
/*                                                          "title": not can_delete_by_id[content_type.id] ? 'content_type.is_in_use'|trans}*/
/*                                             }*/
/*                                         )*/
/*                                     }}*/
/*                                 {{ form_end(deleteForm) }}*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*                     </tbody>*/
/*                 </table>*/
/*                 {{ form_start(create_form, {"action": path("admin_contenttypeCreate", {"contentTypeGroupId": group.id})}) }}*/
/*                 <p class="ez-table-data-buttons">*/
/*                     {# TODO: We should be able to select a language for ContentType creation #}*/
/*                     {{ form_widget(create_form.contentTypeGroupId) }}*/
/*                     <button type="submit" class="pure-button ez-button" data-icon="&#xe616;"{% if not can_create %} disabled="disabled"{% endif %}*/
/*                             name="{{ create_form.create.vars['full_name'] }}"*/
/*                             id="{{ create_form.create.vars['id'] }}">{{ create_form.create.vars['label']|trans(domain="ezrepoforms_content_type") }}</button>*/
/*                     {% do create_form.create.setRendered() %}*/
/*                 </p>*/
/*                 {{ form_end(create_form) }}*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'content_type.group.list'|trans }}{% endblock %}*/
/* */
/* */
