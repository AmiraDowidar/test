<?php

/* EzSystemsRepositoryFormsBundle:Limitation:base_limitation_values.html.twig */
class __TwigTemplate_a0d6b58fb2e7a30d8a70630e908335a6bb54d23e77df7cce1c2e561d6caf9ee5 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "limitationValues", array()), 'label');
        echo "
";
        // line 2
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "limitationValues", array()), 'errors');
        echo "
";
        // line 3
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "limitationValues", array()), 'widget');
        echo "
";
    }

    public function getTemplateName()
    {
        return "EzSystemsRepositoryFormsBundle:Limitation:base_limitation_values.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  23 => 2,  19 => 1,);
    }
}
/* {{ form_label(form.limitationValues) }}*/
/* {{ form_errors(form.limitationValues) }}*/
/* {{ form_widget(form.limitationValues) }}*/
/* */
