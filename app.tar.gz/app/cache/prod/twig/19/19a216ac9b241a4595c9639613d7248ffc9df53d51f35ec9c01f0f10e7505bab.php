<?php

/* eZPlatformUIBundle:Role:list_roles.html.twig */
class __TwigTemplate_77fde1507dad334bc91c788f4445c91c055b1f6f5347dceb5779a263bd8e0fdf extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Role:list_roles.html.twig", 2);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 6
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 7
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => null, "label" => $this->env->getExtension('translator')->trans("role.list", array(), "role")));
        // line 11
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 14
    public function block_header_title($context, array $blocks = array())
    {
        // line 15
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe62d;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.list", array(), "role"), "html", null, true);
        echo "</h1>
";
    }

    // line 18
    public function block_content($context, array $blocks = array())
    {
        // line 19
        echo "    <section class=\"ez-serverside-content\">
        <div class=\"ez-table-data is-flexible\">
            <div class=\"ez-table-data-container\">
                <table class=\"pure-table pure-table-striped ez-selection-table\">
                    <thead>
                    <tr class=\"ez-selection-table-row\">
                        <th>";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.name", array(), "role"), "html", null, true);
        echo "</th>
                        <th>";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.id", array(), "role"), "html", null, true);
        echo "</th>
                        <th colspan=\"2\"></th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["roles"]) ? $context["roles"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
            // line 32
            echo "                        ";
            // line 33
            echo "                        <tr class=\"ez-role\">
                            <td class=\"ez-role-name\"><a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_roleView", array("roleId" => $this->getAttribute($context["role"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["role"], "identifier", array()), "html", null, true);
            echo "</a></td>
                            <td class=\"ez-role-id\">";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["role"], "id", array()), "html", null, true);
            echo "</td>
                            <td class=\"ez-role-edit\">
                                <button
                                    data-universaldiscovery-title=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign.universaldiscovery.title", array("%roleIdentifier%" => $this->getAttribute($context["role"], "identifier", array())), "role"), "html_attr");
            echo "\"
                                    data-role-rest-id=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadRole", array("roleId" => $this->getAttribute($context["role"], "id", array()))), "html", null, true);
            echo "\"
                                    data-role-name=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["role"], "identifier", array()), "html", null, true);
            echo "\"
                                    class=\"ez-role-assign-button ez-button-tree pure-button ez-font-icon ez-button\"
                                    ";
            // line 42
            if ( !(isset($context["can_assign"]) ? $context["can_assign"] : null)) {
                echo "disabled=\"disabled\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign.user_or_group", array(), "role"), "html", null, true);
            echo "</button>
                            </td>
                            <td>
                                <a href=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_roleUpdate", array("roleId" => $this->getAttribute($context["role"], "id", array()))), "html", null, true);
            echo "\" class=\"pure-button ez-button";
            if ( !(isset($context["can_edit"]) ? $context["can_edit"] : null)) {
                echo " pure-button-disabled";
            }
            echo "\" data-icon=\"&#xe606;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.edit", array(), "role"), "html", null, true);
            echo "</a>
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "                    </tbody>
                </table>
                ";
        // line 51
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["create_form"]) ? $context["create_form"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_roleCreate")));
        echo "
                <p class=\"ez-table-data-buttons\">
                    <button type=\"submit\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\"";
        // line 53
        if ( !(isset($context["can_create"]) ? $context["can_create"] : null)) {
            echo " disabled=\"disabled\"";
        }
        // line 54
        echo "                            name=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : null), "create", array()), "vars", array()), "full_name", array(), "array"), "html", null, true);
        echo "\"
                            id=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : null), "create", array()), "vars", array()), "id", array(), "array"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : null), "create", array()), "vars", array()), "label", array(), "array"), array(), "ezrepoforms_role"), "html", null, true);
        echo "</button>
                    ";
        // line 56
        $this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : null), "create", array()), "setRendered", array(), "method");
        // line 57
        echo "                </p>
                ";
        // line 58
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["create_form"]) ? $context["create_form"] : null), 'form_end');
        echo "
            </div>
        </div>
    </section>
";
    }

    // line 64
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.list", array(), "role"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Role:list_roles.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  175 => 64,  166 => 58,  163 => 57,  161 => 56,  155 => 55,  150 => 54,  146 => 53,  141 => 51,  137 => 49,  121 => 45,  111 => 42,  106 => 40,  102 => 39,  98 => 38,  92 => 35,  86 => 34,  83 => 33,  81 => 32,  77 => 31,  69 => 26,  65 => 25,  57 => 19,  54 => 18,  47 => 15,  44 => 14,  37 => 11,  34 => 7,  31 => 6,  11 => 2,);
    }
}
/* {# @var roles \eZ\Publish\API\Repository\Values\User\Role[] #}*/
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "role" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: null, label: 'role.list'|trans}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe62d;">{{ 'role.list'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <div class="ez-table-data is-flexible">*/
/*             <div class="ez-table-data-container">*/
/*                 <table class="pure-table pure-table-striped ez-selection-table">*/
/*                     <thead>*/
/*                     <tr class="ez-selection-table-row">*/
/*                         <th>{{ 'role.name'|trans }}</th>*/
/*                         <th>{{ 'role.id'|trans }}</th>*/
/*                         <th colspan="2"></th>*/
/*                     </tr>*/
/*                     </thead>*/
/*                     <tbody>*/
/*                     {% for role in roles %}*/
/*                         {# @var role \eZ\Publish\API\Repository\Values\User\Role #}*/
/*                         <tr class="ez-role">*/
/*                             <td class="ez-role-name"><a href="{{ path("admin_roleView", {"roleId": role.id}) }}">{{ role.identifier }}</a></td>*/
/*                             <td class="ez-role-id">{{ role.id }}</td>*/
/*                             <td class="ez-role-edit">*/
/*                                 <button*/
/*                                     data-universaldiscovery-title="{{ 'role.assign.universaldiscovery.title'|trans({'%roleIdentifier%': role.identifier })|e('html_attr') }}"*/
/*                                     data-role-rest-id="{{ path( 'ezpublish_rest_loadRole', {'roleId': role.id}) }}"*/
/*                                     data-role-name="{{ role.identifier }}"*/
/*                                     class="ez-role-assign-button ez-button-tree pure-button ez-font-icon ez-button"*/
/*                                     {% if not can_assign %}disabled="disabled"{% endif %}>{{ 'role.assign.user_or_group'|trans }}</button>*/
/*                             </td>*/
/*                             <td>*/
/*                                 <a href="{{ path('admin_roleUpdate', {'roleId': role.id}) }}" class="pure-button ez-button{% if not can_edit %} pure-button-disabled{% endif %}" data-icon="&#xe606;">{{ 'role.edit'|trans }}</a>*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*                     </tbody>*/
/*                 </table>*/
/*                 {{ form_start(create_form, {"action": path("admin_roleCreate")}) }}*/
/*                 <p class="ez-table-data-buttons">*/
/*                     <button type="submit" class="pure-button ez-button" data-icon="&#xe616;"{% if not can_create %} disabled="disabled"{% endif %}*/
/*                             name="{{ create_form.create.vars['full_name'] }}"*/
/*                             id="{{ create_form.create.vars['id'] }}">{{ create_form.create.vars['label']|trans(domain="ezrepoforms_role") }}</button>*/
/*                     {% do create_form.create.setRendered() %}*/
/*                 </p>*/
/*                 {{ form_end(create_form) }}*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'role.list'|trans }}{% endblock %}*/
/* */
