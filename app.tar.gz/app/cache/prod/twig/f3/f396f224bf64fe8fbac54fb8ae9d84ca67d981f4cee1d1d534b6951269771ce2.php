<?php

/* EzPublishCoreBundle::pagelayout.html.twig */
class __TwigTemplate_05a93ab8958f582d8ebd1578a5dfb4abeccd96ccf3b491156ce0af86b9b6113f extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!doctype html>
<html lang=\"";
        // line 2
        echo twig_escape_filter($this->env, twig_replace_filter($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : null), "request", array()), "locale", array()), array("_" => "-")), "html", null, true);
        echo "\">
<head>
    <meta charset=\"utf-8\">
    ";
        // line 5
        if ((array_key_exists("content", $context) &&  !array_key_exists("title", $context))) {
            // line 6
            echo "        ";
            $context["title"] = $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : null));
            // line 7
            echo "    ";
        }
        // line 8
        echo "    <title>";
        echo twig_escape_filter($this->env, ((array_key_exists("title", $context)) ? (_twig_default_filter((isset($context["title"]) ? $context["title"] : null), "Home")) : ("Home")), "html", null, true);
        echo "</title>
    <meta name=\"generator\" content=\"eZ Platform\"/>
    ";
        // line 10
        if ((array_key_exists("content", $context) && $this->getAttribute($this->getAttribute((isset($context["content"]) ? $context["content"] : null), "contentInfo", array()), "mainLocationId", array()))) {
            // line 11
            echo "        <link rel=\"canonical\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ez_urlalias", array("locationId" => $this->getAttribute($this->getAttribute((isset($context["content"]) ? $context["content"] : null), "contentInfo", array()), "mainLocationId", array()))), "html", null, true);
            echo "\" />
    ";
        }
        // line 13
        echo "</head>
<body>
";
        // line 15
        $this->displayBlock('content', $context, $blocks);
        // line 16
        echo "</body>
</html>
";
    }

    // line 15
    public function block_content($context, array $blocks = array())
    {
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle::pagelayout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  63 => 15,  57 => 16,  55 => 15,  51 => 13,  45 => 11,  43 => 10,  37 => 8,  34 => 7,  31 => 6,  29 => 5,  23 => 2,  20 => 1,);
    }
}
/* <!doctype html>*/
/* <html lang="{{ app.request.locale|replace({'_': '-'}) }}">*/
/* <head>*/
/*     <meta charset="utf-8">*/
/*     {% if content is defined and title is not defined %}*/
/*         {% set title = ez_content_name( content ) %}*/
/*     {% endif %}*/
/*     <title>{{ title|default( 'Home' ) }}</title>*/
/*     <meta name="generator" content="eZ Platform"/>*/
/*     {% if content is defined and content.contentInfo.mainLocationId %}*/
/*         <link rel="canonical" href="{{ path( 'ez_urlalias', {'locationId': content.contentInfo.mainLocationId} ) }}" />*/
/*     {% endif %}*/
/* </head>*/
/* <body>*/
/* {% block content %}{% endblock %}*/
/* </body>*/
/* </html>*/
/* */
