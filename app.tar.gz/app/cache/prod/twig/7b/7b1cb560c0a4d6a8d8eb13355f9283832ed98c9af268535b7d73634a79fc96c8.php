<?php

/* eZPlatformUIBundle:ez-support-tools/info:database.html.twig */
class __TwigTemplate_e31ce3671e5a49a30da3805b2494f6ee35e34fe904c84ec378c4062124a9258e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 2
        echo "
<h1>";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("database", array(), "systeminfo"), "html", null, true);
        echo "</h1>
<dl>
    <dt>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("database.type", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "type", array()), "html", null, true);
        echo "</dd>
    <dt>";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("database.name", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "name", array()), "html", null, true);
        echo "</dd>
    <dt>";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("database.host", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "host", array()), "html", null, true);
        echo "</dd>
    <dt>";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("database.username", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : null), "username", array()), "html", null, true);
        echo "</dd>
</dl>
";
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ez-support-tools/info:database.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  55 => 12,  51 => 11,  47 => 10,  43 => 9,  39 => 8,  35 => 7,  31 => 6,  27 => 5,  22 => 3,  19 => 2,);
    }
}
/* {% trans_default_domain "systeminfo" %}*/
/* */
/* <h1>{{ 'database'|trans }}</h1>*/
/* <dl>*/
/*     <dt>{{ 'database.type'|trans }}</dt>*/
/*     <dd>{{ info.type }}</dd>*/
/*     <dt>{{ 'database.name'|trans }}</dt>*/
/*     <dd>{{ info.name }}</dd>*/
/*     <dt>{{ 'database.host'|trans }}</dt>*/
/*     <dd>{{ info.host }}</dd>*/
/*     <dt>{{ 'database.username'|trans }}</dt>*/
/*     <dd>{{ info.username }}</dd>*/
/* </dl>*/
/* */
