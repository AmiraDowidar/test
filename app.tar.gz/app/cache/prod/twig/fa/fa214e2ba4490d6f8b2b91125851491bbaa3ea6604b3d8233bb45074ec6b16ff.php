<?php

/* ::pagelayout_header.html.twig */
class __TwigTemplate_1b95f0bc0ff071afa82199ca4a758d3e49b4646504ce7f5cd36fd2f56154b1bb extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!-- nav header -->
<header class=\"main-header\">
  <a href=\"\" class=\"logo\">
    <img src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/white_logo.svg"), "html", null, true);
        echo "\" alt=\"\" />
  </a>
  <a class=\"mobile-menu-icon\">
    <i class=\"icon-menu visible-xs\"></i>
  </a>

  <menu class=\"mobile-menu\">
    <i class=\"icon-close\"></i>
    <ul>
      <li>
        <a href=\"#\">
          Rates
        </a>
      </li>
      <li>
        <a href=\"#\">
          support
        </a>
      </li>
      <li>
        <a href=\"#\" class=\"flags-list\">
          language
          <span class=\"pull-right\">
            English
            <i class=\"icon-arrow_down\"></i>
          </span>
        </a>
        <div class=\"langs\">
          <div class=\"\">
            <img src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/eng-GB.gif"), "html", null, true);
        echo "\" alt=\"\" /> English
          </div>
          <div class=\"\">
            <img src=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/esl-ES.gif"), "html", null, true);
        echo "\" alt=\"\" /> Español
          </div>
          <div class=\"\">
            <img src=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/fre-FR.gif"), "html", null, true);
        echo "\" alt=\"\" /> Français
          </div>
        </div>
      </li>
    </ul>
  </menu>

  <div class=\"right-section pull-right hidden-xs\">
    <nav class=\"pull-left\">
      <ul>
         <li>
          <a href=\"Rates\">
            Rates
          </a>
        </li>
        <li>
          <a href=\"#\">
            Support
          </a>
        </li>
        <li class=\"has_menu lang-switch\">
          <a href=\"#\">
            <img src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/eng-GB.gif"), "html", null, true);
        echo "\" alt=\"\" />
            English
          </a>
          <ul class=\"lang-list\">
            <li>
              <a href=\"#\">
                <img src=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/eng-GB.gif"), "html", null, true);
        echo "\" alt=\"\" />
                English
              </a>
            </li>
            <li>
              <a href=\"#\">
                <img src=\"";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/esl-ES.gif"), "html", null, true);
        echo "\" alt=\"\" />
                Español
              </a>
            </li>
            <li>
              <a href=\"#\">
                <img src=\"";
        // line 79
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/fre-FR.gif"), "html", null, true);
        echo "\" alt=\"\" />
                Français
              </a>
            </li>
          </ul>
        </li>
        <!-- <li class=\"has_menu\">
          <a href=\"#\">
            Device€
          </a>
        </li> -->
      </ul>
    </nav>
    <div class=\"social pull-left\">
            <a href=\"https://twitter.com/Libon\">
                <img src=\"";
        // line 94
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/twitter_icon.svg"), "html", null, true);
        echo "\">
            </a>
            <a href=\"https://www.facebook.com/libon.fan\">
                <img src=\"";
        // line 97
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/facebook_icon.svg"), "html", null, true);
        echo "\">
            </a>
        </div>
  </div>
</header>";
    }

    public function getTemplateName()
    {
        return "::pagelayout_header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  144 => 97,  138 => 94,  120 => 79,  111 => 73,  102 => 67,  93 => 61,  68 => 39,  62 => 36,  56 => 33,  24 => 4,  19 => 1,);
    }
}
/* <!-- nav header -->*/
/* <header class="main-header">*/
/*   <a href="" class="logo">*/
/*     <img src="{{ asset('assets/images/white_logo.svg') }}" alt="" />*/
/*   </a>*/
/*   <a class="mobile-menu-icon">*/
/*     <i class="icon-menu visible-xs"></i>*/
/*   </a>*/
/* */
/*   <menu class="mobile-menu">*/
/*     <i class="icon-close"></i>*/
/*     <ul>*/
/*       <li>*/
/*         <a href="#">*/
/*           Rates*/
/*         </a>*/
/*       </li>*/
/*       <li>*/
/*         <a href="#">*/
/*           support*/
/*         </a>*/
/*       </li>*/
/*       <li>*/
/*         <a href="#" class="flags-list">*/
/*           language*/
/*           <span class="pull-right">*/
/*             English*/
/*             <i class="icon-arrow_down"></i>*/
/*           </span>*/
/*         </a>*/
/*         <div class="langs">*/
/*           <div class="">*/
/*             <img src="{{ asset('assets/images/eng-GB.gif') }}" alt="" /> English*/
/*           </div>*/
/*           <div class="">*/
/*             <img src="{{ asset('assets/images/esl-ES.gif') }}" alt="" /> Español*/
/*           </div>*/
/*           <div class="">*/
/*             <img src="{{ asset('assets/images/fre-FR.gif') }}" alt="" /> Français*/
/*           </div>*/
/*         </div>*/
/*       </li>*/
/*     </ul>*/
/*   </menu>*/
/* */
/*   <div class="right-section pull-right hidden-xs">*/
/*     <nav class="pull-left">*/
/*       <ul>*/
/*          <li>*/
/*           <a href="Rates">*/
/*             Rates*/
/*           </a>*/
/*         </li>*/
/*         <li>*/
/*           <a href="#">*/
/*             Support*/
/*           </a>*/
/*         </li>*/
/*         <li class="has_menu lang-switch">*/
/*           <a href="#">*/
/*             <img src="{{ asset('assets/images/eng-GB.gif') }}" alt="" />*/
/*             English*/
/*           </a>*/
/*           <ul class="lang-list">*/
/*             <li>*/
/*               <a href="#">*/
/*                 <img src="{{ asset('assets/images/eng-GB.gif') }}" alt="" />*/
/*                 English*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 <img src="{{ asset('assets/images/esl-ES.gif') }}" alt="" />*/
/*                 Español*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 <img src="{{ asset('assets/images/fre-FR.gif') }}" alt="" />*/
/*                 Français*/
/*               </a>*/
/*             </li>*/
/*           </ul>*/
/*         </li>*/
/*         <!-- <li class="has_menu">*/
/*           <a href="#">*/
/*             Device€*/
/*           </a>*/
/*         </li> -->*/
/*       </ul>*/
/*     </nav>*/
/*     <div class="social pull-left">*/
/*             <a href="https://twitter.com/Libon">*/
/*                 <img src="{{ asset('assets/images/twitter_icon.svg') }}">*/
/*             </a>*/
/*             <a href="https://www.facebook.com/libon.fan">*/
/*                 <img src="{{ asset('assets/images/facebook_icon.svg') }}">*/
/*             </a>*/
/*         </div>*/
/*   </div>*/
/* </header>*/
