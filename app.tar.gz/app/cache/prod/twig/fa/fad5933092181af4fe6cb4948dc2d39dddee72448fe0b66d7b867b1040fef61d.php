<?php

/* eZPlatformUIBundle:Language:list.html.twig */
class __TwigTemplate_6320b6fefedfa14aba4550f9b4c42d793ecf7b6854617a78334d22543bd6bd26 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Language:list.html.twig", 1);
        $this->blocks = array(
            'choice_row' => array($this, 'block_choice_row'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_choice_row($context, array $blocks = array())
    {
        // line 6
        echo "    ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'widget');
        echo "
";
    }

    // line 9
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 10
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("language.list", array(), "language")));
        // line 14
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 17
    public function block_header_title($context, array $blocks = array())
    {
        // line 18
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.list", array(), "language"), "html", null, true);
        echo "</h1>
";
    }

    // line 21
    public function block_content($context, array $blocks = array())
    {
        // line 22
        echo "    <section class=\"ez-serverside-content\">
        <div class=\"ez-table-data is-flexible\">
            <div class=\"ez-table-data-container\">
                <table class=\"pure-table pure-table-striped ez-selection-table\" data-selection-buttons=\".ez-remove-language-button\">
                    <thead>
                        <tr>
                            <th>";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.name", array(), "language"), "html", null, true);
        echo "</th>
                            <th>";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.code", array(), "language"), "html", null, true);
        echo "</th>
                            <th>";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.id", array(), "language"), "html", null, true);
        echo "</th>
                            <th>";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.enabled", array(), "language"), "html", null, true);
        echo "</th>
                            <th colspan=\"2\"></th>
                        </tr>
                    </thead>
                    <tbody>
                    ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["languageList"]) ? $context["languageList"] : null));
        foreach ($context['_seq'] as $context["_key"] => $context["language"]) {
            // line 37
            echo "                        <tr class=\"ez-selection-table-row\">
                            <td><a href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_languageview", array("languageId" => $this->getAttribute($context["language"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["language"], "name", array()), "html", null, true);
            echo "</a></td>
                            <td><a href=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_languageview", array("languageId" => $this->getAttribute($context["language"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["language"], "languageCode", array()), "html", null, true);
            echo "</a></td>
                            <td class=\"ez-table-data-id\"><a href=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_languageview", array("languageId" => $this->getAttribute($context["language"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["language"], "id", array()), "html", null, true);
            echo "</a></td>
                            <td><input type=\"checkbox\" disabled ";
            // line 41
            if ($this->getAttribute($context["language"], "enabled", array())) {
                echo "checked title=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.enabled", array(), "language"), "html", null, true);
                echo "\"";
            } else {
                echo "title=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.disabled", array(), "language"), "html", null, true);
                echo "\"";
            }
            echo "></td>
                            <td>
                            ";
            // line 43
            if ((isset($context["canEdit"]) ? $context["canEdit"] : null)) {
                // line 44
                echo "                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_languageedit", array("languageId" => $this->getAttribute($context["language"], "id", array()))), "html", null, true);
                echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.edit", array(), "language"), "html", null, true);
                echo "</a>
                            ";
            } else {
                // line 46
                echo "                                <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.edit", array(), "language"), "html", null, true);
                echo "</span>
                            ";
            }
            // line 48
            echo "                            </td>
                            <td>
                                ";
            // line 50
            $context["deleteForm"] = $this->getAttribute((isset($context["deleteFormsByLanguageId"]) ? $context["deleteFormsByLanguageId"] : null), $this->getAttribute($context["language"], "id", array()), array(), "array");
            // line 51
            echo "                                ";
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_languagedelete", array("languageId" => $this->getAttribute($context["language"], "id", array()), "redirectErrorsTo" => "list"))));
            echo "
                                    ";
            // line 52
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : null), "languageId", array()), 'widget');
            echo "
                                    ";
            // line 53
            echo             // line 54
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(            // line 55
(isset($context["deleteForm"]) ? $context["deleteForm"] : null), "delete", array()), 'widget', array("disabled" =>  !            // line 57
(isset($context["canEdit"]) ? $context["canEdit"] : null), "attr" => array("class" => "pure-button ez-button ez-remove-language-button ez-font-icon ez-button-delete")));
            // line 61
            echo "
                                ";
            // line 62
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : null), 'form_end');
            echo "
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['language'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 66
        echo "                    </tbody>
                </table>
                <p class=\"ez-table-data-buttons\">
                ";
        // line 69
        if ((isset($context["canEdit"]) ? $context["canEdit"] : null)) {
            // line 70
            echo "                    <a href=\"";
            echo $this->env->getExtension('routing')->getPath("admin_languageedit");
            echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.new", array(), "language"), "html", null, true);
            echo "</a>
                ";
        } else {
            // line 72
            echo "                    <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.new", array(), "language"), "html", null, true);
            echo "</span>
                ";
        }
        // line 74
        echo "                </p>
            </div>
        </div>
    </section>
";
    }

    // line 80
    public function block_title($context, array $blocks = array())
    {
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.list", array(), "language"), "html", null, true);
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Language:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  212 => 80,  204 => 74,  198 => 72,  190 => 70,  188 => 69,  183 => 66,  173 => 62,  170 => 61,  168 => 57,  167 => 55,  166 => 54,  165 => 53,  161 => 52,  156 => 51,  154 => 50,  150 => 48,  144 => 46,  136 => 44,  134 => 43,  121 => 41,  115 => 40,  109 => 39,  103 => 38,  100 => 37,  96 => 36,  88 => 31,  84 => 30,  80 => 29,  76 => 28,  68 => 22,  65 => 21,  58 => 18,  55 => 17,  48 => 14,  45 => 10,  42 => 9,  35 => 6,  32 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "language" %}*/
/* */
/* {% block choice_row %}*/
/*     {{ form_widget(form) }}*/
/* {% endblock choice_row %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: '', label: 'language.list'|trans({}, 'language')}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'language.list'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <div class="ez-table-data is-flexible">*/
/*             <div class="ez-table-data-container">*/
/*                 <table class="pure-table pure-table-striped ez-selection-table" data-selection-buttons=".ez-remove-language-button">*/
/*                     <thead>*/
/*                         <tr>*/
/*                             <th>{{ 'language.name'|trans }}</th>*/
/*                             <th>{{ 'language.code'|trans }}</th>*/
/*                             <th>{{ 'language.id'|trans }}</th>*/
/*                             <th>{{ 'language.enabled'|trans }}</th>*/
/*                             <th colspan="2"></th>*/
/*                         </tr>*/
/*                     </thead>*/
/*                     <tbody>*/
/*                     {% for language in languageList %}*/
/*                         <tr class="ez-selection-table-row">*/
/*                             <td><a href="{{ path( 'admin_languageview', {'languageId': language.id} ) }}">{{ language.name }}</a></td>*/
/*                             <td><a href="{{ path( 'admin_languageview', {'languageId': language.id} ) }}">{{ language.languageCode }}</a></td>*/
/*                             <td class="ez-table-data-id"><a href="{{ path( "admin_languageview", {"languageId": language.id} ) }}">{{ language.id }}</a></td>*/
/*                             <td><input type="checkbox" disabled {% if language.enabled %}checked title="{{ 'language.enabled'|trans }}"{% else %}title="{{ 'language.disabled'|trans }}"{% endif %}></td>*/
/*                             <td>*/
/*                             {% if canEdit %}*/
/*                                 <a href="{{ path('admin_languageedit', {'languageId': language.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'language.edit'|trans }}</a>*/
/*                             {% else %}*/
/*                                 <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'language.edit'|trans }}</span>*/
/*                             {% endif %}*/
/*                             </td>*/
/*                             <td>*/
/*                                 {% set deleteForm = deleteFormsByLanguageId[language.id] %}*/
/*                                 {{ form_start(deleteForm, {"action": path("admin_languagedelete", {"languageId": language.id, "redirectErrorsTo": "list"})}) }}*/
/*                                     {{ form_widget(deleteForm.languageId) }}*/
/*                                     {{*/
/*                                         form_widget(*/
/*                                             deleteForm.delete,*/
/*                                             {*/
/*                                                 "disabled": not canEdit,*/
/*                                                 "attr": {"class": "pure-button ez-button ez-remove-language-button ez-font-icon ez-button-delete"}*/
/*                                             }*/
/*                                         )*/
/*                                     }}*/
/*                                 {{ form_end(deleteForm) }}*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*                     </tbody>*/
/*                 </table>*/
/*                 <p class="ez-table-data-buttons">*/
/*                 {% if canEdit %}*/
/*                     <a href="{{ path('admin_languageedit') }}" class="pure-button ez-button" data-icon="&#xe616;">{{ 'language.new'|trans }}</a>*/
/*                 {% else %}*/
/*                     <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe616;">{{ 'language.new'|trans }}</span>*/
/*                 {% endif %}*/
/*                 </p>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'language.list'|trans }}{% endblock %}*/
/* */
