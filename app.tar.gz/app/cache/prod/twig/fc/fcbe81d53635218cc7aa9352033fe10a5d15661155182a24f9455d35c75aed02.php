<?php

/* EzPublishCoreBundle:default/content:embed.html.twig */
class __TwigTemplate_a35adfb6c78b05f84dffd4124b9e8f940c6c956f62c432705d121f6ea5e38c60 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $context["content_name"] = $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : null));
        // line 2
        echo "
";
        // line 3
        if (array_key_exists("location", $context)) {
            // line 4
            echo "    <h3><a href=\"";
            echo $this->env->getExtension('routing')->getPath((isset($context["location"]) ? $context["location"] : null));
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["content_name"]) ? $context["content_name"] : null), "html", null, true);
            echo "</a></h3>
";
        } else {
            // line 6
            echo "    <h3><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ez_urlalias", array("contentId" => $this->getAttribute((isset($context["content"]) ? $context["content"] : null), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["content_name"]) ? $context["content_name"] : null), "html", null, true);
            echo "</a></h3>
";
        }
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/content:embed.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 6,  26 => 4,  24 => 3,  21 => 2,  19 => 1,);
    }
}
/* {% set content_name=ez_content_name(content) %}*/
/* */
/* {% if location is defined %}*/
/*     <h3><a href="{{ path(location) }}">{{ content_name }}</a></h3>*/
/* {% else %}*/
/*     <h3><a href="{{ path( "ez_urlalias", {"contentId": content.id} ) }}">{{ content_name }}</a></h3>*/
/* {% endif %}*/
/* */
