<?php

/* eZPlatformUIBundle:Role:edit_policy.html.twig */
class __TwigTemplate_e29cbcdc0858aab06dbc4285cef56a45ce205f608edc48534a77b0ece7394c8e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Role:edit_policy.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 6
        $context["editTitle"] = (($this->getAttribute((isset($context["policy"]) ? $context["policy"] : null), "new", array())) ? ($this->env->getExtension('translator')->trans("role.policy.create.title", array(), "role")) : ($this->env->getExtension('translator')->trans("role.policy.edit.title", array("%policy%" => (($this->getAttribute((isset($context["policy"]) ? $context["policy"] : null), "module", array()) . "/") . $this->getAttribute((isset($context["policy"]) ? $context["policy"] : null), "function", array()))), "role")));
        // line 2
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        // line 9
        echo "    ";
        echo twig_escape_filter($this->env, (isset($context["editTitle"]) ? $context["editTitle"] : null), "html", null, true);
        echo "
";
    }

    // line 12
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        // line 13
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_role"), "label" => $this->env->getExtension('translator')->trans("role.dashboard_title", array(), "role")), 2 => array("link" => null, "label" => $this->getAttribute($this->getAttribute(        // line 16
(isset($context["policy"]) ? $context["policy"] : null), "roleDraft", array()), "identifier", array())), 3 => array("link" => "", "label" =>         // line 17
(isset($context["editTitle"]) ? $context["editTitle"] : null)));
        // line 19
        echo "
    ";
        // line 20
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
    }

    // line 23
    public function block_header_title($context, array $blocks = array())
    {
        // line 24
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">
        ";
        // line 25
        echo twig_escape_filter($this->env, (isset($context["editTitle"]) ? $context["editTitle"] : null), "html", null, true);
        echo "
    </h1>
";
    }

    // line 29
    public function block_content($context, array $blocks = array())
    {
        // line 30
        echo "    <section class=\"ez-serverside-content\">
        ";
        // line 31
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_start', array("action" => (isset($context["actionUrl"]) ? $context["actionUrl"] : null), "attr" => array("class" => "pure-form pure-form-aligned")));
        echo "
            ";
        // line 32
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : null), 'errors');
        echo "

            <fieldset>
                <div class=\"pure-control-group\">
                    ";
        // line 36
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "moduleFunction", array()), 'label');
        echo "
                    ";
        // line 37
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "moduleFunction", array()), 'errors');
        echo "
                    ";
        // line 38
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "moduleFunction", array()), 'widget', array("disabled" =>  !$this->getAttribute((isset($context["policy"]) ? $context["policy"] : null), "new", array())));
        echo "
                </div>
            </fieldset>

        ";
        // line 43
        echo "        ";
        if ($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "limitationsData", array(), "any", true, true)) {
            // line 44
            echo "            <fieldset>
                <legend>";
            // line 45
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "limitationsData", array()), 'label');
            echo "</legend>
                ";
            // line 46
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "limitationsData", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["limitationForm"]) {
                // line 47
                echo "                    <div class=\"pure-control-group\">
                        ";
                // line 48
                echo twig_include($this->env, $context, $this->getAttribute($this->getAttribute($context["limitationForm"], "vars", array()), "template", array()), array("form" => $context["limitationForm"]), false);
                echo "
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['limitationForm'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 51
            echo "            </fieldset>
        ";
        }
        // line 53
        echo "
            <div class=\"pure-controls\">
                ";
        // line 55
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "removeDraft", array()), 'widget', array("attr" => array("class" => "pure-button ez-button", "formnovalidate" => "formnovalidate")));
        echo "
                ";
        // line 56
        if ($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "saveAndAddLimitation", array(), "any", true, true)) {
            // line 57
            echo "                    ";
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "saveAndAddLimitation", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
            echo "
                ";
        }
        // line 59
        echo "                ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "savePolicy", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
            </div>

        ";
        // line 62
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : null), 'form_end');
        echo "
    </section>
";
    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Role:edit_policy.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  159 => 62,  152 => 59,  146 => 57,  144 => 56,  140 => 55,  136 => 53,  132 => 51,  123 => 48,  120 => 47,  116 => 46,  112 => 45,  109 => 44,  106 => 43,  99 => 38,  95 => 37,  91 => 36,  84 => 32,  80 => 31,  77 => 30,  74 => 29,  67 => 25,  64 => 24,  61 => 23,  55 => 20,  52 => 19,  50 => 17,  49 => 16,  47 => 13,  44 => 12,  37 => 9,  34 => 8,  30 => 2,  28 => 6,  11 => 2,);
    }
}
/* {# @var policy \EzSystems\RepositoryForms\Data\Role\PolicyCreateData|\EzSystems\RepositoryForms\Data\Role\PolicyUpdateData #}*/
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "role" %}*/
/* */
/* {% set editTitle = policy.new ? "role.policy.create.title"|trans() : "role.policy.edit.title"|trans({"%policy%": policy.module ~ "/" ~ policy.function}) %}*/
/* */
/* {% block title %}*/
/*     {{ editTitle }}*/
/* {% endblock %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_role'), label: 'role.dashboard_title'|trans},*/
/*         {link: null, label: policy.roleDraft.identifier},*/
/*         {link: '', label: editTitle}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">*/
/*         {{ editTitle }}*/
/*     </h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         {{ form_start(form, {'action': actionUrl, "attr": {"class": "pure-form pure-form-aligned"}}) }}*/
/*             {{ form_errors(form) }}*/
/* */
/*             <fieldset>*/
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.moduleFunction) }}*/
/*                     {{ form_errors(form.moduleFunction) }}*/
/*                     {{ form_widget(form.moduleFunction, {"disabled": not policy.new}) }}*/
/*                 </div>*/
/*             </fieldset>*/
/* */
/*         {# form.limitationsData doesn't exist yet when creating a new policy draft. #}*/
/*         {% if form.limitationsData is defined %}*/
/*             <fieldset>*/
/*                 <legend>{{ form_label(form.limitationsData) }}</legend>*/
/*                 {% for limitationForm in form.limitationsData %}*/
/*                     <div class="pure-control-group">*/
/*                         {{ include(limitationForm.vars.template, {form: limitationForm}, with_context = false) }}*/
/*                     </div>*/
/*                 {% endfor %}*/
/*             </fieldset>*/
/*         {% endif %}*/
/* */
/*             <div class="pure-controls">*/
/*                 {{ form_widget(form.removeDraft, {"attr": {"class": "pure-button ez-button", "formnovalidate": "formnovalidate"}}) }}*/
/*                 {% if form.saveAndAddLimitation is defined %}*/
/*                     {{ form_widget(form.saveAndAddLimitation, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*                 {% endif %}*/
/*                 {{ form_widget(form.savePolicy, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*             </div>*/
/* */
/*         {{ form_end(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
