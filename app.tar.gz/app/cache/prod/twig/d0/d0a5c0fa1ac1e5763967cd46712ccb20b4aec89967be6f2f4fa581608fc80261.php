<?php

/* EzPublishCoreBundle:FieldType/RichText/tag:default.html.twig */
class __TwigTemplate_6b7e89750e915d822e6faa010418c006177702de40724b0d8c235c6810d9cf88 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<div class=\"";
        if (array_key_exists("align", $context)) {
            echo "align-";
            echo twig_escape_filter($this->env, (isset($context["align"]) ? $context["align"] : null), "html", null, true);
        }
        echo "\">
    RichText template tag <strong>";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : null), "html", null, true);
        echo "</strong> is not configured
</div>
";
    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/tag:default.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 2,  19 => 1,);
    }
}
/* <div class="{% if align is defined %}align-{{ align }}{% endif %}">*/
/*     RichText template tag <strong>{{ name }}</strong> is not configured*/
/* </div>*/
/* */
