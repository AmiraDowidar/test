<?php

// eZPlatformUIBundle:ContentType:list_content_type_groups.html.twig
return array (
);
