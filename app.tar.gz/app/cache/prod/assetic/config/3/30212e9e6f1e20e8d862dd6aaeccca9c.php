<?php

// eZPlatformUIBundle:components:breadcrumbs.html.twig
return array (
);
