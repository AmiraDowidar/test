<?php

// eZPlatformUIBundle:ContentType:view_content_type.html.twig
return array (
);
