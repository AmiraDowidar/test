<?php

// eZPlatformUIBundle:ContentType:edit_content_type_group.html.twig
return array (
);
