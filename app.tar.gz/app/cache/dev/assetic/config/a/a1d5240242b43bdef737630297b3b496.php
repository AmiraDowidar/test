<?php

// eZPlatformUIBundle:ContentType:update_content_type.html.twig
return array (
);
