<?php

// ::pagelayout.html.twig
return array (
  '032e685' => 
  array (
    0 => 
    array (
      0 => 'assets/js/*',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/032e685.js',
      'name' => '032e685',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'f024ab1' => 
  array (
    0 => 
    array (
      0 => 'assets/css/*',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/f024ab1.css',
      'name' => 'f024ab1',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
