<?php

// eZPlatformUIBundle:Exception:error403.html.twig
return array (
  '64dd8c5' => 
  array (
    0 => 
    array (
      0 => '$css.files;ez_platformui$',
    ),
    1 => 
    array (
      0 => 'cssrewrite',
    ),
    2 => 
    array (
      'output' => '_controller/css/64dd8c5.css',
      'name' => '64dd8c5',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  'faccad4' => 
  array (
    0 => 
    array (
      0 => '$javascript.files;ez_platformui$',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/faccad4.js',
      'name' => 'faccad4',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
