<?php

// eZPlatformUIBundle:ContentType:view_content_type_group.html.twig
return array (
);
