<?php

// eZPlatformUIBundle:Dashboard:dashboard.html.twig
return array (
);
