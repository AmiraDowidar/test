<?php 
/* Cachekey: cache/default/ez_spi/content/info/54/ */
/* Type: array */
/* Expiration: 2016-11-24T22:30:21+02:00 */



$loaded = true;
$expiration = 1480019421;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('Tzo0NjoiZVpcUHVibGlzaFxTUElcUGVyc2lzdGVuY2VcQ29udGVudFxDb250ZW50SW5mbyI6MTM6e3M6MjoiaWQiO2k6NTQ7czo0OiJuYW1lIjtzOjg6IlJpZGUgb25lIjtzOjEzOiJjb250ZW50VHlwZUlkIjtpOjE0O3M6OToic2VjdGlvbklkIjtpOjE7czoxNjoiY3VycmVudFZlcnNpb25ObyI7aToyO3M6MTE6ImlzUHVibGlzaGVkIjtiOjE7czo3OiJvd25lcklkIjtpOjE0O3M6MTY6Im1vZGlmaWNhdGlvbkRhdGUiO2k6MTQ3OTM4OTg4MztzOjE1OiJwdWJsaWNhdGlvbkRhdGUiO2k6MTQ3OTM4NTU5NTtzOjE1OiJhbHdheXNBdmFpbGFibGUiO2k6MTtzOjg6InJlbW90ZUlkIjtzOjMyOiJlODFlNWMzMjA4NWZlMjIwZjg5ZmQ2ZmI3OWIwZGVhNiI7czoxNjoibWFpbkxhbmd1YWdlQ29kZSI7czo2OiJlbmctR0IiO3M6MTQ6Im1haW5Mb2NhdGlvbklkIjtpOjU2O30='));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
