<?php 
/* Cachekey: cache/default/ez_spi/content/info/1/ */
/* Type: array */
/* Expiration: 2016-11-25T02:59:57+02:00 */



$loaded = true;
$expiration = 1480035597;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('Tzo0NjoiZVpcUHVibGlzaFxTUElcUGVyc2lzdGVuY2VcQ29udGVudFxDb250ZW50SW5mbyI6MTM6e3M6MjoiaWQiO2k6MTtzOjQ6Im5hbWUiO3M6MTE6ImVaIFBsYXRmb3JtIjtzOjEzOiJjb250ZW50VHlwZUlkIjtpOjE7czo5OiJzZWN0aW9uSWQiO2k6MTtzOjE2OiJjdXJyZW50VmVyc2lvbk5vIjtpOjk7czoxMToiaXNQdWJsaXNoZWQiO2I6MTtzOjc6Im93bmVySWQiO2k6MTQ7czoxNjoibW9kaWZpY2F0aW9uRGF0ZSI7aToxNDQ4ODg5MDQ2O3M6MTU6InB1YmxpY2F0aW9uRGF0ZSI7aToxNDQ4ODg5MDQ2O3M6MTU6ImFsd2F5c0F2YWlsYWJsZSI7aToxO3M6ODoicmVtb3RlSWQiO3M6MzI6Ijk0NTlkM2MyOWUxNTAwNmU0NTE5NzI5NTcyMmM3YWRlIjtzOjE2OiJtYWluTGFuZ3VhZ2VDb2RlIjtzOjY6ImVuZy1HQiI7czoxNDoibWFpbkxvY2F0aW9uSWQiO2k6Mjt9'));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
