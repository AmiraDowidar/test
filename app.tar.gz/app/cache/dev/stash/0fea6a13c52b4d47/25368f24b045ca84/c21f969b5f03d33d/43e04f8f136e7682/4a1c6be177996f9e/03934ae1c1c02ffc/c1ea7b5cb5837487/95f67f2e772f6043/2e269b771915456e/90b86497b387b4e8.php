<?php 
/* Cachekey: cache/default/ez_spi/urlalias/0-d41d8cd98f00b204e9800998ecf8427e/ */
/* Type: array */
/* Expiration: 2016-11-24T19:36:53+02:00 */



$loaded = true;
$expiration = 1480009013;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('Tzo0MzoiZVpcUHVibGlzaFxTUElcUGVyc2lzdGVuY2VcQ29udGVudFxVcmxBbGlhcyI6OTp7czoyOiJpZCI7czozNDoiMC1kNDFkOGNkOThmMDBiMjA0ZTk4MDA5OThlY2Y4NDI3ZSI7czo0OiJ0eXBlIjtpOjA7czoxMToiZGVzdGluYXRpb24iO3M6MToiMiI7czo4OiJwYXRoRGF0YSI7YToxOntpOjA7YToyOntzOjE2OiJhbHdheXMtYXZhaWxhYmxlIjtiOjE7czoxMjoidHJhbnNsYXRpb25zIjthOjE6e3M6NjoiZW5nLUdCIjtzOjA6IiI7fX19czoxMzoibGFuZ3VhZ2VDb2RlcyI7YToxOntpOjA7czo2OiJlbmctR0IiO31zOjE1OiJhbHdheXNBdmFpbGFibGUiO2I6MTtzOjk6ImlzSGlzdG9yeSI7YjowO3M6ODoiaXNDdXN0b20iO2I6MDtzOjc6ImZvcndhcmQiO2I6MDt9'));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
