<?php 
/* Cachekey: cache/default/ez_spi/user/role/assignments/bygroup/inherited/10/ */
/* Type: array */
/* Expiration: 2016-11-24T21:14:03+02:00 */



$loaded = true;
$expiration = 1480014843;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7Tzo0NjoiZVpcUHVibGlzaFxTUElcUGVyc2lzdGVuY2VcVXNlclxSb2xlQXNzaWdubWVudCI6NTp7czoyOiJpZCI7aTozMTtzOjY6InJvbGVJZCI7aToxO3M6OToiY29udGVudElkIjtpOjQyO3M6MjA6ImxpbWl0YXRpb25JZGVudGlmaWVyIjtOO3M6NjoidmFsdWVzIjtOO319'));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
