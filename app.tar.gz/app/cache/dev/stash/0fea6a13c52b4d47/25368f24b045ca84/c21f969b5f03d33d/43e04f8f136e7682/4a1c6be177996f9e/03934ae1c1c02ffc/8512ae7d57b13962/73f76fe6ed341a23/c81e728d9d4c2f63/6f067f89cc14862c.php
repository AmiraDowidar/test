<?php 
/* Cachekey: cache/default/ez_spi/language/2/ */
/* Type: array */
/* Expiration: 2016-11-25T06:06:51+02:00 */



$loaded = true;
$expiration = 1480046811;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('Tzo0MzoiZVpcUHVibGlzaFxTUElcUGVyc2lzdGVuY2VcQ29udGVudFxMYW5ndWFnZSI6NDp7czoyOiJpZCI7aToyO3M6MTI6Imxhbmd1YWdlQ29kZSI7czo2OiJlbmctR0IiO3M6NDoibmFtZSI7czoyNDoiRW5nbGlzaCAoVW5pdGVkIEtpbmdkb20pIjtzOjk6ImlzRW5hYmxlZCI7YjoxO30='));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
