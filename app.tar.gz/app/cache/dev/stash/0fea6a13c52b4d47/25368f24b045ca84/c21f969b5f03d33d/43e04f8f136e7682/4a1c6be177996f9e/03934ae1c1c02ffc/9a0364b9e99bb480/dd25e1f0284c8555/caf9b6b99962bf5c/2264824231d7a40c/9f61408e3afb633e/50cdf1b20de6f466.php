<?php 
/* Cachekey: cache/default/ez_spi/content/info/56/ */
/* Type: array */
/* Expiration: 2016-11-25T01:10:49+02:00 */



$loaded = true;
$expiration = 1480029049;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('Tzo0NjoiZVpcUHVibGlzaFxTUElcUGVyc2lzdGVuY2VcQ29udGVudFxDb250ZW50SW5mbyI6MTM6e3M6MjoiaWQiO2k6NTY7czo0OiJuYW1lIjtzOjEwOiJSaWRlIFRocmVlIjtzOjEzOiJjb250ZW50VHlwZUlkIjtpOjE0O3M6OToic2VjdGlvbklkIjtpOjE7czoxNjoiY3VycmVudFZlcnNpb25ObyI7aToxO3M6MTE6ImlzUHVibGlzaGVkIjtiOjE7czo3OiJvd25lcklkIjtpOjE0O3M6MTY6Im1vZGlmaWNhdGlvbkRhdGUiO2k6MTQ3OTM4NTgxNTtzOjE1OiJwdWJsaWNhdGlvbkRhdGUiO2k6MTQ3OTM4NTgxNTtzOjE1OiJhbHdheXNBdmFpbGFibGUiO2k6MTtzOjg6InJlbW90ZUlkIjtzOjMyOiIzZTEyYWIzZGE1ZWFjMGMwMjE0ZjZiOWQ5MTA0ODJlYSI7czoxNjoibWFpbkxhbmd1YWdlQ29kZSI7czo2OiJlbmctR0IiO3M6MTQ6Im1haW5Mb2NhdGlvbklkIjtpOjU4O30='));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
