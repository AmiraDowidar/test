<?php 
/* Cachekey: cache/default/ez_spi/contenttypegroup/1/ */
/* Type: array */
/* Expiration: 2016-11-25T01:38:38+02:00 */



$loaded = true;
$expiration = 1480030718;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('Tzo0NToiZVpcUHVibGlzaFxTUElcUGVyc2lzdGVuY2VcQ29udGVudFxUeXBlXEdyb3VwIjo4OntzOjI6ImlkIjtpOjE7czo0OiJuYW1lIjthOjA6e31zOjExOiJkZXNjcmlwdGlvbiI7YTowOnt9czoxMDoiaWRlbnRpZmllciI7czo3OiJDb250ZW50IjtzOjc6ImNyZWF0ZWQiO2k6MTAzMTIxNjkyODtzOjg6Im1vZGlmaWVkIjtpOjEwMzM5MjIxMDY7czo5OiJjcmVhdG9ySWQiO2k6MTQ7czoxMDoibW9kaWZpZXJJZCI7aToxNDt9'));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
