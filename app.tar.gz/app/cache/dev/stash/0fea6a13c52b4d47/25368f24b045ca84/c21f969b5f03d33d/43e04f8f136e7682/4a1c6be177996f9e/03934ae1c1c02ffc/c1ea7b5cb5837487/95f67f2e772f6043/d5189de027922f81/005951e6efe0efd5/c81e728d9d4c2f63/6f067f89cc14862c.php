<?php 
/* Cachekey: cache/default/ez_spi/urlalias/location/2/ */
/* Type: array */
/* Expiration: 2016-11-25T09:10:21+02:00 */



$loaded = true;
$expiration = 1480057821;

$data = array();

/* Child Type: array */
$data['return'] = unserialize(base64_decode('YToxOntpOjA7czozNDoiMC1kNDFkOGNkOThmMDBiMjA0ZTk4MDA5OThlY2Y4NDI3ZSI7fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
