<?php 
/* Cachekey: cache/default/ez_spi/location/58/ */
/* Type: array */
/* Expiration: 2016-11-24T16:29:23+02:00 */



$loaded = true;
$expiration = 1479997763;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('Tzo0MzoiZVpcUHVibGlzaFxTUElcUGVyc2lzdGVuY2VcQ29udGVudFxMb2NhdGlvbiI6MTI6e3M6MjoiaWQiO2k6NTg7czo4OiJwcmlvcml0eSI7aTowO3M6NjoiaGlkZGVuIjtiOjA7czo5OiJpbnZpc2libGUiO2I6MDtzOjg6InJlbW90ZUlkIjtzOjMyOiIyODUwYzdjN2EyNmYxMzgyNTYxMTI3ZGRiZmE5ODZjZiI7czo5OiJjb250ZW50SWQiO2k6NTY7czo4OiJwYXJlbnRJZCI7aTo1NTtzOjI0OiJwYXRoSWRlbnRpZmljYXRpb25TdHJpbmciO3M6Mjc6Im5vZGVfMi9hbGxfcmlkZXMvcmlkZV90aHJlZSI7czoxMDoicGF0aFN0cmluZyI7czoxMToiLzEvMi81NS81OC8iO3M6NToiZGVwdGgiO2k6MztzOjk6InNvcnRGaWVsZCI7aToxO3M6OToic29ydE9yZGVyIjtpOjE7fQ=='));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
