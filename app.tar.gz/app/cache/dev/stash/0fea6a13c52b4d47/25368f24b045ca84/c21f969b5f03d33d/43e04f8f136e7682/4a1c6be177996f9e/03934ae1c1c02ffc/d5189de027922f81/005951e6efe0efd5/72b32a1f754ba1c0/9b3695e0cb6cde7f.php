<?php 
/* Cachekey: cache/default/ez_spi/location/57/ */
/* Type: array */
/* Expiration: 2016-11-25T03:53:09+02:00 */



$loaded = true;
$expiration = 1480038789;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('Tzo0MzoiZVpcUHVibGlzaFxTUElcUGVyc2lzdGVuY2VcQ29udGVudFxMb2NhdGlvbiI6MTI6e3M6MjoiaWQiO2k6NTc7czo4OiJwcmlvcml0eSI7aTowO3M6NjoiaGlkZGVuIjtiOjA7czo5OiJpbnZpc2libGUiO2I6MDtzOjg6InJlbW90ZUlkIjtzOjMyOiIzNGI2NmM2ZDI2NTJjZDdjYTEzZDIxMzFjOTZlNWFmNCI7czo5OiJjb250ZW50SWQiO2k6NTU7czo4OiJwYXJlbnRJZCI7aTo1NTtzOjI0OiJwYXRoSWRlbnRpZmljYXRpb25TdHJpbmciO3M6MjU6Im5vZGVfMi9hbGxfcmlkZXMvcmlkZV90d28iO3M6MTA6InBhdGhTdHJpbmciO3M6MTE6Ii8xLzIvNTUvNTcvIjtzOjU6ImRlcHRoIjtpOjM7czo5OiJzb3J0RmllbGQiO2k6MTtzOjk6InNvcnRPcmRlciI7aToxO30='));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
