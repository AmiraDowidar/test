<?php 
/* Cachekey: cache/default/ez_spi/urlalias/url/ */
/* Type: array */
/* Expiration: 2016-11-25T02:50:08+02:00 */



$loaded = true;
$expiration = 1480035008;

$data = array();

/* Child Type: string */
$data['return'] = "0-d41d8cd98f00b204e9800998ecf8427e";

/* Child Type: integer */
$data['createdOn'] = 1479628640;
