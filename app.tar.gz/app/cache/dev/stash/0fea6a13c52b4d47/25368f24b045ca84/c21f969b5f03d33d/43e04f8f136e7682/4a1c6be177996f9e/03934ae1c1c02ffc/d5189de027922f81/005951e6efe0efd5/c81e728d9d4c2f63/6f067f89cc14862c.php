<?php 
/* Cachekey: cache/default/ez_spi/location/2/ */
/* Type: array */
/* Expiration: 2016-11-24T17:48:39+02:00 */



$loaded = true;
$expiration = 1480002519;

$data = array();

/* Child Type: object */
$data['return'] = unserialize(base64_decode('Tzo0MzoiZVpcUHVibGlzaFxTUElcUGVyc2lzdGVuY2VcQ29udGVudFxMb2NhdGlvbiI6MTI6e3M6MjoiaWQiO2k6MjtzOjg6InByaW9yaXR5IjtpOjA7czo2OiJoaWRkZW4iO2I6MDtzOjk6ImludmlzaWJsZSI7YjowO3M6ODoicmVtb3RlSWQiO3M6MzI6ImYzZTkwNTk2MzYxZTMxZDQ5NmQ0MDI2ZWI2MjRjOTgzIjtzOjk6ImNvbnRlbnRJZCI7aToxO3M6ODoicGFyZW50SWQiO2k6MTtzOjI0OiJwYXRoSWRlbnRpZmljYXRpb25TdHJpbmciO3M6Njoibm9kZV8yIjtzOjEwOiJwYXRoU3RyaW5nIjtzOjU6Ii8xLzIvIjtzOjU6ImRlcHRoIjtpOjE7czo5OiJzb3J0RmllbGQiO2k6ODtzOjk6InNvcnRPcmRlciI7aToxO30='));

/* Child Type: integer */
$data['createdOn'] = 1479628640;
