<?php 
/* Cachekey: cache/default/ez_spi/contenttype/identifier/ride/ */
/* Type: array */
/* Expiration: 2016-11-24T19:43:38+02:00 */



$loaded = true;
$expiration = 1480009418;

$data = array();

/* Child Type: integer */
$data['return'] = 14;

/* Child Type: integer */
$data['createdOn'] = 1479628640;
