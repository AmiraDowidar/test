<?php

/* WebProfilerBundle:Collector:router.html.twig */
class __TwigTemplate_c6057e62ecd82564bc96f33aab1a8fa2535da48dcfb3b3290dd3380eaf9e465b extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "WebProfilerBundle:Collector:router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b2c933d3e6f279c8ce3a75254c56979f92a23200142da3c93e396959bea7fe7 = $this->env->getExtension("native_profiler");
        $__internal_0b2c933d3e6f279c8ce3a75254c56979f92a23200142da3c93e396959bea7fe7->enter($__internal_0b2c933d3e6f279c8ce3a75254c56979f92a23200142da3c93e396959bea7fe7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Collector:router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0b2c933d3e6f279c8ce3a75254c56979f92a23200142da3c93e396959bea7fe7->leave($__internal_0b2c933d3e6f279c8ce3a75254c56979f92a23200142da3c93e396959bea7fe7_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_89291e3eaa1e3033fd766ea222e6c0a982039ea0c2a1d29105199b2ecab03571 = $this->env->getExtension("native_profiler");
        $__internal_89291e3eaa1e3033fd766ea222e6c0a982039ea0c2a1d29105199b2ecab03571->enter($__internal_89291e3eaa1e3033fd766ea222e6c0a982039ea0c2a1d29105199b2ecab03571_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_89291e3eaa1e3033fd766ea222e6c0a982039ea0c2a1d29105199b2ecab03571->leave($__internal_89291e3eaa1e3033fd766ea222e6c0a982039ea0c2a1d29105199b2ecab03571_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_c4c68d787bdd004d500e698100e2d4a4219c9b7d18953ce8c94ab487bf6f6d69 = $this->env->getExtension("native_profiler");
        $__internal_c4c68d787bdd004d500e698100e2d4a4219c9b7d18953ce8c94ab487bf6f6d69->enter($__internal_c4c68d787bdd004d500e698100e2d4a4219c9b7d18953ce8c94ab487bf6f6d69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_c4c68d787bdd004d500e698100e2d4a4219c9b7d18953ce8c94ab487bf6f6d69->leave($__internal_c4c68d787bdd004d500e698100e2d4a4219c9b7d18953ce8c94ab487bf6f6d69_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c255b96e53c73210ace5e34e5f4dc73b9da6961dcbc5c37cefcda67139ae3dfa = $this->env->getExtension("native_profiler");
        $__internal_c255b96e53c73210ace5e34e5f4dc73b9da6961dcbc5c37cefcda67139ae3dfa->enter($__internal_c255b96e53c73210ace5e34e5f4dc73b9da6961dcbc5c37cefcda67139ae3dfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('routing')->getPath("_profiler_router", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_c255b96e53c73210ace5e34e5f4dc73b9da6961dcbc5c37cefcda67139ae3dfa->leave($__internal_c255b96e53c73210ace5e34e5f4dc73b9da6961dcbc5c37cefcda67139ae3dfa_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Collector:router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 13,  67 => 12,  56 => 7,  53 => 6,  47 => 5,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@WebProfiler/Profiler/layout.html.twig' %}*/
/* */
/* {% block toolbar %}{% endblock %}*/
/* */
/* {% block menu %}*/
/* <span class="label">*/
/*     <span class="icon">{{ include('@WebProfiler/Icon/router.svg') }}</span>*/
/*     <strong>Routing</strong>*/
/* </span>*/
/* {% endblock %}*/
/* */
/* {% block panel %}*/
/*     {{ render(path('_profiler_router', { token: token })) }}*/
/* {% endblock %}*/
/* */
