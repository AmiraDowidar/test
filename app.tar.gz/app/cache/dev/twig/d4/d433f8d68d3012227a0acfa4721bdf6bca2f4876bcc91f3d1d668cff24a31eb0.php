<?php

/* TwigBundle:Exception:exception.css.twig */
class __TwigTemplate_2874d3731a12c9f16c2fcf73f53d8918d930a56716069ecd382e2255021dcc9c extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_61a65d731e0b5d7cdf0c33d37153a47213af346b8cefa1eb13750a8bf0440b85 = $this->env->getExtension("native_profiler");
        $__internal_61a65d731e0b5d7cdf0c33d37153a47213af346b8cefa1eb13750a8bf0440b85->enter($__internal_61a65d731e0b5d7cdf0c33d37153a47213af346b8cefa1eb13750a8bf0440b85_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.css.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "TwigBundle:Exception:exception.css.twig", 2)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_61a65d731e0b5d7cdf0c33d37153a47213af346b8cefa1eb13750a8bf0440b85->leave($__internal_61a65d731e0b5d7cdf0c33d37153a47213af346b8cefa1eb13750a8bf0440b85_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.css.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 3,  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}*/
/* *//* */
/* */
