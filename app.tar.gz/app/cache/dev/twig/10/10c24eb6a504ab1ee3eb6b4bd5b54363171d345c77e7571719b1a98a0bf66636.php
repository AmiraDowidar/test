<?php

/* TwigBundle:Exception:error.txt.twig */
class __TwigTemplate_7ccad48bf2708b3f779d8829f2c8b7243c652d459483e8ff10b9915f27e06e2a extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5dc4bb57ff97ccf8bf4d9b4f2525b61d865a72050b2fb26df8075dd4518acd00 = $this->env->getExtension("native_profiler");
        $__internal_5dc4bb57ff97ccf8bf4d9b4f2525b61d865a72050b2fb26df8075dd4518acd00->enter($__internal_5dc4bb57ff97ccf8bf4d9b4f2525b61d865a72050b2fb26df8075dd4518acd00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.txt.twig"));

        // line 1
        echo "Oops! An Error Occurred
=======================

The server returned a \"";
        // line 4
        echo (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code"));
        echo " ";
        echo (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text"));
        echo "\".

Something is broken. Please let us know what you were doing when this error occurred.
We will fix it as soon as possible. Sorry for any inconvenience caused.
";
        
        $__internal_5dc4bb57ff97ccf8bf4d9b4f2525b61d865a72050b2fb26df8075dd4518acd00->leave($__internal_5dc4bb57ff97ccf8bf4d9b4f2525b61d865a72050b2fb26df8075dd4518acd00_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.txt.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  27 => 4,  22 => 1,);
    }
}
/* Oops! An Error Occurred*/
/* =======================*/
/* */
/* The server returned a "{{ status_code }} {{ status_text }}".*/
/* */
/* Something is broken. Please let us know what you were doing when this error occurred.*/
/* We will fix it as soon as possible. Sorry for any inconvenience caused.*/
/* */
