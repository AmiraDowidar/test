<?php

/* TwigBundle:Exception:error.atom.twig */
class __TwigTemplate_420f236493358ed4a30c3abd1815536d8005540422f6c88463c444e2cc54b2dc extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7c60fd21f77ac29f8821cb41748dc2b591b19177e4f61bd0f2998a1bb7187a51 = $this->env->getExtension("native_profiler");
        $__internal_7c60fd21f77ac29f8821cb41748dc2b591b19177e4f61bd0f2998a1bb7187a51->enter($__internal_7c60fd21f77ac29f8821cb41748dc2b591b19177e4f61bd0f2998a1bb7187a51_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/error.xml.twig", "TwigBundle:Exception:error.atom.twig", 1)->display($context);
        
        $__internal_7c60fd21f77ac29f8821cb41748dc2b591b19177e4f61bd0f2998a1bb7187a51->leave($__internal_7c60fd21f77ac29f8821cb41748dc2b591b19177e4f61bd0f2998a1bb7187a51_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.atom.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/error.xml.twig' %}*/
/* */
