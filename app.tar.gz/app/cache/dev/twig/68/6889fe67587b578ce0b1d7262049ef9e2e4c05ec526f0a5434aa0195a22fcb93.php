<?php

/* AppBundle:Ride:viewRide.html.twig */
class __TwigTemplate_3b9fe01168f6f8fd961edf2f722fc4f1751343c8b919629160f40c9c486d14e7 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppBundle:Ride:viewRide.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9c2b6834d16847b05d4196231f473e0a31f4f8694b1fb48cf48b396b92de224c = $this->env->getExtension("native_profiler");
        $__internal_9c2b6834d16847b05d4196231f473e0a31f4f8694b1fb48cf48b396b92de224c->enter($__internal_9c2b6834d16847b05d4196231f473e0a31f4f8694b1fb48cf48b396b92de224c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Ride:viewRide.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9c2b6834d16847b05d4196231f473e0a31f4f8694b1fb48cf48b396b92de224c->leave($__internal_9c2b6834d16847b05d4196231f473e0a31f4f8694b1fb48cf48b396b92de224c_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_aed82835930d5ec29c8c48761170cd2360b8764b4676426c0ea86266a4455dd3 = $this->env->getExtension("native_profiler");
        $__internal_aed82835930d5ec29c8c48761170cd2360b8764b4676426c0ea86266a4455dd3->enter($__internal_aed82835930d5ec29c8c48761170cd2360b8764b4676426c0ea86266a4455dd3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "AppBundle:Ride:viewRide";
        
        $__internal_aed82835930d5ec29c8c48761170cd2360b8764b4676426c0ea86266a4455dd3->leave($__internal_aed82835930d5ec29c8c48761170cd2360b8764b4676426c0ea86266a4455dd3_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_dbfe0a701f942e4366f5a6c0c13d65366fcdb9b14b6a3bc708e8a84166c0907e = $this->env->getExtension("native_profiler");
        $__internal_dbfe0a701f942e4366f5a6c0c13d65366fcdb9b14b6a3bc708e8a84166c0907e->enter($__internal_dbfe0a701f942e4366f5a6c0c13d65366fcdb9b14b6a3bc708e8a84166c0907e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "<h1>Welcome to the Ride:viewRide page</h1>
";
        
        $__internal_dbfe0a701f942e4366f5a6c0c13d65366fcdb9b14b6a3bc708e8a84166c0907e->leave($__internal_dbfe0a701f942e4366f5a6c0c13d65366fcdb9b14b6a3bc708e8a84166c0907e_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Ride:viewRide.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block title %}AppBundle:Ride:viewRide{% endblock %}*/
/* */
/* {% block content %}*/
/* <h1>Welcome to the Ride:viewRide page</h1>*/
/* {% endblock %}*/
/* */
