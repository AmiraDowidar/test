<?php

/* @Framework/Form/percent_widget.html.php */
class __TwigTemplate_189843937a4083ef46b7bd60533bfdf130e0f228900a3d9272b92d5ec344eeea extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f68dc5fa2c1607ee263a670bef6c45e18d9af656571565fc7670fb3771a9b00 = $this->env->getExtension("native_profiler");
        $__internal_3f68dc5fa2c1607ee263a670bef6c45e18d9af656571565fc7670fb3771a9b00->enter($__internal_3f68dc5fa2c1607ee263a670bef6c45e18d9af656571565fc7670fb3771a9b00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/percent_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?> %
";
        
        $__internal_3f68dc5fa2c1607ee263a670bef6c45e18d9af656571565fc7670fb3771a9b00->leave($__internal_3f68dc5fa2c1607ee263a670bef6c45e18d9af656571565fc7670fb3771a9b00_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/percent_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?> %*/
/* */
