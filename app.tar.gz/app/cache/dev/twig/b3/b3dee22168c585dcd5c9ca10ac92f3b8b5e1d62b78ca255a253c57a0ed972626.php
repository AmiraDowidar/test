<?php

/* EzPublishCoreBundle:FieldType/RichText/embed:content_denied.html.twig */
class __TwigTemplate_b0fd62aed08f14adcedde94f58f793cde685ecd7104f02ccfde345bdc0e07118 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_535575ac81c21e605cb85114d646624eed7edc10c47f04e8287fc8516c3b882c = $this->env->getExtension("native_profiler");
        $__internal_535575ac81c21e605cb85114d646624eed7edc10c47f04e8287fc8516c3b882c->enter($__internal_535575ac81c21e605cb85114d646624eed7edc10c47f04e8287fc8516c3b882c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:FieldType/RichText/embed:content_denied.html.twig"));

        // line 1
        echo "<div class=\"";
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "align", array(), "any", true, true)) {
            echo "align-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "align", array()), "html", null, true);
        }
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "class", array(), "any", true, true)) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "class", array()), "html", null, true);
        }
        echo "\">
    Content #";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "id", array()), "html", null, true);
        echo ": You do not have permission to view this Content
</div>
";
        
        $__internal_535575ac81c21e605cb85114d646624eed7edc10c47f04e8287fc8516c3b882c->leave($__internal_535575ac81c21e605cb85114d646624eed7edc10c47f04e8287fc8516c3b882c_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/embed:content_denied.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 2,  22 => 1,);
    }
}
/* <div class="{% if embedParams.align is defined %}align-{{ embedParams.align }}{% endif %}{% if embedParams.class is defined %} {{ embedParams.class }}{% endif %}">*/
/*     Content #{{ embedParams.id }}: You do not have permission to view this Content*/
/* </div>*/
/* */
