<?php

/* eZPlatformUIBundle:Language:view.html.twig */
class __TwigTemplate_a074a76de7e5de61de6d89e6f23ae715766cae4f1418fee06bc0b8e889da1d5e extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Language:view.html.twig", 1);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f82306a4e64eb2fec6f29710a9a51a6c48c8891a7b1d453d306a317a7d532e07 = $this->env->getExtension("native_profiler");
        $__internal_f82306a4e64eb2fec6f29710a9a51a6c48c8891a7b1d453d306a317a7d532e07->enter($__internal_f82306a4e64eb2fec6f29710a9a51a6c48c8891a7b1d453d306a317a7d532e07_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Language:view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f82306a4e64eb2fec6f29710a9a51a6c48c8891a7b1d453d306a317a7d532e07->leave($__internal_f82306a4e64eb2fec6f29710a9a51a6c48c8891a7b1d453d306a317a7d532e07_prof);

    }

    // line 5
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_c1a920ee4441c26d96dc89b40b0a6960e279e7619024150a48221372f5e7023a = $this->env->getExtension("native_profiler");
        $__internal_c1a920ee4441c26d96dc89b40b0a6960e279e7619024150a48221372f5e7023a->enter($__internal_c1a920ee4441c26d96dc89b40b0a6960e279e7619024150a48221372f5e7023a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 6
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_languagelist"), "label" => $this->env->getExtension('translator')->trans("language.list", array(), "language")), 2 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("language.view.title", array("%languageName%" => $this->getAttribute(        // line 9
(isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "name", array())), "language")));
        // line 11
        echo "
    ";
        // line 12
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_c1a920ee4441c26d96dc89b40b0a6960e279e7619024150a48221372f5e7023a->leave($__internal_c1a920ee4441c26d96dc89b40b0a6960e279e7619024150a48221372f5e7023a_prof);

    }

    // line 15
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_31bd90971640c8cef450441e1e79af6bcae95eac890fe61f376c400d5af01629 = $this->env->getExtension("native_profiler");
        $__internal_31bd90971640c8cef450441e1e79af6bcae95eac890fe61f376c400d5af01629->enter($__internal_31bd90971640c8cef450441e1e79af6bcae95eac890fe61f376c400d5af01629_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 16
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.view.title", array("%languageName%" => $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "name", array())), "language"), "html", null, true);
        echo "</h1>
";
        
        $__internal_31bd90971640c8cef450441e1e79af6bcae95eac890fe61f376c400d5af01629->leave($__internal_31bd90971640c8cef450441e1e79af6bcae95eac890fe61f376c400d5af01629_prof);

    }

    // line 19
    public function block_content($context, array $blocks = array())
    {
        $__internal_5f2fb93e1dc5225a66c1adeae219799c990899ce0f973a4cc95fc296d1a6d520 = $this->env->getExtension("native_profiler");
        $__internal_5f2fb93e1dc5225a66c1adeae219799c990899ce0f973a4cc95fc296d1a6d520->enter($__internal_5f2fb93e1dc5225a66c1adeae219799c990899ce0f973a4cc95fc296d1a6d520_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 20
        echo "    <section class=\"ez-tabs ez-serverside-content\">
        <ul class=\"ez-tabs-list\">
            <li class=\"ez-tabs-label is-tab-selected\"><a href=\"#ez-tabs-language-name\">";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "name", array()), "html", null, true);
        echo "</a></li>
        </ul>
        <div class=\"ez-tabs-panel is-tab-selected\" id=\"ez-tabs-language-name\">
            <ul>
                <li>
                    <strong>";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.name.label", array(), "language"), "html", null, true);
        echo "</strong>
                    ";
        // line 28
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "name", array()), "html", null, true);
        echo "
                </li>
                <li>
                    <strong>";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.code.label", array(), "language"), "html", null, true);
        echo "</strong>
                    ";
        // line 32
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "languageCode", array()), "html", null, true);
        echo "
                </li>
                <li>
                    <strong>";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.id.label", array(), "language"), "html", null, true);
        echo "</strong>
                    ";
        // line 36
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "id", array()), "html", null, true);
        echo "
                </li>
                <li>
                    <strong>";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.enabled.label", array(), "language"), "html", null, true);
        echo "</strong>
                    <input type=\"checkbox\" disabled ";
        // line 40
        if ($this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "enabled", array())) {
            echo "checked title=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.enabled", array(), "language"), "html", null, true);
            echo "\"";
        } else {
            echo "title=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.disabled", array(), "language"), "html", null, true);
            echo "\"";
        }
        echo ">
                </li>
            </ul>

            <div>
                ";
        // line 45
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_languagedelete", array("languageId" => $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "id", array()), "redirectErrorsTo" => "view"))));
        echo "
                ";
        // line 46
        if ((isset($context["canEdit"]) ? $context["canEdit"] : $this->getContext($context, "canEdit"))) {
            // line 47
            echo "                    <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_languageedit", array("languageId" => $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "id", array()))), "html", null, true);
            echo "\"
                       class=\"pure-button ez-button\" data-icon=\"&#xe606;\">
                        ";
            // line 49
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.edit", array(), "language"), "html", null, true);
            echo "
                    </a>
                ";
        } else {
            // line 52
            echo "                    <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">
                        ";
            // line 53
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.edit", array(), "language"), "html", null, true);
            echo "
                    </span>
                ";
        }
        // line 56
        echo "
                    ";
        // line 57
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "languageId", array()), 'widget');
        echo "
                    ";
        // line 58
        echo         // line 59
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(        // line 60
(isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "delete", array()), 'widget', array("disabled" =>  !        // line 62
(isset($context["canEdit"]) ? $context["canEdit"] : $this->getContext($context, "canEdit")), "attr" => array("class" => "pure-button ez-button ez-remove-language-button ez-font-icon ez-button-delete")));
        // line 66
        echo "
                ";
        // line 67
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_end');
        echo "
            </div>
        </div>
    </section>
";
        
        $__internal_5f2fb93e1dc5225a66c1adeae219799c990899ce0f973a4cc95fc296d1a6d520->leave($__internal_5f2fb93e1dc5225a66c1adeae219799c990899ce0f973a4cc95fc296d1a6d520_prof);

    }

    // line 73
    public function block_title($context, array $blocks = array())
    {
        $__internal_46e19d573f8f0e42a5ae5e2fde23407f98c21177dc17df8d73629bfb6ab6018f = $this->env->getExtension("native_profiler");
        $__internal_46e19d573f8f0e42a5ae5e2fde23407f98c21177dc17df8d73629bfb6ab6018f->enter($__internal_46e19d573f8f0e42a5ae5e2fde23407f98c21177dc17df8d73629bfb6ab6018f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.view.title", array("%languageName%" => $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "name", array())), "language"), "html", null, true);
        
        $__internal_46e19d573f8f0e42a5ae5e2fde23407f98c21177dc17df8d73629bfb6ab6018f->leave($__internal_46e19d573f8f0e42a5ae5e2fde23407f98c21177dc17df8d73629bfb6ab6018f_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Language:view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  197 => 73,  185 => 67,  182 => 66,  180 => 62,  179 => 60,  178 => 59,  177 => 58,  173 => 57,  170 => 56,  164 => 53,  161 => 52,  155 => 49,  149 => 47,  147 => 46,  143 => 45,  127 => 40,  123 => 39,  117 => 36,  113 => 35,  107 => 32,  103 => 31,  97 => 28,  93 => 27,  85 => 22,  81 => 20,  75 => 19,  65 => 16,  59 => 15,  50 => 12,  47 => 11,  45 => 9,  43 => 6,  37 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "language" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_languagelist'), label: 'language.list'|trans({}, 'language')},*/
/*         {link: '', label: 'language.view.title'|trans({'%languageName%': language.name}, 'language')}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'language.view.title'|trans({'%languageName%': language.name}) }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-tabs ez-serverside-content">*/
/*         <ul class="ez-tabs-list">*/
/*             <li class="ez-tabs-label is-tab-selected"><a href="#ez-tabs-language-name">{{ language.name }}</a></li>*/
/*         </ul>*/
/*         <div class="ez-tabs-panel is-tab-selected" id="ez-tabs-language-name">*/
/*             <ul>*/
/*                 <li>*/
/*                     <strong>{{ 'language.name.label'|trans }}</strong>*/
/*                     {{ language.name }}*/
/*                 </li>*/
/*                 <li>*/
/*                     <strong>{{ 'language.code.label'|trans }}</strong>*/
/*                     {{ language.languageCode }}*/
/*                 </li>*/
/*                 <li>*/
/*                     <strong>{{ 'language.id.label'|trans }}</strong>*/
/*                     {{ language.id }}*/
/*                 </li>*/
/*                 <li>*/
/*                     <strong>{{ 'language.enabled.label'|trans }}</strong>*/
/*                     <input type="checkbox" disabled {% if language.enabled %}checked title="{{ 'language.enabled'|trans }}"{% else %}title="{{ 'language.disabled'|trans }}"{% endif %}>*/
/*                 </li>*/
/*             </ul>*/
/* */
/*             <div>*/
/*                 {{ form_start(deleteForm, {"action": path("admin_languagedelete", {"languageId": language.id, "redirectErrorsTo": "view"})}) }}*/
/*                 {% if canEdit %}*/
/*                     <a href="{{ path('admin_languageedit', {'languageId': language.id}) }}"*/
/*                        class="pure-button ez-button" data-icon="&#xe606;">*/
/*                         {{ 'language.edit'|trans }}*/
/*                     </a>*/
/*                 {% else %}*/
/*                     <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">*/
/*                         {{ 'language.edit'|trans }}*/
/*                     </span>*/
/*                 {% endif %}*/
/* */
/*                     {{ form_widget(deleteForm.languageId) }}*/
/*                     {{*/
/*                         form_widget(*/
/*                             deleteForm.delete,*/
/*                             {*/
/*                                 "disabled": not canEdit,*/
/*                                 "attr": {"class": "pure-button ez-button ez-remove-language-button ez-font-icon ez-button-delete"}*/
/*                             }*/
/*                         )*/
/*                     }}*/
/*                 {{ form_end(deleteForm) }}*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'language.view.title'|trans({'%languageName%': language.name}) }}{% endblock %}*/
/* */
