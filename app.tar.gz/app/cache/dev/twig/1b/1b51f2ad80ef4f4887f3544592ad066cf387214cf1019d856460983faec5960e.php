<?php

/* EzPublishCoreBundle::pagelayout.html.twig */
class __TwigTemplate_61963537cf9cacd8133e549da36f93ce51c7e92aa1e9478a7dcf37a893e69514 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0dd3ce09435cb8a8fd4809c77da88f29a769946b403debb690004a60d67c7f4f = $this->env->getExtension("native_profiler");
        $__internal_0dd3ce09435cb8a8fd4809c77da88f29a769946b403debb690004a60d67c7f4f->enter($__internal_0dd3ce09435cb8a8fd4809c77da88f29a769946b403debb690004a60d67c7f4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle::pagelayout.html.twig"));

        // line 1
        echo "<!doctype html>
<html lang=\"";
        // line 2
        echo twig_escape_filter($this->env, twig_replace_filter($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array()), array("_" => "-")), "html", null, true);
        echo "\">
<head>
    <meta charset=\"utf-8\">
    ";
        // line 5
        if ((array_key_exists("content", $context) &&  !array_key_exists("title", $context))) {
            // line 6
            echo "        ";
            $context["title"] = $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")));
            // line 7
            echo "    ";
        }
        // line 8
        echo "    <title>";
        echo twig_escape_filter($this->env, ((array_key_exists("title", $context)) ? (_twig_default_filter((isset($context["title"]) ? $context["title"] : $this->getContext($context, "title")), "Home")) : ("Home")), "html", null, true);
        echo "</title>
    <meta name=\"generator\" content=\"eZ Platform\"/>
    ";
        // line 10
        if ((array_key_exists("content", $context) && $this->getAttribute($this->getAttribute((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")), "contentInfo", array()), "mainLocationId", array()))) {
            // line 11
            echo "        <link rel=\"canonical\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ez_urlalias", array("locationId" => $this->getAttribute($this->getAttribute((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")), "contentInfo", array()), "mainLocationId", array()))), "html", null, true);
            echo "\" />
    ";
        }
        // line 13
        echo "</head>
<body>
";
        // line 15
        $this->displayBlock('content', $context, $blocks);
        // line 16
        echo "</body>
</html>
";
        
        $__internal_0dd3ce09435cb8a8fd4809c77da88f29a769946b403debb690004a60d67c7f4f->leave($__internal_0dd3ce09435cb8a8fd4809c77da88f29a769946b403debb690004a60d67c7f4f_prof);

    }

    // line 15
    public function block_content($context, array $blocks = array())
    {
        $__internal_ae64345fda07384cb76a3d49c60f7bcf6128f37dc6ad7e50763241ec4f1ba89d = $this->env->getExtension("native_profiler");
        $__internal_ae64345fda07384cb76a3d49c60f7bcf6128f37dc6ad7e50763241ec4f1ba89d->enter($__internal_ae64345fda07384cb76a3d49c60f7bcf6128f37dc6ad7e50763241ec4f1ba89d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_ae64345fda07384cb76a3d49c60f7bcf6128f37dc6ad7e50763241ec4f1ba89d->leave($__internal_ae64345fda07384cb76a3d49c60f7bcf6128f37dc6ad7e50763241ec4f1ba89d_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle::pagelayout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  69 => 15,  60 => 16,  58 => 15,  54 => 13,  48 => 11,  46 => 10,  40 => 8,  37 => 7,  34 => 6,  32 => 5,  26 => 2,  23 => 1,);
    }
}
/* <!doctype html>*/
/* <html lang="{{ app.request.locale|replace({'_': '-'}) }}">*/
/* <head>*/
/*     <meta charset="utf-8">*/
/*     {% if content is defined and title is not defined %}*/
/*         {% set title = ez_content_name( content ) %}*/
/*     {% endif %}*/
/*     <title>{{ title|default( 'Home' ) }}</title>*/
/*     <meta name="generator" content="eZ Platform"/>*/
/*     {% if content is defined and content.contentInfo.mainLocationId %}*/
/*         <link rel="canonical" href="{{ path( 'ez_urlalias', {'locationId': content.contentInfo.mainLocationId} ) }}" />*/
/*     {% endif %}*/
/* </head>*/
/* <body>*/
/* {% block content %}{% endblock %}*/
/* </body>*/
/* </html>*/
/* */
