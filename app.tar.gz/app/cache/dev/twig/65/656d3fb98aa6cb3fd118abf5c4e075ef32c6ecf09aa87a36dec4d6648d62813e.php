<?php

/* EzPublishDebugBundle:Profiler/persistence:panel.html.twig */
class __TwigTemplate_e220ed7b1d947bdc787d93c7dde07eae91a3d3371dc86fd1160c18826d6d0baf extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_65242ff5230134ae16eddc402c78ed5ced4e0d7f577d22c467a2522377fff025 = $this->env->getExtension("native_profiler");
        $__internal_65242ff5230134ae16eddc402c78ed5ced4e0d7f577d22c467a2522377fff025->enter($__internal_65242ff5230134ae16eddc402c78ed5ced4e0d7f577d22c467a2522377fff025_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishDebugBundle:Profiler/persistence:panel.html.twig"));

        // line 1
        echo "<table>
    <tr>
        <th>Total Uncached SPI calls:</th>
        <td>";
        // line 4
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "count", array()), "html", null, true);
        echo "</td>
    </tr>
    ";
        // line 6
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "handlerscount", array())) {
            // line 7
            echo "        <tr>
            <th>Uncached SPI handlers(times loaded):</th>
            <td>";
            // line 9
            echo twig_escape_filter($this->env, twig_join_filter($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "handlers", array()), ", "), "html", null, true);
            echo "</td>
        </tr>
    ";
        }
        // line 12
        echo "</table>

";
        // line 14
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "callsLoggingEnabled", array())) {
            // line 15
            echo "    <h3>Uncached SPI calls</h3>
    <table>
        <tr>
            <th>Class</th>
            <th>Method</th>
            <th>Arguments</th>
        </tr>
        ";
            // line 22
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "calls", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["call"]) {
                // line 23
                echo "            <tr>
                <td>";
                // line 24
                echo twig_escape_filter($this->env, $this->getAttribute($context["call"], "class", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 25
                echo twig_escape_filter($this->env, $this->getAttribute($context["call"], "method", array()), "html", null, true);
                echo "</td>
                <td>";
                // line 26
                echo twig_escape_filter($this->env, $this->getAttribute($context["call"], "arguments", array()), "html", null, true);
                echo "</td>
            </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['call'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 29
            echo "    </table>
";
        }
        
        $__internal_65242ff5230134ae16eddc402c78ed5ced4e0d7f577d22c467a2522377fff025->leave($__internal_65242ff5230134ae16eddc402c78ed5ced4e0d7f577d22c467a2522377fff025_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishDebugBundle:Profiler/persistence:panel.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  83 => 29,  74 => 26,  70 => 25,  66 => 24,  63 => 23,  59 => 22,  50 => 15,  48 => 14,  44 => 12,  38 => 9,  34 => 7,  32 => 6,  27 => 4,  22 => 1,);
    }
}
/* <table>*/
/*     <tr>*/
/*         <th>Total Uncached SPI calls:</th>*/
/*         <td>{{ collector.count }}</td>*/
/*     </tr>*/
/*     {% if collector.handlerscount %}*/
/*         <tr>*/
/*             <th>Uncached SPI handlers(times loaded):</th>*/
/*             <td>{{ collector.handlers|join(', ') }}</td>*/
/*         </tr>*/
/*     {% endif %}*/
/* </table>*/
/* */
/* {% if collector.callsLoggingEnabled %}*/
/*     <h3>Uncached SPI calls</h3>*/
/*     <table>*/
/*         <tr>*/
/*             <th>Class</th>*/
/*             <th>Method</th>*/
/*             <th>Arguments</th>*/
/*         </tr>*/
/*         {% for call in collector.calls %}*/
/*             <tr>*/
/*                 <td>{{ call.class }}</td>*/
/*                 <td>{{ call.method }}</td>*/
/*                 <td>{{ call.arguments }}</td>*/
/*             </tr>*/
/*         {% endfor %}*/
/*     </table>*/
/* {% endif %}*/
/* */
