<?php

/* eZPlatformUIBundle:Role:assign_role_by_section.html.twig */
class __TwigTemplate_fa6845513c306989e4c525748675b73c30c62b572d3356d905a0c3b6ea4cec79 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Role:assign_role_by_section.html.twig", 3);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f5ef77e2ef5d6c034b93e59ba7f90f92be5bb6ed3878e562e644a0cd59d11e54 = $this->env->getExtension("native_profiler");
        $__internal_f5ef77e2ef5d6c034b93e59ba7f90f92be5bb6ed3878e562e644a0cd59d11e54->enter($__internal_f5ef77e2ef5d6c034b93e59ba7f90f92be5bb6ed3878e562e644a0cd59d11e54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Role:assign_role_by_section.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f5ef77e2ef5d6c034b93e59ba7f90f92be5bb6ed3878e562e644a0cd59d11e54->leave($__internal_f5ef77e2ef5d6c034b93e59ba7f90f92be5bb6ed3878e562e644a0cd59d11e54_prof);

    }

    // line 7
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_806d61d8b989c162889648d2ab9913ed94c10e5d034ca056e38b10be736213ad = $this->env->getExtension("native_profiler");
        $__internal_806d61d8b989c162889648d2ab9913ed94c10e5d034ca056e38b10be736213ad->enter($__internal_806d61d8b989c162889648d2ab9913ed94c10e5d034ca056e38b10be736213ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 8
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_role"), "label" => $this->env->getExtension('translator')->trans("role.dashboard_title", array(), "role")), 2 => array("link" => $this->env->getExtension('routing')->getPath("admin_roleView", array("roleId" => $this->getAttribute(        // line 11
(isset($context["role"]) ? $context["role"] : $this->getContext($context, "role")), "id", array()))), "label" => $this->getAttribute((isset($context["role"]) ? $context["role"] : $this->getContext($context, "role")), "identifier", array())), 3 => array("link" => null, "label" => $this->env->getExtension('translator')->trans("role.assign_role_limit_section", array(), "role")));
        // line 14
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_806d61d8b989c162889648d2ab9913ed94c10e5d034ca056e38b10be736213ad->leave($__internal_806d61d8b989c162889648d2ab9913ed94c10e5d034ca056e38b10be736213ad_prof);

    }

    // line 17
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_4342c7a7b3a1aa8d07220d6acb1b7f88e95a70e039272ea21e89e96b8b204eb8 = $this->env->getExtension("native_profiler");
        $__internal_4342c7a7b3a1aa8d07220d6acb1b7f88e95a70e039272ea21e89e96b8b204eb8->enter($__internal_4342c7a7b3a1aa8d07220d6acb1b7f88e95a70e039272ea21e89e96b8b204eb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 18
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe62d;\">";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign_limit_section.user_or_group.pagetitle", array("%roleIdentifier%" => $this->getAttribute((isset($context["role"]) ? $context["role"] : $this->getContext($context, "role")), "identifier", array())), "role"), "html", null, true);
        // line 20
        echo "</h1>
";
        
        $__internal_4342c7a7b3a1aa8d07220d6acb1b7f88e95a70e039272ea21e89e96b8b204eb8->leave($__internal_4342c7a7b3a1aa8d07220d6acb1b7f88e95a70e039272ea21e89e96b8b204eb8_prof);

    }

    // line 23
    public function block_content($context, array $blocks = array())
    {
        $__internal_53b4d501e2d75fd646cc3f4d5cd5caf8b34406667c4d022e5fc1c8d495f1f548 = $this->env->getExtension("native_profiler");
        $__internal_53b4d501e2d75fd646cc3f4d5cd5caf8b34406667c4d022e5fc1c8d495f1f548->enter($__internal_53b4d501e2d75fd646cc3f4d5cd5caf8b34406667c4d022e5fc1c8d495f1f548_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 24
        echo "    <section class=\"ez-serverside-content\">
        <label for=\"data-role-assignment-section\">";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.choose_section", array(), "role"), "html", null, true);
        echo "</label>
        <select id=\"data-role-assignment-section\" class=\"ez-role-assignment-section-id\">
            ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sections"]) ? $context["sections"] : $this->getContext($context, "sections")));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 28
            echo "            ";
            // line 29
            echo "                <option data-section-rest-id=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadSection", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
            echo "\"
                        value=\"";
            // line 30
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "name", array()), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['section'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 32
        echo "        </select>
        <p>
            <button
                data-universaldiscovery-limit-section-title=\"";
        // line 35
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign.universaldiscovery.title", array("%roleIdentifier%" => $this->getAttribute((isset($context["role"]) ? $context["role"] : $this->getContext($context, "role")), "identifier", array())), "role"), "html_attr");
        echo "\"
                data-role-rest-id=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadRole", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : $this->getContext($context, "role")), "id", array()))), "html", null, true);
        echo "\"
                data-role-name=\"";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["role"]) ? $context["role"] : $this->getContext($context, "role")), "identifier", array()), "html", null, true);
        echo "\"
                data-role-assignment-limitation-type=\"";
        // line 38
        echo "Section";
        echo "\"
                class=\"ez-role-assign-limit-section-button ez-button-tree pure-button ez-font-icon ez-button\">
                ";
        // line 40
        if ( !(isset($context["can_assign"]) ? $context["can_assign"] : $this->getContext($context, "can_assign"))) {
            echo "disabled";
        }
        // line 41
        echo "                ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign_limit_section.user_or_group", array(), "role"), "html", null, true);
        echo "
            </button>
            <a href=\"";
        // line 43
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_roleView", array("roleId" => $this->getAttribute((isset($context["role"]) ? $context["role"] : $this->getContext($context, "role")), "id", array()))), "html", null, true);
        echo "\" class=\"ez-role-assign-limit-section-cancel-button pure-button ez-button\">";
        // line 44
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign_limit_section.cancel", array(), "role"), "html", null, true);
        // line 45
        echo "</a>
        </p>
    </section>
";
        
        $__internal_53b4d501e2d75fd646cc3f4d5cd5caf8b34406667c4d022e5fc1c8d495f1f548->leave($__internal_53b4d501e2d75fd646cc3f4d5cd5caf8b34406667c4d022e5fc1c8d495f1f548_prof);

    }

    // line 50
    public function block_title($context, array $blocks = array())
    {
        $__internal_b9a11ae0c5e41d23e90e4a9f002bf78d6295ddffcd0846cd75fd70c73de872da = $this->env->getExtension("native_profiler");
        $__internal_b9a11ae0c5e41d23e90e4a9f002bf78d6295ddffcd0846cd75fd70c73de872da->enter($__internal_b9a11ae0c5e41d23e90e4a9f002bf78d6295ddffcd0846cd75fd70c73de872da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role", array(), "role"), "html", null, true);
        
        $__internal_b9a11ae0c5e41d23e90e4a9f002bf78d6295ddffcd0846cd75fd70c73de872da->leave($__internal_b9a11ae0c5e41d23e90e4a9f002bf78d6295ddffcd0846cd75fd70c73de872da_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Role:assign_role_by_section.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  157 => 50,  147 => 45,  145 => 44,  142 => 43,  136 => 41,  132 => 40,  127 => 38,  123 => 37,  119 => 36,  115 => 35,  110 => 32,  100 => 30,  95 => 29,  93 => 28,  89 => 27,  84 => 25,  81 => 24,  75 => 23,  67 => 20,  65 => 19,  63 => 18,  57 => 17,  47 => 14,  45 => 11,  43 => 8,  37 => 7,  11 => 3,);
    }
}
/* {# @var role \eZ\Publish\API\Repository\Values\User\Role #}*/
/* {# @var sections \eZ\Publish\API\Repository\Values\Content\Section[] #}*/
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "role" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_role'), label: 'role.dashboard_title'|trans},*/
/*         {link: path("admin_roleView", {"roleId": role.id}), label: role.identifier},*/
/*         {link: null, label: 'role.assign_role_limit_section'|trans}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe62d;">*/
/*         {{- 'role.assign_limit_section.user_or_group.pagetitle'|trans({'%roleIdentifier%': role.identifier}) -}}*/
/*     </h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <label for="data-role-assignment-section">{{ 'role.choose_section'|trans }}</label>*/
/*         <select id="data-role-assignment-section" class="ez-role-assignment-section-id">*/
/*             {% for section in sections %}*/
/*             {# @var section \eZ\Publish\API\Repository\Values\Content\Section #}*/
/*                 <option data-section-rest-id="{{ path('ezpublish_rest_loadSection', {'sectionId': section.id}) }}"*/
/*                         value="{{ section.id }}">{{ section.name }}</option>*/
/*             {% endfor %}*/
/*         </select>*/
/*         <p>*/
/*             <button*/
/*                 data-universaldiscovery-limit-section-title="{{ 'role.assign.universaldiscovery.title'|trans({'%roleIdentifier%': role.identifier })|e('html_attr') }}"*/
/*                 data-role-rest-id="{{ path( 'ezpublish_rest_loadRole', {'roleId': role.id}) }}"*/
/*                 data-role-name="{{ role.identifier }}"*/
/*                 data-role-assignment-limitation-type="{{ 'Section' }}"*/
/*                 class="ez-role-assign-limit-section-button ez-button-tree pure-button ez-font-icon ez-button">*/
/*                 {% if not can_assign %}disabled{% endif %}*/
/*                 {{ 'role.assign_limit_section.user_or_group'|trans }}*/
/*             </button>*/
/*             <a href="{{ path("admin_roleView", {"roleId": role.id}) }}" class="ez-role-assign-limit-section-cancel-button pure-button ez-button">*/
/*                 {{- 'role.assign_limit_section.cancel'|trans -}}*/
/*             </a>*/
/*         </p>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'role'|trans }}{% endblock %}*/
/* */
