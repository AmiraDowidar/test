<?php

/* eZPlatformUIBundle:Role:edit_policy.html.twig */
class __TwigTemplate_158af58592f8671386482afe2410eda8a9ed4eec0b2ed91397cbc4a255179c52 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Role:edit_policy.html.twig", 2);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6d9a7455da52a53a3c89239695be30b4e548c08e74e83002729e7352f02fbcb5 = $this->env->getExtension("native_profiler");
        $__internal_6d9a7455da52a53a3c89239695be30b4e548c08e74e83002729e7352f02fbcb5->enter($__internal_6d9a7455da52a53a3c89239695be30b4e548c08e74e83002729e7352f02fbcb5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Role:edit_policy.html.twig"));

        // line 6
        $context["editTitle"] = (($this->getAttribute((isset($context["policy"]) ? $context["policy"] : $this->getContext($context, "policy")), "new", array())) ? ($this->env->getExtension('translator')->trans("role.policy.create.title", array(), "role")) : ($this->env->getExtension('translator')->trans("role.policy.edit.title", array("%policy%" => (($this->getAttribute((isset($context["policy"]) ? $context["policy"] : $this->getContext($context, "policy")), "module", array()) . "/") . $this->getAttribute((isset($context["policy"]) ? $context["policy"] : $this->getContext($context, "policy")), "function", array()))), "role")));
        // line 2
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6d9a7455da52a53a3c89239695be30b4e548c08e74e83002729e7352f02fbcb5->leave($__internal_6d9a7455da52a53a3c89239695be30b4e548c08e74e83002729e7352f02fbcb5_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_269e4807d1d9b3a539e977092d2a1ef251f75e894368eadf4267f2110cea44c4 = $this->env->getExtension("native_profiler");
        $__internal_269e4807d1d9b3a539e977092d2a1ef251f75e894368eadf4267f2110cea44c4->enter($__internal_269e4807d1d9b3a539e977092d2a1ef251f75e894368eadf4267f2110cea44c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 9
        echo "    ";
        echo twig_escape_filter($this->env, (isset($context["editTitle"]) ? $context["editTitle"] : $this->getContext($context, "editTitle")), "html", null, true);
        echo "
";
        
        $__internal_269e4807d1d9b3a539e977092d2a1ef251f75e894368eadf4267f2110cea44c4->leave($__internal_269e4807d1d9b3a539e977092d2a1ef251f75e894368eadf4267f2110cea44c4_prof);

    }

    // line 12
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_025000a87689f8701ac3bd1222b7e35085caf8ce346d296f2fe8c0a0d22ebfce = $this->env->getExtension("native_profiler");
        $__internal_025000a87689f8701ac3bd1222b7e35085caf8ce346d296f2fe8c0a0d22ebfce->enter($__internal_025000a87689f8701ac3bd1222b7e35085caf8ce346d296f2fe8c0a0d22ebfce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 13
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_role"), "label" => $this->env->getExtension('translator')->trans("role.dashboard_title", array(), "role")), 2 => array("link" => null, "label" => $this->getAttribute($this->getAttribute(        // line 16
(isset($context["policy"]) ? $context["policy"] : $this->getContext($context, "policy")), "roleDraft", array()), "identifier", array())), 3 => array("link" => "", "label" =>         // line 17
(isset($context["editTitle"]) ? $context["editTitle"] : $this->getContext($context, "editTitle"))));
        // line 19
        echo "
    ";
        // line 20
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_025000a87689f8701ac3bd1222b7e35085caf8ce346d296f2fe8c0a0d22ebfce->leave($__internal_025000a87689f8701ac3bd1222b7e35085caf8ce346d296f2fe8c0a0d22ebfce_prof);

    }

    // line 23
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_affd54358c9a927bac03614ef24c24f2e1c568e2bfce12c8813d139ab1927c49 = $this->env->getExtension("native_profiler");
        $__internal_affd54358c9a927bac03614ef24c24f2e1c568e2bfce12c8813d139ab1927c49->enter($__internal_affd54358c9a927bac03614ef24c24f2e1c568e2bfce12c8813d139ab1927c49_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 24
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">
        ";
        // line 25
        echo twig_escape_filter($this->env, (isset($context["editTitle"]) ? $context["editTitle"] : $this->getContext($context, "editTitle")), "html", null, true);
        echo "
    </h1>
";
        
        $__internal_affd54358c9a927bac03614ef24c24f2e1c568e2bfce12c8813d139ab1927c49->leave($__internal_affd54358c9a927bac03614ef24c24f2e1c568e2bfce12c8813d139ab1927c49_prof);

    }

    // line 29
    public function block_content($context, array $blocks = array())
    {
        $__internal_64cc4902a00558c849aa9ddf99a20ae29b5eed0cfc2ce7e832d4e1bf68237fec = $this->env->getExtension("native_profiler");
        $__internal_64cc4902a00558c849aa9ddf99a20ae29b5eed0cfc2ce7e832d4e1bf68237fec->enter($__internal_64cc4902a00558c849aa9ddf99a20ae29b5eed0cfc2ce7e832d4e1bf68237fec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 30
        echo "    <section class=\"ez-serverside-content\">
        ";
        // line 31
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("action" => (isset($context["actionUrl"]) ? $context["actionUrl"] : $this->getContext($context, "actionUrl")), "attr" => array("class" => "pure-form pure-form-aligned")));
        echo "
            ";
        // line 32
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "

            <fieldset>
                <div class=\"pure-control-group\">
                    ";
        // line 36
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "moduleFunction", array()), 'label');
        echo "
                    ";
        // line 37
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "moduleFunction", array()), 'errors');
        echo "
                    ";
        // line 38
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "moduleFunction", array()), 'widget', array("disabled" =>  !$this->getAttribute((isset($context["policy"]) ? $context["policy"] : $this->getContext($context, "policy")), "new", array())));
        echo "
                </div>
            </fieldset>

        ";
        // line 43
        echo "        ";
        if ($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "limitationsData", array(), "any", true, true)) {
            // line 44
            echo "            <fieldset>
                <legend>";
            // line 45
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "limitationsData", array()), 'label');
            echo "</legend>
                ";
            // line 46
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "limitationsData", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["limitationForm"]) {
                // line 47
                echo "                    <div class=\"pure-control-group\">
                        ";
                // line 48
                echo twig_include($this->env, $context, $this->getAttribute($this->getAttribute($context["limitationForm"], "vars", array()), "template", array()), array("form" => $context["limitationForm"]), false);
                echo "
                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['limitationForm'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 51
            echo "            </fieldset>
        ";
        }
        // line 53
        echo "
            <div class=\"pure-controls\">
                ";
        // line 55
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "removeDraft", array()), 'widget', array("attr" => array("class" => "pure-button ez-button", "formnovalidate" => "formnovalidate")));
        echo "
                ";
        // line 56
        if ($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "saveAndAddLimitation", array(), "any", true, true)) {
            // line 57
            echo "                    ";
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "saveAndAddLimitation", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
            echo "
                ";
        }
        // line 59
        echo "                ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "savePolicy", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
            </div>

        ";
        // line 62
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </section>
";
        
        $__internal_64cc4902a00558c849aa9ddf99a20ae29b5eed0cfc2ce7e832d4e1bf68237fec->leave($__internal_64cc4902a00558c849aa9ddf99a20ae29b5eed0cfc2ce7e832d4e1bf68237fec_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Role:edit_policy.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  186 => 62,  179 => 59,  173 => 57,  171 => 56,  167 => 55,  163 => 53,  159 => 51,  150 => 48,  147 => 47,  143 => 46,  139 => 45,  136 => 44,  133 => 43,  126 => 38,  122 => 37,  118 => 36,  111 => 32,  107 => 31,  104 => 30,  98 => 29,  88 => 25,  85 => 24,  79 => 23,  70 => 20,  67 => 19,  65 => 17,  64 => 16,  62 => 13,  56 => 12,  46 => 9,  40 => 8,  33 => 2,  31 => 6,  11 => 2,);
    }
}
/* {# @var policy \EzSystems\RepositoryForms\Data\Role\PolicyCreateData|\EzSystems\RepositoryForms\Data\Role\PolicyUpdateData #}*/
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "role" %}*/
/* */
/* {% set editTitle = policy.new ? "role.policy.create.title"|trans() : "role.policy.edit.title"|trans({"%policy%": policy.module ~ "/" ~ policy.function}) %}*/
/* */
/* {% block title %}*/
/*     {{ editTitle }}*/
/* {% endblock %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_role'), label: 'role.dashboard_title'|trans},*/
/*         {link: null, label: policy.roleDraft.identifier},*/
/*         {link: '', label: editTitle}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">*/
/*         {{ editTitle }}*/
/*     </h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         {{ form_start(form, {'action': actionUrl, "attr": {"class": "pure-form pure-form-aligned"}}) }}*/
/*             {{ form_errors(form) }}*/
/* */
/*             <fieldset>*/
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.moduleFunction) }}*/
/*                     {{ form_errors(form.moduleFunction) }}*/
/*                     {{ form_widget(form.moduleFunction, {"disabled": not policy.new}) }}*/
/*                 </div>*/
/*             </fieldset>*/
/* */
/*         {# form.limitationsData doesn't exist yet when creating a new policy draft. #}*/
/*         {% if form.limitationsData is defined %}*/
/*             <fieldset>*/
/*                 <legend>{{ form_label(form.limitationsData) }}</legend>*/
/*                 {% for limitationForm in form.limitationsData %}*/
/*                     <div class="pure-control-group">*/
/*                         {{ include(limitationForm.vars.template, {form: limitationForm}, with_context = false) }}*/
/*                     </div>*/
/*                 {% endfor %}*/
/*             </fieldset>*/
/*         {% endif %}*/
/* */
/*             <div class="pure-controls">*/
/*                 {{ form_widget(form.removeDraft, {"attr": {"class": "pure-button ez-button", "formnovalidate": "formnovalidate"}}) }}*/
/*                 {% if form.saveAndAddLimitation is defined %}*/
/*                     {{ form_widget(form.saveAndAddLimitation, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*                 {% endif %}*/
/*                 {{ form_widget(form.savePolicy, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*             </div>*/
/* */
/*         {{ form_end(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
