<?php

/* @Framework/Form/textarea_widget.html.php */
class __TwigTemplate_a63501cd10c0801fc6303606cef1e9cb36ef5e160de0c74190ea36ed79348a8b extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1a02bfe569179994c085b2d928dfa0f4860360442585641f7ee67e3fe2811768 = $this->env->getExtension("native_profiler");
        $__internal_1a02bfe569179994c085b2d928dfa0f4860360442585641f7ee67e3fe2811768->enter($__internal_1a02bfe569179994c085b2d928dfa0f4860360442585641f7ee67e3fe2811768_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/textarea_widget.html.php"));

        // line 1
        echo "<textarea <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>><?php echo \$view->escape(\$value) ?></textarea>
";
        
        $__internal_1a02bfe569179994c085b2d928dfa0f4860360442585641f7ee67e3fe2811768->leave($__internal_1a02bfe569179994c085b2d928dfa0f4860360442585641f7ee67e3fe2811768_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/textarea_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <textarea <?php echo $view['form']->block($form, 'widget_attributes') ?>><?php echo $view->escape($value) ?></textarea>*/
/* */
