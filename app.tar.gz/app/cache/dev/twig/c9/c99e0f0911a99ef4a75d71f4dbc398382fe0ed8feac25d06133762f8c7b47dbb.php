<?php

/* EzPublishCoreBundle:default/content:embed_image.html.twig */
class __TwigTemplate_aac92e90683fb38763084f1e7d231160a7db0184e84eca0b937c39bffe168a8a extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6155c744cb74831b7b84e88c69563928751c3bccbf0ce67a18f429909a6b4244 = $this->env->getExtension("native_profiler");
        $__internal_6155c744cb74831b7b84e88c69563928751c3bccbf0ce67a18f429909a6b4244->enter($__internal_6155c744cb74831b7b84e88c69563928751c3bccbf0ce67a18f429909a6b4244_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:default/content:embed_image.html.twig"));

        // line 1
        $context["image_field_identifier"] = $this->env->getExtension('ezpublish.content')->getFirstFilledImageFieldIdentifier((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")));
        // line 2
        echo "
";
        // line 3
        if ( !(null === (isset($context["image_field_identifier"]) ? $context["image_field_identifier"] : $this->getContext($context, "image_field_identifier")))) {
            // line 4
            echo "    ";
            echo call_user_func_array($this->env->getFunction('ez_render_field')->getCallable(), array($this->env,             // line 5
(isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")),             // line 6
(isset($context["image_field_identifier"]) ? $context["image_field_identifier"] : $this->getContext($context, "image_field_identifier")), array("parameters" => array("alias" => $this->getAttribute(            // line 7
(isset($context["objectParameters"]) ? $context["objectParameters"] : $this->getContext($context, "objectParameters")), "size", array())))));
            // line 8
            echo "
";
        }
        
        $__internal_6155c744cb74831b7b84e88c69563928751c3bccbf0ce67a18f429909a6b4244->leave($__internal_6155c744cb74831b7b84e88c69563928751c3bccbf0ce67a18f429909a6b4244_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/content:embed_image.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  35 => 8,  33 => 7,  32 => 6,  31 => 5,  29 => 4,  27 => 3,  24 => 2,  22 => 1,);
    }
}
/* {% set image_field_identifier = ez_first_filled_image_field_identifier(content) %}*/
/* */
/* {% if image_field_identifier is not null %}*/
/*     {{ ez_render_field(*/
/*        content,*/
/*        image_field_identifier,*/
/*        { parameters: { alias: objectParameters.size } }*/
/*     ) }}*/
/* {% endif %}*/
/* */
