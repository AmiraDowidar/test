<?php

/* @Framework/Form/form.html.php */
class __TwigTemplate_25214f57f71531dd2028c1fb45e6e0405d8239657b42a5f6958ca396c5f11341 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_15d84a45adba3b079f2c1839b2addbc5c1655604e7602523195b4e5f1d5f1db7 = $this->env->getExtension("native_profiler");
        $__internal_15d84a45adba3b079f2c1839b2addbc5c1655604e7602523195b4e5f1d5f1db7->enter($__internal_15d84a45adba3b079f2c1839b2addbc5c1655604e7602523195b4e5f1d5f1db7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form.html.php"));

        // line 1
        echo "<?php echo \$view['form']->start(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
<?php echo \$view['form']->end(\$form) ?>
";
        
        $__internal_15d84a45adba3b079f2c1839b2addbc5c1655604e7602523195b4e5f1d5f1db7->leave($__internal_15d84a45adba3b079f2c1839b2addbc5c1655604e7602523195b4e5f1d5f1db7_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->start($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* <?php echo $view['form']->end($form) ?>*/
/* */
