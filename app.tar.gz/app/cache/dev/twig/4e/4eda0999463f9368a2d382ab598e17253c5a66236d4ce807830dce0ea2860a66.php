<?php

/* eZPlatformUIBundle:ContentType:view_content_type_group.html.twig */
class __TwigTemplate_220ba7e64d17ba341527860423290fdef6ecf88e67e9cd5588d25fb3e492ee21 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:ContentType:view_content_type_group.html.twig", 3);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_f9ef155f84c199bbabb270cce7fcaf833be71577e5bb3efb5cbcdd5aeda05aed = $this->env->getExtension("native_profiler");
        $__internal_f9ef155f84c199bbabb270cce7fcaf833be71577e5bb3efb5cbcdd5aeda05aed->enter($__internal_f9ef155f84c199bbabb270cce7fcaf833be71577e5bb3efb5cbcdd5aeda05aed_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:ContentType:view_content_type_group.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_f9ef155f84c199bbabb270cce7fcaf833be71577e5bb3efb5cbcdd5aeda05aed->leave($__internal_f9ef155f84c199bbabb270cce7fcaf833be71577e5bb3efb5cbcdd5aeda05aed_prof);

    }

    // line 7
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_723b427047961afd765bc0b6400bf3f6d3709ccf56c08adc2e8af306d6f709dd = $this->env->getExtension("native_profiler");
        $__internal_723b427047961afd765bc0b6400bf3f6d3709ccf56c08adc2e8af306d6f709dd->enter($__internal_723b427047961afd765bc0b6400bf3f6d3709ccf56c08adc2e8af306d6f709dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 8
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_contenttype"), "label" => $this->env->getExtension('translator')->trans("content_type.dashboard_title", array(), "content_type")), 2 => array("link" => null, "label" => $this->getAttribute(        // line 11
(isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "identifier", array())));
        // line 13
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_723b427047961afd765bc0b6400bf3f6d3709ccf56c08adc2e8af306d6f709dd->leave($__internal_723b427047961afd765bc0b6400bf3f6d3709ccf56c08adc2e8af306d6f709dd_prof);

    }

    // line 16
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_487c281ed4561667d58d2df2857449e624988a1a6f02a60e08ffa3c1be98a4bf = $this->env->getExtension("native_profiler");
        $__internal_487c281ed4561667d58d2df2857449e624988a1a6f02a60e08ffa3c1be98a4bf->enter($__internal_487c281ed4561667d58d2df2857449e624988a1a6f02a60e08ffa3c1be98a4bf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 17
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group", array("%name%" => $this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "identifier", array())), "content_type"), "html", null, true);
        echo "</h1>
";
        
        $__internal_487c281ed4561667d58d2df2857449e624988a1a6f02a60e08ffa3c1be98a4bf->leave($__internal_487c281ed4561667d58d2df2857449e624988a1a6f02a60e08ffa3c1be98a4bf_prof);

    }

    // line 20
    public function block_content($context, array $blocks = array())
    {
        $__internal_ba15e2d4497c4f8b5ff0f88a6231271a2a2fd5afe3f9ff5682056533e6ed0ff9 = $this->env->getExtension("native_profiler");
        $__internal_ba15e2d4497c4f8b5ff0f88a6231271a2a2fd5afe3f9ff5682056533e6ed0ff9->enter($__internal_ba15e2d4497c4f8b5ff0f88a6231271a2a2fd5afe3f9ff5682056533e6ed0ff9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 21
        echo "    <section class=\"ez-serverside-content\">
        <div class=\"ez-table-data is-flexible\">
            <div class=\"ez-table-data-container\">
                <table class=\"pure-table pure-table-striped ez-selection-table\">
                    <thead>
                    <tr class=\"ez-selection-table-row\">
                        <th>";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.id", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th>";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.name", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th>";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.identifier", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th>";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.modified_date", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th></th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["content_types"]) ? $context["content_types"] : $this->getContext($context, "content_types")));
        foreach ($context['_seq'] as $context["_key"] => $context["content_type"]) {
            // line 37
            echo "                        <tr>
                            <td>";
            // line 38
            echo twig_escape_filter($this->env, $this->getAttribute($context["content_type"], "id", array()), "html", null, true);
            echo "</td>
                            <td><a class=\"ez-contenttype-icon ez-contenttype-icon-";
            // line 39
            echo twig_escape_filter($this->env, $this->getAttribute($context["content_type"], "identifier", array()), "html", null, true);
            echo "\" href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_contenttypeView", array("contentTypeId" => $this->getAttribute($context["content_type"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.content')->getTranslatedProperty($context["content_type"], "name"), "html", null, true);
            echo "</a></td>
                            <td>";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["content_type"], "identifier", array()), "html", null, true);
            echo "</td>
                            <td>";
            // line 41
            echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["content_type"], "modificationDate", array()), "medium", "medium", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array())), "html", null, true);
            echo "</td>
                            <td>
                            ";
            // line 43
            if ((isset($context["can_edit"]) ? $context["can_edit"] : $this->getContext($context, "can_edit"))) {
                // line 44
                echo "                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_contenttypeUpdate", array("contentTypeId" => $this->getAttribute($context["content_type"], "id", array()))), "html", null, true);
                echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.edit", array(), "content_type"), "html", null, true);
                echo "</a>
                            ";
            } else {
                // line 46
                echo "                                <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.edit", array(), "content_type"), "html", null, true);
                echo "</span>
                            ";
            }
            // line 48
            echo "                            </td>
                            <td>
                                ";
            // line 50
            $context["deleteForm"] = $this->getAttribute((isset($context["delete_forms_by_id"]) ? $context["delete_forms_by_id"] : $this->getContext($context, "delete_forms_by_id")), $this->getAttribute($context["content_type"], "id", array()), array(), "array");
            // line 51
            echo "                                ";
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_contenttypeDelete", array("contentTypeId" => $this->getAttribute($context["content_type"], "id", array())))));
            echo "
                                    ";
            // line 52
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "contentTypeId", array()), 'widget');
            echo "
                                    ";
            // line 53
            echo             // line 54
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(            // line 55
(isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "delete", array()), 'widget', array("disabled" =>  !$this->getAttribute(            // line 57
(isset($context["can_delete_by_id"]) ? $context["can_delete_by_id"] : $this->getContext($context, "can_delete_by_id")), $this->getAttribute($context["content_type"], "id", array()), array(), "array"), "attr" => array("class" => "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete", "title" => (( !$this->getAttribute(            // line 59
(isset($context["can_delete_by_id"]) ? $context["can_delete_by_id"] : $this->getContext($context, "can_delete_by_id")), $this->getAttribute($context["content_type"], "id", array()), array(), "array")) ? ($this->env->getExtension('translator')->trans("content_type.is_in_use", array(), "content_type")) : ("")))));
            // line 62
            echo "
                                ";
            // line 63
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_end');
            echo "
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['content_type'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 67
        echo "                    </tbody>
                </table>
                ";
        // line 69
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_contenttypeCreate", array("contentTypeGroupId" => $this->getAttribute((isset($context["group"]) ? $context["group"] : $this->getContext($context, "group")), "id", array())))));
        echo "
                <p class=\"ez-table-data-buttons\">
                    ";
        // line 72
        echo "                    ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), "contentTypeGroupId", array()), 'widget');
        echo "
                    <button type=\"submit\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\"";
        // line 73
        if ( !(isset($context["can_create"]) ? $context["can_create"] : $this->getContext($context, "can_create"))) {
            echo " disabled=\"disabled\"";
        }
        // line 74
        echo "                            name=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), "create", array()), "vars", array()), "full_name", array(), "array"), "html", null, true);
        echo "\"
                            id=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), "create", array()), "vars", array()), "id", array(), "array"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), "create", array()), "vars", array()), "label", array(), "array"), array(), "ezrepoforms_content_type"), "html", null, true);
        echo "</button>
                    ";
        // line 76
        $this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), "create", array()), "setRendered", array(), "method");
        // line 77
        echo "                </p>
                ";
        // line 78
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), 'form_end');
        echo "
            </div>
        </div>
    </section>
";
        
        $__internal_ba15e2d4497c4f8b5ff0f88a6231271a2a2fd5afe3f9ff5682056533e6ed0ff9->leave($__internal_ba15e2d4497c4f8b5ff0f88a6231271a2a2fd5afe3f9ff5682056533e6ed0ff9_prof);

    }

    // line 84
    public function block_title($context, array $blocks = array())
    {
        $__internal_f07142bef08f4d35672c30a419cd0e8903fe97d8ab3633355a642b8be85b3aa0 = $this->env->getExtension("native_profiler");
        $__internal_f07142bef08f4d35672c30a419cd0e8903fe97d8ab3633355a642b8be85b3aa0->enter($__internal_f07142bef08f4d35672c30a419cd0e8903fe97d8ab3633355a642b8be85b3aa0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.list", array(), "content_type"), "html", null, true);
        
        $__internal_f07142bef08f4d35672c30a419cd0e8903fe97d8ab3633355a642b8be85b3aa0->leave($__internal_f07142bef08f4d35672c30a419cd0e8903fe97d8ab3633355a642b8be85b3aa0_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ContentType:view_content_type_group.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  232 => 84,  220 => 78,  217 => 77,  215 => 76,  209 => 75,  204 => 74,  200 => 73,  195 => 72,  190 => 69,  186 => 67,  176 => 63,  173 => 62,  171 => 59,  170 => 57,  169 => 55,  168 => 54,  167 => 53,  163 => 52,  158 => 51,  156 => 50,  152 => 48,  146 => 46,  138 => 44,  136 => 43,  131 => 41,  127 => 40,  119 => 39,  115 => 38,  112 => 37,  108 => 36,  99 => 30,  95 => 29,  91 => 28,  87 => 27,  79 => 21,  73 => 20,  63 => 17,  57 => 16,  47 => 13,  45 => 11,  43 => 8,  37 => 7,  11 => 3,);
    }
}
/* {# @var group \eZ\Publish\API\Repository\Values\ContentType\ContentTypeGroup #}*/
/* {# @var content_types \eZ\Publish\API\Repository\Values\ContentType\ContentType[] #}*/
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "content_type" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_contenttype'), label: 'content_type.dashboard_title'|trans},*/
/*         {link: null, label: group.identifier}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'content_type.group'|trans({'%name%': group.identifier}) }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <div class="ez-table-data is-flexible">*/
/*             <div class="ez-table-data-container">*/
/*                 <table class="pure-table pure-table-striped ez-selection-table">*/
/*                     <thead>*/
/*                     <tr class="ez-selection-table-row">*/
/*                         <th>{{ 'content_type.id'|trans }}</th>*/
/*                         <th>{{ 'content_type.name'|trans }}</th>*/
/*                         <th>{{ 'content_type.identifier'|trans }}</th>*/
/*                         <th>{{ 'content_type.modified_date'|trans }}</th>*/
/*                         <th></th>*/
/*                         <th></th>*/
/*                     </tr>*/
/*                     </thead>*/
/*                     <tbody>*/
/*                     {% for content_type in content_types %}*/
/*                         <tr>*/
/*                             <td>{{ content_type.id }}</td>*/
/*                             <td><a class="ez-contenttype-icon ez-contenttype-icon-{{ content_type.identifier }}" href="{{ path('admin_contenttypeView', {'contentTypeId': content_type.id}) }}">{{ ez_trans_prop(content_type, "name") }}</a></td>*/
/*                             <td>{{ content_type.identifier }}</td>*/
/*                             <td>{{ content_type.modificationDate|localizeddate("medium", "medium", app.request.locale) }}</td>*/
/*                             <td>*/
/*                             {% if can_edit %}*/
/*                                 <a href="{{ path('admin_contenttypeUpdate', {'contentTypeId': content_type.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'content_type.edit'|trans }}</a>*/
/*                             {% else %}*/
/*                                 <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'content_type.edit'|trans }}</span>*/
/*                             {% endif %}*/
/*                             </td>*/
/*                             <td>*/
/*                                 {% set deleteForm = delete_forms_by_id[content_type.id] %}*/
/*                                 {{ form_start(deleteForm, {"action": path("admin_contenttypeDelete", {"contentTypeId": content_type.id})}) }}*/
/*                                     {{ form_widget(deleteForm.contentTypeId) }}*/
/*                                     {{*/
/*                                         form_widget(*/
/*                                             deleteForm.delete,*/
/*                                             {*/
/*                                                 "disabled": not can_delete_by_id[content_type.id],*/
/*                                                 "attr": {"class": "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete",*/
/*                                                          "title": not can_delete_by_id[content_type.id] ? 'content_type.is_in_use'|trans}*/
/*                                             }*/
/*                                         )*/
/*                                     }}*/
/*                                 {{ form_end(deleteForm) }}*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*                     </tbody>*/
/*                 </table>*/
/*                 {{ form_start(create_form, {"action": path("admin_contenttypeCreate", {"contentTypeGroupId": group.id})}) }}*/
/*                 <p class="ez-table-data-buttons">*/
/*                     {# TODO: We should be able to select a language for ContentType creation #}*/
/*                     {{ form_widget(create_form.contentTypeGroupId) }}*/
/*                     <button type="submit" class="pure-button ez-button" data-icon="&#xe616;"{% if not can_create %} disabled="disabled"{% endif %}*/
/*                             name="{{ create_form.create.vars['full_name'] }}"*/
/*                             id="{{ create_form.create.vars['id'] }}">{{ create_form.create.vars['label']|trans(domain="ezrepoforms_content_type") }}</button>*/
/*                     {% do create_form.create.setRendered() %}*/
/*                 </p>*/
/*                 {{ form_end(create_form) }}*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'content_type.group.list'|trans }}{% endblock %}*/
/* */
/* */
