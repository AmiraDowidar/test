<?php

/* EzSystemsRepositoryFormsBundle:Limitation:null_limitation_values.html.twig */
class __TwigTemplate_3cdbafe752e95a42247646e01b28e73549680e099d95ff13740ea4e8f1421a4b extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ea8980e97973c4ec3cec72d8d567a21f12d70f3d866d42325d6ef6b901961da4 = $this->env->getExtension("native_profiler");
        $__internal_ea8980e97973c4ec3cec72d8d567a21f12d70f3d866d42325d6ef6b901961da4->enter($__internal_ea8980e97973c4ec3cec72d8d567a21f12d70f3d866d42325d6ef6b901961da4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzSystemsRepositoryFormsBundle:Limitation:null_limitation_values.html.twig"));

        // line 1
        $this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "setRendered", array(), "method");
        // line 2
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'label');
        echo "
<em>";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.policy.limitation.not_implemented", array("%limitationTypeIdentifier%" => $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars", array()), "data", array()), "identifier", array())), "ezrepoforms_role"), "html", null, true);
        echo "</em>
";
        
        $__internal_ea8980e97973c4ec3cec72d8d567a21f12d70f3d866d42325d6ef6b901961da4->leave($__internal_ea8980e97973c4ec3cec72d8d567a21f12d70f3d866d42325d6ef6b901961da4_prof);

    }

    public function getTemplateName()
    {
        return "EzSystemsRepositoryFormsBundle:Limitation:null_limitation_values.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  28 => 3,  24 => 2,  22 => 1,);
    }
}
/* {% do form.setRendered() %}*/
/* {{ form_label(form) }}*/
/* <em>{{ "role.policy.limitation.not_implemented"|trans({"%limitationTypeIdentifier%": form.vars.data.identifier}, 'ezrepoforms_role') }}</em>*/
/* */
