<?php

/* @Framework/Form/repeated_row.html.php */
class __TwigTemplate_5934875bb8a102ed5e862bb3c37b4eadd049569dda6ca3d2fd31f3c3710c8c5c extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ed37f3b3513ff4f2e0d46a1cca8880bde3a834dea7e3a38f8805113eec938835 = $this->env->getExtension("native_profiler");
        $__internal_ed37f3b3513ff4f2e0d46a1cca8880bde3a834dea7e3a38f8805113eec938835->enter($__internal_ed37f3b3513ff4f2e0d46a1cca8880bde3a834dea7e3a38f8805113eec938835_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/repeated_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_rows') ?>
";
        
        $__internal_ed37f3b3513ff4f2e0d46a1cca8880bde3a834dea7e3a38f8805113eec938835->leave($__internal_ed37f3b3513ff4f2e0d46a1cca8880bde3a834dea7e3a38f8805113eec938835_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/repeated_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_rows') ?>*/
/* */
