<?php

/* EzPublishCoreBundle:default/content:text_linked.html.twig */
class __TwigTemplate_52538446dd54cd6572344bcdb69364afb89e5c8d0396403021627c861b92ac12 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_dda3c3f078a35e6a3de0669c2cec2ac2e151faa9e5e86321183ca27680cb8ea0 = $this->env->getExtension("native_profiler");
        $__internal_dda3c3f078a35e6a3de0669c2cec2ac2e151faa9e5e86321183ca27680cb8ea0->enter($__internal_dda3c3f078a35e6a3de0669c2cec2ac2e151faa9e5e86321183ca27680cb8ea0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:default/content:text_linked.html.twig"));

        // line 1
        $context["content_name"] = $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")));
        // line 2
        echo "
";
        // line 3
        if (array_key_exists("location", $context)) {
            // line 4
            echo "    <a href=\"";
            echo $this->env->getExtension('routing')->getPath((isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")));
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["content_name"]) ? $context["content_name"] : $this->getContext($context, "content_name")), "html", null, true);
            echo "</a>
";
        } else {
            // line 6
            echo "    <p>";
            echo twig_escape_filter($this->env, (isset($context["content_name"]) ? $context["content_name"] : $this->getContext($context, "content_name")), "html", null, true);
            echo "</p>
";
        }
        
        $__internal_dda3c3f078a35e6a3de0669c2cec2ac2e151faa9e5e86321183ca27680cb8ea0->leave($__internal_dda3c3f078a35e6a3de0669c2cec2ac2e151faa9e5e86321183ca27680cb8ea0_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/content:text_linked.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 6,  29 => 4,  27 => 3,  24 => 2,  22 => 1,);
    }
}
/* {% set content_name=ez_content_name(content) %}*/
/* */
/* {% if location is defined %}*/
/*     <a href="{{ path(location) }}">{{ content_name }}</a>*/
/* {% else %}*/
/*     <p>{{ content_name }}</p>*/
/* {% endif %}*/
/* */
