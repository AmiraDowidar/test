<?php

/* EzPublishDebugBundle:Profiler/persistence:toolbar.html.twig */
class __TwigTemplate_c7f257ef151821e7a95c6232bf84f32430c29ea860fabef765c618d31eef6298 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9baad4fd662f3c900fdbf396d102e32d9c1b795e567ae979dcd43c9b959e3e75 = $this->env->getExtension("native_profiler");
        $__internal_9baad4fd662f3c900fdbf396d102e32d9c1b795e567ae979dcd43c9b959e3e75->enter($__internal_9baad4fd662f3c900fdbf396d102e32d9c1b795e567ae979dcd43c9b959e3e75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishDebugBundle:Profiler/persistence:toolbar.html.twig"));

        // line 1
        echo "<div class=\"sf-toolbar-info-piece\">
    <b>SPI (persistence)</b>
</div>
<div class=\"sf-toolbar-info-piece\">
    <b>calls</b> <span class=\"sf-toolbar-status sf-toolbar-status-green\">";
        // line 5
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "count", array()), "html", null, true);
        echo "</span>
</div>
<div class=\"sf-toolbar-info-piece\">
    <b>handlers</b> <span class=\"sf-toolbar-status sf-toolbar-status-green\">";
        // line 8
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "handlerscount", array()), "html", null, true);
        echo "</span>
</div>
";
        
        $__internal_9baad4fd662f3c900fdbf396d102e32d9c1b795e567ae979dcd43c9b959e3e75->leave($__internal_9baad4fd662f3c900fdbf396d102e32d9c1b795e567ae979dcd43c9b959e3e75_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishDebugBundle:Profiler/persistence:toolbar.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  34 => 8,  28 => 5,  22 => 1,);
    }
}
/* <div class="sf-toolbar-info-piece">*/
/*     <b>SPI (persistence)</b>*/
/* </div>*/
/* <div class="sf-toolbar-info-piece">*/
/*     <b>calls</b> <span class="sf-toolbar-status sf-toolbar-status-green">{{ collector.count }}</span>*/
/* </div>*/
/* <div class="sf-toolbar-info-piece">*/
/*     <b>handlers</b> <span class="sf-toolbar-status sf-toolbar-status-green">{{ collector.handlerscount }}</span>*/
/* </div>*/
/* */
