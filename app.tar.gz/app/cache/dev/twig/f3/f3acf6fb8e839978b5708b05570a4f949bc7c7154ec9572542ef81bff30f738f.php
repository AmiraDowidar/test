<?php

/* eZPlatformUIBundle:Language:list.html.twig */
class __TwigTemplate_98d994d23eced7fe8f49f778cdc499bb77eef054eb32d11d924795c9caef3fa1 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Language:list.html.twig", 1);
        $this->blocks = array(
            'choice_row' => array($this, 'block_choice_row'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5088035645f3f0762b53b962d0678e14c32a78ce9f6433e799dcd757a6481a82 = $this->env->getExtension("native_profiler");
        $__internal_5088035645f3f0762b53b962d0678e14c32a78ce9f6433e799dcd757a6481a82->enter($__internal_5088035645f3f0762b53b962d0678e14c32a78ce9f6433e799dcd757a6481a82_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Language:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5088035645f3f0762b53b962d0678e14c32a78ce9f6433e799dcd757a6481a82->leave($__internal_5088035645f3f0762b53b962d0678e14c32a78ce9f6433e799dcd757a6481a82_prof);

    }

    // line 5
    public function block_choice_row($context, array $blocks = array())
    {
        $__internal_9ae2d3f78e8ff14ad4af2cab812557ab0e070fb6ac48ab27b4ff9ded2b5af3b7 = $this->env->getExtension("native_profiler");
        $__internal_9ae2d3f78e8ff14ad4af2cab812557ab0e070fb6ac48ab27b4ff9ded2b5af3b7->enter($__internal_9ae2d3f78e8ff14ad4af2cab812557ab0e070fb6ac48ab27b4ff9ded2b5af3b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        // line 6
        echo "    ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        
        $__internal_9ae2d3f78e8ff14ad4af2cab812557ab0e070fb6ac48ab27b4ff9ded2b5af3b7->leave($__internal_9ae2d3f78e8ff14ad4af2cab812557ab0e070fb6ac48ab27b4ff9ded2b5af3b7_prof);

    }

    // line 9
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_3f37eb4c3d69061068abada063e0a1a5bc9349c841b1e75e05d82bdd10126a3c = $this->env->getExtension("native_profiler");
        $__internal_3f37eb4c3d69061068abada063e0a1a5bc9349c841b1e75e05d82bdd10126a3c->enter($__internal_3f37eb4c3d69061068abada063e0a1a5bc9349c841b1e75e05d82bdd10126a3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 10
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("language.list", array(), "language")));
        // line 14
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_3f37eb4c3d69061068abada063e0a1a5bc9349c841b1e75e05d82bdd10126a3c->leave($__internal_3f37eb4c3d69061068abada063e0a1a5bc9349c841b1e75e05d82bdd10126a3c_prof);

    }

    // line 17
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_95274383127da3d78745c121d23152c9f9bfbef3cccb06118f41d48f7e77f963 = $this->env->getExtension("native_profiler");
        $__internal_95274383127da3d78745c121d23152c9f9bfbef3cccb06118f41d48f7e77f963->enter($__internal_95274383127da3d78745c121d23152c9f9bfbef3cccb06118f41d48f7e77f963_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 18
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.list", array(), "language"), "html", null, true);
        echo "</h1>
";
        
        $__internal_95274383127da3d78745c121d23152c9f9bfbef3cccb06118f41d48f7e77f963->leave($__internal_95274383127da3d78745c121d23152c9f9bfbef3cccb06118f41d48f7e77f963_prof);

    }

    // line 21
    public function block_content($context, array $blocks = array())
    {
        $__internal_947ada0af99152bec657f7991e7d5e90153176e6511341c154ddac5f6b279183 = $this->env->getExtension("native_profiler");
        $__internal_947ada0af99152bec657f7991e7d5e90153176e6511341c154ddac5f6b279183->enter($__internal_947ada0af99152bec657f7991e7d5e90153176e6511341c154ddac5f6b279183_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 22
        echo "    <section class=\"ez-serverside-content\">
        <div class=\"ez-table-data is-flexible\">
            <div class=\"ez-table-data-container\">
                <table class=\"pure-table pure-table-striped ez-selection-table\" data-selection-buttons=\".ez-remove-language-button\">
                    <thead>
                        <tr>
                            <th>";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.name", array(), "language"), "html", null, true);
        echo "</th>
                            <th>";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.code", array(), "language"), "html", null, true);
        echo "</th>
                            <th>";
        // line 30
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.id", array(), "language"), "html", null, true);
        echo "</th>
                            <th>";
        // line 31
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.enabled", array(), "language"), "html", null, true);
        echo "</th>
                            <th colspan=\"2\"></th>
                        </tr>
                    </thead>
                    <tbody>
                    ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["languageList"]) ? $context["languageList"] : $this->getContext($context, "languageList")));
        foreach ($context['_seq'] as $context["_key"] => $context["language"]) {
            // line 37
            echo "                        <tr class=\"ez-selection-table-row\">
                            <td><a href=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_languageview", array("languageId" => $this->getAttribute($context["language"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["language"], "name", array()), "html", null, true);
            echo "</a></td>
                            <td><a href=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_languageview", array("languageId" => $this->getAttribute($context["language"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["language"], "languageCode", array()), "html", null, true);
            echo "</a></td>
                            <td class=\"ez-table-data-id\"><a href=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_languageview", array("languageId" => $this->getAttribute($context["language"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["language"], "id", array()), "html", null, true);
            echo "</a></td>
                            <td><input type=\"checkbox\" disabled ";
            // line 41
            if ($this->getAttribute($context["language"], "enabled", array())) {
                echo "checked title=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.enabled", array(), "language"), "html", null, true);
                echo "\"";
            } else {
                echo "title=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.disabled", array(), "language"), "html", null, true);
                echo "\"";
            }
            echo "></td>
                            <td>
                            ";
            // line 43
            if ((isset($context["canEdit"]) ? $context["canEdit"] : $this->getContext($context, "canEdit"))) {
                // line 44
                echo "                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_languageedit", array("languageId" => $this->getAttribute($context["language"], "id", array()))), "html", null, true);
                echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.edit", array(), "language"), "html", null, true);
                echo "</a>
                            ";
            } else {
                // line 46
                echo "                                <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.edit", array(), "language"), "html", null, true);
                echo "</span>
                            ";
            }
            // line 48
            echo "                            </td>
                            <td>
                                ";
            // line 50
            $context["deleteForm"] = $this->getAttribute((isset($context["deleteFormsByLanguageId"]) ? $context["deleteFormsByLanguageId"] : $this->getContext($context, "deleteFormsByLanguageId")), $this->getAttribute($context["language"], "id", array()), array(), "array");
            // line 51
            echo "                                ";
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_languagedelete", array("languageId" => $this->getAttribute($context["language"], "id", array()), "redirectErrorsTo" => "list"))));
            echo "
                                    ";
            // line 52
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "languageId", array()), 'widget');
            echo "
                                    ";
            // line 53
            echo             // line 54
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(            // line 55
(isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "delete", array()), 'widget', array("disabled" =>  !            // line 57
(isset($context["canEdit"]) ? $context["canEdit"] : $this->getContext($context, "canEdit")), "attr" => array("class" => "pure-button ez-button ez-remove-language-button ez-font-icon ez-button-delete")));
            // line 61
            echo "
                                ";
            // line 62
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_end');
            echo "
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['language'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 66
        echo "                    </tbody>
                </table>
                <p class=\"ez-table-data-buttons\">
                ";
        // line 69
        if ((isset($context["canEdit"]) ? $context["canEdit"] : $this->getContext($context, "canEdit"))) {
            // line 70
            echo "                    <a href=\"";
            echo $this->env->getExtension('routing')->getPath("admin_languageedit");
            echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.new", array(), "language"), "html", null, true);
            echo "</a>
                ";
        } else {
            // line 72
            echo "                    <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.new", array(), "language"), "html", null, true);
            echo "</span>
                ";
        }
        // line 74
        echo "                </p>
            </div>
        </div>
    </section>
";
        
        $__internal_947ada0af99152bec657f7991e7d5e90153176e6511341c154ddac5f6b279183->leave($__internal_947ada0af99152bec657f7991e7d5e90153176e6511341c154ddac5f6b279183_prof);

    }

    // line 80
    public function block_title($context, array $blocks = array())
    {
        $__internal_df0ca34bdee8af98c3171188abcc847e63d8928ab2866aeb77746dfa168157d6 = $this->env->getExtension("native_profiler");
        $__internal_df0ca34bdee8af98c3171188abcc847e63d8928ab2866aeb77746dfa168157d6->enter($__internal_df0ca34bdee8af98c3171188abcc847e63d8928ab2866aeb77746dfa168157d6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.list", array(), "language"), "html", null, true);
        
        $__internal_df0ca34bdee8af98c3171188abcc847e63d8928ab2866aeb77746dfa168157d6->leave($__internal_df0ca34bdee8af98c3171188abcc847e63d8928ab2866aeb77746dfa168157d6_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Language:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  242 => 80,  231 => 74,  225 => 72,  217 => 70,  215 => 69,  210 => 66,  200 => 62,  197 => 61,  195 => 57,  194 => 55,  193 => 54,  192 => 53,  188 => 52,  183 => 51,  181 => 50,  177 => 48,  171 => 46,  163 => 44,  161 => 43,  148 => 41,  142 => 40,  136 => 39,  130 => 38,  127 => 37,  123 => 36,  115 => 31,  111 => 30,  107 => 29,  103 => 28,  95 => 22,  89 => 21,  79 => 18,  73 => 17,  63 => 14,  60 => 10,  54 => 9,  44 => 6,  38 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "language" %}*/
/* */
/* {% block choice_row %}*/
/*     {{ form_widget(form) }}*/
/* {% endblock choice_row %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: '', label: 'language.list'|trans({}, 'language')}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'language.list'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <div class="ez-table-data is-flexible">*/
/*             <div class="ez-table-data-container">*/
/*                 <table class="pure-table pure-table-striped ez-selection-table" data-selection-buttons=".ez-remove-language-button">*/
/*                     <thead>*/
/*                         <tr>*/
/*                             <th>{{ 'language.name'|trans }}</th>*/
/*                             <th>{{ 'language.code'|trans }}</th>*/
/*                             <th>{{ 'language.id'|trans }}</th>*/
/*                             <th>{{ 'language.enabled'|trans }}</th>*/
/*                             <th colspan="2"></th>*/
/*                         </tr>*/
/*                     </thead>*/
/*                     <tbody>*/
/*                     {% for language in languageList %}*/
/*                         <tr class="ez-selection-table-row">*/
/*                             <td><a href="{{ path( 'admin_languageview', {'languageId': language.id} ) }}">{{ language.name }}</a></td>*/
/*                             <td><a href="{{ path( 'admin_languageview', {'languageId': language.id} ) }}">{{ language.languageCode }}</a></td>*/
/*                             <td class="ez-table-data-id"><a href="{{ path( "admin_languageview", {"languageId": language.id} ) }}">{{ language.id }}</a></td>*/
/*                             <td><input type="checkbox" disabled {% if language.enabled %}checked title="{{ 'language.enabled'|trans }}"{% else %}title="{{ 'language.disabled'|trans }}"{% endif %}></td>*/
/*                             <td>*/
/*                             {% if canEdit %}*/
/*                                 <a href="{{ path('admin_languageedit', {'languageId': language.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'language.edit'|trans }}</a>*/
/*                             {% else %}*/
/*                                 <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'language.edit'|trans }}</span>*/
/*                             {% endif %}*/
/*                             </td>*/
/*                             <td>*/
/*                                 {% set deleteForm = deleteFormsByLanguageId[language.id] %}*/
/*                                 {{ form_start(deleteForm, {"action": path("admin_languagedelete", {"languageId": language.id, "redirectErrorsTo": "list"})}) }}*/
/*                                     {{ form_widget(deleteForm.languageId) }}*/
/*                                     {{*/
/*                                         form_widget(*/
/*                                             deleteForm.delete,*/
/*                                             {*/
/*                                                 "disabled": not canEdit,*/
/*                                                 "attr": {"class": "pure-button ez-button ez-remove-language-button ez-font-icon ez-button-delete"}*/
/*                                             }*/
/*                                         )*/
/*                                     }}*/
/*                                 {{ form_end(deleteForm) }}*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*                     </tbody>*/
/*                 </table>*/
/*                 <p class="ez-table-data-buttons">*/
/*                 {% if canEdit %}*/
/*                     <a href="{{ path('admin_languageedit') }}" class="pure-button ez-button" data-icon="&#xe616;">{{ 'language.new'|trans }}</a>*/
/*                 {% else %}*/
/*                     <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe616;">{{ 'language.new'|trans }}</span>*/
/*                 {% endif %}*/
/*                 </p>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'language.list'|trans }}{% endblock %}*/
/* */
