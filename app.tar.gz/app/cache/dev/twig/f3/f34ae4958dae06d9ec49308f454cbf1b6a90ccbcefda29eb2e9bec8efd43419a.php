<?php

/* @Framework/Form/checkbox_widget.html.php */
class __TwigTemplate_1695bd80b367d3377160b43684255a65c9177aa90a876ad3920ee1c8ed0700db extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0fb4c97fd4eb50684e56063202e5c0e1e7563a33cfdddaefac91a13ba34e4bd6 = $this->env->getExtension("native_profiler");
        $__internal_0fb4c97fd4eb50684e56063202e5c0e1e7563a33cfdddaefac91a13ba34e4bd6->enter($__internal_0fb4c97fd4eb50684e56063202e5c0e1e7563a33cfdddaefac91a13ba34e4bd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/checkbox_widget.html.php"));

        // line 1
        echo "<input type=\"checkbox\"
    <?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
    <?php if (strlen(\$value) > 0): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?>
    <?php if (\$checked): ?> checked=\"checked\"<?php endif ?>
/>
";
        
        $__internal_0fb4c97fd4eb50684e56063202e5c0e1e7563a33cfdddaefac91a13ba34e4bd6->leave($__internal_0fb4c97fd4eb50684e56063202e5c0e1e7563a33cfdddaefac91a13ba34e4bd6_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/checkbox_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="checkbox"*/
/*     <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/*     <?php if (strlen($value) > 0): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?>*/
/*     <?php if ($checked): ?> checked="checked"<?php endif ?>*/
/* />*/
/* */
