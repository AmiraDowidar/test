<?php

/* EzPublishCoreBundle:FieldType/RichText/embed:content_inline.html.twig */
class __TwigTemplate_e7e1cfb675edf922658aa9a115910f49817534a876cfe02f8f9a217e0a173f3c extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6f3cfabf712340e2aba1382a707247e60ee76d190294da3f2ae4e2e2e5bc7771 = $this->env->getExtension("native_profiler");
        $__internal_6f3cfabf712340e2aba1382a707247e60ee76d190294da3f2ae4e2e2e5bc7771->enter($__internal_6f3cfabf712340e2aba1382a707247e60ee76d190294da3f2ae4e2e2e5bc7771_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:FieldType/RichText/embed:content_inline.html.twig"));

        // line 1
        $context["params"] = array("objectParameters" => array());
        // line 2
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "config", array(), "any", true, true)) {
            // line 3
            echo "    ";
            $context["params"] = twig_array_merge((isset($context["params"]) ? $context["params"] : $this->getContext($context, "params")), array("objectParameters" => $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "config", array())));
        }
        // line 5
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "link", array(), "any", true, true)) {
            // line 6
            echo "    ";
            $context["params"] = twig_array_merge((isset($context["params"]) ? $context["params"] : $this->getContext($context, "params")), array("linkParameters" => $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "link", array())));
        }
        // line 8
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("ez_content:viewAction", array("contentId" => $this->getAttribute(        // line 13
(isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "id", array()), "viewType" => $this->getAttribute(        // line 14
(isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "viewType", array()), "params" =>         // line 15
(isset($context["params"]) ? $context["params"] : $this->getContext($context, "params")))));
        // line 19
        echo "
";
        
        $__internal_6f3cfabf712340e2aba1382a707247e60ee76d190294da3f2ae4e2e2e5bc7771->leave($__internal_6f3cfabf712340e2aba1382a707247e60ee76d190294da3f2ae4e2e2e5bc7771_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/embed:content_inline.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  41 => 19,  39 => 15,  38 => 14,  37 => 13,  36 => 8,  32 => 6,  30 => 5,  26 => 3,  24 => 2,  22 => 1,);
    }
}
/* {% set params = { "objectParameters": {} } %}*/
/* {% if embedParams.config is defined  %}*/
/*     {% set params = params|merge( { "objectParameters": embedParams.config } ) %}*/
/* {% endif %}*/
/* {% if embedParams.link is defined  %}*/
/*     {% set params = params|merge( { "linkParameters": embedParams.link } ) %}*/
/* {% endif %}*/
/* {{*/
/*     render(*/
/*         controller(*/
/*             "ez_content:viewAction",*/
/*             {*/
/*                 "contentId": embedParams.id,*/
/*                 "viewType": embedParams.viewType,*/
/*                 "params": params*/
/*             }*/
/*         )*/
/*     )*/
/* }}*/
/* */
