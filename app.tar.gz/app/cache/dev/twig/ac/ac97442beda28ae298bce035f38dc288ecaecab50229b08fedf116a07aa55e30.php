<?php

/* @Framework/Form/form_rest.html.php */
class __TwigTemplate_e064a7e360368be259ce014ad795efa47e42e3e1ee220728cae256b910a0dae9 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6704403127cee8e7bb8ac7866f2b9d07d74840b22eef722aeb8bacdd3e7567ff = $this->env->getExtension("native_profiler");
        $__internal_6704403127cee8e7bb8ac7866f2b9d07d74840b22eef722aeb8bacdd3e7567ff->enter($__internal_6704403127cee8e7bb8ac7866f2b9d07d74840b22eef722aeb8bacdd3e7567ff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_rest.html.php"));

        // line 1
        echo "<?php foreach (\$form as \$child): ?>
    <?php if (!\$child->isRendered()): ?>
        <?php echo \$view['form']->row(\$child) ?>
    <?php endif; ?>
<?php endforeach; ?>
";
        
        $__internal_6704403127cee8e7bb8ac7866f2b9d07d74840b22eef722aeb8bacdd3e7567ff->leave($__internal_6704403127cee8e7bb8ac7866f2b9d07d74840b22eef722aeb8bacdd3e7567ff_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_rest.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php foreach ($form as $child): ?>*/
/*     <?php if (!$child->isRendered()): ?>*/
/*         <?php echo $view['form']->row($child) ?>*/
/*     <?php endif; ?>*/
/* <?php endforeach; ?>*/
/* */
