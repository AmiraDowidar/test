<?php

/* eZPlatformUIBundle:Role:update_role.html.twig */
class __TwigTemplate_2a2eb5d12f82a25fd830ec003923e8cea34a39792a035f4ce19ae96ce69a4c1e extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Role:update_role.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'notification' => array($this, 'block_notification'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_22ff65838edf905689b94ca956eda98684730114e3842fba4d12d7b445827d0c = $this->env->getExtension("native_profiler");
        $__internal_22ff65838edf905689b94ca956eda98684730114e3842fba4d12d7b445827d0c->enter($__internal_22ff65838edf905689b94ca956eda98684730114e3842fba4d12d7b445827d0c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Role:update_role.html.twig"));

        // line 7
        $context["edit_title"] = $this->env->getExtension('translator')->trans("role.edit_title", array("%roleName%" => $this->env->getExtension('translator')->trans((isset($context["role_name"]) ? $context["role_name"] : $this->getContext($context, "role_name")), array(), "role")), "role");
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_22ff65838edf905689b94ca956eda98684730114e3842fba4d12d7b445827d0c->leave($__internal_22ff65838edf905689b94ca956eda98684730114e3842fba4d12d7b445827d0c_prof);

    }

    // line 9
    public function block_title($context, array $blocks = array())
    {
        $__internal_9c522a9b69d79534f6934270e7644fda5e5c7e00cbe4993110f17310c056ba93 = $this->env->getExtension("native_profiler");
        $__internal_9c522a9b69d79534f6934270e7644fda5e5c7e00cbe4993110f17310c056ba93->enter($__internal_9c522a9b69d79534f6934270e7644fda5e5c7e00cbe4993110f17310c056ba93_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, (isset($context["edit_title"]) ? $context["edit_title"] : $this->getContext($context, "edit_title")), "html", null, true);
        
        $__internal_9c522a9b69d79534f6934270e7644fda5e5c7e00cbe4993110f17310c056ba93->leave($__internal_9c522a9b69d79534f6934270e7644fda5e5c7e00cbe4993110f17310c056ba93_prof);

    }

    // line 11
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_14bb3f873d5da64d10a7695e112e15f5931b531ad79b5c5485693e75a61e3aa2 = $this->env->getExtension("native_profiler");
        $__internal_14bb3f873d5da64d10a7695e112e15f5931b531ad79b5c5485693e75a61e3aa2->enter($__internal_14bb3f873d5da64d10a7695e112e15f5931b531ad79b5c5485693e75a61e3aa2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 12
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_role"), "label" => $this->env->getExtension('translator')->trans("role.dashboard_title", array(), "role")), 2 => array("link" => null, "label" =>         // line 15
(isset($context["edit_title"]) ? $context["edit_title"] : $this->getContext($context, "edit_title"))));
        // line 17
        echo "
    ";
        // line 18
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_14bb3f873d5da64d10a7695e112e15f5931b531ad79b5c5485693e75a61e3aa2->leave($__internal_14bb3f873d5da64d10a7695e112e15f5931b531ad79b5c5485693e75a61e3aa2_prof);

    }

    // line 21
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_c46dd05b6be677d2714da51fcdd894f4eec2ae05bfce4077f921d32446b99c60 = $this->env->getExtension("native_profiler");
        $__internal_c46dd05b6be677d2714da51fcdd894f4eec2ae05bfce4077f921d32446b99c60->enter($__internal_c46dd05b6be677d2714da51fcdd894f4eec2ae05bfce4077f921d32446b99c60_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 22
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe62d;\">";
        echo twig_escape_filter($this->env, (isset($context["edit_title"]) ? $context["edit_title"] : $this->getContext($context, "edit_title")), "html", null, true);
        echo "</h1>
";
        
        $__internal_c46dd05b6be677d2714da51fcdd894f4eec2ae05bfce4077f921d32446b99c60->leave($__internal_c46dd05b6be677d2714da51fcdd894f4eec2ae05bfce4077f921d32446b99c60_prof);

    }

    // line 25
    public function block_content($context, array $blocks = array())
    {
        $__internal_e44baf01f7a3207f669b357b7a9044ef7b0ceae8be5affe7ca9abb660e107295 = $this->env->getExtension("native_profiler");
        $__internal_e44baf01f7a3207f669b357b7a9044ef7b0ceae8be5affe7ca9abb660e107295->enter($__internal_e44baf01f7a3207f669b357b7a9044ef7b0ceae8be5affe7ca9abb660e107295_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 26
        echo "    <section class=\"ez-serverside-content\">
        ";
        // line 27
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("action" => (isset($context["action_url"]) ? $context["action_url"] : $this->getContext($context, "action_url")), "attr" => array("class" => "pure-form pure-form-aligned")));
        echo "
            ";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "

            <fieldset>
                <div class=\"pure-control-group\">
                    ";
        // line 32
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "identifier", array()), 'label');
        echo "
                    ";
        // line 33
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "identifier", array()), 'errors');
        echo "
                    ";
        // line 34
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "identifier", array()), 'widget');
        echo "
                </div>
            </fieldset>

            <div class=\"pure-controls\">
                ";
        // line 39
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "removeDraft", array()), 'widget', array("attr" => array("class" => "pure-button ez-button", "formnovalidate" => "formnovalidate")));
        echo "
                ";
        // line 40
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "saveRole", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
            </div>

        ";
        // line 43
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </section>
";
        
        $__internal_e44baf01f7a3207f669b357b7a9044ef7b0ceae8be5affe7ca9abb660e107295->leave($__internal_e44baf01f7a3207f669b357b7a9044ef7b0ceae8be5affe7ca9abb660e107295_prof);

    }

    // line 47
    public function block_notification($context, array $blocks = array())
    {
        $__internal_5d2587640da1d5b9eb17d5a0abf1223ca6641beb6e4e8a36bc88cdc35cf1cd0a = $this->env->getExtension("native_profiler");
        $__internal_5d2587640da1d5b9eb17d5a0abf1223ca6641beb6e4e8a36bc88cdc35cf1cd0a->enter($__internal_5d2587640da1d5b9eb17d5a0abf1223ca6641beb6e4e8a36bc88cdc35cf1cd0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "notification"));

        // line 48
        echo "    ";
        if (twig_length_filter($this->env, (isset($context["hasErrors"]) ? $context["hasErrors"] : $this->getContext($context, "hasErrors")))) {
            // line 49
            echo "        <li data-state=\"error\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("form.validation_error", array(), "general"), "html", null, true);
            echo "</li>
    ";
        }
        // line 51
        echo "    ";
        $this->displayParentBlock("notification", $context, $blocks);
        echo "
";
        
        $__internal_5d2587640da1d5b9eb17d5a0abf1223ca6641beb6e4e8a36bc88cdc35cf1cd0a->leave($__internal_5d2587640da1d5b9eb17d5a0abf1223ca6641beb6e4e8a36bc88cdc35cf1cd0a_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Role:update_role.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  162 => 51,  156 => 49,  153 => 48,  147 => 47,  137 => 43,  131 => 40,  127 => 39,  119 => 34,  115 => 33,  111 => 32,  104 => 28,  100 => 27,  97 => 26,  91 => 25,  81 => 22,  75 => 21,  66 => 18,  63 => 17,  61 => 15,  59 => 12,  53 => 11,  41 => 9,  34 => 1,  32 => 7,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* {# @var role_draft \eZ\Publish\API\Repository\Values\User\RoleDraft #}*/
/* {# @var role_name string #}*/
/* */
/* {% trans_default_domain "role" %}*/
/* */
/* {% set edit_title = "role.edit_title"|trans({"%roleName%": role_name|trans}) %}*/
/* */
/* {% block title %}{{ edit_title }}{% endblock %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path("admin_dashboard"), label: "dashboard.title"|trans({}, "dashboard")},*/
/*         {link: path("admin_role"), label: "role.dashboard_title"|trans({}, "role")},*/
/*         {link: null, label: edit_title}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe62d;">{{ edit_title }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         {{ form_start(form, {"action": action_url, "attr": {"class": "pure-form pure-form-aligned"}}) }}*/
/*             {{ form_errors(form) }}*/
/* */
/*             <fieldset>*/
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.identifier) }}*/
/*                     {{ form_errors(form.identifier) }}*/
/*                     {{ form_widget(form.identifier) }}*/
/*                 </div>*/
/*             </fieldset>*/
/* */
/*             <div class="pure-controls">*/
/*                 {{ form_widget(form.removeDraft, {"attr": {"class": "pure-button ez-button", "formnovalidate": "formnovalidate"}}) }}*/
/*                 {{ form_widget(form.saveRole, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*             </div>*/
/* */
/*         {{ form_end(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block notification %}*/
/*     {% if hasErrors|length %}*/
/*         <li data-state="error">{{ "form.validation_error"|trans(domain="general") }}</li>*/
/*     {% endif %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
