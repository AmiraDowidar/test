<?php

/* @Framework/Form/reset_widget.html.php */
class __TwigTemplate_3888241ca1de232029d227f9f4fcad95eb8bef986d4ab3415d3b3eb8a4644100 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cd4006d98a0755443b3228434c022ec0733274e896728ed9348c7185f65015fd = $this->env->getExtension("native_profiler");
        $__internal_cd4006d98a0755443b3228434c022ec0733274e896728ed9348c7185f65015fd->enter($__internal_cd4006d98a0755443b3228434c022ec0733274e896728ed9348c7185f65015fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/reset_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'reset')) ?>
";
        
        $__internal_cd4006d98a0755443b3228434c022ec0733274e896728ed9348c7185f65015fd->leave($__internal_cd4006d98a0755443b3228434c022ec0733274e896728ed9348c7185f65015fd_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/reset_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'reset')) ?>*/
/* */
