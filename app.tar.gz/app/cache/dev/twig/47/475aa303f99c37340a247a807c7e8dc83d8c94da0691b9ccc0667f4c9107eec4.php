<?php

/* @Framework/Form/container_attributes.html.php */
class __TwigTemplate_4333a6354efc2600ae6d875b3e6dc196075c7b418ecc356ffbb4f46f1cd2f0f1 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_20d0d10bdb9f06d0e9f1f3d5fe8e31a075fdbf9fe0da3b713ad05210a91ce545 = $this->env->getExtension("native_profiler");
        $__internal_20d0d10bdb9f06d0e9f1f3d5fe8e31a075fdbf9fe0da3b713ad05210a91ce545->enter($__internal_20d0d10bdb9f06d0e9f1f3d5fe8e31a075fdbf9fe0da3b713ad05210a91ce545_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/container_attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>
";
        
        $__internal_20d0d10bdb9f06d0e9f1f3d5fe8e31a075fdbf9fe0da3b713ad05210a91ce545->leave($__internal_20d0d10bdb9f06d0e9f1f3d5fe8e31a075fdbf9fe0da3b713ad05210a91ce545_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/container_attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_container_attributes') ?>*/
/* */
