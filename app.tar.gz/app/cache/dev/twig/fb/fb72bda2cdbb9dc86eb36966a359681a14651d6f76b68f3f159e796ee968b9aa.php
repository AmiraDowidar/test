<?php

/* eZPlatformUIBundle:ez-support-tools/info:composer.html.twig */
class __TwigTemplate_4ea74bc9bd6f7bc0d3cbbed1bd2205de502e0b56c1c85efae52d0a12d2ecf3c3 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b8373b7ba5225847df6f643551100f827d6a8852f1ea1592e044c2802e6c28b4 = $this->env->getExtension("native_profiler");
        $__internal_b8373b7ba5225847df6f643551100f827d6a8852f1ea1592e044c2802e6c28b4->enter($__internal_b8373b7ba5225847df6f643551100f827d6a8852f1ea1592e044c2802e6c28b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:ez-support-tools/info:composer.html.twig"));

        // line 2
        echo "
<h1>";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("composer", array(), "systeminfo"), "html", null, true);
        echo "</h1>
<dl>
    <dt>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("composer.minimum_stability", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "minimumStability", array()), "html", null, true);
        echo "</dd>

    ";
        // line 8
        if (twig_test_empty($this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "packages", array()))) {
            // line 9
            echo "        <dt>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("packages", array(), "systeminfo"), "html", null, true);
            echo "</dt>
        <dd>";
            // line 10
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("packages.empty", array(), "systeminfo"), "html", null, true);
            echo "</dd>
    ";
        }
        // line 12
        echo "</dl>

";
        // line 14
        if ( !twig_test_empty($this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "packages", array()))) {
            // line 15
            echo "    <h2>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("packages", array(), "systeminfo"), "html", null, true);
            echo "</h2>
    <dl>
        ";
            // line 17
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "packages", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["package"]) {
                // line 18
                echo "            ";
                if (twig_test_empty($this->getAttribute($context["package"], "homepage", array()))) {
                    // line 19
                    echo "                <dt>";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["package"], "name", array()), "html", null, true);
                    echo "</dt>
            ";
                } else {
                    // line 21
                    echo "                <dt><a href=\"";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["package"], "homepage", array()), "html", null, true);
                    echo "\" target=\"_blank\">";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["package"], "name", array()), "html", null, true);
                    echo "</a></dt>
            ";
                }
                // line 23
                echo "            <dd>";
                echo twig_escape_filter($this->env, $this->getAttribute($context["package"], "version", array()), "html", null, true);
                echo " ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["package"], "stability", array()), "html", null, true);
                echo " <span>(";
                echo twig_escape_filter($this->env, twig_localized_date_filter($this->env, $this->getAttribute($context["package"], "dateTime", array()), "short", "short", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array())), "html", null, true);
                echo ", ";
                echo twig_escape_filter($this->env, twig_slice($this->env, $this->getAttribute($context["package"], "reference", array()), 0, 5), "html", null, true);
                echo ")</span></dd>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['package'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 25
            echo "    </dl>
";
        }
        
        $__internal_b8373b7ba5225847df6f643551100f827d6a8852f1ea1592e044c2802e6c28b4->leave($__internal_b8373b7ba5225847df6f643551100f827d6a8852f1ea1592e044c2802e6c28b4_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ez-support-tools/info:composer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 25,  84 => 23,  76 => 21,  70 => 19,  67 => 18,  63 => 17,  57 => 15,  55 => 14,  51 => 12,  46 => 10,  41 => 9,  39 => 8,  34 => 6,  30 => 5,  25 => 3,  22 => 2,);
    }
}
/* {% trans_default_domain "systeminfo" %}*/
/* */
/* <h1>{{ 'composer'|trans }}</h1>*/
/* <dl>*/
/*     <dt>{{ 'composer.minimum_stability'|trans }}</dt>*/
/*     <dd>{{ info.minimumStability }}</dd>*/
/* */
/*     {% if info.packages is empty %}*/
/*         <dt>{{ 'packages'|trans }}</dt>*/
/*         <dd>{{ 'packages.empty'|trans }}</dd>*/
/*     {% endif %}*/
/* </dl>*/
/* */
/* {% if info.packages is not empty %}*/
/*     <h2>{{ 'packages'|trans }}</h2>*/
/*     <dl>*/
/*         {% for package in info.packages %}*/
/*             {% if package.homepage is empty %}*/
/*                 <dt>{{ package.name }}</dt>*/
/*             {% else %}*/
/*                 <dt><a href="{{ package.homepage }}" target="_blank">{{ package.name }}</a></dt>*/
/*             {% endif %}*/
/*             <dd>{{ package.version }} {{ package.stability }} <span>({{ package.dateTime|localizeddate( 'short', 'short', app.request.locale )}}, {{ package.reference | slice(0, 5) }})</span></dd>*/
/*         {% endfor %}*/
/*     </dl>*/
/* {% endif %}*/
/* */
