<?php

/* eZPlatformUIBundle:Exception:error.html.twig */
class __TwigTemplate_941afa8a37c5d2922dfa5718caa6478e3768e99519bddde95d33ce5301a0ff25 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Exception:error.html.twig", 1);
        $this->blocks = array(
            'notification' => array($this, 'block_notification'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_af86e857d5a275f28a8ba7298a58ebafdc3d7b7c4b6ebd308c147a0df37a1605 = $this->env->getExtension("native_profiler");
        $__internal_af86e857d5a275f28a8ba7298a58ebafdc3d7b7c4b6ebd308c147a0df37a1605->enter($__internal_af86e857d5a275f28a8ba7298a58ebafdc3d7b7c4b6ebd308c147a0df37a1605_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Exception:error.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_af86e857d5a275f28a8ba7298a58ebafdc3d7b7c4b6ebd308c147a0df37a1605->leave($__internal_af86e857d5a275f28a8ba7298a58ebafdc3d7b7c4b6ebd308c147a0df37a1605_prof);

    }

    // line 3
    public function block_notification($context, array $blocks = array())
    {
        $__internal_7e1a73e353f3c977ef75d9d4e6de3ab8706bfbf92a66bedc5ca1e0a376fe7c4d = $this->env->getExtension("native_profiler");
        $__internal_7e1a73e353f3c977ef75d9d4e6de3ab8706bfbf92a66bedc5ca1e0a376fe7c4d->enter($__internal_7e1a73e353f3c977ef75d9d4e6de3ab8706bfbf92a66bedc5ca1e0a376fe7c4d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "notification"));

        // line 4
        echo "    <li data-state=\"error\">";
        echo $this->env->getExtension('code')->formatFileFromText(nl2br(twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true)));
        echo "</li>
";
        
        $__internal_7e1a73e353f3c977ef75d9d4e6de3ab8706bfbf92a66bedc5ca1e0a376fe7c4d->leave($__internal_7e1a73e353f3c977ef75d9d4e6de3ab8706bfbf92a66bedc5ca1e0a376fe7c4d_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Exception:error.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  40 => 4,  34 => 3,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% block notification %}*/
/*     <li data-state="error">{{ exception.message|nl2br|format_file_from_text }}</li>*/
/* {% endblock %}*/
/* */
