<?php

/* eZPlatformUIBundle::pjax_admin.html.twig */
class __TwigTemplate_990fc6b033e60d7887ba89154c4910a7f5082c536a4f6420134a3dd42ffb25e7 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'notification' => array($this, 'block_notification'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_567d852bb850b1028499ac45f811ec8e350042cfd875eba00221c274cb229c13 = $this->env->getExtension("native_profiler");
        $__internal_567d852bb850b1028499ac45f811ec8e350042cfd875eba00221c274cb229c13->enter($__internal_567d852bb850b1028499ac45f811ec8e350042cfd875eba00221c274cb229c13_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle::pjax_admin.html.twig"));

        // line 13
        echo "
<div data-name=\"title\">";
        // line 14
        $this->displayBlock('title', $context, $blocks);
        echo "</div>

<div data-name=\"html\">
    <header class=\"ez-page-header\">
        ";
        // line 18
        $this->displayBlock('header_breadcrumbs', $context, $blocks);
        // line 23
        echo "
        ";
        // line 24
        $this->displayBlock('header_title', $context, $blocks);
        // line 25
        echo "    </header>
    ";
        // line 26
        $this->displayBlock('content', $context, $blocks);
        // line 27
        echo "</div>

<ul data-name=\"notification\">
";
        // line 30
        $this->displayBlock('notification', $context, $blocks);
        // line 37
        echo "</ul>
";
        
        $__internal_567d852bb850b1028499ac45f811ec8e350042cfd875eba00221c274cb229c13->leave($__internal_567d852bb850b1028499ac45f811ec8e350042cfd875eba00221c274cb229c13_prof);

    }

    // line 14
    public function block_title($context, array $blocks = array())
    {
        $__internal_d8e3eb4f0923fbda0f02eceec0b254fd81e0214af5c133a2fe60140be75ef982 = $this->env->getExtension("native_profiler");
        $__internal_d8e3eb4f0923fbda0f02eceec0b254fd81e0214af5c133a2fe60140be75ef982->enter($__internal_d8e3eb4f0923fbda0f02eceec0b254fd81e0214af5c133a2fe60140be75ef982_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_d8e3eb4f0923fbda0f02eceec0b254fd81e0214af5c133a2fe60140be75ef982->leave($__internal_d8e3eb4f0923fbda0f02eceec0b254fd81e0214af5c133a2fe60140be75ef982_prof);

    }

    // line 18
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_9e8d75d2656da9b0ac55684eafdbff32f39411401c2a2f6c2fd2573adce3851f = $this->env->getExtension("native_profiler");
        $__internal_9e8d75d2656da9b0ac55684eafdbff32f39411401c2a2f6c2fd2573adce3851f->enter($__internal_9e8d75d2656da9b0ac55684eafdbff32f39411401c2a2f6c2fd2573adce3851f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 19
        echo "            ";
        if (array_key_exists("breadcrumb_items", $context)) {
            // line 20
            echo "                ";
            $this->loadTemplate("eZPlatformUIBundle:components:breadcrumbs.html.twig", "eZPlatformUIBundle::pjax_admin.html.twig", 20)->display(array_merge($context, array("items" => (isset($context["breadcrumb_items"]) ? $context["breadcrumb_items"] : $this->getContext($context, "breadcrumb_items")))));
            // line 21
            echo "            ";
        }
        // line 22
        echo "        ";
        
        $__internal_9e8d75d2656da9b0ac55684eafdbff32f39411401c2a2f6c2fd2573adce3851f->leave($__internal_9e8d75d2656da9b0ac55684eafdbff32f39411401c2a2f6c2fd2573adce3851f_prof);

    }

    // line 24
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_0d9f07c3f74e87c7c9c13400f1be31492a05748d56000078cd9e15eb8a8a5fe8 = $this->env->getExtension("native_profiler");
        $__internal_0d9f07c3f74e87c7c9c13400f1be31492a05748d56000078cd9e15eb8a8a5fe8->enter($__internal_0d9f07c3f74e87c7c9c13400f1be31492a05748d56000078cd9e15eb8a8a5fe8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        echo " ";
        
        $__internal_0d9f07c3f74e87c7c9c13400f1be31492a05748d56000078cd9e15eb8a8a5fe8->leave($__internal_0d9f07c3f74e87c7c9c13400f1be31492a05748d56000078cd9e15eb8a8a5fe8_prof);

    }

    // line 26
    public function block_content($context, array $blocks = array())
    {
        $__internal_3f604e237f467c06a7800b0898a9c5d9c362869fcea818d93bafd877f7ae2cd0 = $this->env->getExtension("native_profiler");
        $__internal_3f604e237f467c06a7800b0898a9c5d9c362869fcea818d93bafd877f7ae2cd0->enter($__internal_3f604e237f467c06a7800b0898a9c5d9c362869fcea818d93bafd877f7ae2cd0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_3f604e237f467c06a7800b0898a9c5d9c362869fcea818d93bafd877f7ae2cd0->leave($__internal_3f604e237f467c06a7800b0898a9c5d9c362869fcea818d93bafd877f7ae2cd0_prof);

    }

    // line 30
    public function block_notification($context, array $blocks = array())
    {
        $__internal_85122026c95b5d22ef6c5da0efd7140ea555c29d3153900fff79544a010454bc = $this->env->getExtension("native_profiler");
        $__internal_85122026c95b5d22ef6c5da0efd7140ea555c29d3153900fff79544a010454bc->enter($__internal_85122026c95b5d22ef6c5da0efd7140ea555c29d3153900fff79544a010454bc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "notification"));

        // line 31
        echo "    ";
        $context["notifications"] = $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashBag", array()), "get", array(0 => "notification"), "method");
        // line 32
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["notifications"]) ? $context["notifications"] : $this->getContext($context, "notifications")));
        foreach ($context['_seq'] as $context["_key"] => $context["notification"]) {
            // line 33
            echo "        <li data-state=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["notification"], "state", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["notification"], "message", array()), "html", null, true);
            echo "</li>

    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['notification'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_85122026c95b5d22ef6c5da0efd7140ea555c29d3153900fff79544a010454bc->leave($__internal_85122026c95b5d22ef6c5da0efd7140ea555c29d3153900fff79544a010454bc_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  134 => 33,  129 => 32,  126 => 31,  120 => 30,  109 => 26,  97 => 24,  90 => 22,  87 => 21,  84 => 20,  81 => 19,  75 => 18,  64 => 14,  56 => 37,  54 => 30,  49 => 27,  47 => 26,  44 => 25,  42 => 24,  39 => 23,  37 => 18,  30 => 14,  27 => 13,);
    }
}
/* {#*/
/*  # Generates an HTML like document to be used by the eZ.ServerSideViewService*/
/*  # JavaScript component*/
/*  #*/
/*  # This is an "extended" version of pjax.html.twig adding the header that is used in admin pages*/
/*  #*/
/*  # Template extending this one should implement four blocks:*/
/*  #   * title: to generate what will be used as the title of the web page*/
/*  #   * header_breadcrums*/
/*  #   * header_title*/
/*  #   * content: to generate the HTML code to put in the page*/
/*  #}*/
/* */
/* <div data-name="title">{% block title %}{% endblock %}</div>*/
/* */
/* <div data-name="html">*/
/*     <header class="ez-page-header">*/
/*         {% block header_breadcrumbs %}*/
/*             {% if breadcrumb_items is defined %}*/
/*                 {% include 'eZPlatformUIBundle:components:breadcrumbs.html.twig' with {'items': breadcrumb_items} %}*/
/*             {% endif %}*/
/*         {% endblock %}*/
/* */
/*         {% block header_title %} {% endblock %}*/
/*     </header>*/
/*     {% block content %}{% endblock %}*/
/* </div>*/
/* */
/* <ul data-name="notification">*/
/* {% block notification %}*/
/*     {% set notifications = app.session.flashBag.get("notification") %}*/
/*     {% for notification in notifications %}*/
/*         <li data-state="{{ notification.state }}">{{ notification.message }}</li>*/
/* */
/*     {% endfor %}*/
/* {% endblock %}*/
/* </ul>*/
/* */
