<?php

/* eZPlatformUIBundle:Exception:exception_full.html.twig */
class __TwigTemplate_746589d4b7fc4af7dd775f9978000f619704d200dcf54ace3d59ab16be08b4c0 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
            'notification' => array($this, 'block_notification'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e8cf22ca6eb42d89d046a32cdd87b4ca029a608279f12bf57b6e36f3de2a0d55 = $this->env->getExtension("native_profiler");
        $__internal_e8cf22ca6eb42d89d046a32cdd87b4ca029a608279f12bf57b6e36f3de2a0d55->enter($__internal_e8cf22ca6eb42d89d046a32cdd87b4ca029a608279f12bf57b6e36f3de2a0d55_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Exception:exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e8cf22ca6eb42d89d046a32cdd87b4ca029a608279f12bf57b6e36f3de2a0d55->leave($__internal_e8cf22ca6eb42d89d046a32cdd87b4ca029a608279f12bf57b6e36f3de2a0d55_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_397214c138bb664401bd33e2da0ce486305302bebd714ba7bd51f548edec01a5 = $this->env->getExtension("native_profiler");
        $__internal_397214c138bb664401bd33e2da0ce486305302bebd714ba7bd51f548edec01a5->enter($__internal_397214c138bb664401bd33e2da0ce486305302bebd714ba7bd51f548edec01a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <div class=\"sf-reset\">
        ";
        // line 5
        echo twig_include($this->env, $context, "TwigBundle:Exception:exception.html.twig");
        echo "
    </div>

    <style type=\"text/css\">
        @import url('";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/structure.css")), "html", null, true);
        echo "');
        @import url('";
        // line 10
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/body.css")), "html", null, true);
        echo "');
        @import url('";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "');
    </style>
";
        
        $__internal_397214c138bb664401bd33e2da0ce486305302bebd714ba7bd51f548edec01a5->leave($__internal_397214c138bb664401bd33e2da0ce486305302bebd714ba7bd51f548edec01a5_prof);

    }

    // line 15
    public function block_notification($context, array $blocks = array())
    {
        $__internal_1753da9ef8d14334779cddbf8a9a658778d3ba05a37a090e205a12efb4cac805 = $this->env->getExtension("native_profiler");
        $__internal_1753da9ef8d14334779cddbf8a9a658778d3ba05a37a090e205a12efb4cac805->enter($__internal_1753da9ef8d14334779cddbf8a9a658778d3ba05a37a090e205a12efb4cac805_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "notification"));

        // line 16
        echo "    <li data-state=\"error\">";
        echo $this->env->getExtension('code')->formatFileFromText(nl2br(twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true)));
        echo "</li>
";
        
        $__internal_1753da9ef8d14334779cddbf8a9a658778d3ba05a37a090e205a12efb4cac805->leave($__internal_1753da9ef8d14334779cddbf8a9a658778d3ba05a37a090e205a12efb4cac805_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  75 => 16,  69 => 15,  59 => 11,  55 => 10,  51 => 9,  44 => 5,  41 => 4,  35 => 3,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% block content %}*/
/*     <div class="sf-reset">*/
/*         {{ include("TwigBundle:Exception:exception.html.twig") }}*/
/*     </div>*/
/* */
/*     <style type="text/css">*/
/*         @import url('{{ absolute_url(asset('bundles/framework/css/structure.css')) }}');*/
/*         @import url('{{ absolute_url(asset('bundles/framework/css/body.css')) }}');*/
/*         @import url('{{ absolute_url(asset('bundles/framework/css/exception.css')) }}');*/
/*     </style>*/
/* {% endblock %}*/
/* */
/* {% block notification %}*/
/*     <li data-state="error">{{ exception.message|nl2br|format_file_from_text }}</li>*/
/* {% endblock %}*/
/* */
