<?php

/* @Framework/FormTable/button_row.html.php */
class __TwigTemplate_a0d23790572bb587f4f4e6490dd614d28c3c1e3349ec6e7a756b9b2311f14f00 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3f8c86ea7ee4878a10c917b80e854b98fb43188090b59cae45a5d6847e33c7fa = $this->env->getExtension("native_profiler");
        $__internal_3f8c86ea7ee4878a10c917b80e854b98fb43188090b59cae45a5d6847e33c7fa->enter($__internal_3f8c86ea7ee4878a10c917b80e854b98fb43188090b59cae45a5d6847e33c7fa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/button_row.html.php"));

        // line 1
        echo "<tr>
    <td></td>
    <td>
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_3f8c86ea7ee4878a10c917b80e854b98fb43188090b59cae45a5d6847e33c7fa->leave($__internal_3f8c86ea7ee4878a10c917b80e854b98fb43188090b59cae45a5d6847e33c7fa_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr>*/
/*     <td></td>*/
/*     <td>*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
