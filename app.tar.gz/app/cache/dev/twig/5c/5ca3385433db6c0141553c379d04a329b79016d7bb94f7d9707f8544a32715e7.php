<?php

/* TwigBundle:Exception:exception.rdf.twig */
class __TwigTemplate_e0687402d1e5a88fa0f41a6f29ab3a33582b91e48392cbd3d6747744171fc88f extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3eb034c4c6f7ea279fd7a0253f0edd32c36fccb48c2632f4a33f923da9737f7e = $this->env->getExtension("native_profiler");
        $__internal_3eb034c4c6f7ea279fd7a0253f0edd32c36fccb48c2632f4a33f923da9737f7e->enter($__internal_3eb034c4c6f7ea279fd7a0253f0edd32c36fccb48c2632f4a33f923da9737f7e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.rdf.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.rdf.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_3eb034c4c6f7ea279fd7a0253f0edd32c36fccb48c2632f4a33f923da9737f7e->leave($__internal_3eb034c4c6f7ea279fd7a0253f0edd32c36fccb48c2632f4a33f923da9737f7e_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.rdf.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
