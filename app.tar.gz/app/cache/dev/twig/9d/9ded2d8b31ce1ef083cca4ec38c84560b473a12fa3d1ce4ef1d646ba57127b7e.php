<?php

/* ::pagelayout_footer.html.twig */
class __TwigTemplate_039f03d45e7f8f3c6f2a84ffb7838ff58da0c77f78333ebbafa9a5b631a8f03a extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8c67704ced2cb6977cdebfc0b1bef0e6d2f7c45027a361b13f15790a6b6a3046 = $this->env->getExtension("native_profiler");
        $__internal_8c67704ced2cb6977cdebfc0b1bef0e6d2f7c45027a361b13f15790a6b6a3046->enter($__internal_8c67704ced2cb6977cdebfc0b1bef0e6d2f7c45027a361b13f15790a6b6a3046_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::pagelayout_footer.html.twig"));

        // line 1
        echo "<footer class=\"global-footer\">
    <div class=\"container\">
      <div class=\"identity\">
        <a href=\"#\" class=\"logo\">
          <img src=\"";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/white_logo.svg"), "html", null, true);
        echo "\" alt=\"\" />
        </a>
        <div class=\"social pull-right hidden-xs\">
          <a href=\"https://twitter.com/Libon\">
            <img src=\"";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/twitter_icon.svg"), "html", null, true);
        echo "\">
          </a>
          <a href=\"https://www.facebook.com/libon.fan\">
            <img src=\"";
        // line 12
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/facebook_icon.svg"), "html", null, true);
        echo "\">
          </a>
        </div>
      </div>
      <ul>
        <li class=\"hidden-xs\">
          <h4>About Libon</h4>
          <ul>
            <li>
              <a href=\"#\">
                Who are we?
              </a>
            </li>
            <li>
              <a href=\"#\">
                Press reviews
              </a>
            </li>
            <li>
              <a href=\"#\">
                Press releases
              </a>
            </li>
          </ul>
        </li>
        <li class=\"hidden-xs\">
          <h4>International calls</h4>
          <ul>
            <li>
              <a href=\"#\">
                Cheap calls to France
              </a>
            </li>
            <li>
              <a href=\"#\">
                Cheap calls to Senegal
              </a>
            </li>
            <li>
              <a href=\"#\">
                Cheap calls to Mali
              </a>
            </li>
            <li>
              <a href=\"#\">
                Cheap calls to Portugal
              </a>
            </li>
            <li>
              <a href=\"#\">
                All destinations
              </a>
            </li>
          </ul>
        </li>
        <li class=\"hidden-xs\">
          <h4>Community</h4>
          <ul>
            <li>
              <a href=\"#\">
                Blog
              </a>
            </li>
            <li>
              <a href=\"#\">
                FAQ
              </a>
            </li>
            <li>
              <a href=\"#\">
                Support
              </a>
            </li>
            <li>
              <a href=\"#\">
                Contact us
              </a>
            </li>
          </ul>
        </li>
        <li class=\"visible-xs\">
          <h4>
            About Libon
            <i class=\"icon-arrow_down\"></i>
          </h4>
          <ul>
            <li>
              <a href=\"#\">
                Who are we?
              </a>
            </li>
            <li>
              <a href=\"#\">
                Press reviews
              </a>
            </li>
            <li>
              <a href=\"#\">
                Press releases
              </a>
            </li>
          </ul>
        </li>
        <li class=\"visible-xs\">
          <h4>
            International calls
            <i class=\"icon-arrow_down\"></i>
          </h4>
          <ul>
            <li>
              <a href=\"#\">
                Cheap calls to France
              </a>
            </li>
            <li>
              <a href=\"#\">
                Cheap calls to Senegal
              </a>
            </li>
            <li>
              <a href=\"#\">
                Cheap calls to Mali
              </a>
            </li>
            <li>
              <a href=\"#\">
                Cheap calls to Portugal
              </a>
            </li>
            <li>
              <a href=\"#\">
                All destinations
              </a>
            </li>
          </ul>
        </li>
        <li class=\"visible-xs\">
          <h4>
            Community
            <i class=\"icon-arrow_down\"></i>
          </h4>
          <ul ng-show=\"footermenu1\">
            <li>
              <a href=\"#\">
                Blog
              </a>
            </li>
            <li>
              <a href=\"#\">
                FAQ
              </a>
            </li>
            <li>
              <a href=\"#\">
                Support
              </a>
            </li>
            <li>
              <a href=\"Contact-Us\">
                Contact us
              </a>
            </li>
          </ul>
        </li>
      </ul>
      <div class=\"social pull-right visible-xs\">
        <a href=\"https://twitter.com/Libon\">
          <img src=\"";
        // line 179
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/twitter_icon.svg"), "html", null, true);
        echo "\">
        </a>
        <a href=\"https://www.facebook.com/libon.fan\">
          <img src=\"";
        // line 182
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/facebook_icon.svg"), "html", null, true);
        echo "\">
        </a>
      </div>
    </div>
   </footer>
   <footer class=\"second-footer\">
     <div class=\"container\">
      <div class=\"text-center\">
        <ul>
          <li>
            <a href=\"#\">
              Terms and conditions
            </a>
          </li>
          <li>
            <a href=\"#\">
              Privacy
            </a>
          </li>
          <li>
            &copy; ";
        // line 202
        echo twig_escape_filter($this->env, twig_date_format_filter($this->env, "now", "Y"), "html", null, true);
        echo " Libon
          </li>
        </ul>
      </div>
     </div>
   </footer>
  <a class=\"to-top\">
  </a>";
        
        $__internal_8c67704ced2cb6977cdebfc0b1bef0e6d2f7c45027a361b13f15790a6b6a3046->leave($__internal_8c67704ced2cb6977cdebfc0b1bef0e6d2f7c45027a361b13f15790a6b6a3046_prof);

    }

    public function getTemplateName()
    {
        return "::pagelayout_footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  240 => 202,  217 => 182,  211 => 179,  41 => 12,  35 => 9,  28 => 5,  22 => 1,);
    }
}
/* <footer class="global-footer">*/
/*     <div class="container">*/
/*       <div class="identity">*/
/*         <a href="#" class="logo">*/
/*           <img src="{{ asset('assets/images/white_logo.svg') }}" alt="" />*/
/*         </a>*/
/*         <div class="social pull-right hidden-xs">*/
/*           <a href="https://twitter.com/Libon">*/
/*             <img src="{{ asset('assets/images/twitter_icon.svg') }}">*/
/*           </a>*/
/*           <a href="https://www.facebook.com/libon.fan">*/
/*             <img src="{{ asset('assets/images/facebook_icon.svg') }}">*/
/*           </a>*/
/*         </div>*/
/*       </div>*/
/*       <ul>*/
/*         <li class="hidden-xs">*/
/*           <h4>About Libon</h4>*/
/*           <ul>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Who are we?*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Press reviews*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Press releases*/
/*               </a>*/
/*             </li>*/
/*           </ul>*/
/*         </li>*/
/*         <li class="hidden-xs">*/
/*           <h4>International calls</h4>*/
/*           <ul>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Cheap calls to France*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Cheap calls to Senegal*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Cheap calls to Mali*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Cheap calls to Portugal*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 All destinations*/
/*               </a>*/
/*             </li>*/
/*           </ul>*/
/*         </li>*/
/*         <li class="hidden-xs">*/
/*           <h4>Community</h4>*/
/*           <ul>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Blog*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 FAQ*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Support*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Contact us*/
/*               </a>*/
/*             </li>*/
/*           </ul>*/
/*         </li>*/
/*         <li class="visible-xs">*/
/*           <h4>*/
/*             About Libon*/
/*             <i class="icon-arrow_down"></i>*/
/*           </h4>*/
/*           <ul>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Who are we?*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Press reviews*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Press releases*/
/*               </a>*/
/*             </li>*/
/*           </ul>*/
/*         </li>*/
/*         <li class="visible-xs">*/
/*           <h4>*/
/*             International calls*/
/*             <i class="icon-arrow_down"></i>*/
/*           </h4>*/
/*           <ul>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Cheap calls to France*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Cheap calls to Senegal*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Cheap calls to Mali*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Cheap calls to Portugal*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 All destinations*/
/*               </a>*/
/*             </li>*/
/*           </ul>*/
/*         </li>*/
/*         <li class="visible-xs">*/
/*           <h4>*/
/*             Community*/
/*             <i class="icon-arrow_down"></i>*/
/*           </h4>*/
/*           <ul ng-show="footermenu1">*/
/*             <li>*/
/*               <a href="#">*/
/*                 Blog*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 FAQ*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 Support*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="Contact-Us">*/
/*                 Contact us*/
/*               </a>*/
/*             </li>*/
/*           </ul>*/
/*         </li>*/
/*       </ul>*/
/*       <div class="social pull-right visible-xs">*/
/*         <a href="https://twitter.com/Libon">*/
/*           <img src="{{ asset('assets/images/twitter_icon.svg') }}">*/
/*         </a>*/
/*         <a href="https://www.facebook.com/libon.fan">*/
/*           <img src="{{ asset('assets/images/facebook_icon.svg') }}">*/
/*         </a>*/
/*       </div>*/
/*     </div>*/
/*    </footer>*/
/*    <footer class="second-footer">*/
/*      <div class="container">*/
/*       <div class="text-center">*/
/*         <ul>*/
/*           <li>*/
/*             <a href="#">*/
/*               Terms and conditions*/
/*             </a>*/
/*           </li>*/
/*           <li>*/
/*             <a href="#">*/
/*               Privacy*/
/*             </a>*/
/*           </li>*/
/*           <li>*/
/*             &copy; {{ "now"|date("Y") }} Libon*/
/*           </li>*/
/*         </ul>*/
/*       </div>*/
/*      </div>*/
/*    </footer>*/
/*   <a class="to-top">*/
/*   </a>*/
