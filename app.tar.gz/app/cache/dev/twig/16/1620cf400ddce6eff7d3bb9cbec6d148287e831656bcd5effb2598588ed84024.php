<?php

/* eZPlatformUIBundle:Section:list.html.twig */
class __TwigTemplate_c62f76c6e8a07b27d837db29583309a4e704158f9ee1839fdca62c6070812ec6 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Section:list.html.twig", 1);
        $this->blocks = array(
            'choice_widget' => array($this, 'block_choice_widget'),
            'choice_row' => array($this, 'block_choice_row'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_090458fabcbce89aa422f6a70ed17d66900dbf34f78addbdb15373f97e349655 = $this->env->getExtension("native_profiler");
        $__internal_090458fabcbce89aa422f6a70ed17d66900dbf34f78addbdb15373f97e349655->enter($__internal_090458fabcbce89aa422f6a70ed17d66900dbf34f78addbdb15373f97e349655_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Section:list.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_090458fabcbce89aa422f6a70ed17d66900dbf34f78addbdb15373f97e349655->leave($__internal_090458fabcbce89aa422f6a70ed17d66900dbf34f78addbdb15373f97e349655_prof);

    }

    // line 5
    public function block_choice_widget($context, array $blocks = array())
    {
        $__internal_96a8d3a0e5c8be9e292637d2b91d6fe79f62116095d7957ea5f3c17f1d43f44e = $this->env->getExtension("native_profiler");
        $__internal_96a8d3a0e5c8be9e292637d2b91d6fe79f62116095d7957ea5f3c17f1d43f44e->enter($__internal_96a8d3a0e5c8be9e292637d2b91d6fe79f62116095d7957ea5f3c17f1d43f44e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_widget"));

        // line 6
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 7
            echo "        ";
            $context["section"] = $this->getAttribute($this->getAttribute($context["child"], "vars", array()), "label", array());
            // line 8
            echo "
        <tr class=\"ez-selection-table-row\">
            <td>
                ";
            // line 11
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["child"], 'widget', array("disabled" =>  !$this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "canDelete", array()), "attr" => array("class" => "ez-selection-table-checkbox")));
            echo "
            </td>
            <td><a href=\"";
            // line 13
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "name", array()), "html", null, true);
            echo "</a></td>
            <td><a href=\"";
            // line 14
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "identifier", array()), "html", null, true);
            echo "</a></td>
            <td class=\"ez-table-data-id\"><a href=\"";
            // line 15
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id", array()), "html", null, true);
            echo "</a></td>
            <td class=\"ez-table-data-count\">";
            // line 16
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "contentCount", array()), "html", null, true);
            echo "</td>
            <td>
                <button
                    data-universaldiscovery-title=\"";
            // line 19
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assign.universaldiscovery.title", array("%sectionName%" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "name", array())), "section"), "html_attr");
            echo "\"
                    data-section-rest-id=\"";
            // line 20
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadSection", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id", array()))), "html", null, true);
            echo "\"
                    data-section-name=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "name", array()), "html", null, true);
            echo "\"
                    class=\"ez-section-assign-button ez-button-tree pure-button ez-font-icon ez-button\"
                    ";
            // line 23
            if ( !$this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "canAssign", array())) {
                echo "disabled=\"disabled\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assign.contents", array(), "section"), "html", null, true);
            echo "</button>
            </td>
            <td>
                <a href=\"";
            // line 26
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionedit", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id", array()))), "html", null, true);
            echo "\" class=\"pure-button ez-button";
            if ( !$this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "canEdit", array())) {
                echo " pure-button-disabled";
            }
            echo "\" data-icon=\"&#xe606;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.edit", array(), "section"), "html", null, true);
            echo "</a>
            </td>
        </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_96a8d3a0e5c8be9e292637d2b91d6fe79f62116095d7957ea5f3c17f1d43f44e->leave($__internal_96a8d3a0e5c8be9e292637d2b91d6fe79f62116095d7957ea5f3c17f1d43f44e_prof);

    }

    // line 32
    public function block_choice_row($context, array $blocks = array())
    {
        $__internal_d7c3e06378534de45211f46b2b21d9dc31396604aa058905c25b33f249e73b79 = $this->env->getExtension("native_profiler");
        $__internal_d7c3e06378534de45211f46b2b21d9dc31396604aa058905c25b33f249e73b79->enter($__internal_d7c3e06378534de45211f46b2b21d9dc31396604aa058905c25b33f249e73b79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "choice_row"));

        // line 33
        echo "    ";
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
        echo "
";
        
        $__internal_d7c3e06378534de45211f46b2b21d9dc31396604aa058905c25b33f249e73b79->leave($__internal_d7c3e06378534de45211f46b2b21d9dc31396604aa058905c25b33f249e73b79_prof);

    }

    // line 36
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_c6dd35086d161ee77cfdd2b4d1659848200c41a497f6270270a2f99f47f6c145 = $this->env->getExtension("native_profiler");
        $__internal_c6dd35086d161ee77cfdd2b4d1659848200c41a497f6270270a2f99f47f6c145->enter($__internal_c6dd35086d161ee77cfdd2b4d1659848200c41a497f6270270a2f99f47f6c145_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 37
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("section.list", array(), "section")));
        // line 41
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_c6dd35086d161ee77cfdd2b4d1659848200c41a497f6270270a2f99f47f6c145->leave($__internal_c6dd35086d161ee77cfdd2b4d1659848200c41a497f6270270a2f99f47f6c145_prof);

    }

    // line 44
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_1b61a61406013ae7fd14da721d44ca2b0c2d94c6b9c93b21cde299bf329ad7e2 = $this->env->getExtension("native_profiler");
        $__internal_1b61a61406013ae7fd14da721d44ca2b0c2d94c6b9c93b21cde299bf329ad7e2->enter($__internal_1b61a61406013ae7fd14da721d44ca2b0c2d94c6b9c93b21cde299bf329ad7e2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 45
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.list", array(), "section"), "html", null, true);
        echo "</h1>
";
        
        $__internal_1b61a61406013ae7fd14da721d44ca2b0c2d94c6b9c93b21cde299bf329ad7e2->leave($__internal_1b61a61406013ae7fd14da721d44ca2b0c2d94c6b9c93b21cde299bf329ad7e2_prof);

    }

    // line 48
    public function block_content($context, array $blocks = array())
    {
        $__internal_303268f3f25833332e038c6f49b0dd02f3cf40ab79969ec7f545bb1dca865aac = $this->env->getExtension("native_profiler");
        $__internal_303268f3f25833332e038c6f49b0dd02f3cf40ab79969ec7f545bb1dca865aac->enter($__internal_303268f3f25833332e038c6f49b0dd02f3cf40ab79969ec7f545bb1dca865aac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 49
        echo "    <section class=\"ez-serverside-content\">
        <div class=\"ez-table-data is-flexible\">
            <div class=\"ez-table-data-container\">
                <table class=\"pure-table pure-table-striped ez-selection-table\" data-selection-buttons=\".ez-remove-section-button\">
                    <thead>
                        <tr>
                            <th>";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.name", array(), "section"), "html", null, true);
        echo "</th>
                            <th>";
        // line 56
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.identifier", array(), "section"), "html", null, true);
        echo "</th>
                            <th>";
        // line 57
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.id", array(), "section"), "html", null, true);
        echo "</th>
                            <th>";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assigned.content", array(), "section"), "html", null, true);
        echo "</th>
                            <th colspan=\"3\"></th>
                        </tr>
                    </thead>
                    <tbody>
                    ";
        // line 63
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["sectionList"]) ? $context["sectionList"] : $this->getContext($context, "sectionList")));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 64
            echo "                        <tr class=\"ez-selection-table-row\">
                            <td><a href=\"";
            // line 65
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "name", array()), "html", null, true);
            echo "</a></td>
                            <td><a href=\"";
            // line 66
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "identifier", array()), "html", null, true);
            echo "</a></td>
                            <td class=\"ez-table-data-id\"><a href=\"";
            // line 67
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionview", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "id", array()), "html", null, true);
            echo "</a></td>
                            <td class=\"ez-table-data-count\">";
            // line 68
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["contentCountBySectionId"]) ? $context["contentCountBySectionId"] : $this->getContext($context, "contentCountBySectionId")), $this->getAttribute($context["section"], "id", array()), array(), "array"), "html", null, true);
            echo "</td>
                            <td>
                                <button
                                    data-universaldiscovery-title=\"";
            // line 71
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assign.universaldiscovery.title", array("%sectionName%" => $this->getAttribute($context["section"], "name", array())), "section"), "html_attr");
            echo "\"
                                    data-section-rest-id=\"";
            // line 72
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadSection", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
            echo "\"
                                    data-section-name=\"";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($context["section"], "name", array()), "html", null, true);
            echo "\"
                                    class=\"ez-section-assign-button ez-button-tree pure-button ez-font-icon ez-button\"
                                    ";
            // line 75
            if ( !(isset($context["canAssign"]) ? $context["canAssign"] : $this->getContext($context, "canAssign"))) {
                echo "disabled=\"disabled\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assign.contents", array(), "section"), "html", null, true);
            echo "</button>
                            </td>
                            <td>
                            ";
            // line 78
            if ((isset($context["canEdit"]) ? $context["canEdit"] : $this->getContext($context, "canEdit"))) {
                // line 79
                echo "                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionedit", array("sectionId" => $this->getAttribute($context["section"], "id", array()))), "html", null, true);
                echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.edit", array(), "section"), "html", null, true);
                echo "</a>
                            ";
            } else {
                // line 81
                echo "                                <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.edit", array(), "section"), "html", null, true);
                echo "</span>
                            ";
            }
            // line 83
            echo "                            </td>
                            <td>
                                ";
            // line 85
            $context["deleteForm"] = $this->getAttribute((isset($context["deleteFormsBySectionId"]) ? $context["deleteFormsBySectionId"] : $this->getContext($context, "deleteFormsBySectionId")), $this->getAttribute($context["section"], "id", array()), array(), "array");
            // line 86
            echo "                                ";
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_sectiondelete", array("sectionId" => $this->getAttribute($context["section"], "id", array()), "redirectErrorsTo" => "list"))));
            echo "
                                    ";
            // line 87
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "sectionId", array()), 'widget');
            echo "
                                    ";
            // line 88
            echo             // line 89
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(            // line 90
(isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "delete", array()), 'widget', array("disabled" =>  !$this->getAttribute(            // line 92
(isset($context["deletableSections"]) ? $context["deletableSections"] : null), $this->getAttribute($context["section"], "id", array()), array(), "array", true, true), "attr" => array("class" => "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete")));
            // line 96
            echo "
                                ";
            // line 97
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_end');
            echo "
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['section'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 101
        echo "                    </tbody>
                </table>
                <p class=\"ez-table-data-buttons\">
                ";
        // line 104
        if ((isset($context["canEdit"]) ? $context["canEdit"] : $this->getContext($context, "canEdit"))) {
            // line 105
            echo "                    <a href=\"";
            echo $this->env->getExtension('routing')->getPath("admin_sectionedit");
            echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.new", array(), "section"), "html", null, true);
            echo "</a>
                ";
        } else {
            // line 107
            echo "                    <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.new", array(), "section"), "html", null, true);
            echo "</span>
                ";
        }
        // line 109
        echo "                </p>
            </div>
        </div>
    </section>
";
        
        $__internal_303268f3f25833332e038c6f49b0dd02f3cf40ab79969ec7f545bb1dca865aac->leave($__internal_303268f3f25833332e038c6f49b0dd02f3cf40ab79969ec7f545bb1dca865aac_prof);

    }

    // line 115
    public function block_title($context, array $blocks = array())
    {
        $__internal_e14975605ac15d7b41cd1ff4160f63e100603796af99187753d9f483e8c94487 = $this->env->getExtension("native_profiler");
        $__internal_e14975605ac15d7b41cd1ff4160f63e100603796af99187753d9f483e8c94487->enter($__internal_e14975605ac15d7b41cd1ff4160f63e100603796af99187753d9f483e8c94487_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.list", array(), "section"), "html", null, true);
        
        $__internal_e14975605ac15d7b41cd1ff4160f63e100603796af99187753d9f483e8c94487->leave($__internal_e14975605ac15d7b41cd1ff4160f63e100603796af99187753d9f483e8c94487_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Section:list.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  351 => 115,  340 => 109,  334 => 107,  326 => 105,  324 => 104,  319 => 101,  309 => 97,  306 => 96,  304 => 92,  303 => 90,  302 => 89,  301 => 88,  297 => 87,  292 => 86,  290 => 85,  286 => 83,  280 => 81,  272 => 79,  270 => 78,  260 => 75,  255 => 73,  251 => 72,  247 => 71,  241 => 68,  235 => 67,  229 => 66,  223 => 65,  220 => 64,  216 => 63,  208 => 58,  204 => 57,  200 => 56,  196 => 55,  188 => 49,  182 => 48,  172 => 45,  166 => 44,  156 => 41,  153 => 37,  147 => 36,  137 => 33,  131 => 32,  110 => 26,  100 => 23,  95 => 21,  91 => 20,  87 => 19,  81 => 16,  75 => 15,  69 => 14,  63 => 13,  58 => 11,  53 => 8,  50 => 7,  45 => 6,  39 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "section" %}*/
/* */
/* {% block choice_widget %}*/
/*     {% for child in form %}*/
/*         {% set section = child.vars.label %}*/
/* */
/*         <tr class="ez-selection-table-row">*/
/*             <td>*/
/*                 {{ form_widget(child, {'disabled': not section.canDelete, 'attr': {'class': 'ez-selection-table-checkbox'} }) }}*/
/*             </td>*/
/*             <td><a href="{{ path( 'admin_sectionview', {'sectionId': section.id} ) }}">{{ section.name }}</a></td>*/
/*             <td><a href="{{ path( 'admin_sectionview', {'sectionId': section.id} ) }}">{{ section.identifier }}</a></td>*/
/*             <td class="ez-table-data-id"><a href="{{ path( "admin_sectionview", {"sectionId": section.id} ) }}">{{ section.id }}</a></td>*/
/*             <td class="ez-table-data-count">{{ section.contentCount }}</td>*/
/*             <td>*/
/*                 <button*/
/*                     data-universaldiscovery-title="{{ 'section.assign.universaldiscovery.title'|trans({'%sectionName%': section.name })|e('html_attr') }}"*/
/*                     data-section-rest-id="{{path( 'ezpublish_rest_loadSection', {'sectionId': section.id}) }}"*/
/*                     data-section-name="{{ section.name }}"*/
/*                     class="ez-section-assign-button ez-button-tree pure-button ez-font-icon ez-button"*/
/*                     {% if not section.canAssign %}disabled="disabled"{% endif %}>{{ 'section.assign.contents'|trans }}</button>*/
/*             </td>*/
/*             <td>*/
/*                 <a href="{{ path('admin_sectionedit', {'sectionId': section.id}) }}" class="pure-button ez-button{% if not section.canEdit %} pure-button-disabled{% endif %}" data-icon="&#xe606;">{{ 'section.edit'|trans }}</a>*/
/*             </td>*/
/*         </tr>*/
/*     {% endfor %}*/
/* {% endblock choice_widget  %}*/
/* */
/* {% block choice_row %}*/
/*     {{ form_widget(form) }}*/
/* {% endblock choice_row %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: '', label: 'section.list'|trans({}, 'section')}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'section.list'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <div class="ez-table-data is-flexible">*/
/*             <div class="ez-table-data-container">*/
/*                 <table class="pure-table pure-table-striped ez-selection-table" data-selection-buttons=".ez-remove-section-button">*/
/*                     <thead>*/
/*                         <tr>*/
/*                             <th>{{ 'section.name'|trans }}</th>*/
/*                             <th>{{ 'section.identifier'|trans }}</th>*/
/*                             <th>{{ 'section.id'|trans }}</th>*/
/*                             <th>{{ 'section.assigned.content'|trans }}</th>*/
/*                             <th colspan="3"></th>*/
/*                         </tr>*/
/*                     </thead>*/
/*                     <tbody>*/
/*                     {% for section in sectionList %}*/
/*                         <tr class="ez-selection-table-row">*/
/*                             <td><a href="{{ path( 'admin_sectionview', {'sectionId': section.id} ) }}">{{ section.name }}</a></td>*/
/*                             <td><a href="{{ path( 'admin_sectionview', {'sectionId': section.id} ) }}">{{ section.identifier }}</a></td>*/
/*                             <td class="ez-table-data-id"><a href="{{ path( "admin_sectionview", {"sectionId": section.id} ) }}">{{ section.id }}</a></td>*/
/*                             <td class="ez-table-data-count">{{ contentCountBySectionId[section.id] }}</td>*/
/*                             <td>*/
/*                                 <button*/
/*                                     data-universaldiscovery-title="{{ 'section.assign.universaldiscovery.title'|trans({'%sectionName%': section.name })|e('html_attr') }}"*/
/*                                     data-section-rest-id="{{ path( 'ezpublish_rest_loadSection', {'sectionId': section.id}) }}"*/
/*                                     data-section-name="{{ section.name }}"*/
/*                                     class="ez-section-assign-button ez-button-tree pure-button ez-font-icon ez-button"*/
/*                                     {% if not canAssign %}disabled="disabled"{% endif %}>{{ 'section.assign.contents'|trans }}</button>*/
/*                             </td>*/
/*                             <td>*/
/*                             {% if canEdit %}*/
/*                                 <a href="{{ path('admin_sectionedit', {'sectionId': section.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'section.edit'|trans }}</a>*/
/*                             {% else %}*/
/*                                 <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'section.edit'|trans }}</span>*/
/*                             {% endif %}*/
/*                             </td>*/
/*                             <td>*/
/*                                 {% set deleteForm = deleteFormsBySectionId[section.id] %}*/
/*                                 {{ form_start(deleteForm, {"action": path("admin_sectiondelete", {"sectionId": section.id, "redirectErrorsTo": "list"})}) }}*/
/*                                     {{ form_widget(deleteForm.sectionId) }}*/
/*                                     {{*/
/*                                         form_widget(*/
/*                                             deleteForm.delete,*/
/*                                             {*/
/*                                                 "disabled": deletableSections[section.id] is not defined,*/
/*                                                 "attr": {"class": "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete"}*/
/*                                             }*/
/*                                         )*/
/*                                     }}*/
/*                                 {{ form_end(deleteForm) }}*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*                     </tbody>*/
/*                 </table>*/
/*                 <p class="ez-table-data-buttons">*/
/*                 {% if canEdit %}*/
/*                     <a href="{{ path('admin_sectionedit') }}" class="pure-button ez-button" data-icon="&#xe616;">{{ 'section.new'|trans }}</a>*/
/*                 {% else %}*/
/*                     <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe616;">{{ 'section.new'|trans }}</span>*/
/*                 {% endif %}*/
/*                 </p>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'section.list'|trans }}{% endblock %}*/
/* */
