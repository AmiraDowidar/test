<?php

/* eZPlatformUIBundle:components:breadcrumbs.html.twig */
class __TwigTemplate_8f61b76e8232d6ebb941c3d59a5736a3089ae434aae8d4abe656760b262c100e extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d300dcfaaa8c413d054eaa7d285b4ca6104ea152402d4464f4752e1e7dd79934 = $this->env->getExtension("native_profiler");
        $__internal_d300dcfaaa8c413d054eaa7d285b4ca6104ea152402d4464f4752e1e7dd79934->enter($__internal_d300dcfaaa8c413d054eaa7d285b4ca6104ea152402d4464f4752e1e7dd79934_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:components:breadcrumbs.html.twig"));

        // line 6
        echo "<nav class=\"ez-breadcrumbs\">
    <ul class=\"ez-breadcrumbs-list\">
        ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["items"]) ? $context["items"] : $this->getContext($context, "items")));
        foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
            // line 9
            echo "            <li class=\"ez-breadcrumbs-item\">
                ";
            // line 10
            if ( !twig_test_empty($this->getAttribute($context["item"], "link", array()))) {
                // line 11
                echo "                    <a href=\"";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "link", array()), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "label", array()), "html", null, true);
                echo "</a>
                ";
            } else {
                // line 13
                echo "                    ";
                echo twig_escape_filter($this->env, $this->getAttribute($context["item"], "label", array()), "html", null, true);
                echo "
                ";
            }
            // line 15
            echo "            </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 17
        echo "    </ul>
</nav>

";
        
        $__internal_d300dcfaaa8c413d054eaa7d285b4ca6104ea152402d4464f4752e1e7dd79934->leave($__internal_d300dcfaaa8c413d054eaa7d285b4ca6104ea152402d4464f4752e1e7dd79934_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:components:breadcrumbs.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 17,  49 => 15,  43 => 13,  35 => 11,  33 => 10,  30 => 9,  26 => 8,  22 => 6,);
    }
}
/* {#*/
/*  # Template dispalying the breadcrumbs.*/
/*  # Parameter :*/
/*  # - items: an array of hashes with a "link" and a "label" for each item.*/
/* #}*/
/* <nav class="ez-breadcrumbs">*/
/*     <ul class="ez-breadcrumbs-list">*/
/*         {% for item in items %}*/
/*             <li class="ez-breadcrumbs-item">*/
/*                 {% if item.link is not empty %}*/
/*                     <a href="{{ item.link }}">{{ item.label }}</a>*/
/*                 {% else %}*/
/*                     {{ item.label }}*/
/*                 {% endif %}*/
/*             </li>*/
/*         {% endfor %}*/
/*     </ul>*/
/* </nav>*/
/* */
/* */
