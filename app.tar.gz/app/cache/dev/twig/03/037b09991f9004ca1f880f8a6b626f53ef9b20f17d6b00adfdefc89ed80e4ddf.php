<?php

/* EzPublishCoreBundle:FieldType/RichText/tag:default.html.twig */
class __TwigTemplate_e12c34ff83d7f792e5df4f97a0fe0d88dab2984b8ff0a4b49f9a4425accff587 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0f768d86431db53f15c2fb00311162544823a8d16bcb04dfff25009b4e408441 = $this->env->getExtension("native_profiler");
        $__internal_0f768d86431db53f15c2fb00311162544823a8d16bcb04dfff25009b4e408441->enter($__internal_0f768d86431db53f15c2fb00311162544823a8d16bcb04dfff25009b4e408441_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:FieldType/RichText/tag:default.html.twig"));

        // line 1
        echo "<div class=\"";
        if (array_key_exists("align", $context)) {
            echo "align-";
            echo twig_escape_filter($this->env, (isset($context["align"]) ? $context["align"] : $this->getContext($context, "align")), "html", null, true);
        }
        echo "\">
    RichText template tag <strong>";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["name"]) ? $context["name"] : $this->getContext($context, "name")), "html", null, true);
        echo "</strong> is not configured
</div>
";
        
        $__internal_0f768d86431db53f15c2fb00311162544823a8d16bcb04dfff25009b4e408441->leave($__internal_0f768d86431db53f15c2fb00311162544823a8d16bcb04dfff25009b4e408441_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/tag:default.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 2,  22 => 1,);
    }
}
/* <div class="{% if align is defined %}align-{{ align }}{% endif %}">*/
/*     RichText template tag <strong>{{ name }}</strong> is not configured*/
/* </div>*/
/* */
