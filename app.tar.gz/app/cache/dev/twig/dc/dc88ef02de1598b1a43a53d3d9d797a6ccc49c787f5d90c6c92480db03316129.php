<?php

/* @Framework/Form/hidden_widget.html.php */
class __TwigTemplate_e910ace05def93a2015765b4c0ed646eb64b366c9dbba84ae04aadfc384e64aa extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e24b0b98df25424794934f8313618650585d7df6d38818aa68ed0ae0583617b8 = $this->env->getExtension("native_profiler");
        $__internal_e24b0b98df25424794934f8313618650585d7df6d38818aa68ed0ae0583617b8->enter($__internal_e24b0b98df25424794934f8313618650585d7df6d38818aa68ed0ae0583617b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'hidden')) ?>
";
        
        $__internal_e24b0b98df25424794934f8313618650585d7df6d38818aa68ed0ae0583617b8->leave($__internal_e24b0b98df25424794934f8313618650585d7df6d38818aa68ed0ae0583617b8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'hidden')) ?>*/
/* */
