<?php

/* @Framework/Form/button_row.html.php */
class __TwigTemplate_cfc8a9794f998170c3f0795a941a0f2c8ad93495a627b23de66841d1e39f9ce7 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_710bacc1bf7bbfb8523e295b5c22e42511469994fbed5f75e0ea31ab92d899b9 = $this->env->getExtension("native_profiler");
        $__internal_710bacc1bf7bbfb8523e295b5c22e42511469994fbed5f75e0ea31ab92d899b9->enter($__internal_710bacc1bf7bbfb8523e295b5c22e42511469994fbed5f75e0ea31ab92d899b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_710bacc1bf7bbfb8523e295b5c22e42511469994fbed5f75e0ea31ab92d899b9->leave($__internal_710bacc1bf7bbfb8523e295b5c22e42511469994fbed5f75e0ea31ab92d899b9_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
