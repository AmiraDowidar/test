<?php

/* eZPlatformUIBundle:Exception:error500.html.twig */
class __TwigTemplate_29c12893437373759e8de7421102baa4a71f8b7be87e5245d624da8352e1b4e8 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle:Exception:error.html.twig", "eZPlatformUIBundle:Exception:error500.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle:Exception:error.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e53d38d78e54e1ef0246a8818e8ae107274fd97a795be0385756745ebe45b6ee = $this->env->getExtension("native_profiler");
        $__internal_e53d38d78e54e1ef0246a8818e8ae107274fd97a795be0385756745ebe45b6ee->enter($__internal_e53d38d78e54e1ef0246a8818e8ae107274fd97a795be0385756745ebe45b6ee_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Exception:error500.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_e53d38d78e54e1ef0246a8818e8ae107274fd97a795be0385756745ebe45b6ee->leave($__internal_e53d38d78e54e1ef0246a8818e8ae107274fd97a795be0385756745ebe45b6ee_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Exception:error500.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle:Exception:error.html.twig" %}*/
/* */
