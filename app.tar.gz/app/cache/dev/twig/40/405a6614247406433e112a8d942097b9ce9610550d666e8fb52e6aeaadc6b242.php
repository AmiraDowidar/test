<?php

/* EzPublishCoreBundle:FieldType/RichText/embed:content.html.twig */
class __TwigTemplate_c82c53849db657858196e8723114e5ac433e07de5857f5dfad61ca8a21de7f89 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bb1ab3be19c781e3f85dae796b3699611c04a5675f993bb9b5b33c4b79168357 = $this->env->getExtension("native_profiler");
        $__internal_bb1ab3be19c781e3f85dae796b3699611c04a5675f993bb9b5b33c4b79168357->enter($__internal_bb1ab3be19c781e3f85dae796b3699611c04a5675f993bb9b5b33c4b79168357_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:FieldType/RichText/embed:content.html.twig"));

        // line 1
        $context["params"] = array("objectParameters" => array());
        // line 2
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "config", array(), "any", true, true)) {
            // line 3
            echo "    ";
            $context["params"] = twig_array_merge((isset($context["params"]) ? $context["params"] : $this->getContext($context, "params")), array("objectParameters" => $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "config", array())));
        }
        // line 5
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "link", array(), "any", true, true)) {
            // line 6
            echo "    ";
            $context["params"] = twig_array_merge((isset($context["params"]) ? $context["params"] : $this->getContext($context, "params")), array("linkParameters" => $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "link", array())));
        }
        // line 8
        echo "<div class=\"";
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "align", array(), "any", true, true)) {
            echo "align-";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "align", array()), "html", null, true);
        }
        if ($this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : null), "class", array(), "any", true, true)) {
            echo " ";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "class", array()), "html", null, true);
        }
        echo "\">
    ";
        // line 9
        echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("ez_content:embedContent", array("contentId" => $this->getAttribute(        // line 14
(isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "id", array()), "viewType" => $this->getAttribute(        // line 15
(isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "viewType", array()), "params" =>         // line 16
(isset($context["params"]) ? $context["params"] : $this->getContext($context, "params")))));
        // line 20
        echo "
</div>
";
        
        $__internal_bb1ab3be19c781e3f85dae796b3699611c04a5675f993bb9b5b33c4b79168357->leave($__internal_bb1ab3be19c781e3f85dae796b3699611c04a5675f993bb9b5b33c4b79168357_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/embed:content.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 20,  51 => 16,  50 => 15,  49 => 14,  48 => 9,  36 => 8,  32 => 6,  30 => 5,  26 => 3,  24 => 2,  22 => 1,);
    }
}
/* {% set params = { "objectParameters": {} } %}*/
/* {% if embedParams.config is defined  %}*/
/*     {% set params = params|merge( { "objectParameters": embedParams.config } ) %}*/
/* {% endif %}*/
/* {% if embedParams.link is defined  %}*/
/*     {% set params = params|merge( { "linkParameters": embedParams.link } ) %}*/
/* {% endif %}*/
/* <div class="{% if embedParams.align is defined %}align-{{ embedParams.align }}{% endif %}{% if embedParams.class is defined %} {{ embedParams.class }}{% endif %}">*/
/*     {{*/
/*         render(*/
/*             controller(*/
/*                 "ez_content:embedContent",*/
/*                 {*/
/*                     "contentId": embedParams.id,*/
/*                     "viewType": embedParams.viewType,*/
/*                     "params": params*/
/*                 }*/
/*             )*/
/*         )*/
/*     }}*/
/* </div>*/
/* */
