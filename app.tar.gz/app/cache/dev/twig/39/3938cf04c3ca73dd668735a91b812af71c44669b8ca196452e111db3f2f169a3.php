<?php

/* @Framework/Form/attributes.html.php */
class __TwigTemplate_19c3cef13bf175f6527de7be3997e21d5f7ec452ffc3fe4c2252a3e4fb3c1e24 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_16eed71bb7fbe6c778e29862378da37b6d4a098729ec96e01f0542034bcc3623 = $this->env->getExtension("native_profiler");
        $__internal_16eed71bb7fbe6c778e29862378da37b6d4a098729ec96e01f0542034bcc3623->enter($__internal_16eed71bb7fbe6c778e29862378da37b6d4a098729ec96e01f0542034bcc3623_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/attributes.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'widget_attributes') ?>
";
        
        $__internal_16eed71bb7fbe6c778e29862378da37b6d4a098729ec96e01f0542034bcc3623->leave($__internal_16eed71bb7fbe6c778e29862378da37b6d4a098729ec96e01f0542034bcc3623_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/attributes.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'widget_attributes') ?>*/
/* */
