<?php

/* @Framework/Form/choice_options.html.php */
class __TwigTemplate_2cb504a6dfd77285f0efa4d58d906f817f43b3e80edd1d5c14cad138d7ce7080 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b042aab86e43fd4d28fd7dc3679ec7df1c88794e679f88b8c2c12d7839f5188 = $this->env->getExtension("native_profiler");
        $__internal_6b042aab86e43fd4d28fd7dc3679ec7df1c88794e679f88b8c2c12d7839f5188->enter($__internal_6b042aab86e43fd4d28fd7dc3679ec7df1c88794e679f88b8c2c12d7839f5188_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_options.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'choice_widget_options') ?>
";
        
        $__internal_6b042aab86e43fd4d28fd7dc3679ec7df1c88794e679f88b8c2c12d7839f5188->leave($__internal_6b042aab86e43fd4d28fd7dc3679ec7df1c88794e679f88b8c2c12d7839f5188_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_options.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'choice_widget_options') ?>*/
/* */
