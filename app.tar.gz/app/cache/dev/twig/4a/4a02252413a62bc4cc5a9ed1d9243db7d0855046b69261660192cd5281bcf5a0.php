<?php

/* @Framework/Form/submit_widget.html.php */
class __TwigTemplate_77cf8b83560c4ff88d7bdc89e3940d718ad9f7046c3a0ea8437038bee18d8217 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a669259573bd73f52bf9ca7c28aa542e1352d8736776ac40b04ebe08384ec1c = $this->env->getExtension("native_profiler");
        $__internal_9a669259573bd73f52bf9ca7c28aa542e1352d8736776ac40b04ebe08384ec1c->enter($__internal_9a669259573bd73f52bf9ca7c28aa542e1352d8736776ac40b04ebe08384ec1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/submit_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'button_widget',  array('type' => isset(\$type) ? \$type : 'submit')) ?>
";
        
        $__internal_9a669259573bd73f52bf9ca7c28aa542e1352d8736776ac40b04ebe08384ec1c->leave($__internal_9a669259573bd73f52bf9ca7c28aa542e1352d8736776ac40b04ebe08384ec1c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/submit_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'button_widget',  array('type' => isset($type) ? $type : 'submit')) ?>*/
/* */
