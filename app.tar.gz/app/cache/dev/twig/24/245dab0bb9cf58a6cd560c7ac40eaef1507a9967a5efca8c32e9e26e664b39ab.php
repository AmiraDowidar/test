<?php

/* eZPlatformUIBundle:Section:view.html.twig */
class __TwigTemplate_cf668fc09f21496170e114b65d02f8a7cfd5afb78cd09f21d88f731f12fe22ee extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Section:view.html.twig", 1);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9a1ac0e2a857d1bffbc4483cc68b3c09e966ab519c7096b98fa9168de9131569 = $this->env->getExtension("native_profiler");
        $__internal_9a1ac0e2a857d1bffbc4483cc68b3c09e966ab519c7096b98fa9168de9131569->enter($__internal_9a1ac0e2a857d1bffbc4483cc68b3c09e966ab519c7096b98fa9168de9131569_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Section:view.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_9a1ac0e2a857d1bffbc4483cc68b3c09e966ab519c7096b98fa9168de9131569->leave($__internal_9a1ac0e2a857d1bffbc4483cc68b3c09e966ab519c7096b98fa9168de9131569_prof);

    }

    // line 5
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_81991b9cb9e7367c73e79f923a6ba380e731c200c8a640c5d2413f9de78731a7 = $this->env->getExtension("native_profiler");
        $__internal_81991b9cb9e7367c73e79f923a6ba380e731c200c8a640c5d2413f9de78731a7->enter($__internal_81991b9cb9e7367c73e79f923a6ba380e731c200c8a640c5d2413f9de78731a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 6
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_sectionlist"), "label" => $this->env->getExtension('translator')->trans("section.list", array(), "section")), 2 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("section.view.title", array("%sectionName%" => $this->getAttribute(        // line 9
(isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "name", array())), "section")));
        // line 11
        echo "
    ";
        // line 12
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_81991b9cb9e7367c73e79f923a6ba380e731c200c8a640c5d2413f9de78731a7->leave($__internal_81991b9cb9e7367c73e79f923a6ba380e731c200c8a640c5d2413f9de78731a7_prof);

    }

    // line 15
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_1d15afcb97754c351c60e473da630a001ec58998a1cfe06354bc0d066e6b7a75 = $this->env->getExtension("native_profiler");
        $__internal_1d15afcb97754c351c60e473da630a001ec58998a1cfe06354bc0d066e6b7a75->enter($__internal_1d15afcb97754c351c60e473da630a001ec58998a1cfe06354bc0d066e6b7a75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 16
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.view.title", array("%sectionName%" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "name", array())), "section"), "html", null, true);
        echo "</h1>
";
        
        $__internal_1d15afcb97754c351c60e473da630a001ec58998a1cfe06354bc0d066e6b7a75->leave($__internal_1d15afcb97754c351c60e473da630a001ec58998a1cfe06354bc0d066e6b7a75_prof);

    }

    // line 19
    public function block_content($context, array $blocks = array())
    {
        $__internal_ce578d83caffaa1839c55eca83e9d373c7cc4155ddbdd7ee28cba23bce4c7cc0 = $this->env->getExtension("native_profiler");
        $__internal_ce578d83caffaa1839c55eca83e9d373c7cc4155ddbdd7ee28cba23bce4c7cc0->enter($__internal_ce578d83caffaa1839c55eca83e9d373c7cc4155ddbdd7ee28cba23bce4c7cc0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 20
        echo "    <section class=\"ez-tabs ez-serverside-content\">
        <ul class=\"ez-tabs-list\">
            <li class=\"ez-tabs-label is-tab-selected\"><a href=\"#ez-tabs-section-name\">";
        // line 22
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "name", array()), "html", null, true);
        echo "</a></li>
            <li class=\"ez-tabs-label\"><a href=\"#ez-tabs-content\">";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.content.translate", array("%contentCount%" => (isset($context["contentCount"]) ? $context["contentCount"] : $this->getContext($context, "contentCount"))), "section"), "html", null, true);
        echo "</a></li>
        </ul>
        <div class=\"ez-tabs-panel is-tab-selected\" id=\"ez-tabs-section-name\">
            <ul>
                <li>
                    <strong>";
        // line 28
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.name.label", array(), "section"), "html", null, true);
        echo "</strong>
                    ";
        // line 29
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "name", array()), "html", null, true);
        echo "
                </li>
                <li>
                    <strong>";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.identifier.label", array(), "section"), "html", null, true);
        echo "</strong>
                    ";
        // line 33
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "identifier", array()), "html", null, true);
        echo "
                </li>
                <li>
                    <strong>";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.id.label", array(), "section"), "html", null, true);
        echo "</strong>
                    ";
        // line 37
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id", array()), "html", null, true);
        echo "
                </li>
            </ul>
            <p>
                ";
        // line 41
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->transchoice("section.assigned.contentcount", (isset($context["contentCount"]) ? $context["contentCount"] : $this->getContext($context, "contentCount")), array("%contentCount%" => (isset($context["contentCount"]) ? $context["contentCount"] : $this->getContext($context, "contentCount"))), "section"), "html", null, true);
        echo "
            </p>

            <div>
                ";
        // line 45
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_sectiondelete", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id", array()), "redirectErrorsTo" => "view"))));
        echo "
                ";
        // line 46
        if ((isset($context["canEdit"]) ? $context["canEdit"] : $this->getContext($context, "canEdit"))) {
            // line 47
            echo "                    <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_sectionedit", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id", array()))), "html", null, true);
            echo "\"
                       class=\"pure-button ez-button\" data-icon=\"&#xe606;\">
                        ";
            // line 49
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.edit", array(), "section"), "html", null, true);
            echo "
                    </a>
                ";
        } else {
            // line 52
            echo "                    <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">
                        ";
            // line 53
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.edit", array(), "section"), "html", null, true);
            echo "
                    </span>
                ";
        }
        // line 56
        echo "
                    ";
        // line 57
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "sectionId", array()), 'widget');
        echo "
                    ";
        // line 58
        echo         // line 59
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(        // line 60
(isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "delete", array()), 'widget', array("disabled" =>  !        // line 62
(isset($context["deletable"]) ? $context["deletable"] : $this->getContext($context, "deletable")), "attr" => array("class" => "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete")));
        // line 66
        echo "
                ";
        // line 67
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_end');
        echo "
            </div>
        </div>

        <div class=\"ez-tabs-panel\" id=\"ez-tabs-content\">
            <p>
                <button
                    data-universaldiscovery-title=\"";
        // line 74
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assign.universaldiscovery.title", array("%sectionName%" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "name", array())), "section"), "html_attr");
        echo "\"
                    data-section-rest-id=\"";
        // line 75
        echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadSection", array("sectionId" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "id", array()))), "html", null, true);
        echo "\"
                    data-section-name=\"";
        // line 76
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "name", array()), "html", null, true);
        echo "\"
                    class=\"ez-section-assign-button ez-button-tree pure-button ez-font-icon ez-button\">
                    ";
        // line 78
        if ( !(isset($context["canAssign"]) ? $context["canAssign"] : $this->getContext($context, "canAssign"))) {
            echo "disabled";
        }
        // line 79
        echo "                    ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.assign.contents", array(), "section"), "html", null, true);
        echo "
                </button>
            </p>
        </div>
    </section>
";
        
        $__internal_ce578d83caffaa1839c55eca83e9d373c7cc4155ddbdd7ee28cba23bce4c7cc0->leave($__internal_ce578d83caffaa1839c55eca83e9d373c7cc4155ddbdd7ee28cba23bce4c7cc0_prof);

    }

    // line 86
    public function block_title($context, array $blocks = array())
    {
        $__internal_556c94191a0d518c5499083893ad2e7975cd1dd332484a949e5892c5c079b8aa = $this->env->getExtension("native_profiler");
        $__internal_556c94191a0d518c5499083893ad2e7975cd1dd332484a949e5892c5c079b8aa->enter($__internal_556c94191a0d518c5499083893ad2e7975cd1dd332484a949e5892c5c079b8aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.view.title", array("%sectionName%" => $this->getAttribute((isset($context["section"]) ? $context["section"] : $this->getContext($context, "section")), "name", array())), "section"), "html", null, true);
        
        $__internal_556c94191a0d518c5499083893ad2e7975cd1dd332484a949e5892c5c079b8aa->leave($__internal_556c94191a0d518c5499083893ad2e7975cd1dd332484a949e5892c5c079b8aa_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Section:view.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  218 => 86,  204 => 79,  200 => 78,  195 => 76,  191 => 75,  187 => 74,  177 => 67,  174 => 66,  172 => 62,  171 => 60,  170 => 59,  169 => 58,  165 => 57,  162 => 56,  156 => 53,  153 => 52,  147 => 49,  141 => 47,  139 => 46,  135 => 45,  128 => 41,  121 => 37,  117 => 36,  111 => 33,  107 => 32,  101 => 29,  97 => 28,  89 => 23,  85 => 22,  81 => 20,  75 => 19,  65 => 16,  59 => 15,  50 => 12,  47 => 11,  45 => 9,  43 => 6,  37 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "section" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_sectionlist'), label: 'section.list'|trans({}, 'section')},*/
/*         {link: '', label: 'section.view.title'|trans({'%sectionName%': section.name}, 'section')}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'section.view.title'|trans({'%sectionName%': section.name}) }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-tabs ez-serverside-content">*/
/*         <ul class="ez-tabs-list">*/
/*             <li class="ez-tabs-label is-tab-selected"><a href="#ez-tabs-section-name">{{ section.name }}</a></li>*/
/*             <li class="ez-tabs-label"><a href="#ez-tabs-content">{{ 'section.content.translate'|trans({"%contentCount%": contentCount}) }}</a></li>*/
/*         </ul>*/
/*         <div class="ez-tabs-panel is-tab-selected" id="ez-tabs-section-name">*/
/*             <ul>*/
/*                 <li>*/
/*                     <strong>{{ 'section.name.label'|trans }}</strong>*/
/*                     {{ section.name }}*/
/*                 </li>*/
/*                 <li>*/
/*                     <strong>{{ 'section.identifier.label'|trans }}</strong>*/
/*                     {{ section.identifier }}*/
/*                 </li>*/
/*                 <li>*/
/*                     <strong>{{ 'section.id.label'|trans }}</strong>*/
/*                     {{ section.id }}*/
/*                 </li>*/
/*             </ul>*/
/*             <p>*/
/*                 {{ 'section.assigned.contentcount'|transchoice(contentCount, {'%contentCount%': contentCount} ) }}*/
/*             </p>*/
/* */
/*             <div>*/
/*                 {{ form_start(deleteForm, {"action": path("admin_sectiondelete", {"sectionId": section.id, "redirectErrorsTo": "view"})}) }}*/
/*                 {% if canEdit %}*/
/*                     <a href="{{ path('admin_sectionedit', {'sectionId': section.id}) }}"*/
/*                        class="pure-button ez-button" data-icon="&#xe606;">*/
/*                         {{ 'section.edit'|trans }}*/
/*                     </a>*/
/*                 {% else %}*/
/*                     <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">*/
/*                         {{ 'section.edit'|trans }}*/
/*                     </span>*/
/*                 {% endif %}*/
/* */
/*                     {{ form_widget(deleteForm.sectionId) }}*/
/*                     {{*/
/*                         form_widget(*/
/*                             deleteForm.delete,*/
/*                             {*/
/*                                 "disabled": not deletable,*/
/*                                 "attr": {"class": "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete"}*/
/*                             }*/
/*                         )*/
/*                     }}*/
/*                 {{ form_end(deleteForm) }}*/
/*             </div>*/
/*         </div>*/
/* */
/*         <div class="ez-tabs-panel" id="ez-tabs-content">*/
/*             <p>*/
/*                 <button*/
/*                     data-universaldiscovery-title="{{ 'section.assign.universaldiscovery.title'|trans({'%sectionName%': section.name })|e('html_attr') }}"*/
/*                     data-section-rest-id="{{ path( 'ezpublish_rest_loadSection', {'sectionId': section.id}) }}"*/
/*                     data-section-name="{{ section.name }}"*/
/*                     class="ez-section-assign-button ez-button-tree pure-button ez-font-icon ez-button">*/
/*                     {% if not canAssign %}disabled{% endif %}*/
/*                     {{ 'section.assign.contents'|trans }}*/
/*                 </button>*/
/*             </p>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'section.view.title'|trans({'%sectionName%': section.name}) }}{% endblock %}*/
/* */
