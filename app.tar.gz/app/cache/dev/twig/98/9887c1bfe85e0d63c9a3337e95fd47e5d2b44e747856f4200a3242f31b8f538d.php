<?php

/* eZPlatformUIBundle:ContentType:view_content_type.html.twig */
class __TwigTemplate_22634a778057101df1c7720c74161985e50b5ced6552522e3308b082bc38d8bf extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 3
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:ContentType:view_content_type.html.twig", 3);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cbd53c9d6084e75e89602d53a3cc443c260378f75b0a37abbaa2a3be64e96079 = $this->env->getExtension("native_profiler");
        $__internal_cbd53c9d6084e75e89602d53a3cc443c260378f75b0a37abbaa2a3be64e96079->enter($__internal_cbd53c9d6084e75e89602d53a3cc443c260378f75b0a37abbaa2a3be64e96079_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:ContentType:view_content_type.html.twig"));

        // line 7
        $context["content_type_group"] = twig_first($this->env, $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "contentTypeGroups", array()));
        // line 8
        $context["content_type_name"] = (($this->getAttribute($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "names", array(), "any", false, true), (isset($context["language_code"]) ? $context["language_code"] : $this->getContext($context, "language_code")), array(), "array", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "names", array(), "any", false, true), (isset($context["language_code"]) ? $context["language_code"] : $this->getContext($context, "language_code")), array(), "array"), "")) : (""));
        // line 9
        $context["content_type_description"] = (($this->getAttribute($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "descriptions", array(), "any", false, true), (isset($context["language_code"]) ? $context["language_code"] : $this->getContext($context, "language_code")), array(), "array", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : null), "descriptions", array(), "any", false, true), (isset($context["language_code"]) ? $context["language_code"] : $this->getContext($context, "language_code")), array(), "array"), "")) : (""));
        // line 3
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cbd53c9d6084e75e89602d53a3cc443c260378f75b0a37abbaa2a3be64e96079->leave($__internal_cbd53c9d6084e75e89602d53a3cc443c260378f75b0a37abbaa2a3be64e96079_prof);

    }

    // line 11
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_0a47c7c2acd63548d93a1dca20ce64b485f2b48e52e34668b8dab9a62fd6f29c = $this->env->getExtension("native_profiler");
        $__internal_0a47c7c2acd63548d93a1dca20ce64b485f2b48e52e34668b8dab9a62fd6f29c->enter($__internal_0a47c7c2acd63548d93a1dca20ce64b485f2b48e52e34668b8dab9a62fd6f29c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 12
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_contenttype"), "label" => $this->env->getExtension('translator')->trans("content_type.dashboard_title", array(), "content_type")), 2 => array("link" => $this->env->getExtension('routing')->getPath("admin_contenttypeGroupView", array("contentTypeGroupId" => $this->getAttribute(        // line 15
(isset($context["content_type_group"]) ? $context["content_type_group"] : $this->getContext($context, "content_type_group")), "id", array()))), "label" => $this->getAttribute((isset($context["content_type_group"]) ? $context["content_type_group"] : $this->getContext($context, "content_type_group")), "identifier", array())), 3 => array("link" => null, "label" =>         // line 16
(isset($context["content_type_name"]) ? $context["content_type_name"] : $this->getContext($context, "content_type_name"))));
        // line 18
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_0a47c7c2acd63548d93a1dca20ce64b485f2b48e52e34668b8dab9a62fd6f29c->leave($__internal_0a47c7c2acd63548d93a1dca20ce64b485f2b48e52e34668b8dab9a62fd6f29c_prof);

    }

    // line 21
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_1121975e3cf31dafca6529fccfdab6de0f7557c3e202117cc1703ef2a9860a30 = $this->env->getExtension("native_profiler");
        $__internal_1121975e3cf31dafca6529fccfdab6de0f7557c3e202117cc1703ef2a9860a30->enter($__internal_1121975e3cf31dafca6529fccfdab6de0f7557c3e202117cc1703ef2a9860a30_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 22
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, (isset($context["content_type_name"]) ? $context["content_type_name"] : $this->getContext($context, "content_type_name")), "html", null, true);
        echo " [";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->transchoice("content_type.content_count", (isset($context["content_count"]) ? $context["content_count"] : $this->getContext($context, "content_count")), array(), "content_type"), "html", null, true);
        echo "]</h1>
";
        
        $__internal_1121975e3cf31dafca6529fccfdab6de0f7557c3e202117cc1703ef2a9860a30->leave($__internal_1121975e3cf31dafca6529fccfdab6de0f7557c3e202117cc1703ef2a9860a30_prof);

    }

    // line 25
    public function block_content($context, array $blocks = array())
    {
        $__internal_b3a3ebdda3a18cfe3473baaef4c44661d998f33b9545deef553ce23ab2b0ac5c = $this->env->getExtension("native_profiler");
        $__internal_b3a3ebdda3a18cfe3473baaef4c44661d998f33b9545deef553ce23ab2b0ac5c->enter($__internal_b3a3ebdda3a18cfe3473baaef4c44661d998f33b9545deef553ce23ab2b0ac5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 26
        echo "    <section class=\"ez-serverside-content\">

        <p class=\"ez-technical-infos\">
            ";
        // line 29
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.last_modified", array("%date%" => twig_localized_date_filter($this->env, $this->getAttribute(        // line 31
(isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "modificationDate", array()), "medium", "medium", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array())), "%modifier%" => $this->getAttribute(        // line 32
(isset($context["modifier"]) ? $context["modifier"] : $this->getContext($context, "modifier")), "login", array())), "content_type"), "html", null, true);
        // line 34
        echo "
        </p>

        <div class=\"pure-g\">
            <div class=\"pure-u-1-2\">
                <div>
                    <h6>";
        // line 40
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.name", array(), "content_type"), "html", null, true);
        echo "</h6>
                    ";
        // line 41
        echo twig_escape_filter($this->env, (isset($context["content_type_name"]) ? $context["content_type_name"] : $this->getContext($context, "content_type_name")), "html", null, true);
        echo "
                </div>

                <div>
                    <h6>";
        // line 45
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.identifier", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 46
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "identifier", array()), "html", null, true);
        echo "
                </div>

                <div>
                    <h6>";
        // line 50
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.description", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 51
        echo twig_escape_filter($this->env, (isset($context["content_type_description"]) ? $context["content_type_description"] : $this->getContext($context, "content_type_description")), "html", null, true);
        echo "
                </div>

                <div>
                    <h6>";
        // line 55
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.name_schema", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 56
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "nameSchema", array()), "html", null, true);
        echo "
                </div>

                <div>
                    <h6>";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.url_alias_schema", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 61
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "urlAliasSchema", array()), "html", null, true);
        echo "
                </div>
            </div>

            <div class=\"pure-u-1-2\">
                <div>
                    <h6>";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.container", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    <input type=\"checkbox\" disabled";
        // line 68
        if ($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "isContainer", array())) {
            echo " checked";
        }
        echo ">
                </div>

                <div>
                    <h6>";
        // line 72
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.default_availability", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 73
        echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "defaultAlwaysAvailable", array())) ? ($this->env->getExtension('translator')->trans("content_type.always_available", array(), "content_type")) : ($this->env->getExtension('translator')->trans("content_type.no_always_available", array(), "content_type"))), "html", null, true);
        echo "
                </div>

                <div>
                    <h6>";
        // line 77
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.default_children_sorting", array(), "content_type"), "html", null, true);
        echo ":</h6>
                    ";
        // line 78
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans(("content_type.sort_field." . $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "defaultSortField", array())), array(), "ezrepoforms_content_type"), "html", null, true);
        echo " / ";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans(("content_type.sort_order." . $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "defaultSortOrder", array())), array(), "ezrepoforms_content_type"), "html", null, true);
        echo "
                </div>
            </div>

            <div class=\"pure-u-1\">
            ";
        // line 83
        if ((isset($context["can_edit"]) ? $context["can_edit"] : $this->getContext($context, "can_edit"))) {
            // line 84
            echo "                <a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_contenttypeUpdate", array("contentTypeId" => $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "id", array()))), "html", null, true);
            echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.edit", array(), "content_type"), "html", null, true);
            echo "</a>
            ";
        } else {
            // line 86
            echo "                <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.edit", array(), "content_type"), "html", null, true);
            echo "</span>
            ";
        }
        // line 88
        echo "                ";
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_contenttypeDelete", array("contentTypeId" => $this->getAttribute((isset($context["content_type"]) ? $context["content_type"] : $this->getContext($context, "content_type")), "id", array())))));
        echo "
                    ";
        // line 89
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), "contentTypeId", array()), 'widget');
        echo "
                    ";
        // line 90
        echo         // line 91
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(        // line 92
(isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), "delete", array()), 'widget', array("disabled" =>  !        // line 94
(isset($context["can_delete"]) ? $context["can_delete"] : $this->getContext($context, "can_delete")), "attr" => array("class" => "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete", "title" => (( !        // line 96
(isset($context["can_delete"]) ? $context["can_delete"] : $this->getContext($context, "can_delete"))) ? ($this->env->getExtension('translator')->trans("content_type.is_in_use", array(), "content_type")) : ("")))));
        // line 99
        echo "
                ";
        // line 100
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["delete_form"]) ? $context["delete_form"] : $this->getContext($context, "delete_form")), 'form_end');
        echo "
            </div>
        </div>
    </section>
";
        
        $__internal_b3a3ebdda3a18cfe3473baaef4c44661d998f33b9545deef553ce23ab2b0ac5c->leave($__internal_b3a3ebdda3a18cfe3473baaef4c44661d998f33b9545deef553ce23ab2b0ac5c_prof);

    }

    // line 106
    public function block_title($context, array $blocks = array())
    {
        $__internal_db52faf8a446850fbea1408359e894103f89eaa599d4a4a71ca8fcde0b524d92 = $this->env->getExtension("native_profiler");
        $__internal_db52faf8a446850fbea1408359e894103f89eaa599d4a4a71ca8fcde0b524d92->enter($__internal_db52faf8a446850fbea1408359e894103f89eaa599d4a4a71ca8fcde0b524d92_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, (isset($context["content_type_name"]) ? $context["content_type_name"] : $this->getContext($context, "content_type_name")), "html", null, true);
        
        $__internal_db52faf8a446850fbea1408359e894103f89eaa599d4a4a71ca8fcde0b524d92->leave($__internal_db52faf8a446850fbea1408359e894103f89eaa599d4a4a71ca8fcde0b524d92_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ContentType:view_content_type.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  247 => 106,  235 => 100,  232 => 99,  230 => 96,  229 => 94,  228 => 92,  227 => 91,  226 => 90,  222 => 89,  217 => 88,  211 => 86,  203 => 84,  201 => 83,  191 => 78,  187 => 77,  180 => 73,  176 => 72,  167 => 68,  163 => 67,  154 => 61,  150 => 60,  143 => 56,  139 => 55,  132 => 51,  128 => 50,  121 => 46,  117 => 45,  110 => 41,  106 => 40,  98 => 34,  96 => 32,  95 => 31,  94 => 29,  89 => 26,  83 => 25,  71 => 22,  65 => 21,  55 => 18,  53 => 16,  52 => 15,  50 => 12,  44 => 11,  37 => 3,  35 => 9,  33 => 8,  31 => 7,  11 => 3,);
    }
}
/* {# @var content_type \eZ\Publish\API\Repository\Values\ContentType\ContentType #}*/
/* */
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "content_type" %}*/
/* */
/* {% set content_type_group = content_type.contentTypeGroups|first %}*/
/* {% set content_type_name = content_type.names[language_code]|default('') %}*/
/* {% set content_type_description = content_type.descriptions[language_code]|default('') %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_contenttype'), label: 'content_type.dashboard_title'|trans},*/
/*         {link: path('admin_contenttypeGroupView', {'contentTypeGroupId': content_type_group.id}), label: content_type_group.identifier},*/
/*         {link: null, label: content_type_name}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ content_type_name }} [{{ 'content_type.content_count'|transchoice(content_count) }}]</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/* */
/*         <p class="ez-technical-infos">*/
/*             {{*/
/*                 "content_type.last_modified"|trans({*/
/*                     "%date%": content_type.modificationDate|localizeddate(locale=app.request.locale),*/
/*                     "%modifier%": modifier.login*/
/*                 })*/
/*             }}*/
/*         </p>*/
/* */
/*         <div class="pure-g">*/
/*             <div class="pure-u-1-2">*/
/*                 <div>*/
/*                     <h6>{{ "content_type.name"|trans }}</h6>*/
/*                     {{ content_type_name }}*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.identifier"|trans }}:</h6>*/
/*                     {{ content_type.identifier }}*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.description"|trans }}:</h6>*/
/*                     {{ content_type_description }}*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.name_schema"|trans }}:</h6>*/
/*                     {{ content_type.nameSchema }}*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.url_alias_schema"|trans }}:</h6>*/
/*                     {{ content_type.urlAliasSchema }}*/
/*                 </div>*/
/*             </div>*/
/* */
/*             <div class="pure-u-1-2">*/
/*                 <div>*/
/*                     <h6>{{ "content_type.container"|trans }}:</h6>*/
/*                     <input type="checkbox" disabled{% if content_type.isContainer %} checked{% endif %}>*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.default_availability"|trans }}:</h6>*/
/*                     {{ content_type.defaultAlwaysAvailable ? "content_type.always_available"|trans : "content_type.no_always_available"|trans }}*/
/*                 </div>*/
/* */
/*                 <div>*/
/*                     <h6>{{ "content_type.default_children_sorting"|trans }}:</h6>*/
/*                     {{ ("content_type.sort_field." ~ content_type.defaultSortField)|trans(domain="ezrepoforms_content_type") }} / {{ ("content_type.sort_order." ~ content_type.defaultSortOrder)|trans(domain="ezrepoforms_content_type") }}*/
/*                 </div>*/
/*             </div>*/
/* */
/*             <div class="pure-u-1">*/
/*             {% if can_edit %}*/
/*                 <a href="{{ path('admin_contenttypeUpdate', {'contentTypeId': content_type.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'content_type.edit'|trans }}</a>*/
/*             {% else %}*/
/*                 <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'content_type.edit'|trans }}</span>*/
/*             {% endif %}*/
/*                 {{ form_start(delete_form, {"action": path("admin_contenttypeDelete", {"contentTypeId": content_type.id})}) }}*/
/*                     {{ form_widget(delete_form.contentTypeId) }}*/
/*                     {{*/
/*                         form_widget(*/
/*                             delete_form.delete,*/
/*                             {*/
/*                                 "disabled": not can_delete,*/
/*                                 "attr": {"class": "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete",*/
/*                                          "title": not can_delete ? 'content_type.is_in_use'|trans}*/
/*                             }*/
/*                         )*/
/*                     }}*/
/*                 {{ form_end(delete_form) }}*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ content_type_name }}{% endblock %}*/
/* */
/* */
/* */
