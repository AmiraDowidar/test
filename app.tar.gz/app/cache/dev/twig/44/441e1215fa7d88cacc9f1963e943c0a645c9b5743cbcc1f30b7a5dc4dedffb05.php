<?php

/* :list:rides.html.twig */
class __TwigTemplate_c84cec601affbae93ef2133e0eb392f85bb6dc0fb382a25d1ced23ca5233b35b extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_7caea752d1a91be864add24d04a5d974190d2d33580c812e3061f95dcb8954e1 = $this->env->getExtension("native_profiler");
        $__internal_7caea752d1a91be864add24d04a5d974190d2d33580c812e3061f95dcb8954e1->enter($__internal_7caea752d1a91be864add24d04a5d974190d2d33580c812e3061f95dcb8954e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":list:rides.html.twig"));

        // line 1
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["pagerRides"]) ? $context["pagerRides"] : $this->getContext($context, "pagerRides")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["ride"]) {
            // line 2
            echo "      ";
            if ($this->getAttribute($context["loop"], "first", array())) {
                // line 3
                echo "        <table class=\"table table-hover\">
        <thead>
        <tr class=\"table-header\">
          <th> Ride</th>
          <th>From</th>
          <th> To</th>
          <th>Distance</th>
          <th>Level</th>
        </tr>
        </thead>
        <tbody>
      ";
            }
            // line 15
            echo "      ";
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("ez_content:viewLocation", array("locationId" => $this->getAttribute($this->getAttribute($this->getAttribute($context["ride"], "versionInfo", array()), "contentInfo", array()), "mainLocationId", array()), "viewType" => "line")));
            echo "
      ";
            // line 16
            if ($this->getAttribute($context["loop"], "last", array())) {
                // line 17
                echo "        </tbody>
        </table>
      ";
            }
            // line 20
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ride'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_7caea752d1a91be864add24d04a5d974190d2d33580c812e3061f95dcb8954e1->leave($__internal_7caea752d1a91be864add24d04a5d974190d2d33580c812e3061f95dcb8954e1_prof);

    }

    public function getTemplateName()
    {
        return ":list:rides.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 20,  63 => 17,  61 => 16,  56 => 15,  42 => 3,  39 => 2,  22 => 1,);
    }
}
/* {% for ride in pagerRides %}*/
/*       {% if loop.first %}*/
/*         <table class="table table-hover">*/
/*         <thead>*/
/*         <tr class="table-header">*/
/*           <th> Ride</th>*/
/*           <th>From</th>*/
/*           <th> To</th>*/
/*           <th>Distance</th>*/
/*           <th>Level</th>*/
/*         </tr>*/
/*         </thead>*/
/*         <tbody>*/
/*       {% endif %}*/
/*       {{ render( controller( 'ez_content:viewLocation', { 'locationId': ride.versionInfo.contentInfo.mainLocationId, 'viewType': 'line' } )) }}*/
/*       {% if loop.last %}*/
/*         </tbody>*/
/*         </table>*/
/*       {% endif %}*/
/*     {% endfor %}*/
