<?php

/* @Framework/Form/integer_widget.html.php */
class __TwigTemplate_140e6f4d9a266df140f3e5f3aaa2005a43b3f3b42dfd72be81c882ea9f9af198 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_26dc92e4a8ce0c338f0bcb6e25da515faaa63918fe6f4eb29a7249d573bcefcc = $this->env->getExtension("native_profiler");
        $__internal_26dc92e4a8ce0c338f0bcb6e25da515faaa63918fe6f4eb29a7249d573bcefcc->enter($__internal_26dc92e4a8ce0c338f0bcb6e25da515faaa63918fe6f4eb29a7249d573bcefcc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/integer_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'number')) ?>
";
        
        $__internal_26dc92e4a8ce0c338f0bcb6e25da515faaa63918fe6f4eb29a7249d573bcefcc->leave($__internal_26dc92e4a8ce0c338f0bcb6e25da515faaa63918fe6f4eb29a7249d573bcefcc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/integer_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'number')) ?>*/
/* */
