<?php

/* EzSystemsRepositoryFormsBundle:ContentType:field_definition_row.html.twig */
class __TwigTemplate_c2d600dce09eb0e0dcbe0c38a9d43a7bc26a5c348a8c7f981f7039251329d29f extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'form_row' => array($this, 'block_form_row'),
            'datetimeinterval_widget' => array($this, 'block_datetimeinterval_widget'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b0531c66cfdaee1917185f89501fffe6d646f07af0213e295d3b4aae5e3af487 = $this->env->getExtension("native_profiler");
        $__internal_b0531c66cfdaee1917185f89501fffe6d646f07af0213e295d3b4aae5e3af487->enter($__internal_b0531c66cfdaee1917185f89501fffe6d646f07af0213e295d3b4aae5e3af487_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzSystemsRepositoryFormsBundle:ContentType:field_definition_row.html.twig"));

        // line 2
        $this->displayBlock('form_row', $context, $blocks);
        // line 73
        echo "
";
        // line 74
        $this->displayBlock('datetimeinterval_widget', $context, $blocks);
        
        $__internal_b0531c66cfdaee1917185f89501fffe6d646f07af0213e295d3b4aae5e3af487->leave($__internal_b0531c66cfdaee1917185f89501fffe6d646f07af0213e295d3b4aae5e3af487_prof);

    }

    // line 2
    public function block_form_row($context, array $blocks = array())
    {
        $__internal_b49bfc72cdcec0845821d65be70c5584f6c76da37595edf1ff332dbcc7ea9828 = $this->env->getExtension("native_profiler");
        $__internal_b49bfc72cdcec0845821d65be70c5584f6c76da37595edf1ff332dbcc7ea9828->enter($__internal_b49bfc72cdcec0845821d65be70c5584f6c76da37595edf1ff332dbcc7ea9828_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "form_row"));

        // line 3
        echo "    <div class=\"field-definition-edit field-type-";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "\">
        <h3>
            ";
        // line 5
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "selected", array()), 'widget');
        echo "
            ";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "names", array()), (isset($context["languageCode"]) ? $context["languageCode"] : $this->getContext($context, "languageCode")), array(), "array"), "html", null, true);
        echo " [";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "] (id: ";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), "fieldDefinition", array()), "id", array()), "html", null, true);
        echo ")
        </h3>

        <div class=\"field-definition-position";
        // line 9
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")), "html", null, true);
        }
        echo "\">
            ";
        // line 10
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "position", array()), 'label');
        echo "
            ";
        // line 11
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "position", array()), 'errors');
        echo "
            ";
        // line 12
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "position", array()), 'widget');
        echo "
        </div>

        <div class=\"field-definition-name";
        // line 15
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")), "html", null, true);
        }
        echo "\">
            ";
        // line 16
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'label');
        echo "
            ";
        // line 17
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'errors');
        echo "
            ";
        // line 18
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget');
        echo "
        </div>

        <div class=\"field-definition-identifier";
        // line 21
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")), "html", null, true);
        }
        echo "\">
            ";
        // line 22
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "identifier", array()), 'label');
        echo "
            ";
        // line 23
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "identifier", array()), 'errors');
        echo "
            ";
        // line 24
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "identifier", array()), 'widget');
        echo "
        </div>

        <div class=\"field-definition-description";
        // line 27
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")), "html", null, true);
        }
        echo "\">
            ";
        // line 28
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'label');
        echo "
            ";
        // line 29
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'errors');
        echo "
            ";
        // line 30
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'widget');
        echo "
        </div>

        <div class=\"field-definition-isRequired";
        // line 33
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")), "html", null, true);
        }
        echo "\">
            ";
        // line 34
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isRequired", array()), 'label');
        echo "
            ";
        // line 35
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isRequired", array()), 'errors');
        echo "
            ";
        // line 36
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isRequired", array()), 'widget');
        echo "
        </div>

        <div class=\"field-definition-isSearchable";
        // line 39
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")), "html", null, true);
        }
        echo "\">
            ";
        // line 40
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isSearchable", array()), 'label');
        echo "
            ";
        // line 41
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isSearchable", array()), 'errors');
        echo "
            ";
        // line 42
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isSearchable", array()), 'widget');
        echo "
        </div>

        <div class=\"field-definition-isTranslatable";
        // line 45
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")), "html", null, true);
        }
        echo "\">
            ";
        // line 46
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isTranslatable", array()), 'label');
        echo "
            ";
        // line 47
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isTranslatable", array()), 'errors');
        echo "
            ";
        // line 48
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isTranslatable", array()), 'widget');
        echo "
        </div>

        <div class=\"field-definition-fieldGroup";
        // line 51
        if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")))) {
            echo " ";
            echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")), "html", null, true);
        }
        echo "\">
            ";
        // line 52
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fieldGroup", array()), 'label');
        echo "
            ";
        // line 53
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fieldGroup", array()), 'errors');
        echo "
            ";
        // line 54
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fieldGroup", array()), 'widget');
        echo "
        </div>

        ";
        // line 58
        echo "        ";
        // line 59
        echo "        ";
        echo call_user_func_array($this->env->getFunction('ez_render_fielddefinition_edit')->getCallable(), array($this->env, (isset($context["value"]) ? $context["value"] : $this->getContext($context, "value")), array("languageCode" => (isset($context["languageCode"]) ? $context["languageCode"] : $this->getContext($context, "languageCode")), "form" => (isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "group_class" => ((array_key_exists("group_class", $context)) ? (_twig_default_filter((isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")), "")) : ("")))));
        echo "
        ";
        // line 61
        echo "        ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 62
            echo "            ";
            // line 63
            echo "            ";
            if (( !$this->getAttribute($context["child"], "rendered", array()) &&  !twig_test_iterable($context["child"]))) {
                // line 64
                echo "                <div";
                if ( !twig_test_empty((isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")))) {
                    echo " class=\"";
                    echo twig_escape_filter($this->env, (isset($context["group_class"]) ? $context["group_class"] : $this->getContext($context, "group_class")), "html", null, true);
                    echo "\"";
                }
                echo ">";
                // line 65
                echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["child"], 'label');
                // line 66
                echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["child"], 'errors');
                // line 67
                echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["child"], 'widget');
                // line 68
                echo "</div>
            ";
            }
            // line 70
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 71
        echo "    </div>
";
        
        $__internal_b49bfc72cdcec0845821d65be70c5584f6c76da37595edf1ff332dbcc7ea9828->leave($__internal_b49bfc72cdcec0845821d65be70c5584f6c76da37595edf1ff332dbcc7ea9828_prof);

    }

    // line 74
    public function block_datetimeinterval_widget($context, array $blocks = array())
    {
        $__internal_febb720d8f7e7f7161af800b2842bc56c5e4a292f4f15cb894723e5531457518 = $this->env->getExtension("native_profiler");
        $__internal_febb720d8f7e7f7161af800b2842bc56c5e4a292f4f15cb894723e5531457518->enter($__internal_febb720d8f7e7f7161af800b2842bc56c5e4a292f4f15cb894723e5531457518_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "datetimeinterval_widget"));

        // line 75
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")));
        foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
            // line 76
            echo "        <div>";
            // line 77
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["child"], 'label');
            // line 78
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["child"], 'errors');
            // line 79
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["child"], 'widget');
            // line 80
            echo "</div>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_febb720d8f7e7f7161af800b2842bc56c5e4a292f4f15cb894723e5531457518->leave($__internal_febb720d8f7e7f7161af800b2842bc56c5e4a292f4f15cb894723e5531457518_prof);

    }

    public function getTemplateName()
    {
        return "EzSystemsRepositoryFormsBundle:ContentType:field_definition_row.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  298 => 80,  296 => 79,  294 => 78,  292 => 77,  290 => 76,  285 => 75,  279 => 74,  271 => 71,  265 => 70,  261 => 68,  259 => 67,  257 => 66,  255 => 65,  247 => 64,  244 => 63,  242 => 62,  237 => 61,  232 => 59,  230 => 58,  224 => 54,  220 => 53,  216 => 52,  209 => 51,  203 => 48,  199 => 47,  195 => 46,  188 => 45,  182 => 42,  178 => 41,  174 => 40,  167 => 39,  161 => 36,  157 => 35,  153 => 34,  146 => 33,  140 => 30,  136 => 29,  132 => 28,  125 => 27,  119 => 24,  115 => 23,  111 => 22,  104 => 21,  98 => 18,  94 => 17,  90 => 16,  83 => 15,  77 => 12,  73 => 11,  69 => 10,  62 => 9,  52 => 6,  48 => 5,  42 => 3,  36 => 2,  29 => 74,  26 => 73,  24 => 2,);
    }
}
/* {# @var value \EzSystems\RepositoryForms\Data\FieldDefinitionData #}*/
/* {% block form_row %}*/
/*     <div class="field-definition-edit field-type-{{ value.fieldTypeIdentifier }}">*/
/*         <h3>*/
/*             {{ form_widget(form.selected) }}*/
/*             {{ value.names[languageCode] }} [{{ value.fieldTypeIdentifier }}] (id: {{ value.fieldDefinition.id }})*/
/*         </h3>*/
/* */
/*         <div class="field-definition-position{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*             {{ form_label(form.position) }}*/
/*             {{ form_errors(form.position) }}*/
/*             {{ form_widget(form.position) }}*/
/*         </div>*/
/* */
/*         <div class="field-definition-name{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*             {{ form_label(form.name) }}*/
/*             {{ form_errors(form.name) }}*/
/*             {{ form_widget(form.name) }}*/
/*         </div>*/
/* */
/*         <div class="field-definition-identifier{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*             {{ form_label(form.identifier) }}*/
/*             {{ form_errors(form.identifier) }}*/
/*             {{ form_widget(form.identifier) }}*/
/*         </div>*/
/* */
/*         <div class="field-definition-description{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*             {{ form_label(form.description) }}*/
/*             {{ form_errors(form.description) }}*/
/*             {{ form_widget(form.description) }}*/
/*         </div>*/
/* */
/*         <div class="field-definition-isRequired{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*             {{ form_label(form.isRequired) }}*/
/*             {{ form_errors(form.isRequired) }}*/
/*             {{ form_widget(form.isRequired) }}*/
/*         </div>*/
/* */
/*         <div class="field-definition-isSearchable{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*             {{ form_label(form.isSearchable) }}*/
/*             {{ form_errors(form.isSearchable) }}*/
/*             {{ form_widget(form.isSearchable) }}*/
/*         </div>*/
/* */
/*         <div class="field-definition-isTranslatable{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*             {{ form_label(form.isTranslatable) }}*/
/*             {{ form_errors(form.isTranslatable) }}*/
/*             {{ form_widget(form.isTranslatable) }}*/
/*         </div>*/
/* */
/*         <div class="field-definition-fieldGroup{% if group_class is not empty %} {{ group_class }}{% endif %}">*/
/*             {{ form_label(form.fieldGroup) }}*/
/*             {{ form_errors(form.fieldGroup) }}*/
/*             {{ form_widget(form.fieldGroup) }}*/
/*         </div>*/
/* */
/*         {# Field type specific fields below #}*/
/*         {# Use field type config, if provided. #}*/
/*         {{ ez_render_fielddefinition_edit(value, {"languageCode": languageCode, "form": form, "group_class": group_class|default("")}) }}*/
/*         {# Default rendering #}*/
/*         {% for child in form %}*/
/*             {# Iterable children means collections, they are handled in field_types.html.twig #}*/
/*             {% if not child.rendered and child is not iterable %}*/
/*                 <div{% if group_class is not empty %} class="{{ group_class }}"{% endif %}>*/
/*                     {{- form_label(child) -}}*/
/*                     {{- form_errors(child) -}}*/
/*                     {{- form_widget(child) -}}*/
/*                 </div>*/
/*             {% endif %}*/
/*         {% endfor %}*/
/*     </div>*/
/* {% endblock %}*/
/* */
/* {% block datetimeinterval_widget %}*/
/*     {% for child in form %}*/
/*         <div>*/
/*             {{- form_label(child) -}}*/
/*             {{- form_errors(child) -}}*/
/*             {{- form_widget(child) -}}*/
/*         </div>*/
/*     {% endfor %}*/
/* {% endblock %}*/
/* */
