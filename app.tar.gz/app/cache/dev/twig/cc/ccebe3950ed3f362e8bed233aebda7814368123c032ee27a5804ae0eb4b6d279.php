<?php

/* eZPlatformUIBundle:Section:create.html.twig */
class __TwigTemplate_438d0ddb8b7a7573711de96248da40f216f4d226a80329882b6ee5f193488339 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Section:create.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1dc82329323be0421790ada27b6304ee1911d11b8eda3431952131b99c0a3647 = $this->env->getExtension("native_profiler");
        $__internal_1dc82329323be0421790ada27b6304ee1911d11b8eda3431952131b99c0a3647->enter($__internal_1dc82329323be0421790ada27b6304ee1911d11b8eda3431952131b99c0a3647_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Section:create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1dc82329323be0421790ada27b6304ee1911d11b8eda3431952131b99c0a3647->leave($__internal_1dc82329323be0421790ada27b6304ee1911d11b8eda3431952131b99c0a3647_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_19eb2acec07d4e79166950438c254403a68e2875323c5fdb2b2d1c2f0be575ba = $this->env->getExtension("native_profiler");
        $__internal_19eb2acec07d4e79166950438c254403a68e2875323c5fdb2b2d1c2f0be575ba->enter($__internal_19eb2acec07d4e79166950438c254403a68e2875323c5fdb2b2d1c2f0be575ba_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.create.title", array(), "section"), "html", null, true);
        
        $__internal_19eb2acec07d4e79166950438c254403a68e2875323c5fdb2b2d1c2f0be575ba->leave($__internal_19eb2acec07d4e79166950438c254403a68e2875323c5fdb2b2d1c2f0be575ba_prof);

    }

    // line 7
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_d5118c22ea18da6b3ce26ad623ec8f87dbeb1f9c166e0d5a3069ba5b0c61da3b = $this->env->getExtension("native_profiler");
        $__internal_d5118c22ea18da6b3ce26ad623ec8f87dbeb1f9c166e0d5a3069ba5b0c61da3b->enter($__internal_d5118c22ea18da6b3ce26ad623ec8f87dbeb1f9c166e0d5a3069ba5b0c61da3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 8
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_sectionlist"), "label" => $this->env->getExtension('translator')->trans("section.list", array(), "section")), 2 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("section.create.title", array(), "section")));
        // line 13
        echo "
    ";
        // line 14
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_d5118c22ea18da6b3ce26ad623ec8f87dbeb1f9c166e0d5a3069ba5b0c61da3b->leave($__internal_d5118c22ea18da6b3ce26ad623ec8f87dbeb1f9c166e0d5a3069ba5b0c61da3b_prof);

    }

    // line 17
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_64c7b3a9bf6d248a977e6e96ef6946ac72968d20753755db07aa92781aa8d141 = $this->env->getExtension("native_profiler");
        $__internal_64c7b3a9bf6d248a977e6e96ef6946ac72968d20753755db07aa92781aa8d141->enter($__internal_64c7b3a9bf6d248a977e6e96ef6946ac72968d20753755db07aa92781aa8d141_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 18
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("section.create.title", array(), "section"), "html", null, true);
        echo "</h1>
";
        
        $__internal_64c7b3a9bf6d248a977e6e96ef6946ac72968d20753755db07aa92781aa8d141->leave($__internal_64c7b3a9bf6d248a977e6e96ef6946ac72968d20753755db07aa92781aa8d141_prof);

    }

    // line 21
    public function block_content($context, array $blocks = array())
    {
        $__internal_57d53b05407b77014bdee940ffe125e7cfeba8b068b6a315886e4ffd5e5ddff5 = $this->env->getExtension("native_profiler");
        $__internal_57d53b05407b77014bdee940ffe125e7cfeba8b068b6a315886e4ffd5e5ddff5->enter($__internal_57d53b05407b77014bdee940ffe125e7cfeba8b068b6a315886e4ffd5e5ddff5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 22
        echo "    <section class=\"ez-serverside-content\">
        <ul class=\"ez-simpleform-error\">
            ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session", array()), "flashbag", array()), "get", array(0 => "error"), "method"));
        foreach ($context['_seq'] as $context["_key"] => $context["flashMessage"]) {
            // line 25
            echo "                <li class=\"ez-simpleform-error-item\">";
            echo twig_escape_filter($this->env, $context["flashMessage"], "html", null, true);
            echo "</li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['flashMessage'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 27
        echo "        </ul>

        ";
        // line 29
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form');
        echo "
    </section>
";
        
        $__internal_57d53b05407b77014bdee940ffe125e7cfeba8b068b6a315886e4ffd5e5ddff5->leave($__internal_57d53b05407b77014bdee940ffe125e7cfeba8b068b6a315886e4ffd5e5ddff5_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Section:create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  113 => 29,  109 => 27,  100 => 25,  96 => 24,  92 => 22,  86 => 21,  76 => 18,  70 => 17,  61 => 14,  58 => 13,  55 => 8,  49 => 7,  37 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "section" %}*/
/* */
/* {% block title %}{{ 'section.create.title'|trans }}{% endblock %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_sectionlist'), label: 'section.list'|trans({}, 'section')},*/
/*         {link: '', label: 'section.create.title'|trans}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'section.create.title'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <ul class="ez-simpleform-error">*/
/*             {% for flashMessage in app.session.flashbag.get('error') %}*/
/*                 <li class="ez-simpleform-error-item">{{ flashMessage }}</li>*/
/*             {% endfor %}*/
/*         </ul>*/
/* */
/*         {{ form(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
