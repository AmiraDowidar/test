<?php

/* eZPlatformUIBundle:Exception:error403.html.twig */
class __TwigTemplate_43a940341dd071ebc314ccbd130fe2d16ebab95b060246740634a81c2f8a8b07 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle:Exception:error.html.twig", "eZPlatformUIBundle:Exception:error403.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle:Exception:error.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cc58ac55e865998d499607e74865a7c5dfea446134acdd6221540263a6d01bfd = $this->env->getExtension("native_profiler");
        $__internal_cc58ac55e865998d499607e74865a7c5dfea446134acdd6221540263a6d01bfd->enter($__internal_cc58ac55e865998d499607e74865a7c5dfea446134acdd6221540263a6d01bfd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Exception:error403.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_cc58ac55e865998d499607e74865a7c5dfea446134acdd6221540263a6d01bfd->leave($__internal_cc58ac55e865998d499607e74865a7c5dfea446134acdd6221540263a6d01bfd_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Exception:error403.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle:Exception:error.html.twig" %}*/
/* */
