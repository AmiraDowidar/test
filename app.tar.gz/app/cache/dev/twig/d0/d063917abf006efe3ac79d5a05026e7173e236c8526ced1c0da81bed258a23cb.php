<?php

/* ::pagelayout_header.html.twig */
class __TwigTemplate_6dde1edb029409dd5912ac6a8c7eedb8340679d6f6a7305c2c319b7fb89249cc extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0109502422cd2d6273553d851ab9e2ed9c2181ccb1aab96cb7e217be7c402a6a = $this->env->getExtension("native_profiler");
        $__internal_0109502422cd2d6273553d851ab9e2ed9c2181ccb1aab96cb7e217be7c402a6a->enter($__internal_0109502422cd2d6273553d851ab9e2ed9c2181ccb1aab96cb7e217be7c402a6a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::pagelayout_header.html.twig"));

        // line 1
        echo "<!-- nav header -->
<header class=\"main-header\">
  <a href=\"\" class=\"logo\">
    <img src=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/white_logo.svg"), "html", null, true);
        echo "\" alt=\"\" />
  </a>
  <a class=\"mobile-menu-icon\">
    <i class=\"icon-menu visible-xs\"></i>
  </a>

  <menu class=\"mobile-menu\">
    <i class=\"icon-close\"></i>
    <ul>
      <li>
        <a href=\"#\">
          Rates
        </a>
      </li>
      <li>
        <a href=\"#\">
          support
        </a>
      </li>
      <li>
        <a href=\"#\" class=\"flags-list\">
          language
          <span class=\"pull-right\">
            English
            <i class=\"icon-arrow_down\"></i>
          </span>
        </a>
        <div class=\"langs\">
          <div class=\"\">
            <img src=\"";
        // line 33
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/eng-GB.gif"), "html", null, true);
        echo "\" alt=\"\" /> English
          </div>
          <div class=\"\">
            <img src=\"";
        // line 36
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/esl-ES.gif"), "html", null, true);
        echo "\" alt=\"\" /> Español
          </div>
          <div class=\"\">
            <img src=\"";
        // line 39
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/fre-FR.gif"), "html", null, true);
        echo "\" alt=\"\" /> Français
          </div>
        </div>
      </li>
    </ul>
  </menu>

  <div class=\"right-section pull-right hidden-xs\">
    <nav class=\"pull-left\">
      <ul>
         <li>
          <a href=\"Rates\">
            Rates
          </a>
        </li>
        <li>
          <a href=\"#\">
            Support
          </a>
        </li>
        <li class=\"has_menu lang-switch\">
          <a href=\"#\">
            <img src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/eng-GB.gif"), "html", null, true);
        echo "\" alt=\"\" />
            English
          </a>
          <ul class=\"lang-list\">
            <li>
              <a href=\"#\">
                <img src=\"";
        // line 67
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/eng-GB.gif"), "html", null, true);
        echo "\" alt=\"\" />
                English
              </a>
            </li>
            <li>
              <a href=\"#\">
                <img src=\"";
        // line 73
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/esl-ES.gif"), "html", null, true);
        echo "\" alt=\"\" />
                Español
              </a>
            </li>
            <li>
              <a href=\"#\">
                <img src=\"";
        // line 79
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/fre-FR.gif"), "html", null, true);
        echo "\" alt=\"\" />
                Français
              </a>
            </li>
          </ul>
        </li>
        <!-- <li class=\"has_menu\">
          <a href=\"#\">
            Device€
          </a>
        </li> -->
      </ul>
    </nav>
    <div class=\"social pull-left\">
            <a href=\"https://twitter.com/Libon\">
                <img src=\"";
        // line 94
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/twitter_icon.svg"), "html", null, true);
        echo "\">
            </a>
            <a href=\"https://www.facebook.com/libon.fan\">
                <img src=\"";
        // line 97
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/facebook_icon.svg"), "html", null, true);
        echo "\">
            </a>
        </div>
  </div>
</header>";
        
        $__internal_0109502422cd2d6273553d851ab9e2ed9c2181ccb1aab96cb7e217be7c402a6a->leave($__internal_0109502422cd2d6273553d851ab9e2ed9c2181ccb1aab96cb7e217be7c402a6a_prof);

    }

    public function getTemplateName()
    {
        return "::pagelayout_header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  147 => 97,  141 => 94,  123 => 79,  114 => 73,  105 => 67,  96 => 61,  71 => 39,  65 => 36,  59 => 33,  27 => 4,  22 => 1,);
    }
}
/* <!-- nav header -->*/
/* <header class="main-header">*/
/*   <a href="" class="logo">*/
/*     <img src="{{ asset('assets/images/white_logo.svg') }}" alt="" />*/
/*   </a>*/
/*   <a class="mobile-menu-icon">*/
/*     <i class="icon-menu visible-xs"></i>*/
/*   </a>*/
/* */
/*   <menu class="mobile-menu">*/
/*     <i class="icon-close"></i>*/
/*     <ul>*/
/*       <li>*/
/*         <a href="#">*/
/*           Rates*/
/*         </a>*/
/*       </li>*/
/*       <li>*/
/*         <a href="#">*/
/*           support*/
/*         </a>*/
/*       </li>*/
/*       <li>*/
/*         <a href="#" class="flags-list">*/
/*           language*/
/*           <span class="pull-right">*/
/*             English*/
/*             <i class="icon-arrow_down"></i>*/
/*           </span>*/
/*         </a>*/
/*         <div class="langs">*/
/*           <div class="">*/
/*             <img src="{{ asset('assets/images/eng-GB.gif') }}" alt="" /> English*/
/*           </div>*/
/*           <div class="">*/
/*             <img src="{{ asset('assets/images/esl-ES.gif') }}" alt="" /> Español*/
/*           </div>*/
/*           <div class="">*/
/*             <img src="{{ asset('assets/images/fre-FR.gif') }}" alt="" /> Français*/
/*           </div>*/
/*         </div>*/
/*       </li>*/
/*     </ul>*/
/*   </menu>*/
/* */
/*   <div class="right-section pull-right hidden-xs">*/
/*     <nav class="pull-left">*/
/*       <ul>*/
/*          <li>*/
/*           <a href="Rates">*/
/*             Rates*/
/*           </a>*/
/*         </li>*/
/*         <li>*/
/*           <a href="#">*/
/*             Support*/
/*           </a>*/
/*         </li>*/
/*         <li class="has_menu lang-switch">*/
/*           <a href="#">*/
/*             <img src="{{ asset('assets/images/eng-GB.gif') }}" alt="" />*/
/*             English*/
/*           </a>*/
/*           <ul class="lang-list">*/
/*             <li>*/
/*               <a href="#">*/
/*                 <img src="{{ asset('assets/images/eng-GB.gif') }}" alt="" />*/
/*                 English*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 <img src="{{ asset('assets/images/esl-ES.gif') }}" alt="" />*/
/*                 Español*/
/*               </a>*/
/*             </li>*/
/*             <li>*/
/*               <a href="#">*/
/*                 <img src="{{ asset('assets/images/fre-FR.gif') }}" alt="" />*/
/*                 Français*/
/*               </a>*/
/*             </li>*/
/*           </ul>*/
/*         </li>*/
/*         <!-- <li class="has_menu">*/
/*           <a href="#">*/
/*             Device€*/
/*           </a>*/
/*         </li> -->*/
/*       </ul>*/
/*     </nav>*/
/*     <div class="social pull-left">*/
/*             <a href="https://twitter.com/Libon">*/
/*                 <img src="{{ asset('assets/images/twitter_icon.svg') }}">*/
/*             </a>*/
/*             <a href="https://www.facebook.com/libon.fan">*/
/*                 <img src="{{ asset('assets/images/facebook_icon.svg') }}">*/
/*             </a>*/
/*         </div>*/
/*   </div>*/
/* </header>*/
