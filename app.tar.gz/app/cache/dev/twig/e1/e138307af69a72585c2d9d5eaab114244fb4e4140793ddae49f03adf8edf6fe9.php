<?php

/* @Framework/Form/form_errors.html.php */
class __TwigTemplate_c6b5d96fd6207826912acb5630b1f2030be71ce920fc7bc7192b3fcf0ebe1546 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_53fe6a5df819afac20c4bdd2462a1d09a17cff96d2a8aed46751295a88409363 = $this->env->getExtension("native_profiler");
        $__internal_53fe6a5df819afac20c4bdd2462a1d09a17cff96d2a8aed46751295a88409363->enter($__internal_53fe6a5df819afac20c4bdd2462a1d09a17cff96d2a8aed46751295a88409363_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_errors.html.php"));

        // line 1
        echo "<?php if (count(\$errors) > 0): ?>
    <ul>
        <?php foreach (\$errors as \$error): ?>
            <li><?php echo \$error->getMessage() ?></li>
        <?php endforeach; ?>
    </ul>
<?php endif ?>
";
        
        $__internal_53fe6a5df819afac20c4bdd2462a1d09a17cff96d2a8aed46751295a88409363->leave($__internal_53fe6a5df819afac20c4bdd2462a1d09a17cff96d2a8aed46751295a88409363_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_errors.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (count($errors) > 0): ?>*/
/*     <ul>*/
/*         <?php foreach ($errors as $error): ?>*/
/*             <li><?php echo $error->getMessage() ?></li>*/
/*         <?php endforeach; ?>*/
/*     </ul>*/
/* <?php endif ?>*/
/* */
