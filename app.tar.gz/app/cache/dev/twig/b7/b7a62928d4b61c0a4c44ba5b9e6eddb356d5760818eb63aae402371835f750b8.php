<?php

/* eZPlatformUIBundle:ContentType:update_content_type.html.twig */
class __TwigTemplate_ba0b40acffe5268a0a4ab49220bec8625c1acca0094a8269fffd51d76b9b09da extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:ContentType:update_content_type.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'notification' => array($this, 'block_notification'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_0b4688df43a4ffee6d2f9719a915e8eea88e46c9db6451b60d9ef2d563b2438c = $this->env->getExtension("native_profiler");
        $__internal_0b4688df43a4ffee6d2f9719a915e8eea88e46c9db6451b60d9ef2d563b2438c->enter($__internal_0b4688df43a4ffee6d2f9719a915e8eea88e46c9db6451b60d9ef2d563b2438c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:ContentType:update_content_type.html.twig"));

        // line 6
        $context["edit_title"] = $this->env->getExtension('translator')->trans("content_type.edit_title", array("%contentTypeName%" => (isset($context["contentTypeName"]) ? $context["contentTypeName"] : $this->getContext($context, "contentTypeName"))), "ezrepoforms_content_type");
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_0b4688df43a4ffee6d2f9719a915e8eea88e46c9db6451b60d9ef2d563b2438c->leave($__internal_0b4688df43a4ffee6d2f9719a915e8eea88e46c9db6451b60d9ef2d563b2438c_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_d99e8080cc10487307a5995a22cdf748e03227c56e141242b1ba6c603054cbe9 = $this->env->getExtension("native_profiler");
        $__internal_d99e8080cc10487307a5995a22cdf748e03227c56e141242b1ba6c603054cbe9->enter($__internal_d99e8080cc10487307a5995a22cdf748e03227c56e141242b1ba6c603054cbe9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 9
        echo "    ";
        echo twig_escape_filter($this->env, (isset($context["edit_title"]) ? $context["edit_title"] : $this->getContext($context, "edit_title")), "html", null, true);
        echo "
";
        
        $__internal_d99e8080cc10487307a5995a22cdf748e03227c56e141242b1ba6c603054cbe9->leave($__internal_d99e8080cc10487307a5995a22cdf748e03227c56e141242b1ba6c603054cbe9_prof);

    }

    // line 12
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_a6c3c7e06052b32cf7525bb51d1d64307f127b8541bef060c2585003f0745f5b = $this->env->getExtension("native_profiler");
        $__internal_a6c3c7e06052b32cf7525bb51d1d64307f127b8541bef060c2585003f0745f5b->enter($__internal_a6c3c7e06052b32cf7525bb51d1d64307f127b8541bef060c2585003f0745f5b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 13
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_contenttype"), "label" => $this->env->getExtension('translator')->trans("content_type.dashboard_title", array(), "content_type")), 2 => array("link" => null, "label" =>         // line 16
(isset($context["edit_title"]) ? $context["edit_title"] : $this->getContext($context, "edit_title"))));
        // line 18
        echo "
    ";
        // line 19
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_a6c3c7e06052b32cf7525bb51d1d64307f127b8541bef060c2585003f0745f5b->leave($__internal_a6c3c7e06052b32cf7525bb51d1d64307f127b8541bef060c2585003f0745f5b_prof);

    }

    // line 22
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_d0ae0e8d8cd56d74e0a6edefbe6e6aed0a5f612e95aa0aa47be48af02ab1425d = $this->env->getExtension("native_profiler");
        $__internal_d0ae0e8d8cd56d74e0a6edefbe6e6aed0a5f612e95aa0aa47be48af02ab1425d->enter($__internal_d0ae0e8d8cd56d74e0a6edefbe6e6aed0a5f612e95aa0aa47be48af02ab1425d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 23
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">
        ";
        // line 24
        echo twig_escape_filter($this->env, (isset($context["edit_title"]) ? $context["edit_title"] : $this->getContext($context, "edit_title")), "html", null, true);
        echo "
    </h1>
";
        
        $__internal_d0ae0e8d8cd56d74e0a6edefbe6e6aed0a5f612e95aa0aa47be48af02ab1425d->leave($__internal_d0ae0e8d8cd56d74e0a6edefbe6e6aed0a5f612e95aa0aa47be48af02ab1425d_prof);

    }

    // line 28
    public function block_content($context, array $blocks = array())
    {
        $__internal_035ec0fbe5ad4a2b09ba158d9ef0a514dfee7eeac08fac596464e3de86e7f370 = $this->env->getExtension("native_profiler");
        $__internal_035ec0fbe5ad4a2b09ba158d9ef0a514dfee7eeac08fac596464e3de86e7f370->enter($__internal_035ec0fbe5ad4a2b09ba158d9ef0a514dfee7eeac08fac596464e3de86e7f370_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 29
        echo "    <section class=\"ez-serverside-content\">

        <p class=\"ez-technical-infos\">
            ";
        // line 32
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.last_modified", array("%date%" => twig_localized_date_filter($this->env, $this->getAttribute(        // line 34
(isset($context["contentTypeDraft"]) ? $context["contentTypeDraft"] : $this->getContext($context, "contentTypeDraft")), "modificationDate", array()), "medium", "medium", $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "request", array()), "locale", array())), "%modifier%" => $this->getAttribute(        // line 35
(isset($context["modifier"]) ? $context["modifier"] : $this->getContext($context, "modifier")), "login", array())), "content_type"), "html", null, true);
        // line 37
        echo "
        </p>

        ";
        // line 40
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("action" => (isset($context["action_url"]) ? $context["action_url"] : $this->getContext($context, "action_url")), "attr" => array("class" => "pure-form pure-form-aligned")));
        echo "
            ";
        // line 41
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "

            <fieldset>
                <div class=\"pure-control-group\">
                    ";
        // line 45
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'label');
        echo "
                    ";
        // line 46
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'errors');
        echo "
                    ";
        // line 47
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 51
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "identifier", array()), 'label');
        echo "
                    ";
        // line 52
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "identifier", array()), 'errors');
        echo "
                    ";
        // line 53
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "identifier", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 57
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'label');
        echo "
                    ";
        // line 58
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'errors');
        echo "
                    ";
        // line 59
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "description", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 63
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nameSchema", array()), 'label');
        echo "
                    ";
        // line 64
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nameSchema", array()), 'errors');
        echo "
                    ";
        // line 65
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "nameSchema", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 69
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "urlAliasSchema", array()), 'label');
        echo "
                    ";
        // line 70
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "urlAliasSchema", array()), 'errors');
        echo "
                    ";
        // line 71
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "urlAliasSchema", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 75
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isContainer", array()), 'label');
        echo "
                    ";
        // line 76
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isContainer", array()), 'errors');
        echo "
                    ";
        // line 77
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "isContainer", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 81
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "defaultSortField", array()), 'label');
        echo "
                    ";
        // line 82
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "defaultSortField", array()), 'errors');
        echo "
                    ";
        // line 83
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "defaultSortField", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 87
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "defaultSortOrder", array()), 'label');
        echo "
                    ";
        // line 88
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "defaultSortOrder", array()), 'errors');
        echo "
                    ";
        // line 89
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "defaultSortOrder", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 93
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "defaultAlwaysAvailable", array()), 'label');
        echo "
                    ";
        // line 94
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "defaultAlwaysAvailable", array()), 'errors');
        echo "
                    ";
        // line 95
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "defaultAlwaysAvailable", array()), 'widget');
        echo "
                </div>
            </fieldset>

            <h2>";
        // line 99
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fieldDefinitionsData", array()), 'label');
        echo "</h2>
            ";
        // line 100
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fieldDefinitionsData", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["fieldDefForm"]) {
            // line 101
            echo "                <fieldset>
                    ";
            // line 102
            $this->env->getExtension('form')->renderer->setTheme($context["fieldDefForm"], array(0 => "EzSystemsRepositoryFormsBundle:ContentType:field_definition_row.html.twig"));
            // line 103
            echo "                    ";
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($context["fieldDefForm"], 'row', array("contentTypeDraft" => (isset($context["contentTypeDraft"]) ? $context["contentTypeDraft"] : $this->getContext($context, "contentTypeDraft")), "languageCode" => (isset($context["languageCode"]) ? $context["languageCode"] : $this->getContext($context, "languageCode")), "group_class" => "pure-control-group"));
            echo "
                </fieldset>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['fieldDefForm'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 106
        echo "
            <div class=\"pure-control-group\">
                ";
        // line 108
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "removeFieldDefinition", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
            </div>

            <div class=\"pure-control-group\">
                ";
        // line 112
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fieldTypeSelection", array()), 'label');
        echo "
                ";
        // line 113
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "fieldTypeSelection", array()), 'widget');
        echo "
                ";
        // line 114
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "addFieldDefinition", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
            </div>

            <div class=\"pure-controls\">
                ";
        // line 118
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "removeDraft", array()), 'widget', array("attr" => array("class" => "pure-button ez-button", "formnovalidate" => "formnovalidate")));
        echo "
                ";
        // line 119
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "saveContentType", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
                ";
        // line 120
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "publishContentType", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
            </div>

        ";
        // line 123
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </section>
";
        
        $__internal_035ec0fbe5ad4a2b09ba158d9ef0a514dfee7eeac08fac596464e3de86e7f370->leave($__internal_035ec0fbe5ad4a2b09ba158d9ef0a514dfee7eeac08fac596464e3de86e7f370_prof);

    }

    // line 127
    public function block_notification($context, array $blocks = array())
    {
        $__internal_7742c426e2b1fcb042d3d1a050e43088aa2b18d09e01600b058b8c1bcac2a9c4 = $this->env->getExtension("native_profiler");
        $__internal_7742c426e2b1fcb042d3d1a050e43088aa2b18d09e01600b058b8c1bcac2a9c4->enter($__internal_7742c426e2b1fcb042d3d1a050e43088aa2b18d09e01600b058b8c1bcac2a9c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "notification"));

        // line 128
        echo "    ";
        if (twig_length_filter($this->env, (isset($context["hasErrors"]) ? $context["hasErrors"] : $this->getContext($context, "hasErrors")))) {
            // line 129
            echo "        <li data-state=\"error\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("form.validation_error", array(), "general"), "html", null, true);
            echo "</li>
    ";
        }
        // line 131
        echo "    ";
        $this->displayParentBlock("notification", $context, $blocks);
        echo "
";
        
        $__internal_7742c426e2b1fcb042d3d1a050e43088aa2b18d09e01600b058b8c1bcac2a9c4->leave($__internal_7742c426e2b1fcb042d3d1a050e43088aa2b18d09e01600b058b8c1bcac2a9c4_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ContentType:update_content_type.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  352 => 131,  346 => 129,  343 => 128,  337 => 127,  327 => 123,  321 => 120,  317 => 119,  313 => 118,  306 => 114,  302 => 113,  298 => 112,  291 => 108,  287 => 106,  277 => 103,  275 => 102,  272 => 101,  268 => 100,  264 => 99,  257 => 95,  253 => 94,  249 => 93,  242 => 89,  238 => 88,  234 => 87,  227 => 83,  223 => 82,  219 => 81,  212 => 77,  208 => 76,  204 => 75,  197 => 71,  193 => 70,  189 => 69,  182 => 65,  178 => 64,  174 => 63,  167 => 59,  163 => 58,  159 => 57,  152 => 53,  148 => 52,  144 => 51,  137 => 47,  133 => 46,  129 => 45,  122 => 41,  118 => 40,  113 => 37,  111 => 35,  110 => 34,  109 => 32,  104 => 29,  98 => 28,  88 => 24,  85 => 23,  79 => 22,  70 => 19,  67 => 18,  65 => 16,  63 => 13,  57 => 12,  47 => 9,  41 => 8,  34 => 1,  32 => 6,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* {# @var contentTypeDraft \eZ\Publish\API\Repository\Values\ContentType\ContentTypeDraft #}*/
/* */
/* {% trans_default_domain "content_type" %}*/
/* */
/* {% set edit_title = "content_type.edit_title"|trans({"%contentTypeName%": contentTypeName}, "ezrepoforms_content_type") %}*/
/* */
/* {% block title %}*/
/*     {{ edit_title }}*/
/* {% endblock %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path("admin_dashboard"), label: "dashboard.title"|trans({}, "dashboard")},*/
/*         {link: path("admin_contenttype"), label: "content_type.dashboard_title"|trans({}, "content_type")},*/
/*         {link: null, label: edit_title}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">*/
/*         {{ edit_title }}*/
/*     </h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/* */
/*         <p class="ez-technical-infos">*/
/*             {{*/
/*                 "content_type.last_modified"|trans({*/
/*                     "%date%": contentTypeDraft.modificationDate|localizeddate(locale=app.request.locale),*/
/*                     "%modifier%": modifier.login*/
/*                 })*/
/*             }}*/
/*         </p>*/
/* */
/*         {{ form_start(form, {"action": action_url, "attr": {"class": "pure-form pure-form-aligned"}}) }}*/
/*             {{ form_errors(form) }}*/
/* */
/*             <fieldset>*/
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.name) }}*/
/*                     {{ form_errors(form.name) }}*/
/*                     {{ form_widget(form.name) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.identifier) }}*/
/*                     {{ form_errors(form.identifier) }}*/
/*                     {{ form_widget(form.identifier) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.description) }}*/
/*                     {{ form_errors(form.description) }}*/
/*                     {{ form_widget(form.description) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.nameSchema) }}*/
/*                     {{ form_errors(form.nameSchema) }}*/
/*                     {{ form_widget(form.nameSchema) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.urlAliasSchema) }}*/
/*                     {{ form_errors(form.urlAliasSchema) }}*/
/*                     {{ form_widget(form.urlAliasSchema) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.isContainer) }}*/
/*                     {{ form_errors(form.isContainer) }}*/
/*                     {{ form_widget(form.isContainer) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.defaultSortField) }}*/
/*                     {{ form_errors(form.defaultSortField) }}*/
/*                     {{ form_widget(form.defaultSortField) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.defaultSortOrder) }}*/
/*                     {{ form_errors(form.defaultSortOrder) }}*/
/*                     {{ form_widget(form.defaultSortOrder) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.defaultAlwaysAvailable) }}*/
/*                     {{ form_errors(form.defaultAlwaysAvailable) }}*/
/*                     {{ form_widget(form.defaultAlwaysAvailable) }}*/
/*                 </div>*/
/*             </fieldset>*/
/* */
/*             <h2>{{ form_label(form.fieldDefinitionsData) }}</h2>*/
/*             {% for fieldDefForm in form.fieldDefinitionsData %}*/
/*                 <fieldset>*/
/*                     {% form_theme fieldDefForm "EzSystemsRepositoryFormsBundle:ContentType:field_definition_row.html.twig" %}*/
/*                     {{ form_row(fieldDefForm, {"contentTypeDraft": contentTypeDraft, "languageCode": languageCode, "group_class": "pure-control-group"}) }}*/
/*                 </fieldset>*/
/*             {% endfor %}*/
/* */
/*             <div class="pure-control-group">*/
/*                 {{ form_widget(form.removeFieldDefinition, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*             </div>*/
/* */
/*             <div class="pure-control-group">*/
/*                 {{ form_label(form.fieldTypeSelection) }}*/
/*                 {{ form_widget(form.fieldTypeSelection) }}*/
/*                 {{ form_widget(form.addFieldDefinition, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*             </div>*/
/* */
/*             <div class="pure-controls">*/
/*                 {{ form_widget(form.removeDraft, {"attr": {"class": "pure-button ez-button", "formnovalidate": "formnovalidate"}}) }}*/
/*                 {{ form_widget(form.saveContentType, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*                 {{ form_widget(form.publishContentType, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*             </div>*/
/* */
/*         {{ form_end(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block notification %}*/
/*     {% if hasErrors|length %}*/
/*         <li data-state="error">{{ "form.validation_error"|trans(domain="general") }}</li>*/
/*     {% endif %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
