<?php

/* EzPublishCoreBundle:default/block:block.html.twig */
class __TwigTemplate_6d653aacc8d0d65ae260e947baeecc8f5c90a02d99a87a54a84cb5050ee92c19 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_9ac33da6371a493aa6746861f44097595691412dbed3de88cff1058c97b927d7 = $this->env->getExtension("native_profiler");
        $__internal_9ac33da6371a493aa6746861f44097595691412dbed3de88cff1058c97b927d7->enter($__internal_9ac33da6371a493aa6746861f44097595691412dbed3de88cff1058c97b927d7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:default/block:block.html.twig"));

        // line 1
        echo "<div>
    <h3>Block ";
        // line 2
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "name", array()), "html", null, true);
        echo "</h3>
    <h3>Block view: ";
        // line 3
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["block"]) ? $context["block"] : $this->getContext($context, "block")), "view", array()), "html", null, true);
        echo "</h3>
</div>
";
        
        $__internal_9ac33da6371a493aa6746861f44097595691412dbed3de88cff1058c97b927d7->leave($__internal_9ac33da6371a493aa6746861f44097595691412dbed3de88cff1058c97b927d7_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/block:block.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  29 => 3,  25 => 2,  22 => 1,);
    }
}
/* <div>*/
/*     <h3>Block {{ block.name }}</h3>*/
/*     <h3>Block view: {{ block.view }}</h3>*/
/* </div>*/
/* */
