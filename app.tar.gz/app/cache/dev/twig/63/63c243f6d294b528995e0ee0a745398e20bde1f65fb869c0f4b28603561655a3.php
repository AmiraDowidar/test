<?php

/* WebProfilerBundle:Profiler:ajax_layout.html.twig */
class __TwigTemplate_40cc835d937f01e23f385c27fa814ae1b580b9eaaa8056b352e10f87c27e0563 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fb9fa62a4305ed31c16093b0ad312a9551da5f6b66cec609ab1149c0a7de0f83 = $this->env->getExtension("native_profiler");
        $__internal_fb9fa62a4305ed31c16093b0ad312a9551da5f6b66cec609ab1149c0a7de0f83->enter($__internal_fb9fa62a4305ed31c16093b0ad312a9551da5f6b66cec609ab1149c0a7de0f83_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "WebProfilerBundle:Profiler:ajax_layout.html.twig"));

        // line 1
        $this->displayBlock('panel', $context, $blocks);
        
        $__internal_fb9fa62a4305ed31c16093b0ad312a9551da5f6b66cec609ab1149c0a7de0f83->leave($__internal_fb9fa62a4305ed31c16093b0ad312a9551da5f6b66cec609ab1149c0a7de0f83_prof);

    }

    public function block_panel($context, array $blocks = array())
    {
        $__internal_2b0757ef6fac2712b65158925975fc3c6dd2eb03cbe9736dd93e2e72ae8917ac = $this->env->getExtension("native_profiler");
        $__internal_2b0757ef6fac2712b65158925975fc3c6dd2eb03cbe9736dd93e2e72ae8917ac->enter($__internal_2b0757ef6fac2712b65158925975fc3c6dd2eb03cbe9736dd93e2e72ae8917ac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        echo "";
        
        $__internal_2b0757ef6fac2712b65158925975fc3c6dd2eb03cbe9736dd93e2e72ae8917ac->leave($__internal_2b0757ef6fac2712b65158925975fc3c6dd2eb03cbe9736dd93e2e72ae8917ac_prof);

    }

    public function getTemplateName()
    {
        return "WebProfilerBundle:Profiler:ajax_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 1,);
    }
}
/* {% block panel '' %}*/
/* */
