<?php

/* @Framework/Form/collection_widget.html.php */
class __TwigTemplate_36a0959dd4b8dbd184dcad47df057f3e0071c5bddac61485700c74d0ae39bbd2 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_57290fa1491cdc6f3d29ed0b83c53b9850cc5b8d199b9ef21ba75ad116dcc060 = $this->env->getExtension("native_profiler");
        $__internal_57290fa1491cdc6f3d29ed0b83c53b9850cc5b8d199b9ef21ba75ad116dcc060->enter($__internal_57290fa1491cdc6f3d29ed0b83c53b9850cc5b8d199b9ef21ba75ad116dcc060_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/collection_widget.html.php"));

        // line 1
        echo "<?php if (isset(\$prototype)): ?>
    <?php \$attr['data-prototype'] = \$view->escape(\$view['form']->row(\$prototype)) ?>
<?php endif ?>
<?php echo \$view['form']->widget(\$form, array('attr' => \$attr)) ?>
";
        
        $__internal_57290fa1491cdc6f3d29ed0b83c53b9850cc5b8d199b9ef21ba75ad116dcc060->leave($__internal_57290fa1491cdc6f3d29ed0b83c53b9850cc5b8d199b9ef21ba75ad116dcc060_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/collection_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if (isset($prototype)): ?>*/
/*     <?php $attr['data-prototype'] = $view->escape($view['form']->row($prototype)) ?>*/
/* <?php endif ?>*/
/* <?php echo $view['form']->widget($form, array('attr' => $attr)) ?>*/
/* */
