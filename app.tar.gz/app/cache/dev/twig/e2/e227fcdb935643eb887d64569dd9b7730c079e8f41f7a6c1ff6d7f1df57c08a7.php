<?php

/* @Framework/Form/form_row.html.php */
class __TwigTemplate_a8f6c22fdfc8b95228e16940e5b011b011dcc674e1e2e444bf7db37eef54c090 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_18b2bec69689e921874ec3b3b1be5f08fbf402a388a525917e3de320a4e25270 = $this->env->getExtension("native_profiler");
        $__internal_18b2bec69689e921874ec3b3b1be5f08fbf402a388a525917e3de320a4e25270->enter($__internal_18b2bec69689e921874ec3b3b1be5f08fbf402a388a525917e3de320a4e25270_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_row.html.php"));

        // line 1
        echo "<div>
    <?php echo \$view['form']->label(\$form) ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php echo \$view['form']->widget(\$form) ?>
</div>
";
        
        $__internal_18b2bec69689e921874ec3b3b1be5f08fbf402a388a525917e3de320a4e25270->leave($__internal_18b2bec69689e921874ec3b3b1be5f08fbf402a388a525917e3de320a4e25270_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div>*/
/*     <?php echo $view['form']->label($form) ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php echo $view['form']->widget($form) ?>*/
/* </div>*/
/* */
