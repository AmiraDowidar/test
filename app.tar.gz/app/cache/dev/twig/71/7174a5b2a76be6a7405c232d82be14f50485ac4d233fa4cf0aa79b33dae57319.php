<?php

/* eZPlatformUIBundle::pjax.html.twig */
class __TwigTemplate_154b81ff5a461a552ec20612a2d89c7844b14b78b7f6ee7b633217a06eb4acd4 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_4a8876a082db8caa0dd07cb088a9a933d36c9d2693cfb1b9bf2ef89e3661d2cb = $this->env->getExtension("native_profiler");
        $__internal_4a8876a082db8caa0dd07cb088a9a933d36c9d2693cfb1b9bf2ef89e3661d2cb->enter($__internal_4a8876a082db8caa0dd07cb088a9a933d36c9d2693cfb1b9bf2ef89e3661d2cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle::pjax.html.twig"));

        // line 8
        echo "<div data-name=\"title\">";
        $this->displayBlock('title', $context, $blocks);
        echo "</div>
<div data-name=\"html\">";
        // line 9
        $this->displayBlock('content', $context, $blocks);
        echo "</div>
";
        
        $__internal_4a8876a082db8caa0dd07cb088a9a933d36c9d2693cfb1b9bf2ef89e3661d2cb->leave($__internal_4a8876a082db8caa0dd07cb088a9a933d36c9d2693cfb1b9bf2ef89e3661d2cb_prof);

    }

    // line 8
    public function block_title($context, array $blocks = array())
    {
        $__internal_6ced04add1b4f54b80998354ae1d3e5775b9fc2a82d13c03bcc07580a2b5e32f = $this->env->getExtension("native_profiler");
        $__internal_6ced04add1b4f54b80998354ae1d3e5775b9fc2a82d13c03bcc07580a2b5e32f->enter($__internal_6ced04add1b4f54b80998354ae1d3e5775b9fc2a82d13c03bcc07580a2b5e32f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_6ced04add1b4f54b80998354ae1d3e5775b9fc2a82d13c03bcc07580a2b5e32f->leave($__internal_6ced04add1b4f54b80998354ae1d3e5775b9fc2a82d13c03bcc07580a2b5e32f_prof);

    }

    // line 9
    public function block_content($context, array $blocks = array())
    {
        $__internal_07754e1f9cff6e76076ff6b1a642a2b7f37c60cff86df0a219aec3b7bfb20002 = $this->env->getExtension("native_profiler");
        $__internal_07754e1f9cff6e76076ff6b1a642a2b7f37c60cff86df0a219aec3b7bfb20002->enter($__internal_07754e1f9cff6e76076ff6b1a642a2b7f37c60cff86df0a219aec3b7bfb20002_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_07754e1f9cff6e76076ff6b1a642a2b7f37c60cff86df0a219aec3b7bfb20002->leave($__internal_07754e1f9cff6e76076ff6b1a642a2b7f37c60cff86df0a219aec3b7bfb20002_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle::pjax.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  49 => 9,  38 => 8,  29 => 9,  24 => 8,);
    }
}
/* {#*/
/*  # Generates an HTML like document to be used by the eZ.ServerSideViewService*/
/*  # JavaScript component*/
/*  # Template extending this one should implement two blocks:*/
/*  #   * title: to generate what will be used as the title of the web page*/
/*  #   * content: to generate the HTML code to put in the page*/
/*  #}*/
/* <div data-name="title">{% block title %}{% endblock %}</div>*/
/* <div data-name="html">{% block content %}{% endblock %}</div>*/
/* */
