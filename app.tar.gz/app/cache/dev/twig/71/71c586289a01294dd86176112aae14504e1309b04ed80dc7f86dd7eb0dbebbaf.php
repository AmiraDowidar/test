<?php

/* pagelayout.html.twig */
class __TwigTemplate_8c6aae8523ed3a4b92c49a0a0a3858fb55fd9f820b2cbf125b4bf5acb1aedbe5 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fee1dd67fad2a8eae5eced07fb4717fce3f8fff48549aa2cdc316dd36a978e35 = $this->env->getExtension("native_profiler");
        $__internal_fee1dd67fad2a8eae5eced07fb4717fce3f8fff48549aa2cdc316dd36a978e35->enter($__internal_fee1dd67fad2a8eae5eced07fb4717fce3f8fff48549aa2cdc316dd36a978e35_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "pagelayout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
    <head>

        <!-- Basic Page Needs
        –––––––––––––––––––––––––––––––––––––––––––––––––– -->
        <meta charset=\"utf-8\">
        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />
        <meta name=\"description\" content=\"\">
        <meta name=\"author\" content=\"\">
        ";
        // line 11
        if ((array_key_exists("content", $context) &&  !array_key_exists("title", $context))) {
            // line 12
            echo "            ";
            $context["title"] = $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")));
            // line 13
            echo "        ";
        }
        // line 14
        echo "        <title>";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans(((array_key_exists("title", $context)) ? (_twig_default_filter((isset($context["title"]) ? $context["title"] : $this->getContext($context, "title")), "Home")) : ("Home"))), "html", null, true);
        echo " - ";
        echo "Cheapest rates for international calls - Libon";
        echo "</title>

        <!-- Mobile Specific Metas
        –––––––––––––––––––––––––––––––––––––––––––––––––– -->
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">

        <meta name=\"theme-color\" content=\"#F16E00\">
        <meta name=\"msapplication-navbutton-color\" content=\"#F16E00\">
        <meta name=\"apple-mobile-web-app-status-bar-style\" content=\"#F16E00\">

        <!-- Load Libon favicon
        –––––––––––––––––––––––––––––––––––––––––––––––––– -->
        <link rel=\"Shortcut icon\" href=\"";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('asset')->getAssetUrl("assets/images/favicon.ico"), "html", null, true);
        echo "\" type=\"image/x-icon\" />


        <!-- FONTS CSS & scripts
        –––––––––––––––––––––––––––––––––––––––––––––––––– -->
        ";
        // line 31
        $this->loadTemplate("pagelayout_styles.html.twig", "pagelayout.html.twig", 31)->display($context);
        // line 32
        echo "        ";
        $this->loadTemplate("pagelayout_scripts.html.twig", "pagelayout.html.twig", 32)->display($context);
        // line 33
        echo "    </head>
    <body>

        ";
        // line 36
        $this->displayBlock('content', $context, $blocks);
        // line 37
        echo "       
        ";
        // line 38
        $this->loadTemplate("pagelayout_footer.html.twig", "pagelayout.html.twig", 38)->display($context);
        // line 39
        echo "
    </body>
</html>
";
        
        $__internal_fee1dd67fad2a8eae5eced07fb4717fce3f8fff48549aa2cdc316dd36a978e35->leave($__internal_fee1dd67fad2a8eae5eced07fb4717fce3f8fff48549aa2cdc316dd36a978e35_prof);

    }

    // line 36
    public function block_content($context, array $blocks = array())
    {
        $__internal_647dd95322c3f03172c92cc668147c5114ccc1e6085ffbfa25c8994d65b131c1 = $this->env->getExtension("native_profiler");
        $__internal_647dd95322c3f03172c92cc668147c5114ccc1e6085ffbfa25c8994d65b131c1->enter($__internal_647dd95322c3f03172c92cc668147c5114ccc1e6085ffbfa25c8994d65b131c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_647dd95322c3f03172c92cc668147c5114ccc1e6085ffbfa25c8994d65b131c1->leave($__internal_647dd95322c3f03172c92cc668147c5114ccc1e6085ffbfa25c8994d65b131c1_prof);

    }

    public function getTemplateName()
    {
        return "pagelayout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  96 => 36,  86 => 39,  84 => 38,  81 => 37,  79 => 36,  74 => 33,  71 => 32,  69 => 31,  61 => 26,  43 => 14,  40 => 13,  37 => 12,  35 => 11,  23 => 1,);
    }
}
/* <!DOCTYPE html>*/
/* <html lang="en">*/
/*     <head>*/
/* */
/*         <!-- Basic Page Needs*/
/*         –––––––––––––––––––––––––––––––––––––––––––––––––– -->*/
/*         <meta charset="utf-8">*/
/*         <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />*/
/*         <meta name="description" content="">*/
/*         <meta name="author" content="">*/
/*         {% if content is defined and title is not defined %}*/
/*             {% set title = ez_content_name(content) %}*/
/*         {% endif %}*/
/*         <title>{{ title|default('Home')|trans }} - {{ 'Cheapest rates for international calls - Libon' }}</title>*/
/* */
/*         <!-- Mobile Specific Metas*/
/*         –––––––––––––––––––––––––––––––––––––––––––––––––– -->*/
/*         <meta name="viewport" content="width=device-width, initial-scale=1">*/
/* */
/*         <meta name="theme-color" content="#F16E00">*/
/*         <meta name="msapplication-navbutton-color" content="#F16E00">*/
/*         <meta name="apple-mobile-web-app-status-bar-style" content="#F16E00">*/
/* */
/*         <!-- Load Libon favicon*/
/*         –––––––––––––––––––––––––––––––––––––––––––––––––– -->*/
/*         <link rel="Shortcut icon" href="{{ asset('assets/images/favicon.ico') }}" type="image/x-icon" />*/
/* */
/* */
/*         <!-- FONTS CSS & scripts*/
/*         –––––––––––––––––––––––––––––––––––––––––––––––––– -->*/
/*         {% include 'pagelayout_styles.html.twig' %}*/
/*         {% include 'pagelayout_scripts.html.twig' %}*/
/*     </head>*/
/*     <body>*/
/* */
/*         {% block content %}{% endblock %}*/
/*        */
/*         {% include 'pagelayout_footer.html.twig' %}*/
/* */
/*     </body>*/
/* </html>*/
/* */
