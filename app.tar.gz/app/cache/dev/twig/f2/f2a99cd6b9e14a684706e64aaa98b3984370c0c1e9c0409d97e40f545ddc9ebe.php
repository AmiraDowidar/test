<?php

/* EzPublishCoreBundle:FieldType/RichText/embed:location_inline_denied.html.twig */
class __TwigTemplate_4b67d485d22ee110659fd0a51a17e9fb763a3c3072411e7a2d63306938398691 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_362a4c4a5eb8708e4b424c971cd7bbcbd01941323abac6edf6a312c3fe02f3fc = $this->env->getExtension("native_profiler");
        $__internal_362a4c4a5eb8708e4b424c971cd7bbcbd01941323abac6edf6a312c3fe02f3fc->enter($__internal_362a4c4a5eb8708e4b424c971cd7bbcbd01941323abac6edf6a312c3fe02f3fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:FieldType/RichText/embed:location_inline_denied.html.twig"));

        // line 1
        echo "[[ Location #";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "id", array()), "html", null, true);
        echo ": You do not have permission to view this Location ]]
";
        
        $__internal_362a4c4a5eb8708e4b424c971cd7bbcbd01941323abac6edf6a312c3fe02f3fc->leave($__internal_362a4c4a5eb8708e4b424c971cd7bbcbd01941323abac6edf6a312c3fe02f3fc_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/embed:location_inline_denied.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* [[ Location #{{ embedParams.id }}: You do not have permission to view this Location ]]*/
/* */
