<?php

/* @Framework/FormTable/hidden_row.html.php */
class __TwigTemplate_394ddd3a479400a25e651d135e6b7a8200d28ac6ca6cd4a2cc63c22a2749ce7c extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f337c12f409503539bab1c2fe3f1c2dbb0de3884a7aa4cd062b017ef1ff12aa = $this->env->getExtension("native_profiler");
        $__internal_5f337c12f409503539bab1c2fe3f1c2dbb0de3884a7aa4cd062b017ef1ff12aa->enter($__internal_5f337c12f409503539bab1c2fe3f1c2dbb0de3884a7aa4cd062b017ef1ff12aa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/hidden_row.html.php"));

        // line 1
        echo "<tr style=\"display: none\">
    <td colspan=\"2\">
        <?php echo \$view['form']->widget(\$form) ?>
    </td>
</tr>
";
        
        $__internal_5f337c12f409503539bab1c2fe3f1c2dbb0de3884a7aa4cd062b017ef1ff12aa->leave($__internal_5f337c12f409503539bab1c2fe3f1c2dbb0de3884a7aa4cd062b017ef1ff12aa_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <tr style="display: none">*/
/*     <td colspan="2">*/
/*         <?php echo $view['form']->widget($form) ?>*/
/*     </td>*/
/* </tr>*/
/* */
