<?php

/* eZPlatformUIBundle:SystemInfo:info.html.twig */
class __TwigTemplate_fbf9246886597ea2ed4edb944d9becdfa89bb606f510adcb8b561dac2107ee81 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:SystemInfo:info.html.twig", 1);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_15982acb95a0fd4ecc7670a39e4aef54e559bba6a149f2c7c7dc0c92b87688b8 = $this->env->getExtension("native_profiler");
        $__internal_15982acb95a0fd4ecc7670a39e4aef54e559bba6a149f2c7c7dc0c92b87688b8->enter($__internal_15982acb95a0fd4ecc7670a39e4aef54e559bba6a149f2c7c7dc0c92b87688b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:SystemInfo:info.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_15982acb95a0fd4ecc7670a39e4aef54e559bba6a149f2c7c7dc0c92b87688b8->leave($__internal_15982acb95a0fd4ecc7670a39e4aef54e559bba6a149f2c7c7dc0c92b87688b8_prof);

    }

    // line 5
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_ef97dba50e7e7628e3525714e7085d7bdd59cd6a4be792b84c8ffdab1e7ecb03 = $this->env->getExtension("native_profiler");
        $__internal_ef97dba50e7e7628e3525714e7085d7bdd59cd6a4be792b84c8ffdab1e7ecb03->enter($__internal_ef97dba50e7e7628e3525714e7085d7bdd59cd6a4be792b84c8ffdab1e7ecb03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 6
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => "", "label" => $this->env->getExtension('translator')->trans("system.information", array(), "systeminfo")));
        // line 10
        echo "
    ";
        // line 11
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_ef97dba50e7e7628e3525714e7085d7bdd59cd6a4be792b84c8ffdab1e7ecb03->leave($__internal_ef97dba50e7e7628e3525714e7085d7bdd59cd6a4be792b84c8ffdab1e7ecb03_prof);

    }

    // line 14
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_ddb491d5e012ec4b6e856dfb6b2739b122a0ea9fcb86a74e2d7af524bf285e3c = $this->env->getExtension("native_profiler");
        $__internal_ddb491d5e012ec4b6e856dfb6b2739b122a0ea9fcb86a74e2d7af524bf285e3c->enter($__internal_ddb491d5e012ec4b6e856dfb6b2739b122a0ea9fcb86a74e2d7af524bf285e3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 15
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe617\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("system.information", array(), "systeminfo"), "html", null, true);
        echo "</h1>
";
        
        $__internal_ddb491d5e012ec4b6e856dfb6b2739b122a0ea9fcb86a74e2d7af524bf285e3c->leave($__internal_ddb491d5e012ec4b6e856dfb6b2739b122a0ea9fcb86a74e2d7af524bf285e3c_prof);

    }

    // line 18
    public function block_content($context, array $blocks = array())
    {
        $__internal_ee0b23edb7184d97375467ed3e29e654a7116a434f04c9a0b3c8de62eee9864a = $this->env->getExtension("native_profiler");
        $__internal_ee0b23edb7184d97375467ed3e29e654a7116a434f04c9a0b3c8de62eee9864a->enter($__internal_ee0b23edb7184d97375467ed3e29e654a7116a434f04c9a0b3c8de62eee9864a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 19
        echo "    <section class=\"ez-tabs ez-serverside-content\">

        <ul class=\"ez-tabs-list\">
            ";
        // line 22
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["collector_identifiers"]) ? $context["collector_identifiers"] : $this->getContext($context, "collector_identifiers")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["collector_identifier"]) {
            // line 23
            echo "                <li class=\"ez-tabs-label";
            if ($this->getAttribute($context["loop"], "first", array())) {
                echo " is-tab-selected";
            }
            echo "\"><a href=\"#ez-tabs-";
            echo twig_escape_filter($this->env, $context["collector_identifier"], "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($context["collector_identifier"], array(), "systeminfo"), "html", null, true);
            echo "</a></li>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['collector_identifier'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "        </ul>

        <div class=\"ez-tabs-panels\">
            ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["collector_identifiers"]) ? $context["collector_identifiers"] : $this->getContext($context, "collector_identifiers")));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["collector_identifier"]) {
            // line 29
            echo "                <div class=\"ez-tabs-panel";
            if ($this->getAttribute($context["loop"], "first", array())) {
                echo " is-tab-selected";
            }
            echo "\" id=\"ez-tabs-";
            echo twig_escape_filter($this->env, $context["collector_identifier"], "html", null, true);
            echo "\">
                    ";
            // line 30
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("support_tools.view.controller:viewInfoAction", array("systemInfoIdentifier" =>             // line 32
$context["collector_identifier"], "viewType" => "pjax_tab")));
            // line 34
            echo "
                </div>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['collector_identifier'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 37
        echo "        </div>

    </section>
";
        
        $__internal_ee0b23edb7184d97375467ed3e29e654a7116a434f04c9a0b3c8de62eee9864a->leave($__internal_ee0b23edb7184d97375467ed3e29e654a7116a434f04c9a0b3c8de62eee9864a_prof);

    }

    // line 42
    public function block_title($context, array $blocks = array())
    {
        $__internal_3f295afc74982736d3a337b665395782d6af2f9cf97a76f688b82f72fe17d1dc = $this->env->getExtension("native_profiler");
        $__internal_3f295afc74982736d3a337b665395782d6af2f9cf97a76f688b82f72fe17d1dc->enter($__internal_3f295afc74982736d3a337b665395782d6af2f9cf97a76f688b82f72fe17d1dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("system.information", array(), "systeminfo"), "html", null, true);
        
        $__internal_3f295afc74982736d3a337b665395782d6af2f9cf97a76f688b82f72fe17d1dc->leave($__internal_3f295afc74982736d3a337b665395782d6af2f9cf97a76f688b82f72fe17d1dc_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:SystemInfo:info.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  185 => 42,  175 => 37,  159 => 34,  157 => 32,  156 => 30,  147 => 29,  130 => 28,  125 => 25,  102 => 23,  85 => 22,  80 => 19,  74 => 18,  64 => 15,  58 => 14,  49 => 11,  46 => 10,  43 => 6,  37 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "systeminfo" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: '', label: 'system.information'|trans({}, 'systeminfo') },*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe617">{{ 'system.information'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-tabs ez-serverside-content">*/
/* */
/*         <ul class="ez-tabs-list">*/
/*             {% for collector_identifier in collector_identifiers %}*/
/*                 <li class="ez-tabs-label{% if loop.first %} is-tab-selected{% endif %}"><a href="#ez-tabs-{{ collector_identifier }}">{{ collector_identifier|trans }}</a></li>*/
/*             {% endfor %}*/
/*         </ul>*/
/* */
/*         <div class="ez-tabs-panels">*/
/*             {% for collector_identifier in collector_identifiers %}*/
/*                 <div class="ez-tabs-panel{% if loop.first %} is-tab-selected{% endif %}" id="ez-tabs-{{ collector_identifier }}">*/
/*                     {{ render( controller(*/
/*                     'support_tools.view.controller:viewInfoAction', {*/
/*                         'systemInfoIdentifier': collector_identifier,*/
/*                         'viewType': 'pjax_tab'*/
/*                     } ) ) }}*/
/*                 </div>*/
/*             {% endfor %}*/
/*         </div>*/
/* */
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{'system.information'|trans }}{% endblock %}*/
/* */
