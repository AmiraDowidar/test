<?php

/* EzPublishCoreBundle:FieldType/RichText/embed:content_inline_denied.html.twig */
class __TwigTemplate_c8cc074a98e715d6665083a98222d2b997acecd6948cf17da37bae9710ae5286 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6a64c754e53d9d409d1a0b7c83642cf7551cc68f76105b140881581cbac7aebe = $this->env->getExtension("native_profiler");
        $__internal_6a64c754e53d9d409d1a0b7c83642cf7551cc68f76105b140881581cbac7aebe->enter($__internal_6a64c754e53d9d409d1a0b7c83642cf7551cc68f76105b140881581cbac7aebe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:FieldType/RichText/embed:content_inline_denied.html.twig"));

        // line 1
        echo "[[ Content #";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["embedParams"]) ? $context["embedParams"] : $this->getContext($context, "embedParams")), "id", array()), "html", null, true);
        echo ": You do not have permission to view this Content ]]
";
        
        $__internal_6a64c754e53d9d409d1a0b7c83642cf7551cc68f76105b140881581cbac7aebe->leave($__internal_6a64c754e53d9d409d1a0b7c83642cf7551cc68f76105b140881581cbac7aebe_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:FieldType/RichText/embed:content_inline_denied.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* [[ Content #{{ embedParams.id }}: You do not have permission to view this Content ]]*/
/* */
