<?php

/* @Framework/Form/range_widget.html.php */
class __TwigTemplate_5e81bcaaf8b197896ca70c7c18fd2e4efa138f0ac62252521534b42eecdaa85b extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_ca180bebec5e6e51344b28973af10631242b195c10d7b3e0e83f92fed5bbcbb2 = $this->env->getExtension("native_profiler");
        $__internal_ca180bebec5e6e51344b28973af10631242b195c10d7b3e0e83f92fed5bbcbb2->enter($__internal_ca180bebec5e6e51344b28973af10631242b195c10d7b3e0e83f92fed5bbcbb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/range_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'range'));
";
        
        $__internal_ca180bebec5e6e51344b28973af10631242b195c10d7b3e0e83f92fed5bbcbb2->leave($__internal_ca180bebec5e6e51344b28973af10631242b195c10d7b3e0e83f92fed5bbcbb2_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/range_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'range'));*/
/* */
