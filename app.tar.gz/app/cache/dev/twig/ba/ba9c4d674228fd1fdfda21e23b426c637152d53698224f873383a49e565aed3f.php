<?php

/* EzSystemsRepositoryFormsBundle:content_name:content_name.html.twig */
class __TwigTemplate_0bcf2ed694fec80944d81f13d491c2398ef7a089a519a17e8dae9b647bd492ca extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((isset($context["viewbaseLayout"]) ? $context["viewbaseLayout"] : $this->getContext($context, "viewbaseLayout")), "EzSystemsRepositoryFormsBundle:content_name:content_name.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_caafcb17f5569de08e2467246072faa0b743b9ea92f1ae952eecdac3804b956d = $this->env->getExtension("native_profiler");
        $__internal_caafcb17f5569de08e2467246072faa0b743b9ea92f1ae952eecdac3804b956d->enter($__internal_caafcb17f5569de08e2467246072faa0b743b9ea92f1ae952eecdac3804b956d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzSystemsRepositoryFormsBundle:content_name:content_name.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_caafcb17f5569de08e2467246072faa0b743b9ea92f1ae952eecdac3804b956d->leave($__internal_caafcb17f5569de08e2467246072faa0b743b9ea92f1ae952eecdac3804b956d_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_2990a5be31225db976c62496ea24720494f6fbd0df9568cb1a89831cd910121a = $this->env->getExtension("native_profiler");
        $__internal_2990a5be31225db976c62496ea24720494f6fbd0df9568cb1a89831cd910121a->enter($__internal_2990a5be31225db976c62496ea24720494f6fbd0df9568cb1a89831cd910121a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content"))), "html", null, true);
        echo "
";
        
        $__internal_2990a5be31225db976c62496ea24720494f6fbd0df9568cb1a89831cd910121a->leave($__internal_2990a5be31225db976c62496ea24720494f6fbd0df9568cb1a89831cd910121a_prof);

    }

    public function getTemplateName()
    {
        return "EzSystemsRepositoryFormsBundle:content_name:content_name.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  39 => 3,  33 => 2,  18 => 1,);
    }
}
/* {% extends viewbaseLayout %}*/
/* {% block content %}*/
/* {{ ez_content_name( content ) }}*/
/* {% endblock %}*/
/* */
