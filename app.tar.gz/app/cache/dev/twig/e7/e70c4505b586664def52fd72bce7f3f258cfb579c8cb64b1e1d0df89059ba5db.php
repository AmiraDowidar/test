<?php

/* eZPlatformUIBundle:ez-support-tools/info:symfony_kernel.html.twig */
class __TwigTemplate_aef80dcd9ef56f2f6953c842b3d2985759e8f175839b0f8d3951790cf1371a18 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_281ea9f2f6b926c4c783e74bffb349321a71f1cc567dfecedc6b117717ef2f45 = $this->env->getExtension("native_profiler");
        $__internal_281ea9f2f6b926c4c783e74bffb349321a71f1cc567dfecedc6b117717ef2f45->enter($__internal_281ea9f2f6b926c4c783e74bffb349321a71f1cc567dfecedc6b117717ef2f45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:ez-support-tools/info:symfony_kernel.html.twig"));

        // line 2
        echo "
<h1>";
        // line 3
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel", array(), "systeminfo"), "html", null, true);
        echo "</h1>
<dl>
    <dt>";
        // line 5
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.environment", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 6
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "environment", array()), "html", null, true);
        echo "</dd>
    <dt>";
        // line 7
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.debugMode", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 8
        if ($this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "debugMode", array())) {
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.debugMode.enabled", array(), "systeminfo"), "html", null, true);
        } else {
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.debugMode.disabled", array(), "systeminfo"), "html", null, true);
        }
        echo "</dd>
    <dt>";
        // line 9
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.version", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 10
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "version", array()), "html", null, true);
        echo "</dd>
    <dt>";
        // line 11
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.name", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "name", array()), "html", null, true);
        echo "</dd>
    <dt>";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.rootDir", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 14
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "rootDir", array()), "html", null, true);
        echo "</dd>
    <dt>";
        // line 15
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.cacheDir", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "cacheDir", array()), "html", null, true);
        echo "</dd>
    <dt>";
        // line 17
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.logDir", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 18
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "logDir", array()), "html", null, true);
        echo "</dd>
    <dt>";
        // line 19
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.charset", array(), "systeminfo"), "html", null, true);
        echo "</dt>
    <dd>";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "charset", array()), "html", null, true);
        echo "</dd>

    ";
        // line 22
        if (twig_test_empty($this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "bundles", array()))) {
            // line 23
            echo "        <dt>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("bundles", array(), "systeminfo"), "html", null, true);
            echo "</dt>
        <dd>";
            // line 24
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("symfony_kernel.bundles.empty", array(), "systeminfo"), "html", null, true);
            echo "</dd>
    ";
        }
        // line 26
        echo "</dl>

";
        // line 28
        if ( !twig_test_empty($this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "bundles", array()))) {
            // line 29
            echo "    <h2>";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("bundles", array(), "systeminfo"), "html", null, true);
            echo "</h2>
    <dl>
        ";
            // line 31
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["info"]) ? $context["info"] : $this->getContext($context, "info")), "bundles", array()));
            foreach ($context['_seq'] as $context["bundle"] => $context["namespace"]) {
                // line 32
                echo "            <dt>";
                echo twig_escape_filter($this->env, $context["bundle"], "html", null, true);
                echo "</dt>
            <dd>";
                // line 33
                echo twig_escape_filter($this->env, $context["namespace"], "html", null, true);
                echo "</dd>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['bundle'], $context['namespace'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 35
            echo "    </dl>
";
        }
        
        $__internal_281ea9f2f6b926c4c783e74bffb349321a71f1cc567dfecedc6b117717ef2f45->leave($__internal_281ea9f2f6b926c4c783e74bffb349321a71f1cc567dfecedc6b117717ef2f45_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ez-support-tools/info:symfony_kernel.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  140 => 35,  132 => 33,  127 => 32,  123 => 31,  117 => 29,  115 => 28,  111 => 26,  106 => 24,  101 => 23,  99 => 22,  94 => 20,  90 => 19,  86 => 18,  82 => 17,  78 => 16,  74 => 15,  70 => 14,  66 => 13,  62 => 12,  58 => 11,  54 => 10,  50 => 9,  42 => 8,  38 => 7,  34 => 6,  30 => 5,  25 => 3,  22 => 2,);
    }
}
/* {% trans_default_domain "systeminfo" %}*/
/* */
/* <h1>{{ 'symfony_kernel'|trans }}</h1>*/
/* <dl>*/
/*     <dt>{{ 'symfony_kernel.environment'|trans }}</dt>*/
/*     <dd>{{ info.environment }}</dd>*/
/*     <dt>{{ 'symfony_kernel.debugMode'|trans }}</dt>*/
/*     <dd>{% if info.debugMode %}{{ 'symfony_kernel.debugMode.enabled'|trans }}{% else %}{{ 'symfony_kernel.debugMode.disabled'|trans }}{% endif %}</dd>*/
/*     <dt>{{ 'symfony_kernel.version'|trans }}</dt>*/
/*     <dd>{{ info.version }}</dd>*/
/*     <dt>{{ 'symfony_kernel.name'|trans }}</dt>*/
/*     <dd>{{ info.name }}</dd>*/
/*     <dt>{{ 'symfony_kernel.rootDir'|trans }}</dt>*/
/*     <dd>{{ info.rootDir }}</dd>*/
/*     <dt>{{ 'symfony_kernel.cacheDir'|trans }}</dt>*/
/*     <dd>{{ info.cacheDir }}</dd>*/
/*     <dt>{{ 'symfony_kernel.logDir'|trans }}</dt>*/
/*     <dd>{{ info.logDir }}</dd>*/
/*     <dt>{{ 'symfony_kernel.charset'|trans }}</dt>*/
/*     <dd>{{ info.charset }}</dd>*/
/* */
/*     {% if info.bundles is empty %}*/
/*         <dt>{{ 'bundles'|trans }}</dt>*/
/*         <dd>{{ 'symfony_kernel.bundles.empty'|trans }}</dd>*/
/*     {% endif %}*/
/* </dl>*/
/* */
/* {% if info.bundles is not empty %}*/
/*     <h2>{{ 'bundles'|trans }}</h2>*/
/*     <dl>*/
/*         {% for bundle, namespace in info.bundles %}*/
/*             <dt>{{ bundle }}</dt>*/
/*             <dd>{{ namespace }}</dd>*/
/*         {% endfor %}*/
/*     </dl>*/
/* {% endif %}*/
/* */
