<?php

/* AppBundle:Homepage:getAllRides.html.twig */
class __TwigTemplate_80f310bcfddc969eae26c6ce3aee183a143e47abbe2955618a6c2e3bfe76c758 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppBundle:Homepage:getAllRides.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1920542ddeeab0bc4d7c37a553a288010d09ccfc70aa381591246b037242849a = $this->env->getExtension("native_profiler");
        $__internal_1920542ddeeab0bc4d7c37a553a288010d09ccfc70aa381591246b037242849a->enter($__internal_1920542ddeeab0bc4d7c37a553a288010d09ccfc70aa381591246b037242849a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Homepage:getAllRides.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1920542ddeeab0bc4d7c37a553a288010d09ccfc70aa381591246b037242849a->leave($__internal_1920542ddeeab0bc4d7c37a553a288010d09ccfc70aa381591246b037242849a_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_4f33cd39dc052d78e652589a918bfc91688c122b8959d21fedf99cd27cde3052 = $this->env->getExtension("native_profiler");
        $__internal_4f33cd39dc052d78e652589a918bfc91688c122b8959d21fedf99cd27cde3052->enter($__internal_4f33cd39dc052d78e652589a918bfc91688c122b8959d21fedf99cd27cde3052_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "AppBundle:Homepage:getAllRides";
        
        $__internal_4f33cd39dc052d78e652589a918bfc91688c122b8959d21fedf99cd27cde3052->leave($__internal_4f33cd39dc052d78e652589a918bfc91688c122b8959d21fedf99cd27cde3052_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_ab193ba2a4f0852b64847baf27d4db560723e15430418d28112ccaf2c2f5493c = $this->env->getExtension("native_profiler");
        $__internal_ab193ba2a4f0852b64847baf27d4db560723e15430418d28112ccaf2c2f5493c->enter($__internal_ab193ba2a4f0852b64847baf27d4db560723e15430418d28112ccaf2c2f5493c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "<h1>Welcome to the Homepage:getAllRides page</h1>
";
        
        $__internal_ab193ba2a4f0852b64847baf27d4db560723e15430418d28112ccaf2c2f5493c->leave($__internal_ab193ba2a4f0852b64847baf27d4db560723e15430418d28112ccaf2c2f5493c_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Homepage:getAllRides.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends "::base.html.twig" %}*/
/* */
/* {% block title %}AppBundle:Homepage:getAllRides{% endblock %}*/
/* */
/* {% block content %}*/
/* <h1>Welcome to the Homepage:getAllRides page</h1>*/
/* {% endblock %}*/
/* */
