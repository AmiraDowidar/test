<?php

/* @Framework/Form/email_widget.html.php */
class __TwigTemplate_fe2fa1a6c20de1f2f18c59111a07743940a039f7c999a72465fbd9308f67d7a2 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e0fdc72b03c18f5a523a3fcaabbf53f5d17163af5ef61008414757f71ec335cf = $this->env->getExtension("native_profiler");
        $__internal_e0fdc72b03c18f5a523a3fcaabbf53f5d17163af5ef61008414757f71ec335cf->enter($__internal_e0fdc72b03c18f5a523a3fcaabbf53f5d17163af5ef61008414757f71ec335cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/email_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple', array('type' => isset(\$type) ? \$type : 'email')) ?>
";
        
        $__internal_e0fdc72b03c18f5a523a3fcaabbf53f5d17163af5ef61008414757f71ec335cf->leave($__internal_e0fdc72b03c18f5a523a3fcaabbf53f5d17163af5ef61008414757f71ec335cf_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/email_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple', array('type' => isset($type) ? $type : 'email')) ?>*/
/* */
