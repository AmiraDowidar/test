<?php

/* :line:point_of_interest.html.twig */
class __TwigTemplate_c385ef779fb9530fb5d2fb38d27b072c260c01cbcea8023cb8d31d08cc62c355 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_eaf509981e29234246c437b0c776c83ae30f22f6017e1017b7db46c2480e252f = $this->env->getExtension("native_profiler");
        $__internal_eaf509981e29234246c437b0c776c83ae30f22f6017e1017b7db46c2480e252f->enter($__internal_eaf509981e29234246c437b0c776c83ae30f22f6017e1017b7db46c2480e252f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", ":line:point_of_interest.html.twig"));

        // line 1
        echo "point_of_interest.html.twig";
        
        $__internal_eaf509981e29234246c437b0c776c83ae30f22f6017e1017b7db46c2480e252f->leave($__internal_eaf509981e29234246c437b0c776c83ae30f22f6017e1017b7db46c2480e252f_prof);

    }

    public function getTemplateName()
    {
        return ":line:point_of_interest.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* point_of_interest.html.twig*/
