<?php

/* eZPlatformUIBundle:Language:edit.html.twig */
class __TwigTemplate_4b7902a380a5b31904aa95b759bc89e0edffe1128e095303934e49bf96d3d7ef extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Language:edit.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_78a23ef45c506ff14561ad4473008ad0b0a808fb2b838281ae39d173d487922f = $this->env->getExtension("native_profiler");
        $__internal_78a23ef45c506ff14561ad4473008ad0b0a808fb2b838281ae39d173d487922f->enter($__internal_78a23ef45c506ff14561ad4473008ad0b0a808fb2b838281ae39d173d487922f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Language:edit.html.twig"));

        // line 5
        $context["editTitle"] = (($this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "new", array())) ? ($this->env->getExtension('translator')->trans("language.create.title", array(), "language")) : ($this->env->getExtension('translator')->trans("language.edit.title", array("%languageName%" => $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "name", array())), "language")));
        // line 1
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_78a23ef45c506ff14561ad4473008ad0b0a808fb2b838281ae39d173d487922f->leave($__internal_78a23ef45c506ff14561ad4473008ad0b0a808fb2b838281ae39d173d487922f_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_cee4388d02c4b1f0f4843482091d811beedc0743881427eb212583ccedad64c2 = $this->env->getExtension("native_profiler");
        $__internal_cee4388d02c4b1f0f4843482091d811beedc0743881427eb212583ccedad64c2->enter($__internal_cee4388d02c4b1f0f4843482091d811beedc0743881427eb212583ccedad64c2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, (isset($context["editTitle"]) ? $context["editTitle"] : $this->getContext($context, "editTitle")), "html", null, true);
        echo "
";
        
        $__internal_cee4388d02c4b1f0f4843482091d811beedc0743881427eb212583ccedad64c2->leave($__internal_cee4388d02c4b1f0f4843482091d811beedc0743881427eb212583ccedad64c2_prof);

    }

    // line 11
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_884edc67227ae23510b94783bb813974b61f88d5054dcdb595d3eaee193d67ad = $this->env->getExtension("native_profiler");
        $__internal_884edc67227ae23510b94783bb813974b61f88d5054dcdb595d3eaee193d67ad->enter($__internal_884edc67227ae23510b94783bb813974b61f88d5054dcdb595d3eaee193d67ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 12
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_languagelist"), "label" => $this->env->getExtension('translator')->trans("language.list", array(), "language")), 2 => array("link" => (($this->getAttribute(        // line 16
(isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "new", array())) ? ("") : ($this->env->getExtension('routing')->getPath("admin_languageview", array("languageId" => $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "id", array()))))), "label" => $this->env->getExtension('translator')->trans("language.view.title", array("%languageName%" => $this->getAttribute(        // line 17
(isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "name", array())), "language")), 3 => array("link" => "", "label" =>         // line 19
(isset($context["editTitle"]) ? $context["editTitle"] : $this->getContext($context, "editTitle"))));
        // line 21
        echo "
    ";
        // line 22
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_884edc67227ae23510b94783bb813974b61f88d5054dcdb595d3eaee193d67ad->leave($__internal_884edc67227ae23510b94783bb813974b61f88d5054dcdb595d3eaee193d67ad_prof);

    }

    // line 25
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_f41a7b7e82746dc49b9f7f152c029f62a482c600b43ac44c37642e5e6bef9675 = $this->env->getExtension("native_profiler");
        $__internal_f41a7b7e82746dc49b9f7f152c029f62a482c600b43ac44c37642e5e6bef9675->enter($__internal_f41a7b7e82746dc49b9f7f152c029f62a482c600b43ac44c37642e5e6bef9675_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 26
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">
        ";
        // line 27
        echo twig_escape_filter($this->env, (isset($context["editTitle"]) ? $context["editTitle"] : $this->getContext($context, "editTitle")), "html", null, true);
        echo "
    </h1>
";
        
        $__internal_f41a7b7e82746dc49b9f7f152c029f62a482c600b43ac44c37642e5e6bef9675->leave($__internal_f41a7b7e82746dc49b9f7f152c029f62a482c600b43ac44c37642e5e6bef9675_prof);

    }

    // line 31
    public function block_content($context, array $blocks = array())
    {
        $__internal_bfbe8edcd1bd60573ac254f9742f9c3c28215acc0030d2082f70a3c128b9e58b = $this->env->getExtension("native_profiler");
        $__internal_bfbe8edcd1bd60573ac254f9742f9c3c28215acc0030d2082f70a3c128b9e58b->enter($__internal_bfbe8edcd1bd60573ac254f9742f9c3c28215acc0030d2082f70a3c128b9e58b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 32
        echo "    <section class=\"ez-serverside-content\">
        ";
        // line 33
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_start', array("action" => (isset($context["actionUrl"]) ? $context["actionUrl"] : $this->getContext($context, "actionUrl")), "attr" => array("class" => "pure-form pure-form-aligned")));
        echo "
            ";
        // line 34
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'errors');
        echo "

            <fieldset>
                <div class=\"pure-control-group\">
                    ";
        // line 38
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'label');
        echo "
                    ";
        // line 39
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'errors');
        echo "
                    ";
        // line 40
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "name", array()), 'widget');
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 44
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "languageCode", array()), 'label');
        echo "
                    ";
        // line 45
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "languageCode", array()), 'errors');
        echo "
                    ";
        // line 46
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "languageCode", array()), 'widget', array("disabled" =>  !$this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "new", array())));
        echo "
                </div>

                <div class=\"pure-control-group\">
                    ";
        // line 50
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "enabled", array()), 'label');
        echo "
                    ";
        // line 51
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "enabled", array()), 'errors');
        echo "
                    ";
        // line 52
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "enabled", array()), 'widget');
        echo "
                </div>
            </fieldset>

            <div class=\"pure-controls\">
                <a href=\"";
        // line 57
        echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "new", array())) ? ($this->env->getExtension('routing')->getPath("admin_languagelist")) : ($this->env->getExtension('routing')->getPath("admin_languageview", array("languageId" => $this->getAttribute((isset($context["language"]) ? $context["language"] : $this->getContext($context, "language")), "id", array()))))), "html", null, true);
        echo "\"
                   class=\"pure-button ez-button\">";
        // line 58
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("language.cancel", array(), "language"), "html", null, true);
        echo "</a>
                ";
        // line 59
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "save", array()), 'widget', array("attr" => array("class" => "pure-button ez-button")));
        echo "
            </div>

        ";
        // line 62
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'form_end');
        echo "
    </section>
";
        
        $__internal_bfbe8edcd1bd60573ac254f9742f9c3c28215acc0030d2082f70a3c128b9e58b->leave($__internal_bfbe8edcd1bd60573ac254f9742f9c3c28215acc0030d2082f70a3c128b9e58b_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Language:edit.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  179 => 62,  173 => 59,  169 => 58,  165 => 57,  157 => 52,  153 => 51,  149 => 50,  142 => 46,  138 => 45,  134 => 44,  127 => 40,  123 => 39,  119 => 38,  112 => 34,  108 => 33,  105 => 32,  99 => 31,  89 => 27,  86 => 26,  80 => 25,  71 => 22,  68 => 21,  66 => 19,  65 => 17,  64 => 16,  62 => 12,  56 => 11,  46 => 8,  40 => 7,  33 => 1,  31 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "language" %}*/
/* */
/* {% set editTitle = language.new ? "language.create.title"|trans() : "language.edit.title"|trans({"%languageName%": language.name}) %}*/
/* */
/* {% block title %}*/
/*     {{ editTitle }}*/
/* {% endblock %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_languagelist'), label: 'language.list'|trans({})},*/
/*         {*/
/*             link: language.new ? "" : path('admin_languageview', {'languageId': language.id}),*/
/*             label: 'language.view.title'|trans({'%languageName%': language.name})*/
/*         },*/
/*         {link: '', label: editTitle}*/
/*     ] %}*/
/* */
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">*/
/*         {{ editTitle }}*/
/*     </h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         {{ form_start(form, {'action': actionUrl, "attr": {"class": "pure-form pure-form-aligned"}}) }}*/
/*             {{ form_errors(form) }}*/
/* */
/*             <fieldset>*/
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.name) }}*/
/*                     {{ form_errors(form.name) }}*/
/*                     {{ form_widget(form.name) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.languageCode) }}*/
/*                     {{ form_errors(form.languageCode) }}*/
/*                     {{ form_widget(form.languageCode, {"disabled": (not language.new)}) }}*/
/*                 </div>*/
/* */
/*                 <div class="pure-control-group">*/
/*                     {{ form_label(form.enabled) }}*/
/*                     {{ form_errors(form.enabled) }}*/
/*                     {{ form_widget(form.enabled) }}*/
/*                 </div>*/
/*             </fieldset>*/
/* */
/*             <div class="pure-controls">*/
/*                 <a href="{{ language.new ? path("admin_languagelist") : path("admin_languageview", {"languageId": language.id}) }}"*/
/*                    class="pure-button ez-button">{{ "language.cancel"|trans }}</a>*/
/*                 {{ form_widget(form.save, {"attr": {"class": "pure-button ez-button"}}) }}*/
/*             </div>*/
/* */
/*         {{ form_end(form) }}*/
/*     </section>*/
/* {% endblock %}*/
/* */
