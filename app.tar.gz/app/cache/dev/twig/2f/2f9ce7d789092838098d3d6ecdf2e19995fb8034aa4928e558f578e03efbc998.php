<?php

/* @Framework/Form/form_widget_compound.html.php */
class __TwigTemplate_7bbd57efb10b9a941041a8a09ff7b883cfd062334d6d8a021deb26d525ef72f7 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d6ccb927959124c1a7c533ae2d3ef77784a54a15684a71acf3326d0ba4ae1175 = $this->env->getExtension("native_profiler");
        $__internal_d6ccb927959124c1a7c533ae2d3ef77784a54a15684a71acf3326d0ba4ae1175->enter($__internal_d6ccb927959124c1a7c533ae2d3ef77784a54a15684a71acf3326d0ba4ae1175_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_compound.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <?php echo \$view['form']->errors(\$form) ?>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</div>
";
        
        $__internal_d6ccb927959124c1a7c533ae2d3ef77784a54a15684a71acf3326d0ba4ae1175->leave($__internal_d6ccb927959124c1a7c533ae2d3ef77784a54a15684a71acf3326d0ba4ae1175_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <?php echo $view['form']->errors($form) ?>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </div>*/
/* */
