<?php

/* eZPlatformUIBundle:Exception:error404.html.twig */
class __TwigTemplate_2d8b16d08f1527307791bde203d682f7c0b05a3b3370ba908a376318e16a9d1a extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle:Exception:error.html.twig", "eZPlatformUIBundle:Exception:error404.html.twig", 1);
        $this->blocks = array(
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle:Exception:error.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_3836fd92bf20e9e6041145b1d1da73179af51c4fa5d437e09e0e5b827acf49cd = $this->env->getExtension("native_profiler");
        $__internal_3836fd92bf20e9e6041145b1d1da73179af51c4fa5d437e09e0e5b827acf49cd->enter($__internal_3836fd92bf20e9e6041145b1d1da73179af51c4fa5d437e09e0e5b827acf49cd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Exception:error404.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_3836fd92bf20e9e6041145b1d1da73179af51c4fa5d437e09e0e5b827acf49cd->leave($__internal_3836fd92bf20e9e6041145b1d1da73179af51c4fa5d437e09e0e5b827acf49cd_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Exception:error404.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle:Exception:error.html.twig" %}*/
/* */
