<?php

/* @TedivmStash/Profiler/icon.svg */
class __TwigTemplate_e8a148fe7b0dbf6724404a4b7914527b40127a87a3c1ab7eb408f42e53837bc0 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_10372c80a499751caee6452e1a04fe98663d6788792b432ff9757e248ea859cf = $this->env->getExtension("native_profiler");
        $__internal_10372c80a499751caee6452e1a04fe98663d6788792b432ff9757e248ea859cf->enter($__internal_10372c80a499751caee6452e1a04fe98663d6788792b432ff9757e248ea859cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@TedivmStash/Profiler/icon.svg"));

        // line 1
        echo "<svg version=\"1.1\" xmlns=\"http://www.w3.org/2000/svg\" x=\"0px\" y=\"0px\" height=\"24\" viewBox=\"0 0 24 24\" enable-background=\"new 0 0 24 24\" xml:space=\"preserve\">
    <path fill=\"#AAAAAA\" d=\"M2,8 L6,3 L17,3 L21,8 L21,9 L21,21 L2,21 M3,8 L20,8 L16.5,3.6 L6.5,3.6 L3,8\"/>
    <text x=\"11.5\" y=\"18\" font-family=\"sans-serif\" font-size=\"10\" text-anchor=\"middle\">S</text>
</svg>
";
        
        $__internal_10372c80a499751caee6452e1a04fe98663d6788792b432ff9757e248ea859cf->leave($__internal_10372c80a499751caee6452e1a04fe98663d6788792b432ff9757e248ea859cf_prof);

    }

    public function getTemplateName()
    {
        return "@TedivmStash/Profiler/icon.svg";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <svg version="1.1" xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" height="24" viewBox="0 0 24 24" enable-background="new 0 0 24 24" xml:space="preserve">*/
/*     <path fill="#AAAAAA" d="M2,8 L6,3 L17,3 L21,8 L21,9 L21,21 L2,21 M3,8 L20,8 L16.5,3.6 L6.5,3.6 L3,8"/>*/
/*     <text x="11.5" y="18" font-family="sans-serif" font-size="10" text-anchor="middle">S</text>*/
/* </svg>*/
/* */
