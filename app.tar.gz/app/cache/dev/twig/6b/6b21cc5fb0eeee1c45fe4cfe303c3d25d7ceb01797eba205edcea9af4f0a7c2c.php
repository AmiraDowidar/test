<?php

/* EzSystemsRepositoryFormsBundle:User:register_confirmation.html.twig */
class __TwigTemplate_a2af82ac4ea91d8ea648941339d9e9155b33b54f658c52419e036dab6ea3ade5 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate((((array_key_exists("noLayout", $context) && ((isset($context["noLayout"]) ? $context["noLayout"] : $this->getContext($context, "noLayout")) == true))) ? ((isset($context["viewbaseLayout"]) ? $context["viewbaseLayout"] : $this->getContext($context, "viewbaseLayout"))) : ((isset($context["pagelayout"]) ? $context["pagelayout"] : $this->getContext($context, "pagelayout")))), "EzSystemsRepositoryFormsBundle:User:register_confirmation.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a43c5e51ff53d4c2d83c9210a6d7528ac9c37ab59538384f0ea5b66663fbfdc8 = $this->env->getExtension("native_profiler");
        $__internal_a43c5e51ff53d4c2d83c9210a6d7528ac9c37ab59538384f0ea5b66663fbfdc8->enter($__internal_a43c5e51ff53d4c2d83c9210a6d7528ac9c37ab59538384f0ea5b66663fbfdc8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzSystemsRepositoryFormsBundle:User:register_confirmation.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a43c5e51ff53d4c2d83c9210a6d7528ac9c37ab59538384f0ea5b66663fbfdc8->leave($__internal_a43c5e51ff53d4c2d83c9210a6d7528ac9c37ab59538384f0ea5b66663fbfdc8_prof);

    }

    // line 3
    public function block_content($context, array $blocks = array())
    {
        $__internal_e9d03b4929ec8dfaf2a7b001b8f3fa026919d82979c1c03f56ca191c45436ffd = $this->env->getExtension("native_profiler");
        $__internal_e9d03b4929ec8dfaf2a7b001b8f3fa026919d82979c1c03f56ca191c45436ffd->enter($__internal_e9d03b4929ec8dfaf2a7b001b8f3fa026919d82979c1c03f56ca191c45436ffd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 4
        echo "    <h1>Your account has been created</h1>
    <p class=\"user-register-confirmation-message\">
        Thank you for registering an account. You can now <a href=\"";
        // line 6
        echo $this->env->getExtension('routing')->getPath("login");
        echo "\">login</a>.
    </p>
";
        
        $__internal_e9d03b4929ec8dfaf2a7b001b8f3fa026919d82979c1c03f56ca191c45436ffd->leave($__internal_e9d03b4929ec8dfaf2a7b001b8f3fa026919d82979c1c03f56ca191c45436ffd_prof);

    }

    public function getTemplateName()
    {
        return "EzSystemsRepositoryFormsBundle:User:register_confirmation.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  43 => 6,  39 => 4,  33 => 3,  18 => 1,);
    }
}
/* {% extends noLayout is defined and noLayout == true ? viewbaseLayout : pagelayout %}*/
/* */
/* {% block content %}*/
/*     <h1>Your account has been created</h1>*/
/*     <p class="user-register-confirmation-message">*/
/*         Thank you for registering an account. You can now <a href="{{ path('login') }}">login</a>.*/
/*     </p>*/
/* {% endblock %}*/
/* */
