<?php

/* ::pagelayout_scripts.html.twig */
class __TwigTemplate_1e7becc5b4174c19726eb8b5a6bf4231ee801e9fa01edcc75f1a90d56a1cf01a extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e9953af99c1956417ae41e2719b55c50516c26b1eda52f2946714e2fc17193a8 = $this->env->getExtension("native_profiler");
        $__internal_e9953af99c1956417ae41e2719b55c50516c26b1eda52f2946714e2fc17193a8->enter($__internal_e9953af99c1956417ae41e2719b55c50516c26b1eda52f2946714e2fc17193a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::pagelayout_scripts.html.twig"));

        // line 1
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "032e685_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_032e685_0") : $this->env->getExtension('asset')->getAssetUrl("_controller/js/032e685_part_1_jquery-3.1.1.min_1.js");
            // line 2
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
";
            // asset "032e685_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_032e685_1") : $this->env->getExtension('asset')->getAssetUrl("_controller/js/032e685_part_1_main_2.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
";
        } else {
            // asset "032e685"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('routing')->getPath("_assetic_032e685") : $this->env->getExtension('asset')->getAssetUrl("_controller/js/032e685.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, (isset($context["asset_url"]) ? $context["asset_url"] : $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
";
        }
        unset($context["asset_url"]);
        
        $__internal_e9953af99c1956417ae41e2719b55c50516c26b1eda52f2946714e2fc17193a8->leave($__internal_e9953af99c1956417ae41e2719b55c50516c26b1eda52f2946714e2fc17193a8_prof);

    }

    public function getTemplateName()
    {
        return "::pagelayout_scripts.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  26 => 2,  22 => 1,);
    }
}
/* {% javascripts 'assets/js/*' %}*/
/*     <script src="{{ asset_url }}"></script>*/
/* {% endjavascripts %}*/
