<?php

/* TwigBundle:Exception:exception_full.html.twig */
class __TwigTemplate_395323110a542dcf1c9a2be21413a71ab7322108e0d63463dfe721fd577158ba extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@Twig/layout.html.twig", "TwigBundle:Exception:exception_full.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@Twig/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_c69a8dfab547ebd9b08fb05f198e867385f4888793d05c530c9f827ac08b5567 = $this->env->getExtension("native_profiler");
        $__internal_c69a8dfab547ebd9b08fb05f198e867385f4888793d05c530c9f827ac08b5567->enter($__internal_c69a8dfab547ebd9b08fb05f198e867385f4888793d05c530c9f827ac08b5567_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception_full.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_c69a8dfab547ebd9b08fb05f198e867385f4888793d05c530c9f827ac08b5567->leave($__internal_c69a8dfab547ebd9b08fb05f198e867385f4888793d05c530c9f827ac08b5567_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_3818117746ba11f695a4d6c5e8a4b3b6affb9969339058e8e58d4712663551cf = $this->env->getExtension("native_profiler");
        $__internal_3818117746ba11f695a4d6c5e8a4b3b6affb9969339058e8e58d4712663551cf->enter($__internal_3818117746ba11f695a4d6c5e8a4b3b6affb9969339058e8e58d4712663551cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    <link href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('request')->generateAbsoluteUrl($this->env->getExtension('asset')->getAssetUrl("bundles/framework/css/exception.css")), "html", null, true);
        echo "\" rel=\"stylesheet\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_3818117746ba11f695a4d6c5e8a4b3b6affb9969339058e8e58d4712663551cf->leave($__internal_3818117746ba11f695a4d6c5e8a4b3b6affb9969339058e8e58d4712663551cf_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_28535c9cf82106b26711c49dc91714dbc58f7502adb435d91f2f6b6c3e0fa95b = $this->env->getExtension("native_profiler");
        $__internal_28535c9cf82106b26711c49dc91714dbc58f7502adb435d91f2f6b6c3e0fa95b->enter($__internal_28535c9cf82106b26711c49dc91714dbc58f7502adb435d91f2f6b6c3e0fa95b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        // line 8
        echo "    ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")), "message", array()), "html", null, true);
        echo " (";
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "html", null, true);
        echo ")
";
        
        $__internal_28535c9cf82106b26711c49dc91714dbc58f7502adb435d91f2f6b6c3e0fa95b->leave($__internal_28535c9cf82106b26711c49dc91714dbc58f7502adb435d91f2f6b6c3e0fa95b_prof);

    }

    // line 11
    public function block_body($context, array $blocks = array())
    {
        $__internal_426b59266f687ffbf861e540d3ac63bd7d70033328d84c300f319496b13a7c31 = $this->env->getExtension("native_profiler");
        $__internal_426b59266f687ffbf861e540d3ac63bd7d70033328d84c300f319496b13a7c31->enter($__internal_426b59266f687ffbf861e540d3ac63bd7d70033328d84c300f319496b13a7c31_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 12
        echo "    ";
        $this->loadTemplate("@Twig/Exception/exception.html.twig", "TwigBundle:Exception:exception_full.html.twig", 12)->display($context);
        
        $__internal_426b59266f687ffbf861e540d3ac63bd7d70033328d84c300f319496b13a7c31->leave($__internal_426b59266f687ffbf861e540d3ac63bd7d70033328d84c300f319496b13a7c31_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception_full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  78 => 12,  72 => 11,  58 => 8,  52 => 7,  42 => 4,  36 => 3,  11 => 1,);
    }
}
/* {% extends '@Twig/layout.html.twig' %}*/
/* */
/* {% block head %}*/
/*     <link href="{{ absolute_url(asset('bundles/framework/css/exception.css')) }}" rel="stylesheet" type="text/css" media="all" />*/
/* {% endblock %}*/
/* */
/* {% block title %}*/
/*     {{ exception.message }} ({{ status_code }} {{ status_text }})*/
/* {% endblock %}*/
/* */
/* {% block body %}*/
/*     {% include '@Twig/Exception/exception.html.twig' %}*/
/* {% endblock %}*/
/* */
