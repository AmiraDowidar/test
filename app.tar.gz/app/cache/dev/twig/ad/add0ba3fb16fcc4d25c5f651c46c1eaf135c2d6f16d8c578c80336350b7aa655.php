<?php

/* @Framework/Form/password_widget.html.php */
class __TwigTemplate_0bcdc80a076b296d8595a468f242d8619c56bbb54122a0189c5970e0c747f4d2 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_87ce18c1a1c1e2608be8e7ccbcae9a18bd03780ddd22d1e3ec9241af87aa0a1b = $this->env->getExtension("native_profiler");
        $__internal_87ce18c1a1c1e2608be8e7ccbcae9a18bd03780ddd22d1e3ec9241af87aa0a1b->enter($__internal_87ce18c1a1c1e2608be8e7ccbcae9a18bd03780ddd22d1e3ec9241af87aa0a1b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/password_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'password')) ?>
";
        
        $__internal_87ce18c1a1c1e2608be8e7ccbcae9a18bd03780ddd22d1e3ec9241af87aa0a1b->leave($__internal_87ce18c1a1c1e2608be8e7ccbcae9a18bd03780ddd22d1e3ec9241af87aa0a1b_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/password_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'password')) ?>*/
/* */
