<?php

/* @Framework/Form/hidden_row.html.php */
class __TwigTemplate_ead4f8005f7c6de529baeaa896b4a26741534d342ef68d5e235211ac497ab729 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6a51473abc45329382a004d092bf8ca9293260024a25e1dc744828e4b959d06d = $this->env->getExtension("native_profiler");
        $__internal_6a51473abc45329382a004d092bf8ca9293260024a25e1dc744828e4b959d06d->enter($__internal_6a51473abc45329382a004d092bf8ca9293260024a25e1dc744828e4b959d06d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/hidden_row.html.php"));

        // line 1
        echo "<?php echo \$view['form']->widget(\$form) ?>
";
        
        $__internal_6a51473abc45329382a004d092bf8ca9293260024a25e1dc744828e4b959d06d->leave($__internal_6a51473abc45329382a004d092bf8ca9293260024a25e1dc744828e4b959d06d_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/hidden_row.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->widget($form) ?>*/
/* */
