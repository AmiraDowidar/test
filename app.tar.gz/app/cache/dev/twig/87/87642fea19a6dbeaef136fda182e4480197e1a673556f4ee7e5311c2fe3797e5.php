<?php

/* @Framework/Form/search_widget.html.php */
class __TwigTemplate_3abfbe081c12e67202432b4184ac339b8cf0ed59c1ddfe41c2db4f3597670479 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5f9db7c94199600fc4149c98a40347894584d5cdf0d4b538544088c8992e5a1c = $this->env->getExtension("native_profiler");
        $__internal_5f9db7c94199600fc4149c98a40347894584d5cdf0d4b538544088c8992e5a1c->enter($__internal_5f9db7c94199600fc4149c98a40347894584d5cdf0d4b538544088c8992e5a1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/search_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'search')) ?>
";
        
        $__internal_5f9db7c94199600fc4149c98a40347894584d5cdf0d4b538544088c8992e5a1c->leave($__internal_5f9db7c94199600fc4149c98a40347894584d5cdf0d4b538544088c8992e5a1c_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/search_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'search')) ?>*/
/* */
