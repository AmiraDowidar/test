<?php

/* eZPlatformUIBundle:ContentType:list_content_type_groups.html.twig */
class __TwigTemplate_24f1bc43e3b99767b58052299eb68ba11418bd9f3f179a7018ea58bf96f953d0 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:ContentType:list_content_type_groups.html.twig", 1);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_46e3e496abfe2df991f1cfb38ab871c2a791986af3ed7a17a5e340f682489d95 = $this->env->getExtension("native_profiler");
        $__internal_46e3e496abfe2df991f1cfb38ab871c2a791986af3ed7a17a5e340f682489d95->enter($__internal_46e3e496abfe2df991f1cfb38ab871c2a791986af3ed7a17a5e340f682489d95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:ContentType:list_content_type_groups.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_46e3e496abfe2df991f1cfb38ab871c2a791986af3ed7a17a5e340f682489d95->leave($__internal_46e3e496abfe2df991f1cfb38ab871c2a791986af3ed7a17a5e340f682489d95_prof);

    }

    // line 5
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_f2d5fa0cefa50c8d263e9e57b51c8d1439cc724b760247d7642204745161e752 = $this->env->getExtension("native_profiler");
        $__internal_f2d5fa0cefa50c8d263e9e57b51c8d1439cc724b760247d7642204745161e752->enter($__internal_f2d5fa0cefa50c8d263e9e57b51c8d1439cc724b760247d7642204745161e752_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 6
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => $this->env->getExtension('routing')->getPath("admin_contenttype"), "label" => $this->env->getExtension('translator')->trans("content_type.dashboard_title", array(), "content_type")), 2 => array("link" => null, "label" => $this->env->getExtension('translator')->trans("content_type.group.list", array(), "content_type")));
        // line 11
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_f2d5fa0cefa50c8d263e9e57b51c8d1439cc724b760247d7642204745161e752->leave($__internal_f2d5fa0cefa50c8d263e9e57b51c8d1439cc724b760247d7642204745161e752_prof);

    }

    // line 14
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_0aed40a2237a867572a3af2a980170287bc1fcb5f5ca6212115c8efe185344fd = $this->env->getExtension("native_profiler");
        $__internal_0aed40a2237a867572a3af2a980170287bc1fcb5f5ca6212115c8efe185344fd->enter($__internal_0aed40a2237a867572a3af2a980170287bc1fcb5f5ca6212115c8efe185344fd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 15
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe61a;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.list", array(), "content_type"), "html", null, true);
        echo "</h1>
";
        
        $__internal_0aed40a2237a867572a3af2a980170287bc1fcb5f5ca6212115c8efe185344fd->leave($__internal_0aed40a2237a867572a3af2a980170287bc1fcb5f5ca6212115c8efe185344fd_prof);

    }

    // line 18
    public function block_content($context, array $blocks = array())
    {
        $__internal_315e80ef372d0a2261607d358ea9e20070338035ed6251bbed6491c3cb71c606 = $this->env->getExtension("native_profiler");
        $__internal_315e80ef372d0a2261607d358ea9e20070338035ed6251bbed6491c3cb71c606->enter($__internal_315e80ef372d0a2261607d358ea9e20070338035ed6251bbed6491c3cb71c606_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 19
        echo "    <section class=\"ez-serverside-content\">
        <div class=\"ez-table-data is-flexible\">
            <div class=\"ez-table-data-container\">
                <table class=\"pure-table pure-table-striped ez-selection-table\">
                    <thead>
                    <tr class=\"ez-selection-table-row\">
                        <th>";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.name", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th>";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.id", array(), "content_type"), "html", null, true);
        echo "</th>
                        <th></th>
                        <th></th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["content_type_groups"]) ? $context["content_type_groups"] : $this->getContext($context, "content_type_groups")));
        foreach ($context['_seq'] as $context["_key"] => $context["group"]) {
            // line 33
            echo "                        ";
            // line 34
            echo "                        <tr>
                            <td><a href=\"";
            // line 35
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_contenttypeGroupView", array("contentTypeGroupId" => $this->getAttribute($context["group"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "identifier", array()), "html", null, true);
            echo "</a></td>
                            <td>";
            // line 36
            echo twig_escape_filter($this->env, $this->getAttribute($context["group"], "id", array()), "html", null, true);
            echo "</td>
                            <td>
                            ";
            // line 38
            if ((isset($context["can_edit"]) ? $context["can_edit"] : $this->getContext($context, "can_edit"))) {
                // line 39
                echo "                                <a href=\"";
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_contenttypeGroupEdit", array("contentTypeGroupId" => $this->getAttribute($context["group"], "id", array()))), "html", null, true);
                echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.edit", array(), "content_type"), "html", null, true);
                echo "</a>
                            ";
            } else {
                // line 41
                echo "                                <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe606;\">";
                echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.edit", array(), "content_type"), "html", null, true);
                echo "</span>
                            ";
            }
            // line 43
            echo "                            </td>
                            <td>
                                ";
            // line 45
            $context["deleteForm"] = $this->getAttribute((isset($context["delete_forms_by_id"]) ? $context["delete_forms_by_id"] : $this->getContext($context, "delete_forms_by_id")), $this->getAttribute($context["group"], "id", array()), array(), "array");
            // line 46
            echo "                                ";
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_contenttypeGroupDelete", array("contentTypeGroupId" => $this->getAttribute($context["group"], "id", array())))));
            echo "
                                ";
            // line 47
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "contentTypeGroupId", array()), 'widget');
            echo "
                                ";
            // line 48
            echo             // line 49
$this->env->getExtension('form')->renderer->searchAndRenderBlock($this->getAttribute(            // line 50
(isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), "delete", array()), 'widget', array("disabled" =>  !            // line 52
(isset($context["can_delete"]) ? $context["can_delete"] : $this->getContext($context, "can_delete")), "attr" => array("class" => "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete")));
            // line 56
            echo "
                                ";
            // line 57
            echo             $this->env->getExtension('form')->renderer->renderBlock((isset($context["deleteForm"]) ? $context["deleteForm"] : $this->getContext($context, "deleteForm")), 'form_end');
            echo "
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['group'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 61
        echo "                    </tbody>
                </table>
                <p class=\"ez-table-data-buttons\">
                    ";
        // line 64
        if ((isset($context["can_edit"]) ? $context["can_edit"] : $this->getContext($context, "can_edit"))) {
            // line 65
            echo "                        <a href=\"";
            echo $this->env->getExtension('routing')->getPath("admin_contenttypeGroupEdit");
            echo "\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.new", array(), "content_type"), "html", null, true);
            echo "</a>
                    ";
        } else {
            // line 67
            echo "                        <span class=\"pure-button ez-button pure-button-disabled\" data-icon=\"&#xe616;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.new", array(), "content_type"), "html", null, true);
            echo "</span>
                    ";
        }
        // line 69
        echo "                </p>
            </div>
        </div>
    </section>
";
        
        $__internal_315e80ef372d0a2261607d358ea9e20070338035ed6251bbed6491c3cb71c606->leave($__internal_315e80ef372d0a2261607d358ea9e20070338035ed6251bbed6491c3cb71c606_prof);

    }

    // line 75
    public function block_title($context, array $blocks = array())
    {
        $__internal_c0822f88df8b6b5227f37c1dc5db3120087dad56af8bb2567bcf2c3d0f192ab9 = $this->env->getExtension("native_profiler");
        $__internal_c0822f88df8b6b5227f37c1dc5db3120087dad56af8bb2567bcf2c3d0f192ab9->enter($__internal_c0822f88df8b6b5227f37c1dc5db3120087dad56af8bb2567bcf2c3d0f192ab9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("content_type.group.list", array(), "content_type"), "html", null, true);
        
        $__internal_c0822f88df8b6b5227f37c1dc5db3120087dad56af8bb2567bcf2c3d0f192ab9->leave($__internal_c0822f88df8b6b5227f37c1dc5db3120087dad56af8bb2567bcf2c3d0f192ab9_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:ContentType:list_content_type_groups.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  200 => 75,  189 => 69,  183 => 67,  175 => 65,  173 => 64,  168 => 61,  158 => 57,  155 => 56,  153 => 52,  152 => 50,  151 => 49,  150 => 48,  146 => 47,  141 => 46,  139 => 45,  135 => 43,  129 => 41,  121 => 39,  119 => 38,  114 => 36,  108 => 35,  105 => 34,  103 => 33,  99 => 32,  90 => 26,  86 => 25,  78 => 19,  72 => 18,  62 => 15,  56 => 14,  46 => 11,  43 => 6,  37 => 5,  11 => 1,);
    }
}
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "content_type" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: path('admin_contenttype'), label: 'content_type.dashboard_title'|trans},*/
/*         {link: null, label: 'content_type.group.list'|trans}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe61a;">{{ 'content_type.group.list'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <div class="ez-table-data is-flexible">*/
/*             <div class="ez-table-data-container">*/
/*                 <table class="pure-table pure-table-striped ez-selection-table">*/
/*                     <thead>*/
/*                     <tr class="ez-selection-table-row">*/
/*                         <th>{{ 'content_type.group.name'|trans }}</th>*/
/*                         <th>{{ 'content_type.group.id'|trans }}</th>*/
/*                         <th></th>*/
/*                         <th></th>*/
/*                     </tr>*/
/*                     </thead>*/
/*                     <tbody>*/
/*                     {% for group in content_type_groups %}*/
/*                         {# @var group \eZ\Publish\Core\Repository\Values\ContentType\ContentTypeGroup #}*/
/*                         <tr>*/
/*                             <td><a href="{{ path("admin_contenttypeGroupView", {"contentTypeGroupId": group.id}) }}">{{ group.identifier }}</a></td>*/
/*                             <td>{{ group.id }}</td>*/
/*                             <td>*/
/*                             {% if can_edit %}*/
/*                                 <a href="{{ path("admin_contenttypeGroupEdit", {'contentTypeGroupId': group.id}) }}" class="pure-button ez-button" data-icon="&#xe606;">{{ 'content_type.group.edit'|trans }}</a>*/
/*                             {% else %}*/
/*                                 <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe606;">{{ 'content_type.group.edit'|trans }}</span>*/
/*                             {% endif %}*/
/*                             </td>*/
/*                             <td>*/
/*                                 {% set deleteForm = delete_forms_by_id[group.id] %}*/
/*                                 {{ form_start(deleteForm, {"action": path("admin_contenttypeGroupDelete", {"contentTypeGroupId": group.id})}) }}*/
/*                                 {{ form_widget(deleteForm.contentTypeGroupId) }}*/
/*                                 {{*/
/*                                     form_widget(*/
/*                                         deleteForm.delete,*/
/*                                         {*/
/*                                             "disabled": not can_delete,*/
/*                                             "attr": {"class": "pure-button ez-button ez-remove-section-button ez-font-icon ez-button-delete"}*/
/*                                         }*/
/*                                     )*/
/*                                 }}*/
/*                                 {{ form_end(deleteForm) }}*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*                     </tbody>*/
/*                 </table>*/
/*                 <p class="ez-table-data-buttons">*/
/*                     {% if can_edit %}*/
/*                         <a href="{{ path('admin_contenttypeGroupEdit') }}" class="pure-button ez-button" data-icon="&#xe616;">{{ 'content_type.group.new'|trans }}</a>*/
/*                     {% else %}*/
/*                         <span class="pure-button ez-button pure-button-disabled" data-icon="&#xe616;">{{ 'content_type.group.new'|trans }}</span>*/
/*                     {% endif %}*/
/*                 </p>*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'content_type.group.list'|trans }}{% endblock %}*/
/* */
