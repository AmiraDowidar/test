<?php

/* EzPublishCoreBundle::viewbase_layout.html.twig */
class __TwigTemplate_e9ce059c003d6e12c5b2cc62274d98569119cfd5c5a29b4d1cf58205113e84bf extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_153ba9229c686e355e8ec7242780b9827b3952d22346cfe3eea1776d47304d3a = $this->env->getExtension("native_profiler");
        $__internal_153ba9229c686e355e8ec7242780b9827b3952d22346cfe3eea1776d47304d3a->enter($__internal_153ba9229c686e355e8ec7242780b9827b3952d22346cfe3eea1776d47304d3a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle::viewbase_layout.html.twig"));

        // line 4
        $this->displayBlock('content', $context, $blocks);
        
        $__internal_153ba9229c686e355e8ec7242780b9827b3952d22346cfe3eea1776d47304d3a->leave($__internal_153ba9229c686e355e8ec7242780b9827b3952d22346cfe3eea1776d47304d3a_prof);

    }

    public function block_content($context, array $blocks = array())
    {
        $__internal_c2439f30d11360269b5fffedd77297f50f366336d1b2ba79e9f12ab261422285 = $this->env->getExtension("native_profiler");
        $__internal_c2439f30d11360269b5fffedd77297f50f366336d1b2ba79e9f12ab261422285->enter($__internal_c2439f30d11360269b5fffedd77297f50f366336d1b2ba79e9f12ab261422285_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        
        $__internal_c2439f30d11360269b5fffedd77297f50f366336d1b2ba79e9f12ab261422285->leave($__internal_c2439f30d11360269b5fffedd77297f50f366336d1b2ba79e9f12ab261422285_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle::viewbase_layout.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  23 => 4,);
    }
}
/* {# this is the layout used when we want to render a block with any decoration*/
/*  # ie with using the complete pagelayout.*/
/*  #}*/
/* {% block content %}{% endblock %}*/
/* */
