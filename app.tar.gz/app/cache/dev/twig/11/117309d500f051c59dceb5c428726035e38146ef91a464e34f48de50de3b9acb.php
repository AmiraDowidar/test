<?php

/* @Framework/Form/choice_widget.html.php */
class __TwigTemplate_a87bf615a6b50c5a2fcb3d79791bd450d412b98eeddf0e228a09cac97b732974 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_347b39173aa2ddefa96c273a8daca747d62b4545648df07f4ce7f38e14f3cb21 = $this->env->getExtension("native_profiler");
        $__internal_347b39173aa2ddefa96c273a8daca747d62b4545648df07f4ce7f38e14f3cb21->enter($__internal_347b39173aa2ddefa96c273a8daca747d62b4545648df07f4ce7f38e14f3cb21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget.html.php"));

        // line 1
        echo "<?php if (\$expanded): ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_expanded') ?>
<?php else: ?>
<?php echo \$view['form']->block(\$form, 'choice_widget_collapsed') ?>
<?php endif ?>
";
        
        $__internal_347b39173aa2ddefa96c273a8daca747d62b4545648df07f4ce7f38e14f3cb21->leave($__internal_347b39173aa2ddefa96c273a8daca747d62b4545648df07f4ce7f38e14f3cb21_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php if ($expanded): ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_expanded') ?>*/
/* <?php else: ?>*/
/* <?php echo $view['form']->block($form, 'choice_widget_collapsed') ?>*/
/* <?php endif ?>*/
/* */
