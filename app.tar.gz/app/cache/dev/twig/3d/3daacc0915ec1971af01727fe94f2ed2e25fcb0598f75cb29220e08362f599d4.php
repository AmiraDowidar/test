<?php

/* @Framework/Form/form_widget_simple.html.php */
class __TwigTemplate_c82a9dd93b4a4f2bd08c04a10fa4d92bf03531a76a8753451ac93de8aa44d517 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_452957e0a147a2e4f1d33d6c270fdb98b81a9d5394f0c7b01dcdb4bf59e3e519 = $this->env->getExtension("native_profiler");
        $__internal_452957e0a147a2e4f1d33d6c270fdb98b81a9d5394f0c7b01dcdb4bf59e3e519->enter($__internal_452957e0a147a2e4f1d33d6c270fdb98b81a9d5394f0c7b01dcdb4bf59e3e519_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/form_widget_simple.html.php"));

        // line 1
        echo "<input type=\"<?php echo isset(\$type) ? \$view->escape(\$type) : 'text' ?>\" <?php echo \$view['form']->block(\$form, 'widget_attributes') ?><?php if (!empty(\$value) || is_numeric(\$value)): ?> value=\"<?php echo \$view->escape(\$value) ?>\"<?php endif ?> />
";
        
        $__internal_452957e0a147a2e4f1d33d6c270fdb98b81a9d5394f0c7b01dcdb4bf59e3e519->leave($__internal_452957e0a147a2e4f1d33d6c270fdb98b81a9d5394f0c7b01dcdb4bf59e3e519_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/form_widget_simple.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <input type="<?php echo isset($type) ? $view->escape($type) : 'text' ?>" <?php echo $view['form']->block($form, 'widget_attributes') ?><?php if (!empty($value) || is_numeric($value)): ?> value="<?php echo $view->escape($value) ?>"<?php endif ?> />*/
/* */
