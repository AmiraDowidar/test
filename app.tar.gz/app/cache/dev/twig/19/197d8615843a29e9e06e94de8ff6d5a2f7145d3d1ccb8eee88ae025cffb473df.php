<?php

/* TwigBundle:Exception:error.js.twig */
class __TwigTemplate_156b18e0fbd2c59064aeef84acaa5abb04da6678bbb08aabd1381dd129254a84 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_e6571453ffe80858d6936af39164a83e7e8db6aefa5c227b5b4b641543b6440b = $this->env->getExtension("native_profiler");
        $__internal_e6571453ffe80858d6936af39164a83e7e8db6aefa5c227b5b4b641543b6440b->enter($__internal_e6571453ffe80858d6936af39164a83e7e8db6aefa5c227b5b4b641543b6440b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:error.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        echo twig_escape_filter($this->env, (isset($context["status_code"]) ? $context["status_code"] : $this->getContext($context, "status_code")), "js", null, true);
        echo " ";
        echo twig_escape_filter($this->env, (isset($context["status_text"]) ? $context["status_text"] : $this->getContext($context, "status_text")), "js", null, true);
        echo "

*/
";
        
        $__internal_e6571453ffe80858d6936af39164a83e7e8db6aefa5c227b5b4b641543b6440b->leave($__internal_e6571453ffe80858d6936af39164a83e7e8db6aefa5c227b5b4b641543b6440b_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:error.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  25 => 2,  22 => 1,);
    }
}
/* /**/
/* {{ status_code }} {{ status_text }}*/
/* */
/* *//* */
/* */
