<?php

/* EzPublishCoreBundle:default/content:embed.html.twig */
class __TwigTemplate_20b39965e3adc9024718cc25ad4d11e0f20d9608fac671671276d6bd86f66087 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_29c1112669c31c04c2dc4df096885d4a7c6938b3e7a9005255ec229e56f54cff = $this->env->getExtension("native_profiler");
        $__internal_29c1112669c31c04c2dc4df096885d4a7c6938b3e7a9005255ec229e56f54cff->enter($__internal_29c1112669c31c04c2dc4df096885d4a7c6938b3e7a9005255ec229e56f54cff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:default/content:embed.html.twig"));

        // line 1
        $context["content_name"] = $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")));
        // line 2
        echo "
";
        // line 3
        if (array_key_exists("location", $context)) {
            // line 4
            echo "    <h3><a href=\"";
            echo $this->env->getExtension('routing')->getPath((isset($context["location"]) ? $context["location"] : $this->getContext($context, "location")));
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["content_name"]) ? $context["content_name"] : $this->getContext($context, "content_name")), "html", null, true);
            echo "</a></h3>
";
        } else {
            // line 6
            echo "    <h3><a href=\"";
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ez_urlalias", array("contentId" => $this->getAttribute((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")), "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, (isset($context["content_name"]) ? $context["content_name"] : $this->getContext($context, "content_name")), "html", null, true);
            echo "</a></h3>
";
        }
        
        $__internal_29c1112669c31c04c2dc4df096885d4a7c6938b3e7a9005255ec229e56f54cff->leave($__internal_29c1112669c31c04c2dc4df096885d4a7c6938b3e7a9005255ec229e56f54cff_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/content:embed.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  37 => 6,  29 => 4,  27 => 3,  24 => 2,  22 => 1,);
    }
}
/* {% set content_name=ez_content_name(content) %}*/
/* */
/* {% if location is defined %}*/
/*     <h3><a href="{{ path(location) }}">{{ content_name }}</a></h3>*/
/* {% else %}*/
/*     <h3><a href="{{ path( "ez_urlalias", {"contentId": content.id} ) }}">{{ content_name }}</a></h3>*/
/* {% endif %}*/
/* */
