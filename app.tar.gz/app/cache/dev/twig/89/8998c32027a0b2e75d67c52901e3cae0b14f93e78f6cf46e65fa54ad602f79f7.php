<?php

/* AppBundle:Ride:index.html.twig */
class __TwigTemplate_a5d7eaf7224b58293cd0081085f8a1cdca748156b7ad83b7c118a7ad5282c1e0 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("pagelayout.html.twig", "AppBundle:Ride:index.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "pagelayout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_a5ad074fff47a18441e821f794f479e87b030034f44ce8d5846f16416d3135c4 = $this->env->getExtension("native_profiler");
        $__internal_a5ad074fff47a18441e821f794f479e87b030034f44ce8d5846f16416d3135c4->enter($__internal_a5ad074fff47a18441e821f794f479e87b030034f44ce8d5846f16416d3135c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:Ride:index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_a5ad074fff47a18441e821f794f479e87b030034f44ce8d5846f16416d3135c4->leave($__internal_a5ad074fff47a18441e821f794f479e87b030034f44ce8d5846f16416d3135c4_prof);

    }

    // line 3
    public function block_title($context, array $blocks = array())
    {
        $__internal_967303a8d693b7523a6beb2102f8d267caa32356b2181d2e8b323a11900d40ad = $this->env->getExtension("native_profiler");
        $__internal_967303a8d693b7523a6beb2102f8d267caa32356b2181d2e8b323a11900d40ad->enter($__internal_967303a8d693b7523a6beb2102f8d267caa32356b2181d2e8b323a11900d40ad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "AppBundle:Ride:index";
        
        $__internal_967303a8d693b7523a6beb2102f8d267caa32356b2181d2e8b323a11900d40ad->leave($__internal_967303a8d693b7523a6beb2102f8d267caa32356b2181d2e8b323a11900d40ad_prof);

    }

    // line 5
    public function block_content($context, array $blocks = array())
    {
        $__internal_8d7e8b75ff15ec52fd21a55c0751e36d622ddeb34712a6ad88fdecab59a0de03 = $this->env->getExtension("native_profiler");
        $__internal_8d7e8b75ff15ec52fd21a55c0751e36d622ddeb34712a6ad88fdecab59a0de03->enter($__internal_8d7e8b75ff15ec52fd21a55c0751e36d622ddeb34712a6ad88fdecab59a0de03_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 6
        echo "<h1>Welcome to the Ride:index page</h1>
";
        
        $__internal_8d7e8b75ff15ec52fd21a55c0751e36d622ddeb34712a6ad88fdecab59a0de03->leave($__internal_8d7e8b75ff15ec52fd21a55c0751e36d622ddeb34712a6ad88fdecab59a0de03_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:Ride:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 6,  47 => 5,  35 => 3,  11 => 1,);
    }
}
/* {% extends "pagelayout.html.twig" %}*/
/* */
/* {% block title %}AppBundle:Ride:index{% endblock %}*/
/* */
/* {% block content %}*/
/* <h1>Welcome to the Ride:index page</h1>*/
/* {% endblock %}*/
/* */
