<?php

/* @Framework/FormTable/form_widget_compound.html.php */
class __TwigTemplate_8e2f7d67a310c732d6bd5870578b1ce5be6413865fbc99136b6ce10195029373 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_63935ed459b61311e82c6c0b87c21ba4c9a4976816b984b19865774be7e46eb8 = $this->env->getExtension("native_profiler");
        $__internal_63935ed459b61311e82c6c0b87c21ba4c9a4976816b984b19865774be7e46eb8->enter($__internal_63935ed459b61311e82c6c0b87c21ba4c9a4976816b984b19865774be7e46eb8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/FormTable/form_widget_compound.html.php"));

        // line 1
        echo "<table <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
    <?php if (!\$form->parent && \$errors): ?>
    <tr>
        <td colspan=\"2\">
            <?php echo \$view['form']->errors(\$form) ?>
        </td>
    </tr>
    <?php endif ?>
    <?php echo \$view['form']->block(\$form, 'form_rows') ?>
    <?php echo \$view['form']->rest(\$form) ?>
</table>
";
        
        $__internal_63935ed459b61311e82c6c0b87c21ba4c9a4976816b984b19865774be7e46eb8->leave($__internal_63935ed459b61311e82c6c0b87c21ba4c9a4976816b984b19865774be7e46eb8_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/FormTable/form_widget_compound.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <table <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/*     <?php if (!$form->parent && $errors): ?>*/
/*     <tr>*/
/*         <td colspan="2">*/
/*             <?php echo $view['form']->errors($form) ?>*/
/*         </td>*/
/*     </tr>*/
/*     <?php endif ?>*/
/*     <?php echo $view['form']->block($form, 'form_rows') ?>*/
/*     <?php echo $view['form']->rest($form) ?>*/
/* </table>*/
/* */
