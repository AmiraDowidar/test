<?php

/* EzPublishCoreBundle::fielddefinition_settings.html.twig */
class __TwigTemplate_1c2fef28da84641b6777b4ac10c9e80e7a818f0b466bda11b48c0c31b5649a69 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'ezstring_settings' => array($this, 'block_ezstring_settings'),
            'eztext_settings' => array($this, 'block_eztext_settings'),
            'ezcountry_settings' => array($this, 'block_ezcountry_settings'),
            'ezboolean_settings' => array($this, 'block_ezboolean_settings'),
            'ezdatetime_settings' => array($this, 'block_ezdatetime_settings'),
            'ezdate_settings' => array($this, 'block_ezdate_settings'),
            'eztime_settings' => array($this, 'block_eztime_settings'),
            'ezinteger_settings' => array($this, 'block_ezinteger_settings'),
            'ezfloat_settings' => array($this, 'block_ezfloat_settings'),
            'ezselection_settings' => array($this, 'block_ezselection_settings'),
            'ezbinaryfile_settings' => array($this, 'block_ezbinaryfile_settings'),
            'ezmedia_settings' => array($this, 'block_ezmedia_settings'),
            'ezimage_settings' => array($this, 'block_ezimage_settings'),
            'ezobjectrelation_settings' => array($this, 'block_ezobjectrelation_settings'),
            'ezobjectrelationlist_settings' => array($this, 'block_ezobjectrelationlist_settings'),
            'ezpage_settings' => array($this, 'block_ezpage_settings'),
            'ezauthor_settings' => array($this, 'block_ezauthor_settings'),
            'ezurl_settings' => array($this, 'block_ezurl_settings'),
            'ezisbn_settings' => array($this, 'block_ezisbn_settings'),
            'ezkeyword_settings' => array($this, 'block_ezkeyword_settings'),
            'ezuser_settings' => array($this, 'block_ezuser_settings'),
            'ezemail_settings' => array($this, 'block_ezemail_settings'),
            'ezgmaplocation_settings' => array($this, 'block_ezgmaplocation_settings'),
            'ezsrrating_settings' => array($this, 'block_ezsrrating_settings'),
            'settings_maxfilesize' => array($this, 'block_settings_maxfilesize'),
            'settings_preferredrows' => array($this, 'block_settings_preferredrows'),
            'settings_selectionroot' => array($this, 'block_settings_selectionroot'),
            'settings_defaultvalue' => array($this, 'block_settings_defaultvalue'),
            'settings_minimumvalue' => array($this, 'block_settings_minimumvalue'),
            'settings_maximumvalue' => array($this, 'block_settings_maximumvalue'),
            'settings_allowmultiple' => array($this, 'block_settings_allowmultiple'),
            'settings_allowisbn13' => array($this, 'block_settings_allowisbn13'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6794c507166b05f42e3515494592afffaf947016e441985f9c83737be30c6166 = $this->env->getExtension("native_profiler");
        $__internal_6794c507166b05f42e3515494592afffaf947016e441985f9c83737be30c6166->enter($__internal_6794c507166b05f42e3515494592afffaf947016e441985f9c83737be30c6166_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle::fielddefinition_settings.html.twig"));

        // line 7
        echo "
";
        // line 8
        $this->displayBlock('ezstring_settings', $context, $blocks);
        // line 22
        echo "
";
        // line 23
        $this->displayBlock('eztext_settings', $context, $blocks);
        // line 29
        echo "
";
        // line 30
        $this->displayBlock('ezcountry_settings', $context, $blocks);
        // line 41
        echo "
";
        // line 42
        $this->displayBlock('ezboolean_settings', $context, $blocks);
        // line 54
        echo "
";
        // line 55
        $this->displayBlock('ezdatetime_settings', $context, $blocks);
        // line 78
        echo "
";
        // line 79
        $this->displayBlock('ezdate_settings', $context, $blocks);
        // line 89
        echo "
";
        // line 90
        $this->displayBlock('eztime_settings', $context, $blocks);
        // line 104
        echo "
";
        // line 105
        $this->displayBlock('ezinteger_settings', $context, $blocks);
        // line 115
        echo "
";
        // line 116
        $this->displayBlock('ezfloat_settings', $context, $blocks);
        // line 126
        echo "
";
        // line 127
        $this->displayBlock('ezselection_settings', $context, $blocks);
        // line 141
        echo "

";
        // line 143
        $this->displayBlock('ezbinaryfile_settings', $context, $blocks);
        // line 148
        echo "
";
        // line 149
        $this->displayBlock('ezmedia_settings', $context, $blocks);
        // line 175
        echo "
";
        // line 176
        $this->displayBlock('ezimage_settings', $context, $blocks);
        // line 181
        echo "
";
        // line 182
        $this->displayBlock('ezobjectrelation_settings', $context, $blocks);
        // line 198
        echo "
";
        // line 199
        $this->displayBlock('ezobjectrelationlist_settings', $context, $blocks);
        // line 236
        echo "
";
        // line 237
        $this->displayBlock('ezpage_settings', $context, $blocks);
        // line 245
        echo "

";
        // line 247
        $this->displayBlock('ezauthor_settings', $context, $blocks);
        // line 248
        echo "
";
        // line 249
        $this->displayBlock('ezurl_settings', $context, $blocks);
        // line 250
        echo "
";
        // line 251
        $this->displayBlock('ezisbn_settings', $context, $blocks);
        // line 259
        echo "
";
        // line 260
        $this->displayBlock('ezkeyword_settings', $context, $blocks);
        // line 261
        echo "
";
        // line 262
        $this->displayBlock('ezuser_settings', $context, $blocks);
        // line 263
        echo "
";
        // line 264
        $this->displayBlock('ezemail_settings', $context, $blocks);
        // line 265
        echo "
";
        // line 266
        $this->displayBlock('ezgmaplocation_settings', $context, $blocks);
        // line 267
        echo "
";
        // line 268
        $this->displayBlock('ezsrrating_settings', $context, $blocks);
        // line 269
        echo "
";
        // line 270
        $this->displayBlock('settings_maxfilesize', $context, $blocks);
        // line 281
        echo "
";
        // line 282
        $this->displayBlock('settings_preferredrows', $context, $blocks);
        // line 292
        echo "
";
        // line 293
        $this->displayBlock('settings_selectionroot', $context, $blocks);
        // line 304
        echo "
";
        // line 305
        $this->displayBlock('settings_defaultvalue', $context, $blocks);
        // line 315
        echo "
";
        // line 316
        $this->displayBlock('settings_minimumvalue', $context, $blocks);
        // line 326
        echo "
";
        // line 327
        $this->displayBlock('settings_maximumvalue', $context, $blocks);
        // line 337
        echo "
";
        // line 338
        $this->displayBlock('settings_allowmultiple', $context, $blocks);
        // line 344
        echo "
";
        // line 345
        $this->displayBlock('settings_allowisbn13', $context, $blocks);
        
        $__internal_6794c507166b05f42e3515494592afffaf947016e441985f9c83737be30c6166->leave($__internal_6794c507166b05f42e3515494592afffaf947016e441985f9c83737be30c6166_prof);

    }

    // line 8
    public function block_ezstring_settings($context, array $blocks = array())
    {
        $__internal_16e260b2da6dc4501ba60ceff32bd2d02ba8fd893c9b025c11482ac3c78969e9 = $this->env->getExtension("native_profiler");
        $__internal_16e260b2da6dc4501ba60ceff32bd2d02ba8fd893c9b025c11482ac3c78969e9->enter($__internal_16e260b2da6dc4501ba60ceff32bd2d02ba8fd893c9b025c11482ac3c78969e9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezstring_settings"));

        // line 9
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 10
        $context["defaultValue"] = $this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "defaultValue", array()), "text", array());
        // line 11
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    <li class=\"max-length\">
        <span>Max string length:</span>
        ";
        // line 14
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "validatorConfiguration", array()), "StringLengthValidator", array()), "maxStringLength", array())) {
            // line 15
            echo "            ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "validatorConfiguration", array()), "StringLengthValidator", array()), "maxStringLength", array()), "html", null, true);
            echo " characters
        ";
        } else {
            // line 17
            echo "            <em>No defined maximum string length</em>
        ";
        }
        // line 19
        echo "    </li>
</ul>
";
        
        $__internal_16e260b2da6dc4501ba60ceff32bd2d02ba8fd893c9b025c11482ac3c78969e9->leave($__internal_16e260b2da6dc4501ba60ceff32bd2d02ba8fd893c9b025c11482ac3c78969e9_prof);

    }

    // line 23
    public function block_eztext_settings($context, array $blocks = array())
    {
        $__internal_961b0e91667da11322cd520d54e90b4b5d3b3b76fdbc326c7abc15613a5f5c45 = $this->env->getExtension("native_profiler");
        $__internal_961b0e91667da11322cd520d54e90b4b5d3b3b76fdbc326c7abc15613a5f5c45->enter($__internal_961b0e91667da11322cd520d54e90b4b5d3b3b76fdbc326c7abc15613a5f5c45_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "eztext_settings"));

        // line 24
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 25
        $context["rows"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "textRows", array());
        // line 26
        echo "    ";
        $this->displayBlock("settings_preferredrows", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_961b0e91667da11322cd520d54e90b4b5d3b3b76fdbc326c7abc15613a5f5c45->leave($__internal_961b0e91667da11322cd520d54e90b4b5d3b3b76fdbc326c7abc15613a5f5c45_prof);

    }

    // line 30
    public function block_ezcountry_settings($context, array $blocks = array())
    {
        $__internal_458fd60d2191fbea93e82ce90bee4c6dc7e8a586b7b796ad78718884415c82c8 = $this->env->getExtension("native_profiler");
        $__internal_458fd60d2191fbea93e82ce90bee4c6dc7e8a586b7b796ad78718884415c82c8->enter($__internal_458fd60d2191fbea93e82ce90bee4c6dc7e8a586b7b796ad78718884415c82c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezcountry_settings"));

        // line 31
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 32
        $context["defaultValue"] = "";
        // line 33
        echo "    ";
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "defaultValue", array()), "countries", array()));
        $context['loop'] = array(
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        );
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["country"]) {
            // line 34
            echo "        ";
            $context["defaultValue"] = (((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue")) . $this->getAttribute($context["country"], "Name", array())) . (( !$this->getAttribute($context["loop"], "last", array())) ? (", ") : ("")));
            // line 35
            echo "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['length'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['country'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 36
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    ";
        // line 37
        $context["isMultiple"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "isMultiple", array());
        // line 38
        echo "    ";
        $this->displayBlock("settings_allowmultiple", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_458fd60d2191fbea93e82ce90bee4c6dc7e8a586b7b796ad78718884415c82c8->leave($__internal_458fd60d2191fbea93e82ce90bee4c6dc7e8a586b7b796ad78718884415c82c8_prof);

    }

    // line 42
    public function block_ezboolean_settings($context, array $blocks = array())
    {
        $__internal_04304cd752fd53f3152d1013f79962390998a2f1c4e72664378146f490f884a4 = $this->env->getExtension("native_profiler");
        $__internal_04304cd752fd53f3152d1013f79962390998a2f1c4e72664378146f490f884a4->enter($__internal_04304cd752fd53f3152d1013f79962390998a2f1c4e72664378146f490f884a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezboolean_settings"));

        // line 43
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    <li class=\"default-value\">
        <span>Default value:</span>
        ";
        // line 46
        if ($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "defaultValue", array()), "bool", array())) {
            // line 47
            echo "            Checked
        ";
        } else {
            // line 49
            echo "            Unchecked
        ";
        }
        // line 51
        echo "    </li>
</ul>
";
        
        $__internal_04304cd752fd53f3152d1013f79962390998a2f1c4e72664378146f490f884a4->leave($__internal_04304cd752fd53f3152d1013f79962390998a2f1c4e72664378146f490f884a4_prof);

    }

    // line 55
    public function block_ezdatetime_settings($context, array $blocks = array())
    {
        $__internal_83f9537041bb804b46c80f6eadf46a9d932323b79589195d0e2b800b5e48eff0 = $this->env->getExtension("native_profiler");
        $__internal_83f9537041bb804b46c80f6eadf46a9d932323b79589195d0e2b800b5e48eff0->enter($__internal_83f9537041bb804b46c80f6eadf46a9d932323b79589195d0e2b800b5e48eff0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezdatetime_settings"));

        // line 56
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 57
        if (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "defaultType", array()) == twig_constant("eZ\\Publish\\Core\\FieldType\\DateAndTime\\Type::DEFAULT_EMPTY"))) {
            // line 58
            echo "        ";
            $context["defaultValue"] = "Empty";
            // line 59
            echo "    ";
        } elseif (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "defaultType", array()) == twig_constant("eZ\\Publish\\Core\\FieldType\\DateAndTime\\Type::DEFAULT_CURRENT_DATE"))) {
            // line 60
            echo "        ";
            $context["defaultValue"] = "Current datetime";
            // line 61
            echo "    ";
        } else {
            // line 62
            echo "        ";
            $context["interval"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "dateInterval", array());
            // line 63
            echo "        ";
            $context["defaultValue"] = "Current datetime adjusted by ";
            // line 64
            echo "        ";
            $context["defaultValue"] = (($this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "y", array())) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue")) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "y", array())) . " year(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue"))));
            // line 65
            echo "        ";
            $context["defaultValue"] = (($this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "m", array())) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue")) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "m", array())) . " month(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue"))));
            // line 66
            echo "        ";
            $context["defaultValue"] = (($this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "d", array())) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue")) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "d", array())) . " day(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue"))));
            // line 67
            echo "        ";
            $context["defaultValue"] = (($this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "h", array())) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue")) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "h", array())) . " hour(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue"))));
            // line 68
            echo "        ";
            $context["defaultValue"] = (($this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "i", array())) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue")) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "i", array())) . " minute(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue"))));
            // line 69
            echo "        ";
            $context["defaultValue"] = ((($this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "s", array()) && $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "useSeconds", array()))) ? ((((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue")) . $this->getAttribute((isset($context["interval"]) ? $context["interval"] : $this->getContext($context, "interval")), "s", array())) . " second(s)")) : ((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue"))));
            // line 70
            echo "    ";
        }
        // line 71
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    <li class=\"use-seconds\">
        <span>Use seconds:</span>
        ";
        // line 74
        echo (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "useSeconds", array())) ? ("Yes") : ("No"));
        echo "
    </li>
</ul>
";
        
        $__internal_83f9537041bb804b46c80f6eadf46a9d932323b79589195d0e2b800b5e48eff0->leave($__internal_83f9537041bb804b46c80f6eadf46a9d932323b79589195d0e2b800b5e48eff0_prof);

    }

    // line 79
    public function block_ezdate_settings($context, array $blocks = array())
    {
        $__internal_632e74bd14a974a47718a7f7dee67bef540a60c38f20e72eba6a9ff4cbd1f4f2 = $this->env->getExtension("native_profiler");
        $__internal_632e74bd14a974a47718a7f7dee67bef540a60c38f20e72eba6a9ff4cbd1f4f2->enter($__internal_632e74bd14a974a47718a7f7dee67bef540a60c38f20e72eba6a9ff4cbd1f4f2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezdate_settings"));

        // line 80
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 81
        if (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "defaultType", array()) == twig_constant("eZ\\Publish\\Core\\FieldType\\Date\\Type::DEFAULT_EMPTY"))) {
            // line 82
            echo "        ";
            $context["defaultValue"] = "Empty";
            // line 83
            echo "    ";
        } else {
            // line 84
            echo "        ";
            $context["defaultValue"] = "Current date";
            // line 85
            echo "    ";
        }
        // line 86
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_632e74bd14a974a47718a7f7dee67bef540a60c38f20e72eba6a9ff4cbd1f4f2->leave($__internal_632e74bd14a974a47718a7f7dee67bef540a60c38f20e72eba6a9ff4cbd1f4f2_prof);

    }

    // line 90
    public function block_eztime_settings($context, array $blocks = array())
    {
        $__internal_038103ad09c35b055f135371113b0cc2120e8d1a2ed78b3ab7cad85bcf7f78e7 = $this->env->getExtension("native_profiler");
        $__internal_038103ad09c35b055f135371113b0cc2120e8d1a2ed78b3ab7cad85bcf7f78e7->enter($__internal_038103ad09c35b055f135371113b0cc2120e8d1a2ed78b3ab7cad85bcf7f78e7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "eztime_settings"));

        // line 91
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 92
        if (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "defaultType", array()) == twig_constant("eZ\\Publish\\Core\\FieldType\\Time\\Type::DEFAULT_EMPTY"))) {
            // line 93
            echo "        ";
            $context["defaultValue"] = "Empty";
            // line 94
            echo "    ";
        } else {
            // line 95
            echo "        ";
            $context["defaultValue"] = "Current time";
            // line 96
            echo "    ";
        }
        // line 97
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    <li class=\"use-seconds\">
        <span>Use seconds:</span>
        ";
        // line 100
        echo (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "useSeconds", array())) ? ("Yes") : ("No"));
        echo "
    </li>
</ul>
";
        
        $__internal_038103ad09c35b055f135371113b0cc2120e8d1a2ed78b3ab7cad85bcf7f78e7->leave($__internal_038103ad09c35b055f135371113b0cc2120e8d1a2ed78b3ab7cad85bcf7f78e7_prof);

    }

    // line 105
    public function block_ezinteger_settings($context, array $blocks = array())
    {
        $__internal_7e13d2b270d93e35c8f7a3ae09de3cbeadf7cd385f68027cbc406fc7e18b9ca3 = $this->env->getExtension("native_profiler");
        $__internal_7e13d2b270d93e35c8f7a3ae09de3cbeadf7cd385f68027cbc406fc7e18b9ca3->enter($__internal_7e13d2b270d93e35c8f7a3ae09de3cbeadf7cd385f68027cbc406fc7e18b9ca3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezinteger_settings"));

        // line 106
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 107
        $context["defaultValue"] = $this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "defaultValue", array()), "value", array());
        // line 108
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    ";
        // line 109
        $context["minValue"] = $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "validatorConfiguration", array()), "IntegerValueValidator", array()), "minIntegerValue", array());
        // line 110
        echo "    ";
        $this->displayBlock("settings_minimumvalue", $context, $blocks);
        echo "
    ";
        // line 111
        $context["maxValue"] = $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "validatorConfiguration", array()), "IntegerValueValidator", array()), "maxIntegerValue", array());
        // line 112
        echo "    ";
        $this->displayBlock("settings_maximumvalue", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_7e13d2b270d93e35c8f7a3ae09de3cbeadf7cd385f68027cbc406fc7e18b9ca3->leave($__internal_7e13d2b270d93e35c8f7a3ae09de3cbeadf7cd385f68027cbc406fc7e18b9ca3_prof);

    }

    // line 116
    public function block_ezfloat_settings($context, array $blocks = array())
    {
        $__internal_80e0a18dc56287d22fe5aa584d89251cbefcf260f69600686eb435b824158026 = $this->env->getExtension("native_profiler");
        $__internal_80e0a18dc56287d22fe5aa584d89251cbefcf260f69600686eb435b824158026->enter($__internal_80e0a18dc56287d22fe5aa584d89251cbefcf260f69600686eb435b824158026_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezfloat_settings"));

        // line 117
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 118
        $context["defaultValue"] = $this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "defaultValue", array()), "value", array());
        // line 119
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    ";
        // line 120
        $context["minValue"] = $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "validatorConfiguration", array()), "FloatValueValidator", array()), "minFloatValue", array());
        // line 121
        echo "    ";
        $this->displayBlock("settings_minimumvalue", $context, $blocks);
        echo "
    ";
        // line 122
        $context["maxValue"] = $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "validatorConfiguration", array()), "FloatValueValidator", array()), "maxFloatValue", array());
        // line 123
        echo "    ";
        $this->displayBlock("settings_maximumvalue", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_80e0a18dc56287d22fe5aa584d89251cbefcf260f69600686eb435b824158026->leave($__internal_80e0a18dc56287d22fe5aa584d89251cbefcf260f69600686eb435b824158026_prof);

    }

    // line 127
    public function block_ezselection_settings($context, array $blocks = array())
    {
        $__internal_7e2de316e35aad30531553216f0aac18ceada676681706fe0ce0cb0ac137c8bd = $this->env->getExtension("native_profiler");
        $__internal_7e2de316e35aad30531553216f0aac18ceada676681706fe0ce0cb0ac137c8bd->enter($__internal_7e2de316e35aad30531553216f0aac18ceada676681706fe0ce0cb0ac137c8bd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezselection_settings"));

        // line 128
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    <li class=\"options\">
        <span>Defined options</span>
        <ul>
        ";
        // line 132
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "options", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["option"]) {
            // line 133
            echo "            <li>";
            echo twig_escape_filter($this->env, $context["option"], "html", null, true);
            echo "</li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['option'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 135
        echo "        </ul>
    </li>
    ";
        // line 137
        $context["isMultiple"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "isMultiple", array());
        // line 138
        echo "    ";
        $this->displayBlock("settings_allowmultiple", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_7e2de316e35aad30531553216f0aac18ceada676681706fe0ce0cb0ac137c8bd->leave($__internal_7e2de316e35aad30531553216f0aac18ceada676681706fe0ce0cb0ac137c8bd_prof);

    }

    // line 143
    public function block_ezbinaryfile_settings($context, array $blocks = array())
    {
        $__internal_6a7edd4e17876d60b2843d4d9872a40b70c1f051f800d6249a715e8602de8be5 = $this->env->getExtension("native_profiler");
        $__internal_6a7edd4e17876d60b2843d4d9872a40b70c1f051f800d6249a715e8602de8be5->enter($__internal_6a7edd4e17876d60b2843d4d9872a40b70c1f051f800d6249a715e8602de8be5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezbinaryfile_settings"));

        // line 144
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 145
        $this->displayBlock("settings_maxfilesize", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_6a7edd4e17876d60b2843d4d9872a40b70c1f051f800d6249a715e8602de8be5->leave($__internal_6a7edd4e17876d60b2843d4d9872a40b70c1f051f800d6249a715e8602de8be5_prof);

    }

    // line 149
    public function block_ezmedia_settings($context, array $blocks = array())
    {
        $__internal_832f51fcad1217137e0f810e6a4cc4124331eab945e535e5953c94b7f51308a0 = $this->env->getExtension("native_profiler");
        $__internal_832f51fcad1217137e0f810e6a4cc4124331eab945e535e5953c94b7f51308a0->enter($__internal_832f51fcad1217137e0f810e6a4cc4124331eab945e535e5953c94b7f51308a0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezmedia_settings"));

        // line 150
        $context["type"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "mediaType", array());
        // line 151
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 152
        $this->displayBlock("settings_maxfilesize", $context, $blocks);
        echo "
    <li class=\"media-player-type\">
        <span>Media player type:</span>
        ";
        // line 155
        if (((isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == "flash")) {
            // line 156
            echo "            Flash
        ";
        } elseif ((        // line 157
(isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == "quick_time")) {
            // line 158
            echo "            Quicktime
        ";
        } elseif ((        // line 159
(isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == "real_player")) {
            // line 160
            echo "            Real Player
        ";
        } elseif ((        // line 161
(isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == "silverlight")) {
            // line 162
            echo "            Silverlight
        ";
        } elseif ((        // line 163
(isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == "windows_media_player")) {
            // line 164
            echo "            Window Media Player
        ";
        } elseif ((        // line 165
(isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == "html5_video")) {
            // line 166
            echo "            HTML5 Video
        ";
        } elseif ((        // line 167
(isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")) == "html5_audio")) {
            // line 168
            echo "            HTML5 Audio
        ";
        } else {
            // line 170
            echo "            <em>No defined value</em>
        ";
        }
        // line 172
        echo "    </li>
</ul>
";
        
        $__internal_832f51fcad1217137e0f810e6a4cc4124331eab945e535e5953c94b7f51308a0->leave($__internal_832f51fcad1217137e0f810e6a4cc4124331eab945e535e5953c94b7f51308a0_prof);

    }

    // line 176
    public function block_ezimage_settings($context, array $blocks = array())
    {
        $__internal_ac977a1807aa0fc9ae88c67dff86771fe006e1ce9d13aa6bf5f646bb90087b84 = $this->env->getExtension("native_profiler");
        $__internal_ac977a1807aa0fc9ae88c67dff86771fe006e1ce9d13aa6bf5f646bb90087b84->enter($__internal_ac977a1807aa0fc9ae88c67dff86771fe006e1ce9d13aa6bf5f646bb90087b84_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezimage_settings"));

        // line 177
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 178
        $this->displayBlock("settings_maxfilesize", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_ac977a1807aa0fc9ae88c67dff86771fe006e1ce9d13aa6bf5f646bb90087b84->leave($__internal_ac977a1807aa0fc9ae88c67dff86771fe006e1ce9d13aa6bf5f646bb90087b84_prof);

    }

    // line 182
    public function block_ezobjectrelation_settings($context, array $blocks = array())
    {
        $__internal_a5c45eabec6533f3fee24772fb444a8fb2e499bfe8024526a51c308bdcc1c388 = $this->env->getExtension("native_profiler");
        $__internal_a5c45eabec6533f3fee24772fb444a8fb2e499bfe8024526a51c308bdcc1c388->enter($__internal_a5c45eabec6533f3fee24772fb444a8fb2e499bfe8024526a51c308bdcc1c388_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezobjectrelation_settings"));

        // line 183
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    <li class=\"selection-method\">
        <span>Selection method:</span>
        ";
        // line 186
        if (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionMethod", array()) == 0)) {
            // line 187
            echo "            Browse
        ";
        } elseif (($this->getAttribute(        // line 188
(isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionMethod", array()) == 1)) {
            // line 189
            echo "            Drop-down list
        ";
        } else {
            // line 191
            echo "            Drop-down tree
        ";
        }
        // line 193
        echo "    </li>
    ";
        // line 194
        $context["rootLocationId"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionRoot", array());
        // line 195
        echo "    ";
        $this->displayBlock("settings_selectionroot", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_a5c45eabec6533f3fee24772fb444a8fb2e499bfe8024526a51c308bdcc1c388->leave($__internal_a5c45eabec6533f3fee24772fb444a8fb2e499bfe8024526a51c308bdcc1c388_prof);

    }

    // line 199
    public function block_ezobjectrelationlist_settings($context, array $blocks = array())
    {
        $__internal_ac10baa9909c5d2aacd4724b7ee9de658a711203de1f7da2b0689c550e629903 = $this->env->getExtension("native_profiler");
        $__internal_ac10baa9909c5d2aacd4724b7ee9de658a711203de1f7da2b0689c550e629903->enter($__internal_ac10baa9909c5d2aacd4724b7ee9de658a711203de1f7da2b0689c550e629903_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezobjectrelationlist_settings"));

        // line 200
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    <li class=\"selection-method\">
        <span>Selection method:</span>
        ";
        // line 203
        if (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionMethod", array()) == 0)) {
            // line 204
            echo "            Browse
        ";
        } elseif (($this->getAttribute(        // line 205
(isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionMethod", array()) == 1)) {
            // line 206
            echo "            Drop-down list
        ";
        } elseif (($this->getAttribute(        // line 207
(isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionMethod", array()) == 2)) {
            // line 208
            echo "            List with radio buttons
        ";
        } elseif (($this->getAttribute(        // line 209
(isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionMethod", array()) == 3)) {
            // line 210
            echo "            List with checkboxes
        ";
        } elseif (($this->getAttribute(        // line 211
(isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionMethod", array()) == 4)) {
            // line 212
            echo "            Multiple selection list
        ";
        } elseif (($this->getAttribute(        // line 213
(isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionMethod", array()) == 5)) {
            // line 214
            echo "            Template based, multi
        ";
        } else {
            // line 216
            echo "            Template based, single
        ";
        }
        // line 218
        echo "    </li>
    <li class=\"allowed-content-types\">
        <span>Allowed content types:</span>
        ";
        // line 221
        if ($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionContentTypes", array())) {
            // line 222
            echo "            ";
            // line 223
            echo "            <ul>
            ";
            // line 224
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionContentTypes", array()));
            foreach ($context['_seq'] as $context["_key"] => $context["typeIdentifier"]) {
                // line 225
                echo "                <li>";
                echo twig_escape_filter($this->env, $context["typeIdentifier"], "html", null, true);
                echo "</li>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['typeIdentifier'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 227
            echo "            </ul>
        ";
        } else {
            // line 229
            echo "            <em>Any</em>
        ";
        }
        // line 231
        echo "    </li>
    ";
        // line 232
        $context["rootLocationId"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "selectionDefaultLocation", array());
        // line 233
        echo "    ";
        $this->displayBlock("settings_selectionroot", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_ac10baa9909c5d2aacd4724b7ee9de658a711203de1f7da2b0689c550e629903->leave($__internal_ac10baa9909c5d2aacd4724b7ee9de658a711203de1f7da2b0689c550e629903_prof);

    }

    // line 237
    public function block_ezpage_settings($context, array $blocks = array())
    {
        $__internal_09508068ce650d23f0dfd1b21d14c21f56f385278a17877a9b4395260907af27 = $this->env->getExtension("native_profiler");
        $__internal_09508068ce650d23f0dfd1b21d14c21f56f385278a17877a9b4395260907af27->enter($__internal_09508068ce650d23f0dfd1b21d14c21f56f385278a17877a9b4395260907af27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezpage_settings"));

        // line 238
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    <li class=\"default-layout\">
        <span>Default layout:</span>
        ";
        // line 241
        echo twig_escape_filter($this->env, (($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "defaultLayout", array())) ? ($this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "defaultLayout", array())) : ("None")), "html", null, true);
        echo "
    </li>
</ul>
";
        
        $__internal_09508068ce650d23f0dfd1b21d14c21f56f385278a17877a9b4395260907af27->leave($__internal_09508068ce650d23f0dfd1b21d14c21f56f385278a17877a9b4395260907af27_prof);

    }

    // line 247
    public function block_ezauthor_settings($context, array $blocks = array())
    {
        $__internal_fea10fbdc3f15ec003e5617cc715b90467b4242cba47d13e4923f2f3c6b9e935 = $this->env->getExtension("native_profiler");
        $__internal_fea10fbdc3f15ec003e5617cc715b90467b4242cba47d13e4923f2f3c6b9e935->enter($__internal_fea10fbdc3f15ec003e5617cc715b90467b4242cba47d13e4923f2f3c6b9e935_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezauthor_settings"));

        
        $__internal_fea10fbdc3f15ec003e5617cc715b90467b4242cba47d13e4923f2f3c6b9e935->leave($__internal_fea10fbdc3f15ec003e5617cc715b90467b4242cba47d13e4923f2f3c6b9e935_prof);

    }

    // line 249
    public function block_ezurl_settings($context, array $blocks = array())
    {
        $__internal_0bfb9a4c3d8bbe9219319404165991c3a3487d0dcf744e64137a0f3008ae2edf = $this->env->getExtension("native_profiler");
        $__internal_0bfb9a4c3d8bbe9219319404165991c3a3487d0dcf744e64137a0f3008ae2edf->enter($__internal_0bfb9a4c3d8bbe9219319404165991c3a3487d0dcf744e64137a0f3008ae2edf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezurl_settings"));

        
        $__internal_0bfb9a4c3d8bbe9219319404165991c3a3487d0dcf744e64137a0f3008ae2edf->leave($__internal_0bfb9a4c3d8bbe9219319404165991c3a3487d0dcf744e64137a0f3008ae2edf_prof);

    }

    // line 251
    public function block_ezisbn_settings($context, array $blocks = array())
    {
        $__internal_c6694a2855875ea442368112b67a8743eabf689056a9e39f9fb4c042befb7906 = $this->env->getExtension("native_profiler");
        $__internal_c6694a2855875ea442368112b67a8743eabf689056a9e39f9fb4c042befb7906->enter($__internal_c6694a2855875ea442368112b67a8743eabf689056a9e39f9fb4c042befb7906_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezisbn_settings"));

        // line 252
        echo "<ul class=\"fielddef-settings ";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "fieldTypeIdentifier", array()), "html", null, true);
        echo "-settings\">
    ";
        // line 253
        $context["defaultValue"] = "";
        // line 254
        echo "    ";
        $this->displayBlock("settings_defaultvalue", $context, $blocks);
        echo "
    ";
        // line 255
        $context["isISBN13"] = $this->getAttribute((isset($context["settings"]) ? $context["settings"] : $this->getContext($context, "settings")), "isISBN13", array());
        // line 256
        echo "    ";
        $this->displayBlock("settings_allowisbn13", $context, $blocks);
        echo "
</ul>
";
        
        $__internal_c6694a2855875ea442368112b67a8743eabf689056a9e39f9fb4c042befb7906->leave($__internal_c6694a2855875ea442368112b67a8743eabf689056a9e39f9fb4c042befb7906_prof);

    }

    // line 260
    public function block_ezkeyword_settings($context, array $blocks = array())
    {
        $__internal_30f663f63a4981bfdab8f75abeb872ededfda54dd4a642fa171ba618d4e519af = $this->env->getExtension("native_profiler");
        $__internal_30f663f63a4981bfdab8f75abeb872ededfda54dd4a642fa171ba618d4e519af->enter($__internal_30f663f63a4981bfdab8f75abeb872ededfda54dd4a642fa171ba618d4e519af_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezkeyword_settings"));

        
        $__internal_30f663f63a4981bfdab8f75abeb872ededfda54dd4a642fa171ba618d4e519af->leave($__internal_30f663f63a4981bfdab8f75abeb872ededfda54dd4a642fa171ba618d4e519af_prof);

    }

    // line 262
    public function block_ezuser_settings($context, array $blocks = array())
    {
        $__internal_8ed46d8bb7afdddc06ef53c42a4b9205a0b0a3df97d663007be45240869410c8 = $this->env->getExtension("native_profiler");
        $__internal_8ed46d8bb7afdddc06ef53c42a4b9205a0b0a3df97d663007be45240869410c8->enter($__internal_8ed46d8bb7afdddc06ef53c42a4b9205a0b0a3df97d663007be45240869410c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezuser_settings"));

        
        $__internal_8ed46d8bb7afdddc06ef53c42a4b9205a0b0a3df97d663007be45240869410c8->leave($__internal_8ed46d8bb7afdddc06ef53c42a4b9205a0b0a3df97d663007be45240869410c8_prof);

    }

    // line 264
    public function block_ezemail_settings($context, array $blocks = array())
    {
        $__internal_8bea3817110462eba7888477ffe4e07904f578dca738a90be7102a1061ed4b4b = $this->env->getExtension("native_profiler");
        $__internal_8bea3817110462eba7888477ffe4e07904f578dca738a90be7102a1061ed4b4b->enter($__internal_8bea3817110462eba7888477ffe4e07904f578dca738a90be7102a1061ed4b4b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezemail_settings"));

        
        $__internal_8bea3817110462eba7888477ffe4e07904f578dca738a90be7102a1061ed4b4b->leave($__internal_8bea3817110462eba7888477ffe4e07904f578dca738a90be7102a1061ed4b4b_prof);

    }

    // line 266
    public function block_ezgmaplocation_settings($context, array $blocks = array())
    {
        $__internal_7c10250ab2bdb6b30c9d81fd9e4a1e0fd8df8881cbca96fe675c14b9e925fadc = $this->env->getExtension("native_profiler");
        $__internal_7c10250ab2bdb6b30c9d81fd9e4a1e0fd8df8881cbca96fe675c14b9e925fadc->enter($__internal_7c10250ab2bdb6b30c9d81fd9e4a1e0fd8df8881cbca96fe675c14b9e925fadc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezgmaplocation_settings"));

        
        $__internal_7c10250ab2bdb6b30c9d81fd9e4a1e0fd8df8881cbca96fe675c14b9e925fadc->leave($__internal_7c10250ab2bdb6b30c9d81fd9e4a1e0fd8df8881cbca96fe675c14b9e925fadc_prof);

    }

    // line 268
    public function block_ezsrrating_settings($context, array $blocks = array())
    {
        $__internal_0990ea3c55e41525e8e6455ebf30425a8ae34fc5f9e4249af81caab129190d91 = $this->env->getExtension("native_profiler");
        $__internal_0990ea3c55e41525e8e6455ebf30425a8ae34fc5f9e4249af81caab129190d91->enter($__internal_0990ea3c55e41525e8e6455ebf30425a8ae34fc5f9e4249af81caab129190d91_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "ezsrrating_settings"));

        
        $__internal_0990ea3c55e41525e8e6455ebf30425a8ae34fc5f9e4249af81caab129190d91->leave($__internal_0990ea3c55e41525e8e6455ebf30425a8ae34fc5f9e4249af81caab129190d91_prof);

    }

    // line 270
    public function block_settings_maxfilesize($context, array $blocks = array())
    {
        $__internal_8b3014f16c504afcca7c9c69ebeae59fadd940fd4ba2a6e22fd06bc4dea8fa94 = $this->env->getExtension("native_profiler");
        $__internal_8b3014f16c504afcca7c9c69ebeae59fadd940fd4ba2a6e22fd06bc4dea8fa94->enter($__internal_8b3014f16c504afcca7c9c69ebeae59fadd940fd4ba2a6e22fd06bc4dea8fa94_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "settings_maxfilesize"));

        // line 271
        echo "    <li class=\"maximum-file-size\">
        <span>Maximum file size:</span>
        ";
        // line 273
        if ($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "validatorConfiguration", array()), "FileSizeValidator", array()), "maxFileSize", array())) {
            // line 274
            echo "            ";
            // line 275
            echo "            ";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["fielddefinition"]) ? $context["fielddefinition"] : $this->getContext($context, "fielddefinition")), "validatorConfiguration", array()), "FileSizeValidator", array()), "maxFileSize", array()), "html", null, true);
            echo " bytes
        ";
        } else {
            // line 277
            echo "            <em>No defined maximum size</em>
        ";
        }
        // line 279
        echo "    </li>
";
        
        $__internal_8b3014f16c504afcca7c9c69ebeae59fadd940fd4ba2a6e22fd06bc4dea8fa94->leave($__internal_8b3014f16c504afcca7c9c69ebeae59fadd940fd4ba2a6e22fd06bc4dea8fa94_prof);

    }

    // line 282
    public function block_settings_preferredrows($context, array $blocks = array())
    {
        $__internal_97491128bcb3997a5be46d67df37c0b6748fda958bd6fdc214474c710601b42f = $this->env->getExtension("native_profiler");
        $__internal_97491128bcb3997a5be46d67df37c0b6748fda958bd6fdc214474c710601b42f->enter($__internal_97491128bcb3997a5be46d67df37c0b6748fda958bd6fdc214474c710601b42f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "settings_preferredrows"));

        // line 283
        echo "    <li class=\"preferred-rows-number\">
        <span>Preferred number of rows:</span>
        ";
        // line 285
        if ((isset($context["rows"]) ? $context["rows"] : $this->getContext($context, "rows"))) {
            // line 286
            echo "            ";
            echo twig_escape_filter($this->env, (isset($context["rows"]) ? $context["rows"] : $this->getContext($context, "rows")), "html", null, true);
            echo " rows
        ";
        } else {
            // line 288
            echo "            <em>No preferred number of rows</em>
        ";
        }
        // line 290
        echo "    </li>
";
        
        $__internal_97491128bcb3997a5be46d67df37c0b6748fda958bd6fdc214474c710601b42f->leave($__internal_97491128bcb3997a5be46d67df37c0b6748fda958bd6fdc214474c710601b42f_prof);

    }

    // line 293
    public function block_settings_selectionroot($context, array $blocks = array())
    {
        $__internal_c5e1866d06ece1d5bd46d8d2941aaff3cf9e5f2e13d9985b226c64c33fc7fa75 = $this->env->getExtension("native_profiler");
        $__internal_c5e1866d06ece1d5bd46d8d2941aaff3cf9e5f2e13d9985b226c64c33fc7fa75->enter($__internal_c5e1866d06ece1d5bd46d8d2941aaff3cf9e5f2e13d9985b226c64c33fc7fa75_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "settings_selectionroot"));

        // line 294
        echo "    <li class=\"selection-root\">
        <span>Selection root:</span>
        ";
        // line 296
        if ((isset($context["rootLocationId"]) ? $context["rootLocationId"] : $this->getContext($context, "rootLocationId"))) {
            // line 297
            echo "            ";
            // line 298
            echo "            ";
            echo $this->env->getExtension('http_kernel')->renderFragment($this->env->getExtension('http_kernel')->controller("ez_content:viewLocation", array("locationId" => (isset($context["rootLocationId"]) ? $context["rootLocationId"] : $this->getContext($context, "rootLocationId")), "viewType" => "line")), array("strategy" => "esi"));
            echo "
        ";
        } else {
            // line 300
            echo "            <em>No defined root</em>
        ";
        }
        // line 302
        echo "    </li>
";
        
        $__internal_c5e1866d06ece1d5bd46d8d2941aaff3cf9e5f2e13d9985b226c64c33fc7fa75->leave($__internal_c5e1866d06ece1d5bd46d8d2941aaff3cf9e5f2e13d9985b226c64c33fc7fa75_prof);

    }

    // line 305
    public function block_settings_defaultvalue($context, array $blocks = array())
    {
        $__internal_a781dee490ef2fc1854ccb3769ed1d33379e76dd6cec2d7ec3bee2f1dd36689d = $this->env->getExtension("native_profiler");
        $__internal_a781dee490ef2fc1854ccb3769ed1d33379e76dd6cec2d7ec3bee2f1dd36689d->enter($__internal_a781dee490ef2fc1854ccb3769ed1d33379e76dd6cec2d7ec3bee2f1dd36689d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "settings_defaultvalue"));

        // line 306
        echo "    <li class=\"default-value\">
        <span>Default value:</span>
        ";
        // line 308
        if ((isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue"))) {
            // line 309
            echo "            ";
            echo twig_escape_filter($this->env, (isset($context["defaultValue"]) ? $context["defaultValue"] : $this->getContext($context, "defaultValue")), "html", null, true);
            echo "
        ";
        } else {
            // line 311
            echo "            <em>No default value</em>
        ";
        }
        // line 313
        echo "    </li>
";
        
        $__internal_a781dee490ef2fc1854ccb3769ed1d33379e76dd6cec2d7ec3bee2f1dd36689d->leave($__internal_a781dee490ef2fc1854ccb3769ed1d33379e76dd6cec2d7ec3bee2f1dd36689d_prof);

    }

    // line 316
    public function block_settings_minimumvalue($context, array $blocks = array())
    {
        $__internal_c10eec2e9f5dbd53e3b085b0134142b063772990af2ebac8063d20f186763a46 = $this->env->getExtension("native_profiler");
        $__internal_c10eec2e9f5dbd53e3b085b0134142b063772990af2ebac8063d20f186763a46->enter($__internal_c10eec2e9f5dbd53e3b085b0134142b063772990af2ebac8063d20f186763a46_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "settings_minimumvalue"));

        // line 317
        echo "    <li class=\"min-value\">
        <span>Minimum value:</span>
        ";
        // line 319
        if ((isset($context["minValue"]) ? $context["minValue"] : $this->getContext($context, "minValue"))) {
            // line 320
            echo "            ";
            echo twig_escape_filter($this->env, (isset($context["minValue"]) ? $context["minValue"] : $this->getContext($context, "minValue")), "html", null, true);
            echo "
        ";
        } else {
            // line 322
            echo "            <em>No defined minimum value</em>
        ";
        }
        // line 324
        echo "    </li>
";
        
        $__internal_c10eec2e9f5dbd53e3b085b0134142b063772990af2ebac8063d20f186763a46->leave($__internal_c10eec2e9f5dbd53e3b085b0134142b063772990af2ebac8063d20f186763a46_prof);

    }

    // line 327
    public function block_settings_maximumvalue($context, array $blocks = array())
    {
        $__internal_83e0bfcaa4eda09a628a3c78a0f1ff3cf5646e2db3529c80d123e2110839cba3 = $this->env->getExtension("native_profiler");
        $__internal_83e0bfcaa4eda09a628a3c78a0f1ff3cf5646e2db3529c80d123e2110839cba3->enter($__internal_83e0bfcaa4eda09a628a3c78a0f1ff3cf5646e2db3529c80d123e2110839cba3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "settings_maximumvalue"));

        // line 328
        echo "    <li class=\"max-value\">
        <span>Maximum value:</span>
        ";
        // line 330
        if ((isset($context["maxValue"]) ? $context["maxValue"] : $this->getContext($context, "maxValue"))) {
            // line 331
            echo "            ";
            echo twig_escape_filter($this->env, (isset($context["maxValue"]) ? $context["maxValue"] : $this->getContext($context, "maxValue")), "html", null, true);
            echo "
        ";
        } else {
            // line 333
            echo "            <em>No defined maximum value</em>
        ";
        }
        // line 335
        echo "    </li>
";
        
        $__internal_83e0bfcaa4eda09a628a3c78a0f1ff3cf5646e2db3529c80d123e2110839cba3->leave($__internal_83e0bfcaa4eda09a628a3c78a0f1ff3cf5646e2db3529c80d123e2110839cba3_prof);

    }

    // line 338
    public function block_settings_allowmultiple($context, array $blocks = array())
    {
        $__internal_567cf6a3b3479727e109537162e1bd06df9c33f9dc31d503fdfaadb59cf11190 = $this->env->getExtension("native_profiler");
        $__internal_567cf6a3b3479727e109537162e1bd06df9c33f9dc31d503fdfaadb59cf11190->enter($__internal_567cf6a3b3479727e109537162e1bd06df9c33f9dc31d503fdfaadb59cf11190_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "settings_allowmultiple"));

        // line 339
        echo "    <li class=\"multiple\">
        <span>Allow multiple choices:</span>
        ";
        // line 341
        echo (((isset($context["isMultiple"]) ? $context["isMultiple"] : $this->getContext($context, "isMultiple"))) ? ("Yes") : ("No"));
        echo "
    </li>
";
        
        $__internal_567cf6a3b3479727e109537162e1bd06df9c33f9dc31d503fdfaadb59cf11190->leave($__internal_567cf6a3b3479727e109537162e1bd06df9c33f9dc31d503fdfaadb59cf11190_prof);

    }

    // line 345
    public function block_settings_allowisbn13($context, array $blocks = array())
    {
        $__internal_b7e5605838590211c129989e812b4f8c087495876682791b2151a5ce7da25de2 = $this->env->getExtension("native_profiler");
        $__internal_b7e5605838590211c129989e812b4f8c087495876682791b2151a5ce7da25de2->enter($__internal_b7e5605838590211c129989e812b4f8c087495876682791b2151a5ce7da25de2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "settings_allowisbn13"));

        // line 346
        echo "    <li class=\"isbn\">
        <span>Selected ISBN format:</span>
        ";
        // line 348
        echo (((isset($context["isISBN13"]) ? $context["isISBN13"] : $this->getContext($context, "isISBN13"))) ? ("ISBN-13") : ("ISBN-10"));
        echo "
    </li>
";
        
        $__internal_b7e5605838590211c129989e812b4f8c087495876682791b2151a5ce7da25de2->leave($__internal_b7e5605838590211c129989e812b4f8c087495876682791b2151a5ce7da25de2_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle::fielddefinition_settings.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  1250 => 348,  1246 => 346,  1240 => 345,  1230 => 341,  1226 => 339,  1220 => 338,  1212 => 335,  1208 => 333,  1202 => 331,  1200 => 330,  1196 => 328,  1190 => 327,  1182 => 324,  1178 => 322,  1172 => 320,  1170 => 319,  1166 => 317,  1160 => 316,  1152 => 313,  1148 => 311,  1142 => 309,  1140 => 308,  1136 => 306,  1130 => 305,  1122 => 302,  1118 => 300,  1112 => 298,  1110 => 297,  1108 => 296,  1104 => 294,  1098 => 293,  1090 => 290,  1086 => 288,  1080 => 286,  1078 => 285,  1074 => 283,  1068 => 282,  1060 => 279,  1056 => 277,  1050 => 275,  1048 => 274,  1046 => 273,  1042 => 271,  1036 => 270,  1025 => 268,  1014 => 266,  1003 => 264,  992 => 262,  981 => 260,  970 => 256,  968 => 255,  963 => 254,  961 => 253,  956 => 252,  950 => 251,  939 => 249,  928 => 247,  917 => 241,  910 => 238,  904 => 237,  893 => 233,  891 => 232,  888 => 231,  884 => 229,  880 => 227,  871 => 225,  867 => 224,  864 => 223,  862 => 222,  860 => 221,  855 => 218,  851 => 216,  847 => 214,  845 => 213,  842 => 212,  840 => 211,  837 => 210,  835 => 209,  832 => 208,  830 => 207,  827 => 206,  825 => 205,  822 => 204,  820 => 203,  813 => 200,  807 => 199,  796 => 195,  794 => 194,  791 => 193,  787 => 191,  783 => 189,  781 => 188,  778 => 187,  776 => 186,  769 => 183,  763 => 182,  753 => 178,  748 => 177,  742 => 176,  733 => 172,  729 => 170,  725 => 168,  723 => 167,  720 => 166,  718 => 165,  715 => 164,  713 => 163,  710 => 162,  708 => 161,  705 => 160,  703 => 159,  700 => 158,  698 => 157,  695 => 156,  693 => 155,  687 => 152,  682 => 151,  680 => 150,  674 => 149,  664 => 145,  659 => 144,  653 => 143,  642 => 138,  640 => 137,  636 => 135,  627 => 133,  623 => 132,  615 => 128,  609 => 127,  598 => 123,  596 => 122,  591 => 121,  589 => 120,  584 => 119,  582 => 118,  577 => 117,  571 => 116,  560 => 112,  558 => 111,  553 => 110,  551 => 109,  546 => 108,  544 => 107,  539 => 106,  533 => 105,  522 => 100,  515 => 97,  512 => 96,  509 => 95,  506 => 94,  503 => 93,  501 => 92,  496 => 91,  490 => 90,  479 => 86,  476 => 85,  473 => 84,  470 => 83,  467 => 82,  465 => 81,  460 => 80,  454 => 79,  443 => 74,  436 => 71,  433 => 70,  430 => 69,  427 => 68,  424 => 67,  421 => 66,  418 => 65,  415 => 64,  412 => 63,  409 => 62,  406 => 61,  403 => 60,  400 => 59,  397 => 58,  395 => 57,  390 => 56,  384 => 55,  375 => 51,  371 => 49,  367 => 47,  365 => 46,  358 => 43,  352 => 42,  341 => 38,  339 => 37,  334 => 36,  320 => 35,  317 => 34,  299 => 33,  297 => 32,  292 => 31,  286 => 30,  275 => 26,  273 => 25,  268 => 24,  262 => 23,  253 => 19,  249 => 17,  243 => 15,  241 => 14,  234 => 11,  232 => 10,  227 => 9,  221 => 8,  214 => 345,  211 => 344,  209 => 338,  206 => 337,  204 => 327,  201 => 326,  199 => 316,  196 => 315,  194 => 305,  191 => 304,  189 => 293,  186 => 292,  184 => 282,  181 => 281,  179 => 270,  176 => 269,  174 => 268,  171 => 267,  169 => 266,  166 => 265,  164 => 264,  161 => 263,  159 => 262,  156 => 261,  154 => 260,  151 => 259,  149 => 251,  146 => 250,  144 => 249,  141 => 248,  139 => 247,  135 => 245,  133 => 237,  130 => 236,  128 => 199,  125 => 198,  123 => 182,  120 => 181,  118 => 176,  115 => 175,  113 => 149,  110 => 148,  108 => 143,  104 => 141,  102 => 127,  99 => 126,  97 => 116,  94 => 115,  92 => 105,  89 => 104,  87 => 90,  84 => 89,  82 => 79,  79 => 78,  77 => 55,  74 => 54,  72 => 42,  69 => 41,  67 => 30,  64 => 29,  62 => 23,  59 => 22,  57 => 8,  54 => 7,);
    }
}
/* {# Template blocks used to render the settings of each field definition #}*/
/* {# Block naming convention is <fieldTypeIdentifier>_settings> #}*/
/* {# The following variables are available in each block:*/
/*  #  - \eZ\Publish\API\Repository\Values\ContentType\FieldDefinition fielddefinition the field definition*/
/*  #  - array settings settings of the field definition*/
/*  #}*/
/* */
/* {% block ezstring_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set defaultValue = fielddefinition.defaultValue.text %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     <li class="max-length">*/
/*         <span>Max string length:</span>*/
/*         {% if fielddefinition.validatorConfiguration.StringLengthValidator.maxStringLength %}*/
/*             {{ fielddefinition.validatorConfiguration.StringLengthValidator.maxStringLength }} characters*/
/*         {% else %}*/
/*             <em>No defined maximum string length</em>*/
/*         {% endif %}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block eztext_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set rows = settings.textRows %}*/
/*     {{ block( 'settings_preferredrows' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezcountry_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set defaultValue = '' %}*/
/*     {% for country in fielddefinition.defaultValue.countries %}*/
/*         {% set defaultValue = defaultValue ~ country.Name ~ ( not loop.last ? ', ' : '' ) %}*/
/*     {% endfor %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     {% set isMultiple = settings.isMultiple %}*/
/*     {{ block( 'settings_allowmultiple' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezboolean_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     <li class="default-value">*/
/*         <span>Default value:</span>*/
/*         {% if fielddefinition.defaultValue.bool %}*/
/*             Checked*/
/*         {% else %}*/
/*             Unchecked*/
/*         {% endif %}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezdatetime_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% if settings.defaultType == constant( 'eZ\\Publish\\Core\\FieldType\\DateAndTime\\Type::DEFAULT_EMPTY' ) %}*/
/*         {% set defaultValue = 'Empty' %}*/
/*     {% elseif settings.defaultType == constant( 'eZ\\Publish\\Core\\FieldType\\DateAndTime\\Type::DEFAULT_CURRENT_DATE' ) %}*/
/*         {% set defaultValue = 'Current datetime' %}*/
/*     {% else %}*/
/*         {% set interval = settings.dateInterval %}*/
/*         {% set defaultValue = 'Current datetime adjusted by ' %}*/
/*         {% set defaultValue = interval.y ? defaultValue ~ interval.y ~ ' year(s)' : defaultValue %}*/
/*         {% set defaultValue = interval.m ? defaultValue ~ interval.m ~ ' month(s)' : defaultValue %}*/
/*         {% set defaultValue = interval.d ? defaultValue ~ interval.d ~ ' day(s)' : defaultValue %}*/
/*         {% set defaultValue = interval.h ? defaultValue ~ interval.h ~ ' hour(s)' : defaultValue %}*/
/*         {% set defaultValue = interval.i ? defaultValue ~ interval.i ~ ' minute(s)' : defaultValue %}*/
/*         {% set defaultValue = interval.s and settings.useSeconds ? defaultValue ~ interval.s ~ ' second(s)' : defaultValue %}*/
/*     {% endif %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     <li class="use-seconds">*/
/*         <span>Use seconds:</span>*/
/*         {{ settings.useSeconds ? 'Yes' : 'No' }}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezdate_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% if settings.defaultType == constant( 'eZ\\Publish\\Core\\FieldType\\Date\\Type::DEFAULT_EMPTY' ) %}*/
/*         {% set defaultValue = 'Empty' %}*/
/*     {% else %}*/
/*         {% set defaultValue = 'Current date' %}*/
/*     {% endif %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block eztime_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% if settings.defaultType == constant( 'eZ\\Publish\\Core\\FieldType\\Time\\Type::DEFAULT_EMPTY' ) %}*/
/*         {% set defaultValue = 'Empty' %}*/
/*     {% else %}*/
/*         {% set defaultValue = 'Current time' %}*/
/*     {% endif %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     <li class="use-seconds">*/
/*         <span>Use seconds:</span>*/
/*         {{ settings.useSeconds ? 'Yes' : 'No' }}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezinteger_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set defaultValue = fielddefinition.defaultValue.value %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     {% set minValue = fielddefinition.validatorConfiguration.IntegerValueValidator.minIntegerValue %}*/
/*     {{ block( 'settings_minimumvalue' ) }}*/
/*     {% set maxValue = fielddefinition.validatorConfiguration.IntegerValueValidator.maxIntegerValue %}*/
/*     {{ block( 'settings_maximumvalue' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezfloat_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set defaultValue = fielddefinition.defaultValue.value %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     {% set minValue = fielddefinition.validatorConfiguration.FloatValueValidator.minFloatValue %}*/
/*     {{ block( 'settings_minimumvalue' ) }}*/
/*     {% set maxValue = fielddefinition.validatorConfiguration.FloatValueValidator.maxFloatValue %}*/
/*     {{ block( 'settings_maximumvalue' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezselection_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     <li class="options">*/
/*         <span>Defined options</span>*/
/*         <ul>*/
/*         {% for option in settings.options %}*/
/*             <li>{{ option }}</li>*/
/*         {% endfor %}*/
/*         </ul>*/
/*     </li>*/
/*     {% set isMultiple = settings.isMultiple %}*/
/*     {{ block( 'settings_allowmultiple' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* */
/* {% block ezbinaryfile_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {{ block( 'settings_maxfilesize' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezmedia_settings %}*/
/* {% set type = settings.mediaType %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {{ block( 'settings_maxfilesize' ) }}*/
/*     <li class="media-player-type">*/
/*         <span>Media player type:</span>*/
/*         {% if type == 'flash' %}*/
/*             Flash*/
/*         {% elseif type == 'quick_time' %}*/
/*             Quicktime*/
/*         {% elseif type == 'real_player' %}*/
/*             Real Player*/
/*         {% elseif type == 'silverlight' %}*/
/*             Silverlight*/
/*         {% elseif type == 'windows_media_player' %}*/
/*             Window Media Player*/
/*         {% elseif type == 'html5_video' %}*/
/*             HTML5 Video*/
/*         {% elseif type == 'html5_audio' %}*/
/*             HTML5 Audio*/
/*         {% else %}*/
/*             <em>No defined value</em>*/
/*         {% endif %}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezimage_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {{ block( 'settings_maxfilesize' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezobjectrelation_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     <li class="selection-method">*/
/*         <span>Selection method:</span>*/
/*         {% if settings.selectionMethod == 0 %}*/
/*             Browse*/
/*         {% elseif settings.selectionMethod == 1 %}*/
/*             Drop-down list*/
/*         {% else %}*/
/*             Drop-down tree*/
/*         {% endif %}*/
/*     </li>*/
/*     {% set rootLocationId = settings.selectionRoot %}*/
/*     {{ block( 'settings_selectionroot' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezobjectrelationlist_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     <li class="selection-method">*/
/*         <span>Selection method:</span>*/
/*         {% if settings.selectionMethod == 0 %}*/
/*             Browse*/
/*         {% elseif settings.selectionMethod == 1 %}*/
/*             Drop-down list*/
/*         {% elseif settings.selectionMethod == 2 %}*/
/*             List with radio buttons*/
/*         {% elseif settings.selectionMethod == 3 %}*/
/*             List with checkboxes*/
/*         {% elseif settings.selectionMethod == 4 %}*/
/*             Multiple selection list*/
/*         {% elseif settings.selectionMethod == 5 %}*/
/*             Template based, multi*/
/*         {% else %}*/
/*             Template based, single*/
/*         {% endif %}*/
/*     </li>*/
/*     <li class="allowed-content-types">*/
/*         <span>Allowed content types:</span>*/
/*         {% if settings.selectionContentTypes %}*/
/*             {# TODO display content type name #}*/
/*             <ul>*/
/*             {% for typeIdentifier in settings.selectionContentTypes %}*/
/*                 <li>{{ typeIdentifier }}</li>*/
/*             {% endfor %}*/
/*             </ul>*/
/*         {% else %}*/
/*             <em>Any</em>*/
/*         {% endif %}*/
/*     </li>*/
/*     {% set rootLocationId = settings.selectionDefaultLocation %}*/
/*     {{ block( 'settings_selectionroot' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezpage_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     <li class="default-layout">*/
/*         <span>Default layout:</span>*/
/*         {{ settings.defaultLayout ? settings.defaultLayout : "None" }}*/
/*     </li>*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* */
/* {% block ezauthor_settings %}{% endblock %}*/
/* */
/* {% block ezurl_settings %}{% endblock %}*/
/* */
/* {% block ezisbn_settings %}*/
/* <ul class="fielddef-settings {{ fielddefinition.fieldTypeIdentifier }}-settings">*/
/*     {% set defaultValue = '' %}*/
/*     {{ block( 'settings_defaultvalue' ) }}*/
/*     {% set isISBN13 = settings.isISBN13 %}*/
/*     {{ block( 'settings_allowisbn13' ) }}*/
/* </ul>*/
/* {% endblock %}*/
/* */
/* {% block ezkeyword_settings %}{% endblock %}*/
/* */
/* {% block ezuser_settings %}{% endblock %}*/
/* */
/* {% block ezemail_settings %}{% endblock %}*/
/* */
/* {% block ezgmaplocation_settings %}{% endblock %}*/
/* */
/* {% block ezsrrating_settings %}{% endblock %}*/
/* */
/* {% block settings_maxfilesize %}*/
/*     <li class="maximum-file-size">*/
/*         <span>Maximum file size:</span>*/
/*         {% if fielddefinition.validatorConfiguration.FileSizeValidator.maxFileSize %}*/
/*             {# TODO l10n / unit #}*/
/*             {{ fielddefinition.validatorConfiguration.FileSizeValidator.maxFileSize }} bytes*/
/*         {% else %}*/
/*             <em>No defined maximum size</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_preferredrows %}*/
/*     <li class="preferred-rows-number">*/
/*         <span>Preferred number of rows:</span>*/
/*         {% if rows %}*/
/*             {{ rows }} rows*/
/*         {% else %}*/
/*             <em>No preferred number of rows</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_selectionroot %}*/
/*     <li class="selection-root">*/
/*         <span>Selection root:</span>*/
/*         {% if rootLocationId %}*/
/*             {# TODO: use a dedicated viewType #}*/
/*             {{ render( controller( "ez_content:viewLocation", {'locationId': rootLocationId, 'viewType': 'line'} ), {'strategy': 'esi'} ) }}*/
/*         {% else %}*/
/*             <em>No defined root</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_defaultvalue %}*/
/*     <li class="default-value">*/
/*         <span>Default value:</span>*/
/*         {% if defaultValue %}*/
/*             {{ defaultValue }}*/
/*         {% else %}*/
/*             <em>No default value</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_minimumvalue %}*/
/*     <li class="min-value">*/
/*         <span>Minimum value:</span>*/
/*         {% if minValue %}*/
/*             {{ minValue }}*/
/*         {% else %}*/
/*             <em>No defined minimum value</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_maximumvalue %}*/
/*     <li class="max-value">*/
/*         <span>Maximum value:</span>*/
/*         {% if maxValue %}*/
/*             {{ maxValue }}*/
/*         {% else %}*/
/*             <em>No defined maximum value</em>*/
/*         {% endif %}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_allowmultiple %}*/
/*     <li class="multiple">*/
/*         <span>Allow multiple choices:</span>*/
/*         {{ isMultiple ? 'Yes' : 'No' }}*/
/*     </li>*/
/* {% endblock %}*/
/* */
/* {% block settings_allowisbn13 %}*/
/*     <li class="isbn">*/
/*         <span>Selected ISBN format:</span>*/
/*         {{ isISBN13 ? 'ISBN-13' : 'ISBN-10' }}*/
/*     </li>*/
/* {% endblock %}*/
/* */
