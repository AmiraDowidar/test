<?php

/* @Framework/Form/number_widget.html.php */
class __TwigTemplate_4e7d986a477076b77bca15793ec873781a0318f61ef6edced8728bf202a72934 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_887eef64fb415e5025dfea1f85a2a75f4fa9451763426a227f2e5f006d9834ca = $this->env->getExtension("native_profiler");
        $__internal_887eef64fb415e5025dfea1f85a2a75f4fa9451763426a227f2e5f006d9834ca->enter($__internal_887eef64fb415e5025dfea1f85a2a75f4fa9451763426a227f2e5f006d9834ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/number_widget.html.php"));

        // line 1
        echo "<?php echo \$view['form']->block(\$form, 'form_widget_simple',  array('type' => isset(\$type) ? \$type : 'text')) ?>
";
        
        $__internal_887eef64fb415e5025dfea1f85a2a75f4fa9451763426a227f2e5f006d9834ca->leave($__internal_887eef64fb415e5025dfea1f85a2a75f4fa9451763426a227f2e5f006d9834ca_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/number_widget.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <?php echo $view['form']->block($form, 'form_widget_simple',  array('type' => isset($type) ? $type : 'text')) ?>*/
/* */
