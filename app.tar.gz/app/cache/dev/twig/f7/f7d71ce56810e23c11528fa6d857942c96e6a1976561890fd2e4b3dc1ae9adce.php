<?php

/* EzPublishCoreBundle:default/content:full.html.twig */
class __TwigTemplate_3fb150c6ecaa23f003124c79a79a979201132fa3dfa9a3f2c9ae2f4fa648ce11 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return $this->loadTemplate(((((isset($context["noLayout"]) ? $context["noLayout"] : $this->getContext($context, "noLayout")) == true)) ? ((isset($context["viewbaseLayout"]) ? $context["viewbaseLayout"] : $this->getContext($context, "viewbaseLayout"))) : ((isset($context["pagelayout"]) ? $context["pagelayout"] : $this->getContext($context, "pagelayout")))), "EzPublishCoreBundle:default/content:full.html.twig", 1);
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6fbf23aca7b6d7d6cb7edb4c6ba62d106ad9450255897c28f83c00da7ef4e3dd = $this->env->getExtension("native_profiler");
        $__internal_6fbf23aca7b6d7d6cb7edb4c6ba62d106ad9450255897c28f83c00da7ef4e3dd->enter($__internal_6fbf23aca7b6d7d6cb7edb4c6ba62d106ad9450255897c28f83c00da7ef4e3dd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "EzPublishCoreBundle:default/content:full.html.twig"));

        $this->getParent($context)->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6fbf23aca7b6d7d6cb7edb4c6ba62d106ad9450255897c28f83c00da7ef4e3dd->leave($__internal_6fbf23aca7b6d7d6cb7edb4c6ba62d106ad9450255897c28f83c00da7ef4e3dd_prof);

    }

    // line 2
    public function block_content($context, array $blocks = array())
    {
        $__internal_d026129d5aee1ca26ba1c92b12cae166d6c5d89beaf8bfb5d89201271694130d = $this->env->getExtension("native_profiler");
        $__internal_d026129d5aee1ca26ba1c92b12cae166d6c5d89beaf8bfb5d89201271694130d->enter($__internal_d026129d5aee1ca26ba1c92b12cae166d6c5d89beaf8bfb5d89201271694130d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 3
        echo "    <h2>";
        echo twig_escape_filter($this->env, $this->env->getExtension('ezpublish.content')->getTranslatedContentName((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content"))), "html", null, true);
        echo "</h2>
    ";
        // line 4
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute((isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")), "fieldsByLanguage", array()));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            // line 5
            echo "        <h3>";
            echo twig_escape_filter($this->env, $this->getAttribute($context["field"], "fieldDefIdentifier", array()), "html", null, true);
            echo "</h3>
        ";
            // line 6
            echo call_user_func_array($this->env->getFunction('ez_render_field')->getCallable(), array($this->env, (isset($context["content"]) ? $context["content"] : $this->getContext($context, "content")), $this->getAttribute($context["field"], "fieldDefIdentifier", array())));
            echo "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        
        $__internal_d026129d5aee1ca26ba1c92b12cae166d6c5d89beaf8bfb5d89201271694130d->leave($__internal_d026129d5aee1ca26ba1c92b12cae166d6c5d89beaf8bfb5d89201271694130d_prof);

    }

    public function getTemplateName()
    {
        return "EzPublishCoreBundle:default/content:full.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  53 => 6,  48 => 5,  44 => 4,  39 => 3,  33 => 2,  18 => 1,);
    }
}
/* {% extends noLayout == true ? viewbaseLayout : pagelayout %}*/
/* {% block content %}*/
/*     <h2>{{ ez_content_name(content) }}</h2>*/
/*     {% for field in content.fieldsByLanguage %}*/
/*         <h3>{{ field.fieldDefIdentifier }}</h3>*/
/*         {{ ez_render_field(content, field.fieldDefIdentifier) }}*/
/*     {% endfor %}*/
/* {% endblock %}*/
/* */
