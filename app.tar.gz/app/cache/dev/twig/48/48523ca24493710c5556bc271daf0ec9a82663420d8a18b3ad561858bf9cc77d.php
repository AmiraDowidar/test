<?php

/* eZPlatformUIBundle:Role:list_roles.html.twig */
class __TwigTemplate_6cda46b2a9826680372e54a0a7e2d60da0dce3256107c16aa1228bde6665d15c extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 2
        $this->parent = $this->loadTemplate("eZPlatformUIBundle::pjax_admin.html.twig", "eZPlatformUIBundle:Role:list_roles.html.twig", 2);
        $this->blocks = array(
            'header_breadcrumbs' => array($this, 'block_header_breadcrumbs'),
            'header_title' => array($this, 'block_header_title'),
            'content' => array($this, 'block_content'),
            'title' => array($this, 'block_title'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "eZPlatformUIBundle::pjax_admin.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bc44533441805e025a00bf5495e1942244e79b953603f717b5c14eb0d3019954 = $this->env->getExtension("native_profiler");
        $__internal_bc44533441805e025a00bf5495e1942244e79b953603f717b5c14eb0d3019954->enter($__internal_bc44533441805e025a00bf5495e1942244e79b953603f717b5c14eb0d3019954_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "eZPlatformUIBundle:Role:list_roles.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bc44533441805e025a00bf5495e1942244e79b953603f717b5c14eb0d3019954->leave($__internal_bc44533441805e025a00bf5495e1942244e79b953603f717b5c14eb0d3019954_prof);

    }

    // line 6
    public function block_header_breadcrumbs($context, array $blocks = array())
    {
        $__internal_6d80da6e3fda7f710439e538deb8d9ef949727630f9670bdca72e833e0750f3b = $this->env->getExtension("native_profiler");
        $__internal_6d80da6e3fda7f710439e538deb8d9ef949727630f9670bdca72e833e0750f3b->enter($__internal_6d80da6e3fda7f710439e538deb8d9ef949727630f9670bdca72e833e0750f3b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_breadcrumbs"));

        // line 7
        echo "    ";
        $context["breadcrumb_items"] = array(0 => array("link" => $this->env->getExtension('routing')->getPath("admin_dashboard"), "label" => $this->env->getExtension('translator')->trans("dashboard.title", array(), "dashboard")), 1 => array("link" => null, "label" => $this->env->getExtension('translator')->trans("role.list", array(), "role")));
        // line 11
        echo "    ";
        $this->displayParentBlock("header_breadcrumbs", $context, $blocks);
        echo "
";
        
        $__internal_6d80da6e3fda7f710439e538deb8d9ef949727630f9670bdca72e833e0750f3b->leave($__internal_6d80da6e3fda7f710439e538deb8d9ef949727630f9670bdca72e833e0750f3b_prof);

    }

    // line 14
    public function block_header_title($context, array $blocks = array())
    {
        $__internal_b0eaff98564d3a5811da741463ba4ad47b3244d31940802c78468d65c086b8e3 = $this->env->getExtension("native_profiler");
        $__internal_b0eaff98564d3a5811da741463ba4ad47b3244d31940802c78468d65c086b8e3->enter($__internal_b0eaff98564d3a5811da741463ba4ad47b3244d31940802c78468d65c086b8e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header_title"));

        // line 15
        echo "    <h1 class=\"ez-page-header-name\" data-icon=\"&#xe62d;\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.list", array(), "role"), "html", null, true);
        echo "</h1>
";
        
        $__internal_b0eaff98564d3a5811da741463ba4ad47b3244d31940802c78468d65c086b8e3->leave($__internal_b0eaff98564d3a5811da741463ba4ad47b3244d31940802c78468d65c086b8e3_prof);

    }

    // line 18
    public function block_content($context, array $blocks = array())
    {
        $__internal_14a29ac2b115529f695028af131a7c173214423daf6df757d1329fb4b34d58d3 = $this->env->getExtension("native_profiler");
        $__internal_14a29ac2b115529f695028af131a7c173214423daf6df757d1329fb4b34d58d3->enter($__internal_14a29ac2b115529f695028af131a7c173214423daf6df757d1329fb4b34d58d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "content"));

        // line 19
        echo "    <section class=\"ez-serverside-content\">
        <div class=\"ez-table-data is-flexible\">
            <div class=\"ez-table-data-container\">
                <table class=\"pure-table pure-table-striped ez-selection-table\">
                    <thead>
                    <tr class=\"ez-selection-table-row\">
                        <th>";
        // line 25
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.name", array(), "role"), "html", null, true);
        echo "</th>
                        <th>";
        // line 26
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.id", array(), "role"), "html", null, true);
        echo "</th>
                        <th colspan=\"2\"></th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["roles"]) ? $context["roles"] : $this->getContext($context, "roles")));
        foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
            // line 32
            echo "                        ";
            // line 33
            echo "                        <tr class=\"ez-role\">
                            <td class=\"ez-role-name\"><a href=\"";
            // line 34
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_roleView", array("roleId" => $this->getAttribute($context["role"], "id", array()))), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["role"], "identifier", array()), "html", null, true);
            echo "</a></td>
                            <td class=\"ez-role-id\">";
            // line 35
            echo twig_escape_filter($this->env, $this->getAttribute($context["role"], "id", array()), "html", null, true);
            echo "</td>
                            <td class=\"ez-role-edit\">
                                <button
                                    data-universaldiscovery-title=\"";
            // line 38
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign.universaldiscovery.title", array("%roleIdentifier%" => $this->getAttribute($context["role"], "identifier", array())), "role"), "html_attr");
            echo "\"
                                    data-role-rest-id=\"";
            // line 39
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("ezpublish_rest_loadRole", array("roleId" => $this->getAttribute($context["role"], "id", array()))), "html", null, true);
            echo "\"
                                    data-role-name=\"";
            // line 40
            echo twig_escape_filter($this->env, $this->getAttribute($context["role"], "identifier", array()), "html", null, true);
            echo "\"
                                    class=\"ez-role-assign-button ez-button-tree pure-button ez-font-icon ez-button\"
                                    ";
            // line 42
            if ( !(isset($context["can_assign"]) ? $context["can_assign"] : $this->getContext($context, "can_assign"))) {
                echo "disabled=\"disabled\"";
            }
            echo ">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.assign.user_or_group", array(), "role"), "html", null, true);
            echo "</button>
                            </td>
                            <td>
                                <a href=\"";
            // line 45
            echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("admin_roleUpdate", array("roleId" => $this->getAttribute($context["role"], "id", array()))), "html", null, true);
            echo "\" class=\"pure-button ez-button";
            if ( !(isset($context["can_edit"]) ? $context["can_edit"] : $this->getContext($context, "can_edit"))) {
                echo " pure-button-disabled";
            }
            echo "\" data-icon=\"&#xe606;\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.edit", array(), "role"), "html", null, true);
            echo "</a>
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['role'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 49
        echo "                    </tbody>
                </table>
                ";
        // line 51
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), 'form_start', array("action" => $this->env->getExtension('routing')->getPath("admin_roleCreate")));
        echo "
                <p class=\"ez-table-data-buttons\">
                    <button type=\"submit\" class=\"pure-button ez-button\" data-icon=\"&#xe616;\"";
        // line 53
        if ( !(isset($context["can_create"]) ? $context["can_create"] : $this->getContext($context, "can_create"))) {
            echo " disabled=\"disabled\"";
        }
        // line 54
        echo "                            name=\"";
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), "create", array()), "vars", array()), "full_name", array(), "array"), "html", null, true);
        echo "\"
                            id=\"";
        // line 55
        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), "create", array()), "vars", array()), "id", array(), "array"), "html", null, true);
        echo "\">";
        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), "create", array()), "vars", array()), "label", array(), "array"), array(), "ezrepoforms_role"), "html", null, true);
        echo "</button>
                    ";
        // line 56
        $this->getAttribute($this->getAttribute((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), "create", array()), "setRendered", array(), "method");
        // line 57
        echo "                </p>
                ";
        // line 58
        echo         $this->env->getExtension('form')->renderer->renderBlock((isset($context["create_form"]) ? $context["create_form"] : $this->getContext($context, "create_form")), 'form_end');
        echo "
            </div>
        </div>
    </section>
";
        
        $__internal_14a29ac2b115529f695028af131a7c173214423daf6df757d1329fb4b34d58d3->leave($__internal_14a29ac2b115529f695028af131a7c173214423daf6df757d1329fb4b34d58d3_prof);

    }

    // line 64
    public function block_title($context, array $blocks = array())
    {
        $__internal_887a518cb54c3ef30280656f236f2621b632decc66957aebb36ba9729bad0096 = $this->env->getExtension("native_profiler");
        $__internal_887a518cb54c3ef30280656f236f2621b632decc66957aebb36ba9729bad0096->enter($__internal_887a518cb54c3ef30280656f236f2621b632decc66957aebb36ba9729bad0096_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("role.list", array(), "role"), "html", null, true);
        
        $__internal_887a518cb54c3ef30280656f236f2621b632decc66957aebb36ba9729bad0096->leave($__internal_887a518cb54c3ef30280656f236f2621b632decc66957aebb36ba9729bad0096_prof);

    }

    public function getTemplateName()
    {
        return "eZPlatformUIBundle:Role:list_roles.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  199 => 64,  187 => 58,  184 => 57,  182 => 56,  176 => 55,  171 => 54,  167 => 53,  162 => 51,  158 => 49,  142 => 45,  132 => 42,  127 => 40,  123 => 39,  119 => 38,  113 => 35,  107 => 34,  104 => 33,  102 => 32,  98 => 31,  90 => 26,  86 => 25,  78 => 19,  72 => 18,  62 => 15,  56 => 14,  46 => 11,  43 => 7,  37 => 6,  11 => 2,);
    }
}
/* {# @var roles \eZ\Publish\API\Repository\Values\User\Role[] #}*/
/* {% extends "eZPlatformUIBundle::pjax_admin.html.twig" %}*/
/* */
/* {% trans_default_domain "role" %}*/
/* */
/* {% block header_breadcrumbs %}*/
/*     {% set breadcrumb_items = [*/
/*         {link: path('admin_dashboard'), label: 'dashboard.title'|trans({}, 'dashboard')},*/
/*         {link: null, label: 'role.list'|trans}*/
/*     ] %}*/
/*     {{ parent() }}*/
/* {% endblock %}*/
/* */
/* {% block header_title %}*/
/*     <h1 class="ez-page-header-name" data-icon="&#xe62d;">{{ 'role.list'|trans }}</h1>*/
/* {% endblock %}*/
/* */
/* {% block content %}*/
/*     <section class="ez-serverside-content">*/
/*         <div class="ez-table-data is-flexible">*/
/*             <div class="ez-table-data-container">*/
/*                 <table class="pure-table pure-table-striped ez-selection-table">*/
/*                     <thead>*/
/*                     <tr class="ez-selection-table-row">*/
/*                         <th>{{ 'role.name'|trans }}</th>*/
/*                         <th>{{ 'role.id'|trans }}</th>*/
/*                         <th colspan="2"></th>*/
/*                     </tr>*/
/*                     </thead>*/
/*                     <tbody>*/
/*                     {% for role in roles %}*/
/*                         {# @var role \eZ\Publish\API\Repository\Values\User\Role #}*/
/*                         <tr class="ez-role">*/
/*                             <td class="ez-role-name"><a href="{{ path("admin_roleView", {"roleId": role.id}) }}">{{ role.identifier }}</a></td>*/
/*                             <td class="ez-role-id">{{ role.id }}</td>*/
/*                             <td class="ez-role-edit">*/
/*                                 <button*/
/*                                     data-universaldiscovery-title="{{ 'role.assign.universaldiscovery.title'|trans({'%roleIdentifier%': role.identifier })|e('html_attr') }}"*/
/*                                     data-role-rest-id="{{ path( 'ezpublish_rest_loadRole', {'roleId': role.id}) }}"*/
/*                                     data-role-name="{{ role.identifier }}"*/
/*                                     class="ez-role-assign-button ez-button-tree pure-button ez-font-icon ez-button"*/
/*                                     {% if not can_assign %}disabled="disabled"{% endif %}>{{ 'role.assign.user_or_group'|trans }}</button>*/
/*                             </td>*/
/*                             <td>*/
/*                                 <a href="{{ path('admin_roleUpdate', {'roleId': role.id}) }}" class="pure-button ez-button{% if not can_edit %} pure-button-disabled{% endif %}" data-icon="&#xe606;">{{ 'role.edit'|trans }}</a>*/
/*                             </td>*/
/*                         </tr>*/
/*                     {% endfor %}*/
/*                     </tbody>*/
/*                 </table>*/
/*                 {{ form_start(create_form, {"action": path("admin_roleCreate")}) }}*/
/*                 <p class="ez-table-data-buttons">*/
/*                     <button type="submit" class="pure-button ez-button" data-icon="&#xe616;"{% if not can_create %} disabled="disabled"{% endif %}*/
/*                             name="{{ create_form.create.vars['full_name'] }}"*/
/*                             id="{{ create_form.create.vars['id'] }}">{{ create_form.create.vars['label']|trans(domain="ezrepoforms_role") }}</button>*/
/*                     {% do create_form.create.setRendered() %}*/
/*                 </p>*/
/*                 {{ form_end(create_form) }}*/
/*             </div>*/
/*         </div>*/
/*     </section>*/
/* {% endblock %}*/
/* */
/* {% block title %}{{ 'role.list'|trans }}{% endblock %}*/
/* */
