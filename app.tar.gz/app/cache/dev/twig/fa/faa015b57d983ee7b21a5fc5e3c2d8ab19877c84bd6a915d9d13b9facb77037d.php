<?php

/* @Framework/Form/choice_widget_expanded.html.php */
class __TwigTemplate_bf2027a4c48243c05c382c37113a4d6a90df2da0813dc95969ae156050950dc5 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_8da650d18995ed58c42f20b7a63b0a139d9e45229b2dfacc03049e1a05ba4084 = $this->env->getExtension("native_profiler");
        $__internal_8da650d18995ed58c42f20b7a63b0a139d9e45229b2dfacc03049e1a05ba4084->enter($__internal_8da650d18995ed58c42f20b7a63b0a139d9e45229b2dfacc03049e1a05ba4084_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/choice_widget_expanded.html.php"));

        // line 1
        echo "<div <?php echo \$view['form']->block(\$form, 'widget_container_attributes') ?>>
<?php foreach (\$form as \$child): ?>
    <?php echo \$view['form']->widget(\$child) ?>
    <?php echo \$view['form']->label(\$child, null, array('translation_domain' => \$choice_translation_domain)) ?>
<?php endforeach ?>
</div>
";
        
        $__internal_8da650d18995ed58c42f20b7a63b0a139d9e45229b2dfacc03049e1a05ba4084->leave($__internal_8da650d18995ed58c42f20b7a63b0a139d9e45229b2dfacc03049e1a05ba4084_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/choice_widget_expanded.html.php";
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* <div <?php echo $view['form']->block($form, 'widget_container_attributes') ?>>*/
/* <?php foreach ($form as $child): ?>*/
/*     <?php echo $view['form']->widget($child) ?>*/
/*     <?php echo $view['form']->label($child, null, array('translation_domain' => $choice_translation_domain)) ?>*/
/* <?php endforeach ?>*/
/* </div>*/
/* */
