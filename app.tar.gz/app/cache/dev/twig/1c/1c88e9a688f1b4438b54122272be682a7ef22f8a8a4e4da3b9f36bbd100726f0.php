<?php

/* TwigBundle:Exception:exception.atom.twig */
class __TwigTemplate_8b298701175ba50a6a0fc1a8a867f96651c95b1bfba0ca3ee03cc06147339363 extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_d5dea43b7d0d2c72198b3f8410bbfa7ec365185757e0acbdec924c4c80d9251b = $this->env->getExtension("native_profiler");
        $__internal_d5dea43b7d0d2c72198b3f8410bbfa7ec365185757e0acbdec924c4c80d9251b->enter($__internal_d5dea43b7d0d2c72198b3f8410bbfa7ec365185757e0acbdec924c4c80d9251b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "TwigBundle:Exception:exception.atom.twig"));

        // line 1
        $this->loadTemplate("@Twig/Exception/exception.xml.twig", "TwigBundle:Exception:exception.atom.twig", 1)->display(array_merge($context, array("exception" => (isset($context["exception"]) ? $context["exception"] : $this->getContext($context, "exception")))));
        
        $__internal_d5dea43b7d0d2c72198b3f8410bbfa7ec365185757e0acbdec924c4c80d9251b->leave($__internal_d5dea43b7d0d2c72198b3f8410bbfa7ec365185757e0acbdec924c4c80d9251b_prof);

    }

    public function getTemplateName()
    {
        return "TwigBundle:Exception:exception.atom.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  22 => 1,);
    }
}
/* {% include '@Twig/Exception/exception.xml.twig' with { 'exception': exception } %}*/
/* */
