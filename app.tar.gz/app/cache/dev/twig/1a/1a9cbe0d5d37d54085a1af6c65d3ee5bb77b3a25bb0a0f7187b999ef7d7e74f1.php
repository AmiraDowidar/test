<?php

/* @Framework/Form/button_label.html.php */
class __TwigTemplate_17eaa7a359b442d9291f5aef622a87122eeb479a0b32ee5c107f8e19d3d9715a extends eZ\Bundle\EzPublishDebugBundle\Twig\DebugTemplate
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fa335f2ddfec85815e94afd8e52fa2922ad661219e8b8c4729fb8066dbc87dcc = $this->env->getExtension("native_profiler");
        $__internal_fa335f2ddfec85815e94afd8e52fa2922ad661219e8b8c4729fb8066dbc87dcc->enter($__internal_fa335f2ddfec85815e94afd8e52fa2922ad661219e8b8c4729fb8066dbc87dcc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Framework/Form/button_label.html.php"));

        
        $__internal_fa335f2ddfec85815e94afd8e52fa2922ad661219e8b8c4729fb8066dbc87dcc->leave($__internal_fa335f2ddfec85815e94afd8e52fa2922ad661219e8b8c4729fb8066dbc87dcc_prof);

    }

    public function getTemplateName()
    {
        return "@Framework/Form/button_label.html.php";
    }

    public function getDebugInfo()
    {
        return array ();
    }
}
